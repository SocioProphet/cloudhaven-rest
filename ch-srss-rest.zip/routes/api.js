import mongoose from 'mongoose';
import passport from 'passport';
import config from '../config/database';
import passportObj from '../config/passport'
import express from 'express';
import jwt from 'jsonwebtoken';
import User from "../models/user";
import { HomePage } from './pages/home.js'
import { CPTCodesPage } from './pages/cptcodes.js'
import { ICD10CodesPage } from './pages/icd10codes.js'
import { OSCSetupPage } from './pages/oscsetup.js'
import { PatientEditPage } from './pages/patientedit.js'
import { PatientsPage } from './pages/patients.js'
import { PatientSelectPage } from './pages/patientselect.js';
import { PatientSearch } from './actions/patientsearch.js';
import { ProcedureSearch } from './actions/proceduresearch.js';
import { CaseOptions } from './actions/caseoptions.js';
import { CreatePatientCase } from './actions/createpatientcase.js';
import { UpdatePatientCase } from './actions/updatepatientcase.js';
import { Alerts } from './actions/alerts.js';
import { CasePayerInfo } from './actions/casepayerinfo.js';
import { PatientAcceptance } from './actions/patientacceptance.js';
import { ConfirmBooking } from './actions/confirmbooking.js';
import { PatientCaseList } from './actions/patientcaselist.js';
import { Pipeline } from './actions/pipeline.js';
import { CalendarScheduling } from './actions/calendarscheduling.js';
import { ScheduleCase } from './actions/schedulecase.js';
import { UserInfo } from './actions/userinfo.js'
import { Reports } from './actions/reports.js'
//import { BillPatient } from './actions/billpatient'
import { BillPayer } from './actions/billpayer'
import { ReceivePayment } from './actions/receivepayment'
import { SurgeryCompleted } from './actions/surgerycompleted'
import { UpdateState } from './actions/updatestate'
import { PayablesMgt } from './actions/payablesmgt'
import { GetCaseState } from './actions/getcasestate'
import { ParticipationResponse } from './actions/participationresponse'
import { DoDailyJob } from './actions/dodailyjob'
import { PHIImageHandler } from './actions/phiimagehandler'
import { AddDevice } from './actions/adddevice'
//import { PayerXContactMgr } from './actions/payercontact'
import { VendorContactMgr } from './actions/vendorcontact'
import { PayerProcedure } from './actions/payerprocedure'
import { PatientCaseEdit } from './actions/patientcaseedit'
import { OSCEdit } from './actions/oscsetup'
import { VendorPayables } from './actions/vendorpayables'
import { ClearingHouse } from './actions/clearinghouse'
import { ChangePassword } from './actions/chgpwd'
import { VendorFees } from './actions/vendorfees'
import { GetPatientRecord } from './actions/patientrecord'
import { OutstandingPreops } from './actions/outstandingpreops'
import cityStateLookup from '../services/citystatelookup'
import NotificationService from '../services/notificationservice'
import { AuditLogReview } from './actions/auditlogreview'
import { EventLogReview } from './actions/eventlogreview'
import { PatientStatement } from './actions/patientstatement'
import { UpdatePayerNotes } from './actions/updatepayernotes'




import { UserController, CPTCodeController, ICD10CodeController, 
  ProcedureTypeController, ProcedureController, VendorController, 
  PayerController, PatientCaseController, NotificationTypeController,
  /*WorkflowStateController, CaseWorkflowAssignmentController, */PatientController } from './controllers';


export default function() {
  passportObj(passport);
  const router = express.Router();

  router.get('/citystatelookup/:zip', (req, res) => {
    cityStateLookup(req.params.zip)
    .then(cityStateObj=>{
      res.json(cityStateObj);
    })
   });
  router.post('/emailtest', (req, res) => {
    NotificationService.sendEmail( req.body.testEmail, 'Email Test', 'This is a test email from SRSS.', process.env.EMAIL_USER )
    .then(ok =>{
      res.json({succeeded:ok});
    })
  });
  
    router.post('/signup', (req, res) => {
      if (!req.body.email || !req.body.password) {
        res.json({success: false, msg: 'Please supply both email and password.'});
      } else {
        var newUser = new User({
          email: req.body.email,
          password: req.body.password,
          language: req.body.language,
          roles: []
        });
        // save the user
        newUser.save(function(err) {
          if (err) {
            if (err.name == 'ValidationError') {
              res.json({success:false, errMsg: err.message})
            } else if (err.name == 'MongoError' && err.code == 11000) {
              res.json({success: false, msg: `User with email ${req.body.email} already exists.`});
            } else {
              res.json({success:false, errMsg: err.message})
            }
          }
          res.json({success: true, msg: 'Successful created new user.'});
        });
      }
    });
  
    router.post('/login', (req, res) => {
      User.findOne({email: req.body.email}, {OSC:1, email:1, password:1, name:1, roles:1, vendor:1})
      .then(user => {
        if (!user) {
          res.status(401).send({success: false, msg: 'Authentication failed. User not found.'});
        } else {
          // check if password matches
          user.comparePassword(req.body.password, function (err, isMatch) {
            if (isMatch && !err) {
              // if user is found and password is right create a token
              var token = jwt.sign(user.toJSON(), config.secret,  {expiresIn: '24h'} );
              // return the information including token as JSON
              res.json({success: true, token: 'JWT ' + token, user:user});
            } else {
              res.status(401).send({success: false, msg: 'Authentication failed. Wrong password.'});
            }
          });
        }
      })
      .catch(err=>{
        res.status(401).send({success: false, msg: `Authentication failed. Error: ${err}.`});
      })
    });
  
    router.use( '/users', new UserController().route());
    router.use( '/cptcodes', new CPTCodeController().route());
    router.use( '/icd10codes', new ICD10CodeController().route());
    router.use( '/proceduretypes', new ProcedureTypeController().route());
    router.use( '/procedures', new ProcedureController().route());
    router.use( '/vendors', new VendorController().route());
    router.use( '/payers', new PayerController().route());
    router.use( '/patients', new PatientController().route());
    router.use( '/patientcases', new PatientCaseController().route());
    router.use( '/notificationtypes', new NotificationTypeController().route());
//    router.use( '/caseworkflowassignments', new CaseWorkflowAssignmentController().route());
    router.use( '/patients', new PatientController().route());
    router.use( '/patientsearch', new PatientSearch().route());
    router.use( '/caseoptions', new CaseOptions().route());
    router.use( '/proceduresearch', new ProcedureSearch().route());
    router.use( '/createpatientcase', new CreatePatientCase().route());
    router.use( '/updatepatientcase', new UpdatePatientCase().route());
    router.use( '/alerts', new Alerts().route());
    router.use( '/casepayerinfo', new CasePayerInfo().route());
    router.use( '/patientacceptance', new PatientAcceptance().route());
    router.use( '/confirmbooking', new ConfirmBooking().route());
//    router.use( '/billpatient', new BillPatient().route());
    router.use( '/billpayer', new BillPayer().route());
    router.use( '/receivepayment', new ReceivePayment().route());
    router.use( '/surgerycompleted', new SurgeryCompleted().route());    
    router.use( '/payables', new PayablesMgt().route());
  
    router.use( '/patientcaselist', new PatientCaseList().route());
    router.use( '/pipeline', new Pipeline().route());
    router.use( '/calendarscheduling', new CalendarScheduling().route());
    router.use( '/schedulecase', new ScheduleCase().route());
    router.use( '/updatestate', new UpdateState().route());
    router.use( '/getcasestate', new GetCaseState().route());
    router.use( '/auditlog', new AuditLogReview().route());
    router.use( '/eventlog', new EventLogReview().route());

    router.use( '/userinfo', new UserInfo().route());
    router.use( '/reports', new Reports().route());
    router.use( '/participationresponse', new ParticipationResponse().route());
    router.use( '/dodailyjob', new DoDailyJob().route());
    router.use( '/phiimage', new PHIImageHandler().route());
    router.use( '/adddevice', new AddDevice().route());
//    router.use( '/payercontact', new PayerXContactMgr().route());
    router.use( '/vendorcontact', new VendorContactMgr().route());
    router.use( '/payerprocedure', new PayerProcedure().route());
    router.use( '/patientcaseedit', new PatientCaseEdit().route());
    router.use( '/oscsetup', new OSCEdit().route());
    router.use( '/vendorpayables', new VendorPayables().route());
    router.use( '/clearinghouse', new ClearingHouse().route());
    router.use( '/chgpwd', new ChangePassword().route());
    router.use( '/vendorfees', new VendorFees().route());
    router.use( '/patientrecord', new GetPatientRecord().route());
    router.use( '/outstandingpreops', new OutstandingPreops().route());
    router.use( '/patientstatement', new PatientStatement().route());
    router.use( '/payernotes', new UpdatePayerNotes().route());
    router.use( '/apppages/home', new HomePage().route());
    router.use( '/apppages/cptcodes', new CPTCodesPage().route());
    router.use( '/apppages/icd10codes', new ICD10CodesPage().route());
    router.use( '/apppages/oscsetup', new OSCSetupPage().route());
    router.use( '/apppages/patientedit', new PatientEditPage().route());    
    router.use( '/apppages/patients', new PatientsPage().route());    
    router.use( '/apppages/patientselect', new PatientSelectPage().route());    
    return router;
  }
