
const dataModel = {
  patientStatementDlg: false,
  statementNote: '',
  updateStatementSentDate: true,
  patientId:'',
  valid:false,
  headers: [
    { text: 'Actions', value: 'name', sortable: false, align:'center', width:"200px" },
    { text: 'Last Name', align: 'left', sortable: true, value: 'lastName' },
    { text: 'First Name', align: 'left', sortable: true, value: 'firstName' },
    { text: 'Phone', align:'left', sortable:true, value: 'contactInfo.phone' },
    { text: 'Email', align:'left', sortable:true, value: 'contactInfo.email' },
    { text: 'SSN', align:'left', sortable:true, value: 'ssn' }
  ],
  patients: []
};
const uiMethods = {
  initialize: {
    body: `
    debugger;
    this._userSearch( this._route.params.appParams, function(users) {
      var userIds = users.map(u=>u._id);
      debugger;
      this._appPost( 'patientsearch', {searchCriteria:{userIds:userIds}}, function(patients){
        debugger;
        this.patients = patients;
      })
    }); `
  },
  closePatientStatementDlg: {
    args: ["event"],
    body: `
    if (event.keyCode != 27) return;
    this.patientStatementDlg = false;
    `
  },
  listCases: {
    args: ["item"],
    body: `
//    this.routerParams.patientId = item._id.toString();
//    this.routerParams.patientName = item.name;
    this._gotoAppPage( 'caseselect', {patientId: item._id.toString(), patientName: item.name } );
    `
  },
  newCase: {
    args: ["item"],
    body: `
    //this.routerParams.patientId = item._id.toString();
    this._gotoAppPage( 'patientcase', {patientId: item._id.toString(), mode:'create'} );
    `
  },
  printPatientStatement: {
    args: ["patientId"],
    body: `
    //this.$store.commit('SET_RESULTNOTIFICATION', '');
    this.patientId = patientId;
    this.updateStatementSentDate = true;
    this.patientStatementDlg=true;
    `
  },
  editPatient: {
    args: ["patientId"],
    body: `
//    this.routerParams.patientId = patientId;
    this._gotoAppPage( 'patientedit', {patientId: patientId } )
    `
  },
  printStatement: {
    body: `
//        this.$store.commit('SET_ERRMSG', '');
    this._appPost('patientstatement', 
      {patientId: this.patientId, statementNote:this.statementNote, updateStatementSentDate:this.updateStatementSentDate}, function(response) {
      const file = new Blob( [response.data], {type: 'application/pdf'});
      const fileURL = URL.createObjectURL(file);
      var win = window.open(fileURL, 'Cost Estimate', "height=960,width=840,toolbar=no,menubar=no,scrollbars=yes,location=no,status=no");
      try {
        win.focus();
      } catch(e){
        console.log(e);
      }
    })`
  }
};
const computed = {
};

const uiConfig = {
  requiredUserData: [],
  dataModel:dataModel,
  uiMethods: uiMethods,
  computed:computed,
  uiSchema: {
    component: "div", contents: [
      {component: "toolbar", props:{flat:true, color:"white"}, contents:[
        {component: "toolbarTitle", contents:"Patient Selector"}
      ]},
      {
        component: "dataTable", props:{headers:"this.headers", items:"this.patients", "hide-default-footer":true, "disable-pagination":true},
          class:"elevation-1", scopedSlots: {
            item: {
              component: "tr", on:{click:{eventModifier: "stop", method: "newCase", scopedProp:"item"}}, contents: [
                {component:"td", attrs:{class:"d-flex justify-space-around align-center px-3 mx-0", width:"200px"}, contents:[
                  {component: "button", props:{icon:true}, class:"ml-4", contents:[
                    {component:"icon", props:{medium:true}, on:{click:{eventModifier:"stop", method:"listCases", scopedProp:"item"}},
                      contents:"mdi-view-list"}
                  ]},
                  {component: "button", props:{icon:true}, class:"ml-4", contents:[
                    {component:"icon", props:{medium:true}, on:{click:{eventModifier:"stop", method:"newCase", scopedProp:"item"}},
                      contents:"mdi-file-plus"}
                  ]},
                  {component: "button", props:{icon:true}, class:"ml-4", contents:[
                    {component:"icon", props:{medium:true}, on:{click:{eventModifier:"stop", method:"printPatientStatement", scopedProp:"item.id"}},
                      contents:"mdi-printer"}
                  ]},
                  {component: "button", props:{icon:true}, class:"ml-4", contents:[
                    {component:"icon", props:{medium:true}, on:{click:{eventModifier:"stop", method:"editPatient", scopedProp:"item.id"}},
                      contents:"mdi-account-edit"}
                  ]}
                ]},
                {component:"template", template:"<td>{{ _scopedProps.item.lastName }}</td>"},
                {component:"template", template:"<td>{{ _scopedProps.item.firstName }}</td>"},
                {component:"template", template:"<td>{{ _scopedProps.item.contactInfo.phone | formattedPhone }}</td>"},
                {component:"template", template:"<td>{{ _scopedProps.item.contactInfo.email }} </td>"},
                {component:"template", template:"<td>{{ _scopedProps.item.ssn | formattedSSN }} </td>"},
              ]
            }
          }
      },
      {
        component:"dialog", vmodel:"patientStatementDlg", props:{"max-width":"500px"}, on:{keydown:{eventModifier:"prevent", method:"closePatientStatementDlg"}}, contents:[
          {component:"card", contents:[
            {component: "cardTitle", template:'<span class="text-h5">Patient Statement</span>'},
            {component: "cardBody", contents:[
              {component:"form", vmodel:"valid", contents:[
                {component:"textarea", vmodel:"statementNode", props:{label:"Statement Note", rows:6}},
                {component:"checkbox", vmodel:"updateStatementSentDate", props:{label:"Update Date Statement Last Sent"}}
              ]}
            ]},
            {component:"cardActions", contents:[
              { component: "button", props:{elevation:"2", color:"blue darken-1", text:true}, on: {click:"closePatientStatementDlg"}, contents:"Cancel" },
              { component: "spacer"},
              { component: "button", props:{elevation:"2", color:"blue darken-1", text:true}, on: {click:"printStatement"},
                contents:[{component:"icon", props:{left:true, dark:true}, contents:"mdi-printer"}, 
                          {component:'span', contents:"Print"}
              ] },
            ]}
          ]}
        ]
      }
    ]
  }
};

import BaseAction from '../actions/baseaction'
import Roles from '../../models/workflowroles'
export class PatientSelectPage extends BaseAction{
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.Scheduler];
  }
  
  route() {

    this.router.get("/", (req, res) => {
      res.json(uiConfig)
    });

    return this.router;
  }
}
