import fieldMap from './misc/userfields.js'

const dataModel = {
  patientStatementDlg: false,
  statementNote: '',
  updateStatementSentDate: true,
  patientId:'',
  valid:false,
  headers: [
    { text: 'Actions', value: 'name', sortable: false, align:'center', width:"200px" },
    { text: 'Last Name', align: 'left', sortable: true, value: 'lastName' },
    { text: 'First Name', align: 'left', sortable: true, value: 'firstName' },
    { text: 'Phone', align:'left', sortable:true, value: 'contactInfo.phone' },
    { text: 'Email', align:'left', sortable:true, value: 'contactInfo.email' },
    { text: 'SSN', align:'left', sortable:true, value: 'ssn' }
  ],
  patients: []
};
const filters = {
  formattedPhone: {
    args: ["value"],
    body: `
    if (!value) return '';
    var rawPhone = value.replace(/[( )-.]/g, '');
    if (rawPhone.length==10) {
      return '('+rawPhone.substring(0,3)+') '+rawPhone.substring(3,6)+'-'+rawPhone.substring(6);
    } else if (rawPhone.length==7) {
      return rawPhone.substring(0,3)+'-'+rawPhone.substring(3);
    } else {
      return rawPhone;
    }`
  },
  formattedSSN: {
    args: ["value"],
    body: `
    if (!value) return '';
    if (value.length!=9) return value;
    return value.substring(0,3)+'-'+value.substring(3,5)+'-'+value.substring(5);
    `
  }
}
const uiMethods = {
  mounted: {
    body: `
    this._userSearch( this._appParams.searchCriteria, function(users) {
      var userIds = users.map(u=>u._id);
      this._appPost( 'patientsearch', {searchCriteria:{userIds:userIds}}, function(patients){
        this.patients = patients;
        var fieldMap = this.fieldMap();
        this._getUserDataForList (userIds, this.patients, 'cloudHavenUserId', fieldMap, () => {
          this.patients.forEach(p=>(p.jDateOfBirth=this.moment(p.dateOfBirth).toDate()));
          this.loading = false;  
        });
      })
    }); `
  },
  fieldMap: {
    body: 'return '+JSON.stringify(fieldMap)+';'
  },
  closePatientStatementDlg: {
    args: ["event"],
    body: `
    if (event.keyCode != 27) return;
    this.patientStatementDlg = false;
    `
  },
  listCases: {
    args: ["item"],
    body: `
//    this.routerParams.patientId = item._id.toString();
//    this.routerParams.patientName = item.name;
    this._gotoAppPage( 'caseselect', {patientId: item._id, patientName: item.name } );
    `
  },
  newCase: {
    args: ["item"],
    body: `
    //this.routerParams.patientId = item._id.toString();
    this._gotoAppPage( 'patientcase', {patientId: item._id, mode:'create'} );
    `
  },
  printPatientStatement: {
    args: ["patientId"],
    body: `
    //this.$store.commit('SET_RESULTNOTIFICATION', '');
    this.patientId = patientId;
    this.updateStatementSentDate = true;
    this.patientStatementDlg=true;
    `
  },
  editPatient: {
    args: ["patientId"],
    body: `
//    this.routerParams.patientId = patientId;
    this._gotoAppPage( 'patientedit', {patientId: patientId } )
    `
  },
  printStatement: {
    body: `
//        this.$store.commit('SET_ERRMSG', '');
    this._appPost('patientstatement', 
      {patientId: this.patientId, statementNote:this.statementNote, updateStatementSentDate:this.updateStatementSentDate}, function(response) {
      const file = new Blob( [response.data], {type: 'application/pdf'});
      const fileURL = URL.createObjectURL(file);
      var win = window.open(fileURL, 'Cost Estimate', "height=960,width=840,toolbar=no,menubar=no,scrollbars=yes,location=no,status=no");
      try {
        win.focus();
      } catch(e){
        console.log(e);
      }
    })`
  }
};
const computed = {
};

const uiConfig = {
  requiredUserData: [],
  dataModel:dataModel,
  uiMethods: uiMethods,
  computed:computed,
  filters: filters,
  uiSchema: {
    component: "div", contents: [
      {component: "toolbar", props:{flat:true, color:"white"}, contents:[
        {component: "toolbarTitle", contents:"Patient Selector"}
      ]},
      {
        component: "dataTable", props:{":headers":"headers", ":items":"patients", "hide-default-footer":true, "disable-pagination":true},
          class:"elevation-1", scopedSlots: {
            item: {component: "tr", on:{"click.stop":"alert('row event'); newCase(item)"}, contents:[
              {component:"td", attrs:{class:"d-flex justify-space-around align-center px-3 mx-0", width:"200px"}, contents:[
                {component:"tooltip", props:{right:true}, class:"d-flex", scopedSlots:{
                  activator: {component: "button", props:{icon:true}, class:"ml-4",  ":attrs":"attrs", 
                  on:"on", contents:[
                    {component:"icon", props:{medium:true}, on:{"click.stop":"listCases(item)"},
                      contents:"mdi-view-list"}
                  ]}
                }, template:"<span>Show all cases</span>"},
                {component:"tooltip", props:{right:true}, class:"d-flex", scopedSlots:{
                  activator: {component: "button", props:{icon:true},  ":attrs":"attrs", 
                  on:"on", contents:[
                    {component:"icon", props:{medium:true}, on:{"click.stop":"newCase(item)"},
                      contents:"mdi-file-plus"}
                  ]}
                }, template:"<span>Create case</span>"},
                {component:"tooltip", props:{right:true}, class:"d-flex", scopedSlots:{
                  activator: {component: "button", props:{icon:true},  ":attrs":"attrs", 
                  on:"on", contents:[
                    {component:"icon", props:{medium:true}, on:{"click.stop":"printPatientStatement(item.id)"},
                      contents:"mdi-printer"}
                  ]}
                }, template:"<span>Patient Statement</span>"},
                {component:"tooltip", props:{right:true}, class:"d-flex", scopedSlots:{
                  activator: {component: "button", props:{icon:true},  ":attrs":"attrs", 
                  on:"on", contents:[
                    {component:"icon", props:{medium:true}, on:{"click.stop":"editPatient(item.id)"},
                      contents:"mdi-account-edit"}
                  ]}
                }, template:"<span>Edit patient</span>"}
              ]},
              {component:"template", template:"<td>{{ item.lastName }}</td>"},
              {component:"template", template:"<td>{{ item.firstName }}</td>"},
              {component:"template", template:"<td>{{ item.contactInfo.phone | formattedPhone }}</td>"},
              {component:"template", template:"<td>{{ item.contactInfo.email }} </td>"},
              {component:"template", template:"<td>{{ item.ssn | formattedSSN }} </td>"},
            ]
          }
        }
      },
      {
        component:"dialog", vmodel:"patientStatementDlg", props:{"max-width":"500px"}, on:{"keydown.prevent":"closePatientStatementDlg"}, contents:[
          {component:"card", contents:[
            {component: "cardTitle", template:'<span class="text-h5">Patient Statement</span>'},
            {component: "cardText", contents:[
              {component:"form", vmodel:"valid", contents:[
                {component:"textarea", vmodel:"statementNote", props:{label:"Statement Note", rows:6}},
                {component:"checkbox", vmodel:"updateStatementSentDate", props:{label:"Update Date Statement Last Sent"}}
              ]}
            ]},
            {component:"cardActions", contents:[
              { component: "button", props:{elevation:"2", color:"blue darken-1", text:true}, on: {click:"closePatientStatementDlg"}, contents:"Cancel" },
              { component: "spacer"},
              { component: "button", props:{elevation:"2", color:"blue darken-1", text:true}, on: {click:"printStatement"},
                contents:[{component:"icon", props:{left:true, dark:true}, contents:"mdi-printer"}, 
                          {component:'span', contents:"Print"}
              ] },
            ]}
          ]}
        ]
      }
    ]
  }
};

import BaseAction from '../actions/baseaction'
import Roles from '../../models/workflowroles'
export class PatientSelectPage extends BaseAction{
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.Scheduler];
  }
  
  route() {

    this.router.get("/", (req, res) => {
      res.json(uiConfig)
    });

    return this.router;
  }
}
