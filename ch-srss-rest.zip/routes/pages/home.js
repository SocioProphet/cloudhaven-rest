



const dataModel = {
  showLeftSidebar: true,
  pwdDialog: false,
  pwdValid: true,
  chgPwdObj: {},
  confPwdErrMsg:'',
  reportId:'',
  setup: {},
  caseId: '',
  caseIdErrMsg: '',
  panels: [0, 1, 2],
  reportOptions: [
    {value:'agedAR', text:'Payer Aged A/R'},
    {value:'patientAgedAR', text:'Patient Aged A/R'},
    {value:'avgRevPerMonth', text:'Average Revenue'},
    {value:'overPayments', text:'Overpayments'},
    {value:'receivedPayments', text:'Received Payments'},
    {value:'tentativeCases', text:'Tentative Cases'},
    {value:'totalCasesMTD', text:'Total Cases MTD'},
    {value:'totalCasesYTD', text:'Total Cases YTD'},
    {value:'vendorAPDaysOverdue', text:'Vendor A/P Days Overdue'},
    {value:'vendorMonthlyDigest', text:'Vendor Monthly Digest'}
  ],
  lateReceivablesPanelOpen: true,
  patientSearchCriteria: '',
  patientSearchSubmitted: false,
  patientSearchValid: true,
  sDateOfBirth: '',
  rules:{
      required: value => !!value || 'Required.',
    nonEmpty: value => !!value || 'Enter at least one character.',
  }
};
const uiMethods = {
  initialize: {
    args:[],
    body: `
    this._appGet('formData', function(data) {
      this.getUserData();
    })`
  },
  required: {
    args: ["v"],
    body: `
    return !!v || "Required."
    `
  },
  leftSideBarVisibility: {
    body: `return this.showLeftSidebar?'block':'none';`
  }
};

const uiConfig = {
  requiredUserData: [],
  dataModel:dataModel,
  uiMethods: uiMethods,
  appFrame: {
    name: 'Surgical Recovery Suites',
    appBarStyle: {background: 'linear-gradient(rgb(40, 54, 102) 0%, rgb(37, 114, 210) 100%)'},
    appBarTextClass: "yellow--text text--accent-2",
    nameTextClass: "white--text",
    menuItems: [
      { page: 'apppages/procedures', title: 'Procedures'},
      { page: 'apppages/vendors', title: 'Vendors' },
      { page: 'apppages/payers', title: 'Payers' },
      { page: 'apppages/oscsetup', title: 'OSC Setup' },
      { page: 'apppages/users', title: 'Users' },
      { page: 'apppages/notificationTypes', title: 'Notification Types'},
      { page: 'apppages/procedureTypes', title: 'Procedure Types'},
      { page: 'apppages/cptcodes', title: 'CPT Codes'},
      { page: 'apppages/icd10Codes', title: 'ICD10 Codes'},
      { page: 'apppages/alerts', title: 'Case Alerts'},
      { page: 'apppages/auditLog', title: 'Audit Log'},
      { page: 'apppages/eventLog', title: 'Event Log'},
    ]
  },
  uiSchema: {
    component: 'container',
    props: {fluid:true},
    contents: [
      {
        component: 'dialog',
        vmodel: "pwdDialog",
        style: "background-color:white;",
        props: {"max-width":"500px"},
        on: {keydown:{args:["event"], body:`if (event.keyCode==27) { this.pwdDialog=false; event.preventDefault(); }`}},
        defaultSlot: {
          component: "card",
          contents:[
            {
              component: "cardTitle",
              template: '<span class="text-h5">Change Password</span>'
            },
            {
              component: "cardBody",
              defaultSlot: {
                component: "form",
                props: {ref:"pwdChgForm", "lazy-validation": true},
                vmodel: "pwdValid",
                contents: [
                  {
                    component: "textField",
                    props: {type:"password", label:"New Password", required:true },
                    attrs: {rules:["required"]},
                    vmodel: "chgPwdObj.newPassword"
                  },
                  {
                    component: "textField",
                    props: {type:"password", label:"Confirm Password", required:true },
                    attrs: {rules:["required"], "error-messages":"confPwdErrMsg"},
                    vmodel: "chgPwdObj.newPassword2"
                  },
                ]
              }
            },
            {
              component: "cardActions",
              defaultSlot: [
                {
                  component: "button",
                  props: {elevation:"2", color:"blue darken-1", text:true},
                  on: {click:{body:"pwdDialog = false"}},
                  defaultSlot: {
                    component: "icon",
                    contents: "mdi-cancel"
                  },
                  contents: "Cancel"
                },
                { component: "spacer"},
                {
                  component: "button",
                  props: {elevation:"2", color:"blue darken-1", text:true},
                  nativeOn: "savePwdChange",
                  defaultSlot: {
                    component: "icon",
                    props: {left:true, dark: true},
                    contents: "mdi-content-save"
                  },
                  contents: "Save"
                }
              ]
            }
          ]

        }
      },
      {
        component: "row", props: {wrap:true},
        defaultSlot: [
          {
            component: "col",
            props: {cols:"12", sm:"12", md:"3", lg:"3", xl:"2"},
            class: "pr-0",
            attrs: {style:"leftSideBarVisibility"},
            defaultSlot: {
              component: "row",
              class: "flex-column justify-start align-start",
              defaultSlot: {
                component: "col",
                defaultSlot: {
                  component: "card",
                  defaultSlot: {
                    component: "form"
                  }
                }

              }
            }
          }
        ]
      }

    ]
  }
};

import BaseAction from '../actions/baseaction'
import Roles from '../../models/workflowroles'
export class HomePage extends BaseAction{
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.Scheduler];
  }
  
  route() {

    this.router.get("/", (req, res) => {
      res.json(uiConfig)
    });

    return this.router;
  }
}


    /*this.router.get("/formSubmitted", (req, res) => {
      res.json(uiConfig2)
    });
    this.router.get("/formData", (req, res) => {
      res.json([
        {firstName:'Bob', lastName: 'Smith', address: '1234 Bob Street, Bob City, CA 99999'},
        {firstName:'Dave', lastName: 'Anderson', address: '9999 Dave Street, Some City, CA 99999'},
        {firstName:'Xaviar', lastName: 'Gomez', address: '7777 Xav Street, Gomez City, CA 99999'}
      ]);
    });

    this.router.post("/submitform", (req, res) => {
      console.log('Form data:\n'+JSON.stringify(req.body));
      res.json({success:true, newPage:'formSubmitted'})
    });*/

