import pipelineUIConfig from './components/pipeline.js'


const dataModel = {
  showLeftSidebar: true,
  pwdDialog: false,
  pwdValid: true,
  chgPwdObj: {},
  confPwdErrMsg:'',
  reportId:'',
  setup: {},
  caseId: '',
  caseIdErrMsg: '',
  panels: [0, 1, 2],
  reportOptions: [
    {value:'agedAR', text:'Payer Aged A/R'},
    {value:'patientAgedAR', text:'Patient Aged A/R'},
    {value:'avgRevPerMonth', text:'Average Revenue'},
    {value:'overPayments', text:'Overpayments'},
    {value:'receivedPayments', text:'Received Payments'},
    {value:'tentativeCases', text:'Tentative Cases'},
    {value:'totalCasesMTD', text:'Total Cases MTD'},
    {value:'totalCasesYTD', text:'Total Cases YTD'},
    {value:'vendorAPDaysOverdue', text:'Vendor A/P Days Overdue'},
    {value:'vendorMonthlyDigest', text:'Vendor Monthly Digest'}
  ],
  lateReceivablesPanelOpen: true,
  patientSearchCriteria: '',
  patientSearchSubmitted: false,
  patientSearchValid: true,
  sDateOfBirth: ''
};
const uiMethods = {
  initialize: {
    args:[],
    body: `
    this.routerParams.caseId = '';
    this.caseFilter = '';
    this.updateUserInfo();
    this._appGet('oscsetup', function(data) {
      this.setup = data;
    });`
  },
  required: {
    args: ["v"],
    body: `
    return !!v || "Required."
    `
  },
  hideLeftSidebar: {
    body: `this.showLeftSidebar=false; `
  },
  displayLeftSidebar: {
    body: `this.showLeftSidebar=true; `
  },
  nonEmptyRule: {
    args: ["value"],
    body: `return !!value || 'Enter at least one character.';`
  },
  dateOfBirthRule: {
    args: ["v"],
    body: `
    return this.setup.patientSearchDateOfBirthRequired?this.required(v):null;
    `
  },
  caseSearch: {
    args: ["event"],
    body: `
    if (event && event.keyCode != 13) return;
    this._appGet('patientcaseedit/lookup/'+this.caseId, function(response) {
      if (response.patientCaseId) {
        this.caseIdErrMsg = '';
        this.routerParams.patientCaseId = response.patientCaseId;
        this._gotoRoute( {name: 'patientCase', params:{patientCaseId:response.patientCaseId}} );
      } else {
        this.caseIdErrMsg = 'Not found';
      }
    });`
  },
  updateUserInfo: {
    body: `
    this._appGet('userinfo', function(response) {
      this.$store.commit('SET_USERINFO', response);
    });`
  },
  gotoReport: {
    body: `this._gotoRoute({name:this.reportId});`
  },
  patientSearch: {
    args: ["event"],
    body: `
    if (event && event.keyCode != 13) return;
    if (this.$refs.patientSearchForm.validate()) {
      this.$store.commit('SET_PATIENTSEARCHCRITERIA', {phrase:this.patientSearchCriteria, dateOfBirth:this.$digitsToDate(this.sDateOfBirth)});
      this._gotoRoute( { name: 'patientSelect'} );
    }`
  },
  listPatients: {
    body: `this._gotoRoute( { name: 'patients'} );`
  },
  listCases: {
    body: `
    this.routerParams.patientId = '';
    this.routerParams.patientName = '';
    this._gotoRoute( { name: 'caseSelect' });
    `
  },
  gotoCase: {
    args: ["id"],
    body: `
    this.routerParams.patientCaseId = id;
    this._gotoRoute( {name: 'patientCase', params:{patientCaseId:id}} );
    `
  },
  gotoEventCalendar: {
    body: `this._gotoRoute({name:'schedulingCalendar', params:{}});`
  }
};
const computed = {
  showSidebarButtonVisibility: {
    body: `
    debugger;
    return {display:this.showLeftSidebar?'none':'block'};
    var x = '';
    `
  },
  rightPaneCols: {
    body: `return this.showLeftSidebar?9:12;`
  },
  leftSidebarStyle: {
    body: `return {display:this.showLeftSidebar?'block':'none'};`
  },
  routerParams: {
    body: `return this.$store.state.routerParams;`
  },
  allowedReportOptions: {
    body: `
    var optionsMap = Object.keys(this.reportsByRole).reduce((mp,role)=>{
      var rm = this.user.rolesMap;
      console.log(JSON.stringify(rm));
      if (this.user.rolesMap[role]) {
        var reports = this.reportsByRole[role];
        if (reports) {
          reports.forEach(r=>{
            mp[r.value] = r;
          });
        }
      }
      return mp;
    },{});
    return this.reportsByRole['BMCSYSADMIN'].reduce((ar,report)=>{
      if (optionsMap[report.value]) {
        ar.push(report);
      }
      return ar;
    },[]);`
  },
}
const components = {pipeline:pipelineUIConfig};
const uiConfig = {
  components: components,
  requiredUserData: [],
  dataModel:dataModel,
  uiMethods: uiMethods,
  computed: computed,
  appFrame: {
    name: 'Surgical Recovery Suites',
    appBarStyle: {background: 'linear-gradient(rgb(40, 54, 102) 0%, rgb(37, 114, 210) 100%)'},
    appBarTextClass: "yellow--text text--accent-2",
    nameTextClass: "white--text",
    menuItems: [
      { page: 'apppages/procedures', title: 'Procedures'},
      { page: 'apppages/vendors', title: 'Vendors' },
      { page: 'apppages/payers', title: 'Payers' },
      { page: 'apppages/oscsetup', title: 'OSC Setup' },
      { page: 'apppages/users', title: 'Users' },
      { page: 'apppages/notificationTypes', title: 'Notification Types'},
      { page: 'apppages/procedureTypes', title: 'Procedure Types'},
      { page: 'apppages/cptcodes', title: 'CPT Codes'},
      { page: 'apppages/icd10Codes', title: 'ICD10 Codes'},
      { page: 'apppages/alerts', title: 'Case Alerts'},
      { page: 'apppages/auditLog', title: 'Audit Log'},
      { page: 'apppages/eventLog', title: 'Event Log'},
    ]
  },
  uiSchema: {
    component: 'container',
    props: {fluid:true},
    contents: [
      {
        component: "row", props: {wrap:true},
        contents: [
          {
            component: "col",
            props: {cols:"12", sm:"12", md:"3", lg:"3", xl:"2"},
            class: "pr-0",
            style:"this.leftSidebarStyle",
            contents: [{
              component: "row",
              class: "flex-column justify-start align-start",
              contents: [{
                component: "col",
                contents: [{
                  component: "card",
                  contents: [{ //
                    component: "form", ref:"patientSearchForm", vmodel:"patientSearchValid",
                    props: {"lazy-validation":true},
                    nativeOn: {keyup:"patientSearch"},
                    contents: [
                      { component: "toolbar", props: {dense:true, color:"#1E5AC8", light:true, flat:true}, class:"elevation-0",
                        contents:[
                          { component: "toolbarTitle", class:"ml-0 pa-0 white--text text-h6", contents:"PatientSearch" },
                          { component: "spacer"},
                          { component: "button", props:{icon:true /*,to:"{ name: 'patientEdit'}"*/}, 
                            contents: {component:"icon", props:{color:"white"}, contents:"mdi-account-plus"}}
                        ]
                      },
                      {
                        component: "row",
                        contents: [
                          {component: "col", props:{cols:"12"},
                            contents:[
                              {component:"textField", rules:["nonEmptyRule"], vmodel:"patientSearchCriteria",
                                props:{label:"Search Phrase", hint:"name, ssn, phone, or email"}, class:"mx-3 my-0" },
                              { component: "textField", vmodel:"sDateOfBirth",
                                props:{label:"Date of Birth"}, mask:"'##/##/####'", class:"mx-3 my-0",
                                rules:["dateOfBirthRule"]}              
                            ]
                          }
                        ]
                      },
                      {component: "row", class:"px-3", contents: [
                        {component: "button", props:{block:true, color:"#FFF10E"}, on:{click:"patientSearch"},
                          contents: [
                            {component:"icon", props:{left:true}, contents:"mdi-magnify"},
                             {component:"span", contents:"Search"}
                          ]
                        }
                      ]},
                      {component: "row", class:"px-3 mb-1", contents: [
                        {component: "button", props:{block:true, color:"#FFF10E"}, class:"mt-3", on:{click:"listPatients"},
                          contents: [
                            {component:"icon", props:{left:true}, contents:">mdi-view-list"},
                             {component:"span", contents:"View All"}
                          ]
                        }
                      ]},
                    ]
                  }]
                }]
              },
              {
                component: "col", props:{"min-width":"100%"}, contents: [
                  {component: "card", contents: [
                    {component: "form", ref:"caseSearchForm", vmodel:"patientSearchValid", props:{"lazy-validation":true}, 
                     on:{keyup:"caseSearch"}, contents:[
                       { component: "toolbar", props:{dense:true, color:"#1E5AC8", light:true, class:"elevation-0", flat:true}, contents:[
                        {component: "toolbarTitle", class:"ml-0 white--text text-h6", contents:"Case Retriever"},                        
                       ]},
                       {component:"container", class:"mx-0 pa-3 mb-3", contents: [{component: "row", contents:[{component:"col",class:"ma-0 pa-1", contents:[
                        {component:"textField", vmodel:"caseId", props:{"error-messages":"caseIdErrMsg", label:"Case Id", class:"mx-3 my-0" }}
                      ]}]}]},
                       {component: "row", class:"px-3", contents:[
                         {component: "button", props:{block:true, color:"#FFF10E"}, on:{click:"caseSearch"}, contents:[
                           {component: "icon", props:{left:true}, contents:"mdi-magnify"},
                            {component:"span", contents:"Search"}
                         ]}
                       ]},
                       {component: "row", class:"px-3 mb-1", contents:[
                        {component: "button", props:{block:true, color:"#FFF10E"}, class:"mt-3", on:{click:"listCases"}, contents:[
                          {component: "icon", props:{left:true}, contents:"mdi-view-list"},
                           {component:"span", contents:"View All"}
                        ]}
                      ]}
                    ]}
                    ]
                  }
                ]
              },
              {
                component: "col", style:"min-width:100%", class:"ml-0",props:{"fill-height":true}, contents:[
                  {component: "button", props:{rounded:true, outlineripple:true, color:"#FFF10E"},
                   style:"width:98%", class:"ml-1 px-0 mr-1", on:{click:"gotoEventCalendar"}, contents:[
                    {component:"span", contents:"Scheduling"},
                    {component: "icon", props:{left:true}, contents:"mdi-view-list", class:"ml-3"}
                  ]}
                ]
              },
              {
                component: "col", style:"min-width:100%", class:"ml-0", props:{"fill-height":true}, contents:[
                  {component: "card", props:{color:"#1E5AC8", light:true}, contents: [
                    {component: "cardTitle", style:"color:white", class:"white--text text-h6 pl-4 py-2", contents:"Reports"},
                    {component: "cardBody", class:"pa-1", contents:[
                      {component:"select", style:"background-color:white", vmodel:"reportId",
                        props:{items:"this.reportOptions", label:"''", placeholder:"Select Report", solo:true, "hide-details":true, "single-line":true}, 
                        on:{change:"gotoReport"}
                      }
                    ]}
                  ]}
                ]
              },
              {component: "div", class:"pa-4 white", attrs:{align:"center"}, contents:[
                  {component: "button", on:{click:"hideLeftSidebar"}, contents:"Hide Sidebar"}
                ]}
              ]
            }]
          },
          {
            component: "col", props:{cols:"12", sm:"12", md:"this.rightPaneCols", lg:"this.rightPaneCols", "fill-height":true},
              contents: [
                {
                  component: "expansionPanels", props:{accordian:true, multiple:true, flat:true}, vmodel:"panels", class:"ma-0 pa-0",
                  contents: [
                    { component: "expansionPanel", props:{ripple:true}, style:"background-color:#1E5AC8", class:"mb-3", contents:[
                      { component: "expansionPanelHeader", contents:[{component:"span", class:"white--text text-h6", contents:"Pipeline"}]},
                      { component: "expansionPanelContent", props:{flat:true}, class:"ma-0 pa-0", contents: [
                        {component: "dynamicComponent", config:components.pipeline}
                      ]}
                    ]},
                    { component: "expansionPanel", props:{ripple:true}, style:"background-color:#1E5AC8", class:"mb-3", contents:[
                      { component: "expansionPanelHeader", contents:[{component:"span", class:"white--text text-h6", contents:"Pre-op Testing To be Completed"}]},
                      { component: "expansionPanelContent", props:{flat:true}, class:"pa-0", contents: [
                        //<OutstandingPreops/>
                      ]}
                    ]},
                    { component: "expansionPanel", props:{ripple:true}, style:"background-color:#1E5AC8", class:"mb-3", contents:[
                      { component: "expansionPanelHeader", contents:[{component:"span", class:"white--text text-h6", contents:"Payables"}]},
                      { component: "expansionPanelContent", props:{flat:true}, contents: [
                        {component: "card", class:"grey lighten-4", props:{light:true}, contents:[
                        //<PaymentDisbursements/>
                        ]}
                      ]}
                    ]}
                  ]
                },
                { component: "div", attrs:{width:"100%"}, style:"this.showSidebarButtonVisibility", contents:[
                  {component: "button", on:{click:"displayLeftSidebar"}, contents:"Show Sidebar"}
                ]}

              ]
          },
          { component: "spacer" }
        ]
      }
    ]
  }
};

import BaseAction from '../actions/baseaction'
import Roles from '../../models/workflowroles'
export class HomePage extends BaseAction{
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.Scheduler];
  }
  
  route() {

    this.router.get("/", (req, res) => {
      res.json(uiConfig)
    });

    return this.router;
  }
}

