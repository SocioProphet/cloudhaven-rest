import fieldMap from './misc/userfields.js'

const dataModel = {
  dialog: false,
  patientStatementDlg: false,
  statementNote: '',
  updateStatementSentDate: true,
  valid: true,
  patients:[],
  search: '',
  timeoutId: null,
  itemsPerPage: 10,
  page: 1,
  sortBy: ['patientId'],
  sortDesc: [false],
  patientCount: 0,
  loading: true,
  headers: [
    { text: 'Actions', value: 'name', sortable: false, align:'center' },
    { text: 'Patient Id', align:'left', sortable:true, value: 'patientId' },
//        { text: '# Cases', align:'right', sortable:true, value: 'caseCount' },
    { text: 'First Name', align:'left', sortable:true, value: 'firstName' },
    { text: 'Last Name', align:'left', sortable:true, value: 'lastName' },
    { text: 'Date of Birth', align:'left', sortable:true, value: 'jDateOfBirth' },
    { text: 'Email', align:'left', sortable:true, value: 'contactInfo.email' },
    { text: 'Phone', align:'left', sortable:true, value: 'contactInfo.phone' },
    { text: 'Street Address', align:'left', sortable:true, value: 'contactInfo.streetAddress' },
  ]
};
const uiMethods = {
  initialize: {
    body: `
    this.loadPatients();
    `
  },
  searchChg: {
    body: `
    if (this.timeoutId) {
      clearTimeout(this.timeoutId);
    }
    this.loading = true;
    this.timeoutId = setTimeout(() => {
      this.loadPatients();
    }, 2000);`
  },
  printStatement: {
    body:`
    this._pdfPost('patientstatement', {patientId: this.editedItem._id, statementNote:this.statementNote, updateStatementSentDate:this.updateStatementSentDate}, function(data) {
      const file = new Blob( [data], {type: 'application/pdf'});
      const fileURL = URL.createObjectURL(file);
      var win = window.open(fileURL, 'Cost Estimate', "height=960,width=840,toolbar=no,menubar=no,scrollbars=yes,location=no,status=no");
      try {
        win.focus();
      } catch(e){
        console.log(e);
      }
    });`
  },
  loadPatients: {
    body:`
    debugger;
    this.timeoutId = null;
    this.loading = true;
    var options = {
        itemsPerPage:(this.itemsPerPage||10),
        page:(this.page||1)-1,
        sortBy: (Array.isArray(this.sortBy) && this.sortBy.length==1)?this.sortBy[0]:'patientId',
        sortDesc: (Array.isArray(this.sortDesc) && this.sortDesc.length==1)?this.sortDesc[0]:false
      };
    if (options.sortBy == 'jDateOfBirth') options.sortBy = 'dateOfBirth';
    this._appPost('patientcaselist/patients', {options: options, search:this.search}, (data) => {
      this.patients = [].concat(data.list);
      this.patientCount = data.count;
      var userIds = this.patients.map(p=>(p.cloudHavenUserId));
      this._getUserDataForList (userIds, this.patients, this.fieldMap(), () => {
        this.patients.forEach(p=>(p.jDateOfBirth=this.moment(p.dateOfBirth).toDate()));
        this.loading = false;  
      });
    });`
  },
  editPatient: {
    args:["patientId"],
    body: `
    this.$store.commit('SET_RESULTNOTIFICATION', '')
//    this.routerParams.patientId = patientId;
    this._gotoAppPage( 'patientEdit', {patientId: patientId } );
    `
  },
  deleteItem: {
    args:["item"],
    body: `
    this.$store.commit('SET_RESULTNOTIFICATION', '');
    if (confirm("Are you sure you want to delete "+item.firstName+" "+item.lastName+"?")) {
      this._appPost( 'patients', {op:'delete', id:item._id}, function(response) {
        this.loadPatients();
      })
    }`
  },
  listCases: {
    args: ["item"],
    body: `
//    this.routerParams.patientId = item._id.toString();
//    this.routerParams.patientName = item.name;
    this._gotoAppPage( 'caseselect', {patientId: item._id.toString(), patientName: item.name } )
    `
  },
  closePatientStatementDlg: {
    args: ["event"],
    body: `
    if (event.keyCode != 27) return;
    this.patientStatementDlg = false;
    `
  },
  fieldMap: {
    body: 'return '+JSON.stringify(fieldMap)+';'
  }

}
const computed = {
  formTitle () {
    return this.editedItem._id  ? ('Edit Patient '+ this.editedItem.patientId) : 'New Patient'
  }
};

const uiConfig = {
  requiredUserData: ["firstName","middleName", "lastName", "ssn", "phone", "email", "fax", "textPhone", "attn",
  "streetAddress", "city", "stateOrProvince", "zipOrPostalCode", "country", "dateOfBirth", "gender", 
  "preferredContactMethod", "language"],
  dataModel:dataModel,
  uiMethods: uiMethods,
  computed:computed,
  uiSchema: {
    component: "div", contents: [
      {component: "toolbar", props:{flat:true, color:"white"}, contents:[
        {component: "toolbarTitle", contents:"Patients"},
        {component: "divider", class:"mx-2", props:{inset:true, vertical:true}},
        {component: "spacer"},
        {component: "textField", vmodel:"search", props:{"append-icon":"mdi-account-search", label:"Search", "single-line":true, "hide-details":true},
          on:{keyup:"searchChg"}}
      ]},
      {
        component: "dataTable", props:{headers:"this.headers", items:"this.patients", loading:"this.loading", "items-per-page":"this.itemsPerPage",
          page:"this.page", "sort-by":"this.sortBy", "sort-desc":"this.sortDesc", "server-items-length":"this.patiensCount", "footer-props":{itemsPerPageOptions:[5, 10, 25, 50, -1]}},
          on:{"update:page":"loadpatients", "update:items-per-page":"loadPatients", "update:sort-by":"loadPatients", "update:sort-dec":"loadPatients"},
          class:"elevation-1 mx-3", scopedSlots: {
            item: {
              component: "tr", on:{click:{eventModifier: "stop", method: "editPatient", scopedProp:"item"}}, contents: [
                {component:"td", attrs:{class:"d-flex justify-space-around align-center px-0"}, contents:[
                  {component: "button", props:{icon:true}, class:"ml-4", contents:[
                    {component:"icon", props:{medium:true}, on:{click:{eventModifier:"stop", method:"editPatient", scopedProp:"item._id"}},
                      contents:"mdi-pencil"}
                  ]},
                  {component: "button", props:{icon:true}, class:"ml-4", contents:[
                    {component:"icon", props:{medium:true}, on:{click:{eventModifier:"stop", method:"listCases", scopedProp:"item"}},
                      contents:"mdi-view-list"}
                  ]},
                  {component: "button", props:{icon:true}, class:"ml-4", contents:[
                    {component:"icon", props:{medium:true}, on:{click:{eventModifier:"stop", method:"deleteItem", scopedProp:"item"}},
                      contents:"mdi-trash-can"}
                  ]}
                ]},
                {component:"template", template:"<td>{{ _scopedProps.item.patientId }}</td>"},
                {component:"template", template:"<td>{{ _scopedProps.item.firstName }}</td>"},
                {component:"template", template:"<td>{{ _scopedProps.item.lastName }}</td>"},
                {component:"template", template:"<td>{{ _scopedProps.item.dateOfBirth | date }}</td>"},
                {component:"template", template:"<td>{{ _scopedProps.item.contactInfo.email }} </td>"},
                {component:"template", template:"<td>{{ _scopedProps.item.contactInfo.phone | formattedPhone }}</td>"},
                {component:"template", template:"<td>{{ _scopedProps.item.contactInfo.streetAddress }} </td>"}
              ]
            },
            "no-data":{ component:"span", contents:"NO PATIENTS FOUND"}
          }
      },
      {
        component:"dialog", vmodel:"patientStatementDlg", props:{"max-width":"500px"}, on:{keydown:{eventModifier:"prevent", method:"closePatientStatementDlg"}}, contents:[
          {component:"card", contents:[
            {component: "cardTitle", template:'<span class="text-h5">Patient Statement</span>'},
            {component: "cardBody", contents:[
              {component:"form", vmodel:"valid", contents:[
                {component:"textarea", vmodel:"statementNode", props:{label:"Statement Note", rows:6}},
                {component:"checkbox", vmodel:"updateStatementSentDate", props:{label:"Update Date Statement Last Sent"}}
              ]}
            ]},
            {component:"cardActions", contents:[
              { component: "button", props:{elevation:"2", color:"blue darken-1", text:true}, on: {click:"closePatientStatementDlg"}, contents:"Cancel" },
              { component: "spacer"},
              { component: "button", props:{elevation:"2", color:"blue darken-1", text:true}, on: {click:"printStatement"},
                contents:[{component:"icon", props:{left:true, dark:true}, contents:"mdi-printer"}, 
                          {component:'span', contents:"Print"}
              ] },
            ]}
          ]}
        ]
      }
    ]
  }
};

import BaseAction from '../actions/baseaction'
import Roles from '../../models/workflowroles'
export class PatientsPage extends BaseAction{
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.Scheduler];
  }
  
  route() {

    this.router.get("/", (req, res) => {
      res.json(uiConfig)
    });

    return this.router;
  }
}
