const dataModel = {
  valid: false,
  error: '',
  authPayer: {},
  authCodeErrMsg: '',
  pendingAuthCode:'',
  authCode: '',
  authDate: '',
  deniedDate: '',
  notesEntry: '',
  payerNotesDlg: false,
  patientCase: {
    totalDueFromPatient: null,
    patient:{
      name:'',
      contactInfo:{}
    },
    notesLog:[],
    payerInfo:{authorizationContact:'', authorizationPhone:'', authorizationFax:''},
    primaryPayer: {claimsPayer:{_id:'', name:''}, contractedRate:null},
    secondaryPayer:{claimsPayer:{_id:'', name:''}, contractedRate:null},
    procedure:{}
  }
};
const filters = {
  formattedNumber: {
    args: ["value", "decimalPlaces"],
    body: `
    decimalPlaces = decimalPlaces || 2;
    if (value == undefined || value===null || value==='') return '';
    var val = value.toLocaleString(undefined, {minimumFractionDigits: decimalPlaces||0, maximumFractionDigits: decimalPlaces||0});
    return val;`
  }
};
const computed = {
  fmtPayerResponsibility: 'return this.$options.filters.formattedNumber(this.payerResponsibility);',
  fmtTotalDueFromPatient: 'return this.$options.filters.formattedNumber(this.patientCase.totalDueFromPatient);',
  fmtPayer1ContractedRate: 'return this.$options.filters.formattedNumber(this.patientCase.primaryPayer.contractedRate);',
  curPayerId: 'return this.$safeRef(this.patientCase[this.payerSelector].claimsPayer)._id;',
  payerName: 'return this.$safeRef(this.patientCase[this.payerSelector].claimsPayer).name;',
  payerSelector: "return this.isPrimaryPayer?'primaryPayer':'secondaryPayer';",
  isPrimaryPayer: "return this._appParams.payerType == 'Primary Payer';",
  payerResponsibility: `
    var hasSecondaryPayer = this.patientCase.secondaryPayer.claimsPayer && this.patientCase.secondaryPayer.claimsPayer._id;
    hasSecondaryPayer = hasSecondaryPayer!=null && hasSecondaryPayer!='';
    if (!hasSecondaryPayer) {
      return this.patientCase.primaryPayer.contractedRate - this.patientCase.primaryPayer.totalDueFromPatient;
    }
    var patientDueAfterPrimary = this.patientCase.primaryPayer.totalDueFromPatient;
    var patientDueAfterSecondary = this.patientCase.secondaryPayer.totalDueFromPatient;
    var secondaryResp = patientDueAfterPrimary - patientDueAfterSecondary;
    var primaryResp = this.patientCase.primaryPayer.contractedRate - (patientDueAfterSecondary + secondaryResp);
    return this.isPrimaryPayer?primaryResp.toFixed(2):secondaryResp.toFixed(2);`,
  stateOptions: 'return stateList;',
  supportsClaimsAPI: 'return this.isPrimaryPayer?this.patientCase.primaryPayer.claimsPayer.supportsElectronicClaims:false;'
};

const uiMethods = {
  requiredRule: {
    args: ["v"],
    body: `
    return !!v || "Required."
    `
  },
  emailRule: {
    args: ["v"],
    body: `return !v || /^[^@]+@[^.]+\..+$/.test(v) || 'Please enter a valid email.'`
  },
  requiredObjectRule: {
    args: ["value"],
    body: `return (value && value._id!='') || 'Required.'`
  },
  created:`
    if (this._appParams.patientCaseId) {
      this._appPost('casepayerinfo', {patientCaseId:this._appParams.patientCaseId}, (response)=>{
        debugger;
        this.patientCase = _.merge(this.patientCase, response);
        var pppp = this.patientCase.patient;
        this._getUserData(this.patientCase.patient.cloudHavenUserId, this.patientCase.patient, {name: 'name'}, ()=>{
          debugger;
          var x = pppp;
          var y = x;
        });
//        this.$root.$emit('alerts available', this.patientCase.alerts.filter(a=>(!a.dismissed)));
        if (!this.patientCase.payerInfo) this.patientCase.payerInfo = {};
        if (this.isPrimaryPayer) {
          this.pendingAuthCode = this.patientCase.payerInfo.pendingAuthorizationCode;
          this.authCode = this.patientCase.payerInfo.approvedAuthorizationCode;
          this.authDate = this.patientCase.payerInfo.payerAuthorizationDate;
          this.deniedDate = this.patientCase.payerInfo.payerDeniedDate;
        } else {
          this.authPayer = this.patientCase.secondaryPayer.claimsPayer;
          this.pendingAuthCode = this.patientCase.payerInfo.pendingAuthorizationCode2;
          this.authCode = this.patientCase.payerInfo.approvedAuthorizationCode2;
          this.authDate = this.patientCase.payerInfo.payerAuthorizationDate2;
          this.deniedDate = this.patientCase.payerInfo.payerDeniedDate2;
        }
      });
    } else {
      this._gotoAppPage('home')
    }`,
  showPayerNotes: 'this.payerNotesDlg=true;',
  deny:`
    this.$refs.form.validate()
    this.submit('denied')`,
  makePending: "this.submit('pending')",
  authorize: `
    if (this.$refs.form.validate()) {
      this.submit('authorized')
    }`,
  submit: {
    args: ["state"],
    body: `
    this.authCodeErrMsg = '';
    if (state == 'authorized' && !this.authCode) {
      this.authCodeErrMsg = 'Authorization Code is required.';
      return;
    }
    this._appPost('casepayerinfo/'+state, 
      {
        payerType: this._appParams.payerType,
        patientCaseId: this.patientCase._id,
        pendingAuthorizationCode: this.pendingAuthCode,
        approvedAuthorizationCode: this.authCode,
        authorizationContact: this.patientCase.payerInfo.authorizationContact,
        authorizationPhone: this.patientCase.payerInfo.authorizationPhone,
        authorizationFax: this.patientCase.payerInfo.authorizationFax,
        notesEntry: this.notesEntry
      }, (response)=>{
        if (response.success) {
          this._showNotification('Payer authorization received for Case '+this.patientCase.caseId+'.');
          if (this._appParams.from == 'patientCase') {
            this._gotoAppPage('patientCase', {patientCaseId:this.patientCase._id})
          } else {
            this._gotoAppPage('home')
          }
        } else if (response.errMsg) {
          this._showError(response.errMsg)
        }
    });`
  }
}

const uiConfig = {
  requiredUserData: [],
  dataModel:dataModel,
  methods: uiMethods,
  filters: filters,
  computed:computed,
  uiSchema: {
    component: "div", contents: [
      {component: "container", contents: [
        {component: "card", contents: [
          {component: "cardTitle", template: '<span class="text-h5">{{_appParams.payerType}} Authorization</span>'},
          {component: "cardText", contents: [
            {component: "form", ref:"form", vmodel:"valid", props: {"lazy-validation":true}, contents: [
              {component: "row", class:"justify-space-around", contents: [
                {component: "col", props:{cols:"12", sm:"12", md:"4", lg:"4"}, contents: [
                  {component: "textField", props:{dense:true, readonly:true, ":value":"patientCase.caseId", label:"Case #"}},
                  {component: "textField", props:{dense:true, readonly:true, ":value":"patientCase.patient.name", label:"Patient Name"}},
                  {component: "textField", props:{dense:true, readonly:true, ":value":"patientCase.procedure.name", label:"Procedure"}},
                  {component: "textField", vmodel:"patientCase.payerInfo.authorizationContact", props:{label:"Authorizing Contact"}},
                  {component: "textField", vmodel:"patientCase.payerInfo.authorizationPhone", props:{label:"Authorizing Phone", 
                    ":mask":"(patientCase.payerInfo.authorizationPhone||'').length>7?'(###) ###-####':'###-#### #'"}},
                  {component: "textField", vmodel:"patientCase.payerInfo.authorizationFax", props:{label:"Authorizing Fax", ":mask":"(patientCase.payerInfo.authorizationFax||'').length>7?'(###) ###-####':'###-#### #'"}},
                ]},
                {component: "col", props:{cols:"12", sm:"12", md:"4", lg:"4"}, contents: [
                  {component: "textField", props:{dense:true, readonly:true, ":value":"payerName", ":label":"_appParams.payerType",
                    "append-icon":"mdi-note-multiple", ":append-icon-cb":"showPayerNotes" }},
                  {component: "textField", props:{dense:true, readonly:true, ":value":"fmtPayer1ContractedRate", label:"Allowable Rate"}},
                  {component: "textField", props:{dense:true, readonly:true, ":value":"fmtTotalDueFromPatient", label:"Patient Responsibility" }},
                  {component: "textField", props:{dense:true, readonly:true, ":value":"fmtPayerResponsibility", label:"Payer Responsibility" }},
                  {component: "textField", vmodel:"pendingAuthCode", props: {label:"Pending Authorization Code"}},
                  {component: "textField", props:{":error-messages":"authCodeErrMsg", label:"Approved Authorization Code"}, vmodel:"authCode",},
                ]},
                {component: "col", props:{cols:"12", sm:"12", md:"12", lg:"12"}, class:"mt-0 pt-0", contents: [
                  {component: "textarea", vmodel:"notesEntry", props: {label:"Additional Notes", "hide-details":true, class:"mb-1 mt-0 pt-0"}}
                ]}
              ]}
            ]}
          ]},
          {component: "cardActions", contents: [
            {component: "button", props:{elevation:"2", color:"blue darken-1", text:true}, on:{click:"deny", contents:"Denied"}},
            {component: "spacer"},
            {component: "button", props:{elevation:"2", color:"blue darken-1", text:true}, on:{click:"makePending"}, contents:"Pending"},
            {component: "button", props:{elevation:"2", color:"blue darken-1", text:true}, on:{click:"authorize"}, contents:"Authorized"}
          ]}
        ]}
      ]}
/*    <v-container>
      <NotesLog :logItems:"patientCase.notesLog" defaultCategory:"Payer Authorization"/>
    </v-container>
    <PayerNotes :show.sync:"payerNotesDlg" :payerId:"curPayerId" :payerName:"payerName" @close:"payerNotesDlg=false"/>*/
  ]}
}

import BaseAction from '../actions/baseaction'
import Roles from '../../models/workflowroles'
export class GetPayerAuthorizationPage extends BaseAction {
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.Scheduler];
  }
  
  route() {

    this.router.get("/", (req, res) => {
      res.json(uiConfig)
    });

    return this.router;
  }
}
