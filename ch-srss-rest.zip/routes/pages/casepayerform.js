import patientHdrCfg from './components/patientheader.js'
import stateList from '../../_helpers/stateList.js'

//import NotesLog from './NotesLog.vue'
const dataModel = {
  valid: true,
  panels: [0],
  costEstimateDialog: false,
  notesEntry: '',
  enableOnChange: false,
  costEstValid: true,
  error: '',
  payer2FirstNameErrMsg: '',
  payer2LastNameErrMsg: '',
  payer2DOBErrMsg: '',
  payer2RelErrMsg: '',
  payer2PolicyNumErrMsg: '',
  payer2EligibilityDateErrMsg: '',
  payerInfoWasEntered: false,
  wasSubmitted: false,
  sendCostEstimate: true,
  printCostEstimate: true,
  patientCase: {patient:{contactInfo:{}}, notesLog:[],
    payerInfo:{},
    procedure:{}, 
    primaryPayer:{
      insuredsDateOfBirth:null,
      insuredsSSN:'',
      insuredsFirstName:'',
      insuredsMiddleName:'',
      insuredsLastName:"",
      totalDueFromPatient: '',
      contractedRate:'',
      claimsPayer:{}}, 
    secondaryPayer:{
      insuredsDateOfBirth:null,
      insuredsSSN:'',
      insuredsFirstName:'',
      insuredsMiddleName:'',
      insuredsLastName:"",
      totalDueFromPatient: '',
      contractedRate:'',
      claimsPayer:{}
    },
    totalDueFromPatient:''
  },
  payerOptions: [],
  payers: [],
  casePatientModelToUserDataMap: {
    "firstName": "firstName",
    "lastName": "lastName",
    "middleName": "middleName",
    "dateOfBirth": "dateOfBirth",
    "ssn": "ssn"
  }
};

const filters = {
  formattedNumber: {
    args: ["value", "decimalPlaces"],
    body: `
    decimalPlaces = decimalPlaces || 2;
    if (value == undefined || value===null || value==='') return '';
    var val = value.toLocaleString(undefined, {minimumFractionDigits: decimalPlaces||0, maximumFractionDigits: decimalPlaces||0});
    return val;`
  }
};
const computed = {
  fmtPayer2TotalDueFromPatient: {
    body:`
    return this.$options.filters.formattedNumber(this.patientCase.secondaryPayer.totalDueFromPatient);`
  },
  fmtPayer1TotalDueFromPatient: {
    body:`
    return this.$options.filters.formattedNumber(this.patientCase.primaryPayer.totalDueFromPatient);`
  },
  fmtPayer1ContractedRate: {
    body:`
    return this.$options.filters.formattedNumber(this.patientCase.primaryPayer.contractedRate);`
  },
  fmtTotalDueFromPatient: {
    body:`
    return this.$options.filters.formattedNumber(this.patientCase.totalDueFromPatient);`
  },
  stateOptions: {
    body: `
    return stateList;`
  },
  hasSecondaryPayer: {
    body:`
    var id = this._deepGet(this.patientCase.secondaryPayer, "claimsPayer._id");
    return id!=null && id!='';`
  },
  formTitle: {
    body: `return "Case "+this.patientCase.caseId+" Payer Info";`
  },
  isCashPayer: {
    body:`
    return this._deepGet(this.patientCase.primaryPayer, "claimsPayer.isSelfPayer");`
  },
  primaryPayerPaymentDue: {
    body:`
    if (!this.patientCase.paymentsDue) return {};
    return this.patientCase.paymentsDue.find(pd=>(pd.payerType=='Primary Payer')) || {};`
  },
  secondaryPayerPaymentDue: {
    body:`
    if (!this.patientCase.paymentsDue) return {};
    return this.patientCase.paymentsDue.find(pd=>(pd.payerType=='Secondary Payer')) || {};`
  },
  primaryPayerEditable: {
    body:`
    return (!this.primaryPayerPaymentDue || !this._deepGet(this.primaryPayerPaymentDue,"transactions.length") );`
  },
  secondaryPayerEditable: {
    body:`
    return (!this.surgeryCompleted || 
        !this.secondaryPayerPaymentDue || !this._deepGet(this.secondaryPayerPaymentDue, "transactions.length")
    );`
  },
  isPayor1AmtsEditable: {
    body:`
    var retVal = (!this.patientCase.opReportUploaded || !this._deepGet(this.primaryPayerPaymentDue, "transactions.length"))
    return retVal;`
  },
  isPayor2AmtsEditable: {
    body:`
    var retVal = (!this.patientCase.opReportUploaded || (
        this._deepGet(this.secondaryPayerPaymentDue,"payerType") && !this._deepGet(this.secondaryPayerPaymentDue,"transactions.length")
      )
    );
    return retVal;`
  }
};

const uiMethods = {
  mounted: {
    body: `
    debugger;
    if (!this.patientCase.primaryPayer.relationshipToPatient) {
      this.sendCostEstimate = true;
      this.printCostEstimate = true;
    }
    setTimeout(()=>{this.enableOnChange=true;}, 300);`
  },
  created: {
    body: `
      if (this._appParams.patientCaseId) {
        this._appGet( 'payers/list', (payers)=>{
          this.payers = payers;
          this.payerOptions = [{_id:'',name:''}].concat(this.payers.sort((a,b)=>(a.name>b.name?1:a.name<b.name?-1:0)));
        });
        this._appPost( 'casepayerinfo', {patientCaseId:this._appParams.patientCaseId}, (response) => {
          debugger;
          this.patientCase = this._merge(this.patientCase, response);
          this.payerInfoWasEntered = (this.patientCase.primaryPayer.policyNumber||'')!='';
          this._getUserData(this.patientCase.patient.cloudHavenUserId, this.patientCase.patient, this.casePatientModelToUserDataMap );

//          this.$root.$emit('alerts available', this.patientCase.alerts.filter(a=>(!a.dismissed)));
          if (!this.patientCase.payerInfo) this.patientCase.payerInfo = {};
        });
      } else {
        this._gotoAppPage('home');
      }`
  },
  decimalNumberRule: {
    args: ["value"],
    body: `value => (value && /^(\d*\.)?\d+$/.test(value)) || 'Enter decimal number.'`
  },
  emailRule: {
    args: ["v"],
    body: `return !v || /^[^@]+@[^.]+\..+$/.test(v) || 'Please enter a valid email.'`
  },
  requiredObjectRule: {
    args: ["value"],
    body: `return (value && value._id!='') || 'Required.'`
  },
  nonNegative: {
    args: ["value"],
    body: `return value >= 0 || 'Enter non-negative number.'`
  },
  phoneRule: {
    args:["v"],
    body: `return !v || /^(?:(?:\+?1\s*(?:[.-]\s*)?)?(?:\(\s*([2-9]1[02-9]|[2-9][02-8]1|[2-9][02-8][02-9])\s*\)|([2-9]1[02-9]|[2-9][02-8]1|[2-9][02-8][02-9]))\s*(?:[.-]\s*)?)?([2-9]1[02-9]|[2-9][02-9]1|[2-9][02-9]{2})\s*(?:[.-]\s*)?([0-9]{4})(?:\s*(?:#|x\.?|ext\.?|extension)\s*(\d+))?$/.test(v) || 'Please enter a valid phone number.'`
  },
  ssnRule: {
    args: ["v"],
    body: `return !v || /^(?!666|000|9\\d{2})\\d{3}-(?!00)\\d{2}-(?!0{4})\\d{4}$/.test(v) || 'Enter a valid social security number.';`
  },
  onPrimaryPayerChange: {
    body: `
      if (!this.enableOnChange) return;
      if (this._deepGet(this.patientCase.primaryPayer, "claimsPayer._id")) {
        var payerProcedure = this.patientCase.primaryPayer.claimsPayer.procedures.find(p=>(p.procedure._id==this.patientCase.procedure._id))
        this.patientCase.primaryPayer.contractedRate = payerProcedure?payerProcedure.contractedRate:'';
      }
      this.updateCalc();
      this.setPrimaryPayerHealthPlanIdDefault();`
    },
  setPrimaryPayerHealthPlanIdDefault: {
    body: `
    var numHealthPlanIds = 0;
    try {
      numHealthPlanIds = this.patientCase.primaryPayer.claimsPayer.healthPlanIds.length;
    } catch(e) {console.log(e)}
    if (this._deepGet(this.patientCase.primaryPayer, "claimsPayer.supportsElectronicClaims")) {
      if (numHealthPlanIds == 1) {
        this.patientCase.primaryPayer.healthPlanId = this.patientCase.primaryPayer.claimsPayer.healthPlanIds[0];
      }
    } else {
      this.patientCase.primaryPayer.healthPlanId = '';
    }`
  },
  onPrimaryRelChg: {
    body: `
    debugger;
    this.onRelChange('primaryPayer')`
  },
  onSecondaryRelChg: {
    body:`
    this.payer2RelErrMsg = '';
    this.onRelChange('secondaryPayer');`
  },
  onRelChange: {
    args: ["payerSelector"],
    body: `
    if (!this.enableOnChange) return;
    var rel = this.patientCase[payerSelector].relationshipToPatient;
    if (rel=='Self') {
      this.patientCase[payerSelector].insuredsDateOfBirth = this.patientCase.patient.dateOfBirth;
      this.patientCase[payerSelector].insuredsSSN = this.patientCase.patient.ssn;
      this.patientCase[payerSelector].insuredsFirstName = this.patientCase.patient.firstName;
      this.patientCase[payerSelector].insuredsMiddleName = this.patientCase.patient.middleName;
      this.patientCase[payerSelector].insuredsLastName = this.patientCase.patient.lastName;
      return;
    }
    this.patientCase[payerSelector].insuredsFirstName = '';
    this.patientCase[payerSelector].insuredsMiddleName = '';
    if (rel!='Spouse' && rel!='Parent') {
      this.patientCase[payerSelector].insuredsLastName = '';
      this.$forceUpdate();
    } else {
      this.patientCase[payerSelector].insuredsLastName = this.patientCase.patient.lastName;
      this.$forceUpdate();
    }
    this.patientCase[payerSelector].insuredsSSN = '';
    if (payerSelector == 'primaryPayer') {
      this.patientCase.primaryPayer.insuredsDateOfBirth = '';
    } else {
      this.patientCase.secondaryPayer.insuredsDateOfBirth = '';
    }`
  },
  showCostEstimatePdf: {
    body:`
    debugger;
    this._pdfGet('patientacceptance/getcostestimate/'+this.patientCase._id, (response)=>{
      const file = new Blob( [response.data], {type: 'application/pdf'});
      const fileURL = URL.createObjectURL(file);
      var width = screen.width<820?(screen.width-40):840;
      var win = window.open(fileURL, 'Cost Estimate', "height=960,width="+width+",toolbar=no,menubar=no,scrollbars=yes,location=no,status=no,top=5,left=0");
      try {
        win.focus();
      } catch(e){
        console.log(e);
      }
    })`
  },
  amtFld: {
    args: ["prefix", "fld"],
    body: `
    var val = (prefix?(prefix+fld.substring(0,1).toUpperCase()+fld.substring(1)):fld);
    return val;`
  },
  calcSection: {
    args: ["patientCase", "payerSelector", "cost"],
    body:`
    if (!this.enableOnChange) return;
    var payerSection = patientCase[payerSelector];
    if (!payerSection || !payerSection.claimsPayer || !payerSection.claimsPayer._id) {
      payerSection.totalDueFromPatient = '';
      return 0;
    }
    if (payerSelector=='secondaryPayer' && payerSection.expectedAmountOverride) {
      patientCase.secondaryPayer.totalDueFromPatient = this.round(patientCase.primaryPayer.totalDueFromPatient||0) - (payerSection.expectedAmountOverride||0);
      return patientCase.secondaryPayer.totalDueFromPatient;
    }
    var oopIncludeDeductible = payerSection.oopAmountIncludesDeductible;
    var deductible = parseFloat(payerSection.deductible || 0);
    var deductibleMet = parseFloat(payerSection.deductibleMet || 0);
    var deductibleRemaining = this.round(deductible - deductibleMet);
    if (deductibleRemaining<0) deductibleRemaining = 0;

    var patientFactor = this.round((100.0 - parseFloat(payerSection.benefitPercent || 0) )/100.0);

    var outOfPocket = parseFloat(payerSection.outOfPocket || 0);
    var outOfPocketMet = parseFloat(payerSection.outOfPocketMet || 0);
    var outOfPocketRemaining = this.round(outOfPocket - outOfPocketMet);
    if (outOfPocketRemaining<0) outOfPocketRemaining = 0;

    var patientCopay = parseFloat(payerSection.copayAmount || 0);

    var coInsurance = 0;
    var patientAmtDue = 0;
    if (oopIncludeDeductible) {
      coInsurance = this.round(patientFactor * (cost - deductibleRemaining));
      patientAmtDue = this.round(coInsurance + deductibleRemaining);
      if (patientAmtDue>cost) patientAmtDue = cost;
      if (outOfPocket) {
        patientAmtDue = patientAmtDue > outOfPocketRemaining ? outOfPocketRemaining : patientAmtDue;
      }
      patientAmtDue += patientCopay;
      payerSection.totalDueFromPatient = this.round(patientAmtDue);
    } else {
      coInsurance = this.round(cost * patientFactor);
      if (outOfPocket) {
        patientAmtDue = coInsurance > outOfPocketRemaining ? outOfPocketRemaining : coInsurance;
      }
      patientAmtDue = this.round(patientAmtDue + deductibleRemaining + patientCopay);
      payerSection.totalDueFromPatient = patientAmtDue;
    }
    return payerSection.totalDueFromPatient;`
  },
  onSecondaryPayerChange: {
    body:`
    if (!this.enableOnChange) return;
    this.payer2FirstNameErrMsg = '';
    this.payer2LastNameErrMsg = '';
    this.payer2DOBErrMsg = '';
    this.payer2RelErrMsg = '';
    this.payer2PolicyNumErrMsg = '';
    this.payer2EligibilityDateErrMsg = '';
    if (this.deepGet(this.patientCase.secondaryPayer, "claimsPayer._id")) {
      var payerProcedure = this.patientCase.secondaryPayer.claimsPayer.procedures.find(pp=>(pp.procedure._id==this.patientCase.procedure._id));
      this.patientCase.secondaryPayer.contractedRate = payerProcedure?payerProcedure.contractedRate:null;
    } else {
      this.patientCase.secondaryPayer.insuredsDateOfBirth = '';
      this.patientCase.secondaryPayer.eligibilityDate = '';
      ['relationshipToPatient', 'insuredsFirstName', 'insuredsMiddleName', 'insuredsLastName', 'insuredsSSN', 'healthPlanId',
        'groupNumber', 'policyNumber', 'oopAmountIncludesDeductible', 'copayAmount', 'deductible', 'deductibleMet', 'benefitPercent',
        'outOfPocket', 'outOfPocketMet', 'expectedAmountOverride', 'totalDueFromPatient'].forEach(fld=>{
        this.patientCase.secondaryPayer[fld] = null;
      });
    }
    this.updateCalc();`
  },
  updateCalc: {
    body:`
    var miscPatientAmountDue = 0; 
    var contractedRate = parseFloat(this.patientCase.primaryPayer.contractedRate || 0);
    var totalDueFromPatient = this.calcSection( this.patientCase, 'primaryPayer', contractedRate );
    if (this.patientCase.secondaryPayer && this.patientCase.secondaryPayer.claimsPayer && this.patientCase.secondaryPayer.claimsPayer._id) {
      totalDueFromPatient = this.calcSection( this.patientCase, 'secondaryPayer', totalDueFromPatient );
    }
    this.patientCase.totalDueFromPatient = this.round(totalDueFromPatient + miscPatientAmountDue);`
  },
  displayCostEstimateDlg: {
    body:`
    debugger;
    this.costEstimateDialog = true;`
  },
  saveForm: {
    body:`
    debugger;
    this.costEstimateDialog = false;
    this.payer2FirstNameErrMsg = '';
    this.payer2LastNameErrMsg = '';
    this.payer2DOBErrMsg = '';
    this.payer2RelErrMsg = '';
    this.payer2PolicyNumErrMsg = '';
    this.payer2EligibilityDateErrMsg = '';
    if (this.hasSecondaryPayer) {
      if (!this.patientCase.secondaryPayer.insuredsFirstName) {
        this.payer2FirstNameErrMsg = "Insured's First Name is required.";
        return;
      }
      if (!this.patientCase.secondaryPayer.insuredsLastName) {
        this.payer2LastNameErrMsg = "Insured's Last Name is required.";
        return;
      }
      if (!this.patientCase.secondaryPayer.insuredsDateOfBirth) {
        this.payer2DOBErrMsg = 'Date of Birth is required.';
        return;
      }
      if (!this.patientCase.secondaryPayer.relationshipToPatient) {
        this.payer2RelErrMsg = 'Relationship to Patient is required.';
        return;
      }
      if (!this.patientCase.secondaryPayer.policyNumber) {
        this.payer2PolicyNumErrMsg = 'Policy Number is required.';
        return;
      }
      if (!this.patientCase.secondaryPayer.eligibilityDate) {
        this.payer2EligibilityDateErrMsg = 'Eligibility Date is required.';
        return;
      }
    }

    if (!this.patientCase.primaryPayer.insuredsSSN) {
      if (!confirm("Proceed without the insured's SSN?")) return;
    }
    var isValid = this.$refs.form.validate();
    if (isValid) {
      this._appPost('casepayerinfo/update', {patientCaseId: this.patientCase._id, patientCase: this.patientCase, notesEntry:this.notesEntry, sendCostEstimate: this.sendCostEstimate},
        (response) =>{
        if (response.record) {
          this._showNotification( "Case "+this.patientCase.caseId+" payer information updated.");
          this.wasSubmitted = true;
          if (this.printCostEstimate) {
            this.showCostEstimatePdf();
          }
//            this._gotoAppPage('home');
        } else if (response.errMsg) {
          this._showError( response.errMsg );
        }
      });
    }
    `
  },
  cancelForm: {
    body:`
    if (this._appParams.from == 'patientCase') {
      this._gotoAppPage('patientCase', {patientCaseId:this._appParams.patientCaseId});
    } else {
      this._routerGoBack();
    }`
  },
  round: {
    args: ["n"],
    body:`
    return Number((n||0).toFixed(2));`
  }
}

const components = [patientHdrCfg];
const uiConfig = {
    requiredUserData: [],
    dataModel:dataModel,
    uiMethods: uiMethods,
    filters: filters,
    computed:computed,
    components: components,
    uiSchema: {
      component: "div", contents: [
        {component: "card", contents:[
          {component: "cardTitle", template:'<span class="text-h5">{{formTitle}}</span>'},
          {component: "cardText", contents:[
            {component: "form", ref:"form", vmodel:"valid", props:{"lazy-validation":true}, contents: [
              {component: "row", class:"mt-1", contents:[
                {component: "dynamicComponent", name: "PatientHeader", show:"patientCase.patient.cloudHavenUserId",
                props:{isReadOnly:true, ":patientId":"patientCase.patient.patientId", ":userId":"patientCase.patient.cloudHavenUserId"}}
              ]},
              {component: "divider"},
              {component: "container", contents:[
                {component: "row", class:"justify-space-around flex-wrap fill-height", contents:[
                  {component: "col", props: {cols:12, sm:12, md:4,lg:4}, contents: [
                    {component: "textField",props:{readonly:true, ":value":"patientCase.procedure.name", label:"Procedure"}}
                  ]},
                  {component: "col", show:"!isCashPayer", props: {cols:12, sm:12, md:4,lg:4}, contents: [
                    {component: "textField",props:{readonly:true, ":value":"fmtPayer1ContractedRate", label:"Allowable Rate"}}
                  ]},
                  {component: "col", props: {cols:12, sm:12, md:4,lg:4}, contents: [
                    {component: "textField",props:{readonly:true, ":value":"fmtTotalDueFromPatient", label:"Total Patient Responsibility"}}
                  ]},
                ]},
                {component: "expansionPanels", props:{dark:true, multiple:true, ":value":"panels"}, contents:[
                  {component: "expansionPanel", style:"background-color:#1E5AC8", contents: [
                    {component: "expansionPanelHeader", contents:"Primary Payer"},
                    {component: "expansionPanelContent", contents: [
                      {component: "card", class:"grey lighten-4", props:{light:true}, contents: [
                        {component: "container", contents: [
                          {component: "row", class:"flex-wrap justify-space-between", contents:[
                            {component: "col", props:{column:true}, class:"justify-start mx-6", contents: [
                              {component: "autocomplete", vmodel:"patientCase.primaryPayer.claimsPayer", 
                                props:{":readonly":"!primaryPayerEditable || !isPayor1AmtsEditable", ":items":"payerOptions", 
                                  placeholder:"Enter some letters of the payer name", "item-value":"_id", "item-text":"name",
                                  "return-object":true, label:"Claims Payer"}, on:{change:"onPrimaryPayerChange"}, rules:["requiredObjectRule"]},
                              {component: "select", show:"!isCashPayer", vmodel:"patientCase.primaryPayer.relationshipToPatient",
                                props:{label:"Relationship To Patient", ":items":"['Self','Parent', 'Spouse', 'Partner', 'Guardian', 'Employer']"},
                                rules:["requiredRule"], on:{change:"onPrimaryRelChg"}},
                              {component: "textField", show:"!isCashPayer", vmodel:"patientCase.primaryPayer.insuredsFirstName", props:{label:"Insureds First Name"},
                                rules:["requiredRule"]},
                              {component: "textField", show:"!isCashPayer", vmodel:"patientCase.primaryPayer.insuredsMiddleName", props:{label:"Insureds Middle Name",
                                placeholder:"Insureds Middle Name (or Initial)"}},
                              {component: "textField", show:"!isCashPayer", vmodel:"patientCase.primaryPayer.insuredsLastName", props:{label:"Insureds Last Name"},
                                rules:["requiredRule"]},
                              {component: "textField", show:"!isCashPayer", vmodel:"patientCase.primaryPayer.insuredsSSN", props:{label:"Insureds SSN"},
                                rules:["ssnRule"], mask:"'###-##-####'"},
                              {component: "dateField", show:"!isCashPayer", vmodel:"patientCase.primaryPayer.insuredsDateOfBirth", ensureDate:true, 
                                props:{label:"Insured's Date Of Birth"}, rules:["requiredRule"], mask:"'##/##/####'"},
                              {component: "select", show:"!isCashPayer && _deepGet(patientCase.primaryPayer,'claimsPayer.supportsElectronicClaims')",
                                vmodel:"patientCase.primaryPayer.healthPlanId", props:{":items":"patientCase.primaryPayer.claimsPayer.healthPlanIds", 
                                label:"Health Plan Id"}},
                              {component: "textField", show:"!isCashPayer", vmodel:"patientCase.primaryPayer.groupNumber", props:{label:"Group Number"}},
                              {component: "textField", show:"!isCashPayer", vmodel:"patientCase.primaryPayer.policyNumber", props:{label:"Policy Number"},
                                rules:["requiredRule"]},
                              {component: "dateField", vmodel:"patientCase.primaryPayer.eligibilityDate", ensureDate:true, props:{label:"Eligibility Date"},
                              rules:["requiredRule"], mask:"'##/##/####'"}
                            ]},
                            {component: "col", show:"!isCashPayer", class:"mx-6 align-start justify-start", contents: [
                              {component: "checkbox", vmodel:"patientCase.primaryPayer.oopAmountIncludesDeductible",
                                props:{label:"Deductible included in OOP Amount"}, on:{change:"updateCalc"}},
                              {component: "textField", props:{readonly:true, ":value":"fmtPayer1ContractedRate", label:"Allowable Rate"}},
                              {component: "textField", props:{":readonly":"!isPayor1AmtsEditable", type:"number",  label:"Co-pay", step:"0.01"},
                                vmodel:"patientCase.primaryPayer.copayAmount", on:{change:"updateCalc"}},
                              {component: "textField", props:{":readonly":"!isPayor1AmtsEditable", type:"number", label:"Deductible", step:"0.01"}, on:{change:"updateCalc"},
                                vmodel:"patientCase.primaryPayer.deductible"},
                              {component: "textField", props:{":readonly":"!isPayor1AmtsEditable", type:"number", label:"Deductible Met", step:"0.01"},
                                vmodel:"patientCase.primaryPayer.deductibleMet", on:{change:"updateCalc"}},
                              {component: "textField", props:{":readonly":"!isPayor1AmtsEditable", type:"number", label:"Benefit %", step:"0.01"},
                                vmodel:"patientCase.primaryPayer.benefitPercent", on:{change:"updateCalc"}},
                              {component: "textField", props:{":readonly":"!isPayor1AmtsEditable", type:"number", label:"Out of Pocket", step:"0.01"},
                                vmodel:"patientCase.primaryPayer.outOfPocket", on:{change:"updateCalc"}},
                              {component: "textField", props:{":readonly":"!isPayor1AmtsEditable", type:"number", label:"Out of Pocket Met", step:"0.01"},
                                vmodel:"patientCase.primaryPayer.outOfPocketMet", on:{change:"updateCalc"}},
                              {component: "textField", props:{readonly:true, ":value":"fmtPayer1TotalDueFromPatient", label:"Patient Responsibility" }}
                            ]}
                          ]}
                        ]}
                      ]}
                    ]}
                  ]},
                  {component: "expansionPanel", show:"!isCashPayer", style:"background-color:#1E5AC8", contents: [
                    {component: "expansionPanelHeader", contents:"Secondary Payer"},
                    {component: "expansionPanelContent", contents: [
                      {component: "card", class:"grey lighten-4", props:{light:true}, contents: [
                        {component: "container", contents: [
                          {component: "row", class:"flex-wrap justify-space-between", contents: [
                            {component: "col", props:{column:true}, class:"justify-start mx-6", contents: [
                              {component: "autocomplete", props:{":readonly":"!secondaryPayerEditable || !isPayor2AmtsEditable", ":items":"payerOptions",
                                placeholder:"Enter some letters of the payer name", "item-value":"_id", "item-text":"name", "return-object":true,
                                label:"Claims Payer"}, vmodel:"patientCase.secondaryPayer.claimsPayer", on:{change:"onSecondaryPayerChange"}},
                              {component: "select", vmodel:"patientCase.secondaryPayer.relationshipToPatient", props:{label:"Relationship To Patient", 
                                ":error-messages":"payer2RelErrMsg", ":items":"['Self','Parent', 'Spouse', 'Partner', 'Guardian', 'Employer']"},
                                on:{change:"onSecondaryRelChg"}},
                              {component: "textField", vmodel:"patientCase.secondaryPayer.insuredsFirstName", 
                                props:{label:"Insureds First Name", ":error-messages":"payer2FirstNameErrMsg"}, on:{change:"payer2FirstNameErrMsg=''"}},
                              {component: "textField", vmodel:"patientCase.secondaryPayer.insuredsMiddleName", props:{label:"Insureds Middle Name", placeholder:"Insureds Middle Name (or Initial)" }},
                              {component: "textField", vmodel:"patientCase.secondaryPayer.insuredsLastName", props:{label:"Insureds Last Name", ":error-messages":"payer2LastNameErrMsg"},
                                on:{change:"payer2LastNameErrMsg=''"}},
                              {component: "textField", vmodel:"patientCase.secondaryPayer.insuredsSSN", props:{label:"Insureds SSN"}, rules:["ssnRule"], mask:"'###-##-####'"},
                              {component: "dateField", vmodel:"patientCase.secondaryPayer.insuredsDateOfBirth", ensureDate:true, props:{label:"Insured's Date Of Birth", ":error-messages":"payer2DOBErrMsg"},
                                mask:"'##/##/####'", on:{change:"payer2DOBErrMsg=''"}},
                              {component: "select", show:"_deepGet(patientCase.secondaryPayer, 'claimsPayer.supportsElectronicClaims')", 
                                vmodel:"patientCase.secondaryPayer.healthPlanId", props:{":items":"patientCase.secondaryPayer.claimsPayer.healthPlanIds", label:"Health Plan Id"}},
                              {component: "textField", vmodel:"patientCase.secondaryPayer.groupNumber", props:{label:"Group Number" }},
                              {component: "textField", vmodel:"patientCase.secondaryPayer.policyNumber",props:{label:"Policy Number", ":error-messages":"payer2PolicyNumErrMsg"},
                                on:{change:"payer2PolicyNumErrMsg=''"}},
                              {component: "dateField", vmodel:"patientCase.secondaryPayer.eligibilityDate", ensureDate:true, mask:"'##/##/####'", 
                                props:{label:"Eligibility Date", ":error-messages":"payer2EligibilityDateErrMsg"}, on:{change:"payer2EligibilityDateErrMsg=''"}}
                            ]},
                            {component: "col", class:"justify-start mx-6", contents: [
                              {component: "checkbox", vmodel:"patientCase.secondaryPayer.oopAmountIncludesDeductible", props:{":readonly":"!isPayor2AmtsEditable", 
                                label:"Deductible included in OOP Amount"}, on:{change:"updateCalc"}},
                              {component: "textField", props: {readonly:true, ":value":"fmtPayer1TotalDueFromPatient", label:"Patient Balance after Primary Payer"}},
                              {component: "textField", props:{":readonly":"!isPayor2AmtsEditable", type:"number", label:"Co-pay", step:"0.01"},
                                vmodel:"patientCase.secondaryPayer.copayAmount", on:{change:"updateCalc"}},
                              {component: "textField", vmodel:"patientCase.secondaryPayer.deductible", props:{":readonly":"!isPayor2AmtsEditable", type:"number", label:"Deductible", step:"0.01"},
                                on:{change:"updateCalc"}},
                              {component: "textField", vmodel:"patientCase.secondaryPayer.deductibleMet", props:{":readonly":"!isPayor2AmtsEditable", type:"number", label:"Deductible Met", step:"0.01"}, on:{change:"updateCalc"}},
                              {component: "textField", vmodel:"patientCase.secondaryPayer.benefitPercent", props:{":readonly":"!isPayor2AmtsEditable", type:"number", label:"Benefit %", step:"0.01"}, on:{change:"updateCalc"}},
                              {component: "textField", vmodel:"patientCase.secondaryPayer.outOfPocket", props:{":readonly":"!isPayor2AmtsEditable", type:"number", label:"Out of Pocket", step:"0.01"}, on:{change:"updateCalc"}},
                              {component: "textField", vmodel:"patientCase.secondaryPayer.outOfPocketMet", props:{":readonly":"!isPayor2AmtsEditable", type:"number", label:"Out of Pocket Met", step:"0.01"}, on:{change:"updateCalc"}},
                              {component: "textField", vmodel:"patientCase.secondaryPayer.expectedAmountOverride", props:{":readonly":"!isPayor2AmtsEditable", type:"number", label:"Expected Amount Override", step:"0.01"}, on:{change:"updateCalc"}},
                              {component: "textField", props: {readonly:true, ":value":"fmtPayer2TotalDueFromPatient", label:"Patient Responsibility"}}
                            ]}
                          ]}
                        ]} //container
                      ]} //card
                    ]} //epc
                  ]} //ep
                ]},
                {component: "row", props:{wrap:true}, contents: [
                  {component: "col", props:{cols:12, sm:12, md:12, lg:"12"}, contents: [
                    {component: "textarea", vmodel:"notesEntry", props:{label:"Additional Notes", "hide-details":true}, class:"mb-1"}
                  ]}
                ]}
              ]}
            ]}
          ]},
          {component:"cardActions", contents:[
            {component: "button", props:{elevation:2, color:"blue darken-1", text:true}, on:{click:"cancelForm()"}, contents:[
              {component: "icon", props:{left:true, dark:true}, contents:"mdi-arrow-left"}, "Go Back"  ]},
            {component: "spacer"},
            {component: "button", show:"payerInfoWasEntered || wasSubmitted", props:{elevation:2, color:"blue darken-1", text:true}, nativeOn:{click:"showCostEstimatePdf"},
              contents:[{component: "icon", props:{left:true, dark:true}, contents:"mdi-printer"}, "Print Cost Estimate" ]},
            {component: "spacer", show:"patientCase.primaryPayer.eligibilityDate"},
            {component: "button", props:{elevation:2, ":disabled":"wasSubmitted", color:"blue darken-1", text:true}, on:{click:"displayCostEstimateDlg()"},
              contents:[{component:"icon", props:{left:true, dark:true}, contents:"mdi-content-save"},"Save"]}
          ]}
        ]},

    
  /*<NotesLog :logItems="patientCase.notesLog" defaultCategory="Payer Info"/>*/
        {component: "dialog", vmodel:"costEstimateDialog", /*on:{keydown:{eventModifier:prevent, method:"fixme_costEstimateDialog = false"}},*/
          props:{"max-width":"500px", scrollable:true}, contents:[
          {component: "card", contents: [
            {component: "cardTitle", template:'<span class="text-h5">Print/Send Cost Estimate</span>'},
            {component: "cardText", contents: [
              {component: "form", ref:"costEstimateForm", vmodel:"costEstValid", props:{"lazy-validation":true}, contents: [
                {component: "switch", props:{label:"Email Cost Estimate"},vmodel:"sendCostEstimate"},
                {component: "switch", props:{label:"Display Cost Estimate (to print)"}, vmodel:"printCostEstimate"}
              ]}
            ]},
            {component:"cardActions", contents:[
              {component: "button", props:{elevation:2, color:"blue darken-1", text:true}, nativeOn:{click:{body:"costEstimateDialog=false"}}, 
                contents:"Cancel"},
              {component: "spacer"},
              {component: "button", debug:true, props:{elevation:2, color:"blue darken-1", text:true}, nativeOn:{click:"saveForm"}, contents:[
                {component: "icon", props:{left:true, dark:true}, contents:"mdi-content-save"},"Continue"]}
            ]}
          ]}
        ]}
      ]}
    }

import BaseAction from '../actions/baseaction'
import Roles from '../../models/workflowroles'
export class CasePayerFormPage extends BaseAction {
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.Scheduler];
  }
  
  route() {

    this.router.get("/", (req, res) => {
      res.json(uiConfig)
    });

    return this.router;
  }
}

