

const dataModel = {
  firstName:'',
  lastName:'',
  ssn:'',
  phone: '',
  dateOfBirth: '',
  email:'',
  city:''
}
const uiMethods = {
  valueOrOneSpace: {
    args: ["val"],
    body: `return val || ' ';`
  },
  mounted: {
    body: `
    if (this.userId) {
      this.loadUser( this.userId );
    }`
  },
  loadUser: {
    args: ["userId"],
    body: `
    if (userId) {
      this._getUserData(userId, null, null, () =>{
        if (!this.city) this.city = " ";
        if (!this.email) this.email = " ";
        if (!this.phone) this.phone = " ";
        if (!this.ssn) this.ssn = " ";
      });
    }`
  },
  
};
const watch = {
  userId: {
    args: ["val"],
    body: `
    this.loadUser(val);
    `
  }
}
const filters = {
/*  formattedPhone: {
    args: ["value"],
    body: `
    if (!value) return '';
    var rawPhone = value.replace(/[( )-.]/g, '');
    if (rawPhone.length==10) {
      return '('+rawPhone.substring(0,3)+') '+rawPhone.substring(3,6)+'-'+rawPhone.substring(6);
    } else if (rawPhone.length==7) {
      return rawPhone.substring(0,3)+'-'+rawPhone.substring(3);
    } else {
      return rawPhone;
    }`
  },
  formattedSSN: {
    args: ["value"],
    body: `
    if (!value) return '';
    if (value.length!=9) return value;
    return value.substring(0,3)+'-'+value.substring(3,5)+'-'+value.substring(5);
    `
  }*/
}
const computed = {
  debugVal: {
    body: `
    return this.ssn+', '+this.phone+', '+this.email;`
  },
  getCols: {
    body: `
      return this.showAddress?3:4;
    `
  },
/*  fmtPhone: {
    body: `
    return this.$options.filters.formattedPhone(this.phone);`
  },
  fmtPatientSSN: {
    body: `
    return ''; //this.$options.filters.formattedSSN(this.ssn);`
  }*/
};
const props = {
  isReadOnly: { type: "Boolean"},
  patientId: { type: "String"},
  userId: {type: "String"},
  showAddress: {type: "Boolean"}
};

export default {
  name:"PatientHeader",
  requiredUserData: [],
  props:props,
  dataModel:dataModel,
  methods: uiMethods,
  computed:computed,
  filters:filters,
  watch: watch,
  uiSchema: {
    component: "container", class:"justify-space-around justify-stretch px-5 py-2 mb-3", style:"background-color:#F0F0F0", contents: [
      {component: "row", class:"justify-space-around justify-stretch px-5 py-2 mb-3", style:"background-color:#F0F0F0", contents:[
          {component: "col", props:{cols:12, ":xl":"getCols", ":lg":"getCols", ":md":"getCols"},
            class:{body:"{'py-0':isReadOnly }"}, contents: [
            {component: "textField", props:{dense:false, ":value":"patientId", 
              ":readonly":"isReadOnly", label:"Patient Id","hide-details":true}},
            {component: "textField", userData:{id:"lastName", model:"lastName"}, 
              props:{dense:false, ":value":"lastName", 
              ":readonly":"isReadOnly", label:"Last Name", "hide-details":true}},
            {component: "textField", userData:{id:"firstName", model:"firstName"},
              props:{dense:false, ":value":"firstName", 
              ":readonly":"isReadOnly", label:"First Name", "hide-details":true}},
            {component: "textField", userData:{id:"ssn", model:"ssn"}, props:{dense:false, ":value":"ssn",
              ":readonly":"isReadOnly", label:"SSN", "hide-details":true}}
            ]
          },
          {component: "col", props:{cols:12, ":xl":"getCols", ":lg":"getCols", ":md":"getCols"},
            class:{body:"{'py-0':isReadOnly }"}, contents: [
            {component: "dateField", ensureDate: true, userData:{id:"dateOfBirth", model:"dateOfBirth"}, 
              props:{dense:false, ":value":"dateOfBirth", ":readonly":"isReadOnly", 
              label:"Date of Birth", "hide-details":true}},
            {component: "textField", userData:{id:"phone", model:"phone"}, props:{dense:false, ":value":"phone", ":readonly":"isReadOnly", 
              label:"Phone", "hide-details":true}},
            {component: "textField", userData:{id:"email", model:"email"}, props:{dense:false, ":value":"email", ":readonly":"isReadOnly",
              label:"Email", "hide-details":true}},
            {component: "textField", userData:{id:"city", model:"city"}, 
              props:{dense:false, ":value":"city", ":readonly":"isReadOnly", 
              label:"City", "hide-details":true}}
            ]
          },
        ]}
    ]
  }
};
