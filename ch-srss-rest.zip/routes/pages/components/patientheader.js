

const dataModel = {
};
const uiMethods = {
};
const props = {

}
const computed = {
  getCols: {
    body: `
      return this.showAddress?3:4;
    `
  },
  fmtPhone: {
    body: `
    debugger;
    return this.$options.filters.formattedPhone(this.patient.contactInfo.phone);`
  },
  fmtPatientSSN: {
    body: `
    return ''; //this.$options.filters.formattedSSN(this.patient.ssn);`
  },
  dateOfBirth: {
    body: `
    return moment(this.patient.dateOfBirth).format('l');`
  }
};

export default {
  requiredUserData: [],
  dataModel:dataModel,
  uiMethods: uiMethods,
  computed:computed,
  props: props,
  uiSchema: {
    component: "container", class:"justify-space-around justify-stretch px-5 py-2 mb-3", style:"background-color:#F0F0F0", contents: [
      {component: "row", class:"justify-space-around justify-stretch px-5 py-2 mb-3", style:"background-color:#F0F0F0", contents:[
          {component: "col", props:{cols:12, xl:"this.getCols", lg:"this.getCols", md:"this.getCols"},
            class:{body:"return {'py-0':this.isReadOnly }"}, contents: [
            {component: "textField", props:{dense:true, value:"this.patient.patientId", readonly:"this.isReadOnly", 
              label:"Patient Id","hide-details":true}},
            {component: "textField", props:{dense:true, value:"this.patient.lastName", readonly:"this.isReadOnly", 
              label:"Last Name", "hide-details":true}},
            {component: "textField", props:{dense:true, value:"this.patient.firstName", readonly:"this.isReadOnly",
              label:"First Name", "hide-details":true}},
            {component: "textField", props:{dense:true, value:"this.patient.ssn", readonly:"this.isReadOnly", 
              label:"SSN", "hide-details":true}}
            ]
          },
          {component: "col", props:{cols:12, xl:"this.getCols", lg:"this.getCols", md:"this.getCols"},
            class:{body:"return {'py-0':this.isReadOnly }"}, contents: [
            {component: "textField", props:{dense:true, value:"this.patient.dateOfBirth", readonly:"this.isReadOnly", 
              label:"Date of Birth","hide-details":true}},
            {component: "textField", props:{dense:true, value:"this.patient.contractInfo.phone", readonly:"this.isReadOnly", 
              label:"Phone", "hide-details":true}},
            {component: "textField", props:{dense:true, value:"this.patient.contactInfo.email", readonly:"this.isReadOnly",
              label:"Email", "hide-details":true}},
            {component: "textField", props:{dense:true, value:"this.patient.contactInfo.city", readonly:"this.isReadOnly", 
              label:"City", "hide-details":true}}
            ]
          },
        ]}
    ]
  }
};
