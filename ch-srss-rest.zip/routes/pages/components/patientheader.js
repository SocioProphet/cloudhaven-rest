

const dataModel = {
}
const uiMethods = {
  valueOrOneSpace: {
    args: ["val"],
    body: `return val || ' ';`
  },
  mounted: {
    body: `
    if (this.patient) {
      this.loadUser( this.patient.cloudHavenUserId );
    }`
  },
  loadUser: {
    args: ["userId"],
    body: `
    if (userId) {
      this._getUserData(userId);
      if (!this.patient.contactInfo.city) this.patient.contactInfo.city = " ";
      if (this.patient.contactInfo.email) this.patient.contactInfo.email = " ";
      if (this.patient.contactInfo.phone) this.patient.contactInfo.phone = " ";
      if (this.patient.ssn) this.patient.ssn = " ";

    }`
  },
  
};
const watch = {
  'patient.cloudHavenUserId': {
    args: ["val"],
    body: `
    this.loadUser(val);
    `
  }
}
const filters = {
  formattedPhone: {
    args: ["value"],
    body: `
    if (!value) return '';
    var rawPhone = value.replace(/[( )-.]/g, '');
    if (rawPhone.length==10) {
      return '('+rawPhone.substring(0,3)+') '+rawPhone.substring(3,6)+'-'+rawPhone.substring(6);
    } else if (rawPhone.length==7) {
      return rawPhone.substring(0,3)+'-'+rawPhone.substring(3);
    } else {
      return rawPhone;
    }`
  },
  formattedSSN: {
    args: ["value"],
    body: `
    if (!value) return '';
    if (value.length!=9) return value;
    return value.substring(0,3)+'-'+value.substring(3,5)+'-'+value.substring(5);
    `
  }
}
const computed = {
  userId: {
    body: `
      return this.patient?this.patient.cloudHavenUserId:'';
    `
  },
  getCols: {
    body: `
    console.log('getcols, showAddress: '+this.showAddress);
      return this.showAddress?3:4;
    `
  },
  fmtPhone: {
    body: `
    return this.$options.filters.formattedPhone(this.patient.contactInfo.phone);`
  },
  fmtPatientSSN: {
    body: `
    return ''; //this.$options.filters.formattedSSN(this.patient.ssn);`
  },
  dateOfBirth: {
    body: `
    return moment(this.patient.dateOfBirth).format('l');`
  }
};
const props = {
  isReadOnly: { type: "Boolean"},
  patient: { type: "Object"},
  showAddress: {type: "Boolean"}
};

export default {
  name:"PatientHeader",
  requiredUserData: [],
  props:props,
  dataModel:dataModel,
  uiMethods: uiMethods,
  computed:computed,
  filters:filters,
  watch: watch,
  uiSchema: {
    component: "container", class:"justify-space-around justify-stretch px-5 py-2 mb-3", style:"background-color:#F0F0F0", contents: [
      {component: "row", class:"justify-space-around justify-stretch px-5 py-2 mb-3", style:"background-color:#F0F0F0", contents:[
          {component: "col", props:{cols:12, ":xl":"getCols", ":lg":"getCols", ":md":"getCols"},
            class:{body:"{'py-0':isReadOnly }"}, contents: [
            {component: "textField", props:{dense:false, ":value":"patient.patientId", 
              ":readonly":"isReadOnly", label:"Patient Id","hide-details":true}},
            {component: "textField", userData:{id:"lastName", model:"patient.lastName"}, 
              props:{dense:false, ":value":"patient.lastName", 
              ":readonly":"isReadOnly", label:"Last Name", "hide-details":true}},
            {component: "textField", userData:{id:"firstName", model:"patient.firstName"},
              props:{dense:false, ":value":"patient.firstName", 
              ":readonly":"isReadOnly", label:"First Name", "hide-details":true}},
            {component: "textField", userData:{id:"ssn", model:"patient.ssn"}, props:{dense:false, ":value":"patient.ssn",
              ":readonly":"isReadOnly", label:"SSN", "hide-details":true}}
            ]
          },
          {component: "col", props:{cols:12, ":xl":"getCols", ":lg":"getCols", ":md":"getCols"},
            class:{body:"{'py-0':isReadOnly }"}, contents: [
            {component: "dateField", userData:{id:"dateOfBirth", model:"patient.dateOfBirth"}, 
              props:{dense:false, ":value":"patient.dateOfBirth", ":readonly":"isReadOnly", 
              label:"Date of Birth", "hide-details":true}},
            {component: "textField", userData:{id:"phone", model:"patient.contactInfo.phone"}, props:{dense:false, ":value":"patient.contactInfo.phone", ":readonly":"isReadOnly", 
              label:"Phone", "hide-details":true}},
            {component: "textField", userData:{id:"email", model:"patient.contactInfo.email"}, props:{dense:false, ":value":"patient.contactInfo.email", ":readonly":"isReadOnly",
              label:"Email", "hide-details":true}},
            {component: "textField", userData:{id:"city", model:"patient.contactInfo.city"}, 
              props:{dense:false, ":value":"patient.contactInfo.city", ":readonly":"isReadOnly", 
              label:"City", "hide-details":true}}
            ]
          },
        ]}
    ]
  }
};
