export default {
  'Bill Patient': {name:"billpatient", label:"Bill Patient"},
  'Bill Primary Payer': {name:"billpayer", label:"Bill Primary Payer", params:{payerType:'Primary Payer'}},
  'Bill Secondary Payer': {name:"billpayer", label:"Bill Secondary Payer", params:{payerType:'Secondary Payer'}},
  'Book Confirmed Date': {name:"patientcase", label:"Book Confirmed Date", params:{isForConfirmingBooking: true}},
  'Disburse Payments': {name:"paymentdisbursements", label:"Disburse Payments"},
  'Need Payer Authorization': {name:"getpayerauthorization", label:"Get Payer Authorization", params:{payerType:'Primary Payer'}},
  'Need Secondary Payer Authorization': {name:"getpayerauthorization", label:"Get Payer Authorization", params:{payerType:'Secondary Payer'}},
  'Payer Info Required': {name:"casepayerinfo", label:"Get Payer Info"},
  'Need Patient Acceptance': {name:"patientacceptance", label:"Get Patient Acceptance"},
  'Patient Payment Due': {name:"receivepayment", params:{payerType:'Patient'}, label:"Receive Patient Payment"},
  'Primary Payer Payment Due': {name:"receivepayment", params:{payerType:'Primary Payer'}, label:"Receive Primary Payer Payment"},
  'Secondary Payer Payment Due': {name:"receivepayment", params:{payerType:'Secondary Payer'}, label:"Receive Secondary Payer Payment"},
  'Awaiting Surgery': {name:"surgerycompleted", label:"Complete Surgery"},
  'Needs Tentative Scheduling': {name:"patientcaseform", params:{mode:'edit'}, label:"Schedule Tentative Service Date"}
}
