export default {
  'Bill Patient': {name:"billPatient", label:"Bill Patient"},
  'Bill Primary Payer': {name:"billPayer", label:"Bill Primary Payer", params:{payerType:'Primary Payer'}},
  'Bill Secondary Payer': {name:"billPayer", label:"Bill Secondary Payer", params:{payerType:'Secondary Payer'}},
  'Book Confirmed Date': {name:"patientCase", label:"Book Confirmed Date", params:{isForConfirmingBooking: true}},
  'Disburse Payments': {name:"paymentDisbursements", label:"Disburse Payments"},
  'Need Payer Authorization': {name:"getPayerAuthorization", label:"Get Payer Authorization", params:{payerType:'Primary Payer'}},
  'Need Secondary Payer Authorization': {name:"getPayerAuthorization", label:"Get Payer Authorization", params:{payerType:'Secondary Payer'}},
  'Payer Info Required': {name:"casePayerInfo", label:"Get Payer Info"},
  'Need Patient Acceptance': {name:"patientAcceptance", label:"Get Patient Acceptance"},
  'Patient Payment Due': {name:"receivePayment", params:{payerType:'Patient'}, label:"Receive Patient Payment"},
  'Primary Payer Payment Due': {name:"receivePayment", params:{payerType:'Primary Payer'}, label:"Receive Primary Payer Payment"},
  'Secondary Payer Payment Due': {name:"receivePayment", params:{payerType:'Secondary Payer'}, label:"Receive Secondary Payer Payment"},
  'Awaiting Surgery': {name:"surgeryCompleted", label:"Complete Surgery"},
  'Needs Tentative Scheduling': {name:"patientCase", params:{mode:'edit'}, label:"Schedule Tentative Service Date"}
}
