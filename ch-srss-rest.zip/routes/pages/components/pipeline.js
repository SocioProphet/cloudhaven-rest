

import workflowRouteMap from './workflowRouteMap'

const dataModel = {
  isMounted: false,
  caseIdFilter:'',
  pagination: {
    sortBy: ['patient.name'],//'caseId'
    sortDesc: [true],
    page: 1,
    itemsPerPage: 10
//        totalItems: pipelineRows.length
  },
  headers: [
    { text: 'Case #', value: 'caseId', sortable:true, align:'left' },
    { text: 'Last Name', value: 'patient.lastName', sortable:true, align:'left' },
    { text: 'First Name', value: 'patient.firstName', sortable:true, align:'left' },
    { text: 'Procedure', value: 'procedure.name', sortable:true, align:'left' },
    { text: 'Surgery Center', value: 'surgeryCenter.name', sortable:true, align:'left' },
    { text: 'Action Required', value: 'workflowAction', sortable:true, align:'left' },
    { text: 'Service Date', value: 'dateOfService', sortable:true, align:'left' }
  ],
  pipelineData: [],
  workflowRouteMap:workflowRouteMap,
  userFieldMap: {
    firstName:"patient.firstName",
    lastName:"patient.lastName"
  }
};
const uiMethods = {
  mounted: {
    body: `
/*    var jsonPipelineSettings = this.$store.getters.getUserSetting('pipeline');
    if (jsonPipelineSettings) {
      var pagination = JSON.parse(jsonPipelineSettings);
      if (!Array.isArray(pagination.sortBy)) {
        pagination.sortBy = ['patient.name'];
      }
      if (!Array.isArray(pagination.sortDesc)) {
        pagination.sortDesc = [false];
      }
      this.pagination.sortBy = pagination.sortBy?pagination.sortBy:['caseId'];
      this.pagination.sortDesc = pagination.sortDesc?pagination.sortDesc:[false];
      this.pagination.itemsPerPage = pagination.itemsPerPage?pagination.itemsPerPage:5;
      this.pagination.page = pagination.page?pagination.page:1;
    }
    if (!this.$store.getters.currentRole) return;*/

    this._eventBusOn('pipeline updated', () => {
      var rows = this.pipelineData.reduce((ar,patientCase)=>{
        patientCase.workflowStates.forEach((workflowState)=>{
          if (workflowState!='Disburse Payments' /*|| (this.user.rolesMap['AP'] || this.user.rolesMap['BMCSYSADMIN'])*/) {
            var label = this.workflowRouteMap[workflowState].label;
            var row = Object.assign({workflowState:workflowState, workflowAction:label}, patientCase);
            ar.push(row);
          }
        })
        return ar;
      },[]);
/*      var maxPage = Math.trunc((rows.length-1)/this.pagination.itemsPerPage)+1;
      if (this.pagination.page > maxPage) {
        this.pagination.page = maxPage;
        this.$store.commit('SET_USER_SETTING', {setting:'pipeline', value:JSON.stringify(this.pagination)});
      }*/
    })
    this.loadPipeline();
    this._eventBusOn('refresh-pipeline', ()=>{
      this.loadPipeline();
    });
/*    setInterval(()=>{
      this.loadPipeline();
    }, 65000);*/
    this.isMounted = true;
  `
  },
  refresh: {
    body: `this.loadPipeline();`
  },
  updatePagination: {
    args: ["pagination"],
    body: `
    if (!this.isMounted) return;
//    this.$store.commit('SET_USER_SETTING', {setting:'pipeline', value:JSON.stringify(pagination)});
    `
  },
  loadPipeline: {
    body: `
    this._appPost('pipeline', {}, (data)=>{
      var dataList = [].concat(data);
      var userIds = dataList.map(p=>(p.patient.cloudHavenUserId));
      this._getUserDataForList (userIds, dataList, 'patient.cloudHavenUserId', this.userFieldMap, () => {
        this.pipelineData = dataList;
      });
    })
    `
  },
  changeSort: {
    args: ["column"],
    body: `
    if (this.pagination.sortBy[0] === column) {
      this.pagination.sortDesc[0] = !this.pagination.sortDesc[0]
    } else {
      this.pagination.sortBy = [column]
      this.pagination.sortDesc = [false]
    }`
  },
  doWorkflowAction: {
    args: ["item"],
    body: `
    var workflowState = item.workflowState;
    var patientCaseId = item._id;
    var caseId = item.caseId;
    var params = Object.assign(this.workflowRouteMap[workflowState].params||{}, {patientCaseId:patientCaseId, caseId });
    this._gotoAppPage( this.workflowRouteMap[workflowState].name, params );
    `
  },
  setRole: {
    args: ["val"],
    body: `
//    this.$store.commit('SET_ROLE', val);
    this.loadPipeline();
    `
  }
};
const computed = {
  roleOptions: {
    body: `
    const roleLabelMap = {
      BMCSYSADMIN: 'All',
      SCHEDULER: 'Scheduler',
      FCM: 'Financial Case Manager',
      AUTHMGR: 'Authorizing Manager',
      AR:'A/R',
      AP:'A/P',
      VENDOR: 'Vendor',
      VENDOR_ASSOCIATE: 'Vendor Associate',
      CONTRACTED_PAYER: 'Contracted Payer',
      CLAIMS_PAYER: 'Claims Payer',
      AUTHORIZING_PAYER: 'Authorizing Payer'
    };
    return /*this.user.roles*/Object.keys(roleLabelMap).map((r)=>{return {value:r, text:roleLabelMap[r]};});
    `
  },
  pipelineRows: {
    body: `
    return this.pipelineData.reduce((ar,patientCase)=>{
      patientCase.workflowStates.forEach((workflowState)=>{
        if (workflowState!='Disburse Payments' /*|| (this.user.rolesMap['AP'] || this.user.rolesMap['BMCSYSADMIN'])*/) {
          var label = this.workflowRouteMap[workflowState].label;
          if (workflowState == 'Need Payer Authorization') {
            label = 'Get Primary Payer Authorization';
          } else if (workflowState == 'Need Secondary Payer Authorization') {
            label = 'Get Secondary Payer Authorization';
          }
          var row = Object.assign({workflowState:workflowState, workflowAction:label}, patientCase);
          ar.push(row);
        }
      })
      return ar;
    },[]);`
  },
  filteredRows: {
    body: `
    return this.pipelineRows.filter((r)=>{return (this.caseIdFilter==''||r.caseId.indexOf(this.caseIdFilter)==0)});`
  }
};
const filters = {
  date: {
    args: ["value"],
    body: `
    return value?this._moment(value).format('l'):'';
    `
  }
}
export default {
  name: "Pipeline",
  props: {},
  requiredUserData: [],
  dataModel:dataModel,
  uiMethods: uiMethods,
  computed:computed,
  filters: filters,
  uiSchema: {
    component: "div", contents:[
      {
        component: 'dataTable',
        props: {":headers":"headers", ":items":"filteredRows", "item-key":"caseId", 
          ":options":"pagination"}, class:"elevation-2", on:{"update:options":"updatePagination"},
        scopedSlots: {
          item: {
            component: "tr", style:"cursor:pointer",
            on: {"click.stop": "doWorkflowAction( item )"},
            contents:[
              {component: 'template', template: "<td>{{ item.caseId}}</td>" },
              {component: 'template', template: "<td>{{ item.patient.lastName}}</td>" },
              {component: 'template', template: "<td>{{ item.patient.firstName}}</td>" },
              {component: 'template', template: "<td>{{ item.procedure.name}}</td>" },
              {component: 'template', template: "<td>{{ item.surgeryCenter.name}}</td>" },
              {component: 'template', template: "<td>{{ item.workflowAction}}</td>" },
              {component: 'template', template: "<td>{{ item.dateOfService | date }}</td>" }
            ]
          },
          top: {
            component: "row", class:"align-center justify-space-between", contents: [
              {component: "col", class:"pt-0 ml-2", contents: [
                {component: "button", props:{rounded:true, color:"#FFF10E"}, on:{click:"refresh"}, contents: [
                  {component: "icon", props:{left:true, light:true}, class:"ml-2 mr-1", contents:"mdi-refresh"},
                  "Refresh"]}
              ]},
              /*<v-col>
                <v-form>
                  <v-select :items="roleOptions" hint="Select Role" class="mb-0 pb-0" @input="setRole" :value="$store.getters.currentRole" label="Role"></v-select>
                </v-form>
              </v-col>*/
              {component: "col", contents: [
                {component: "form", contents: [
                  {component: "textField", vmodel:"caseIdFilter", props:{label:"Case Id Filter", class:"ma-0"}}
                ]}
              ]}
            ]
          }
        }
      }
    ]
  }
};
