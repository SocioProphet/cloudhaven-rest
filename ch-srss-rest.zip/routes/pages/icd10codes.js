



const dataModel = {
  dialog: false,
  valid: true,
  headers: [
    { text: 'Actions', value: 'name', sortable: false, align:'center' },
    {
      text: 'Code',
      align: 'left',
      sortable: true,
      value: 'code'
    },
    { text: 'Description', align:'left', sortable:true, value: 'description' }
  ],
  editedIndex: -1,
  editedItem: {
    code: '',
    description: ''
  },
  icd10Codes: []
};
const uiMethods = {
  mounted: {
    body: `
    this.loadIcd10Codes();
    `
  },
  resetEditObject: {
    body: `this.editedItem = {code: '', description: ''}; this.editedIndex = -1; `
  },
  loadIcd10Codes: {
    body: `
    this._appGet('icd10codes/list', function(data) {
      this.icd10Codes = data;
    })
    `
  },
  required: {
    args: ["v"],
    body: `
    return !!v || "Required."
    `
  },
  editItem: {
    args: ["item"],
    body: `
    this.editedIndex = this.icd10Codes.indexOf(item)
    this.editedItem = Object.assign({}, item)
    if (!this.editedItem._id) {
      this.$refs.form.reset()
    }
    this.dialog = true;
    `
  },
  deleteItem: {
    args: ["item"],
    body: `
    confirm('Are you sure you want to delete '+item.code+'?') && 
      this._appPost('icd10codes', {op:'delete', id:item._id}, function(){
        this._showNotification( item.code + ' deleted.');
        this.loadIcd10Codes();
      })
    `
  },
  cancel: {
    body: `
    this.dialog = false;`
  },
  close: {
    body: `
    setTimeout(() => {
      this.resetEditObject();
    }, 300)`
  },
  save: {
    body: `
    if (!this.valid) return;
    this._appPost('icd10codes', {op:this.editedIndex > -1?'update':'create', data:this.editedItem}, function(result) {
      if (result.errMsg) {
        this._showError( 'ICD10 Code ('+this.editedItem.code+'): '+result.errMsg );
      } else {
        this._showNotification( this.editedItem.code+' '+(this.editedIndex > -1?'updated':'added')+'.');
        this.loadIcd10Codes();
      }
      this.dialog = false;
    });
    `
  }
};
const computed = {
  formTitle: {
    body: "return this.editedIndex === -1 ? 'New ICD10 Code' : 'Edit ICD10 Code'"
  }
};

const uiConfig = {
  requiredUserData: [],
  dataModel:dataModel,
  uiMethods: uiMethods,
  computed:computed,
  uiSchema: {
    component: 'container',
    props: {fluid:true},
    contents: [
      {
        component: 'toolbar',
        props: {flat:true, color:'white'},
        contents: [
          {component: 'toolbarTitle', contents:"ICD10 Codes"},
          {component: 'divider', props:{insert:true, vertical:true}, attrs:{class:'mx-3'}},
          {component: 'spacer'},
          {component: 'button', props:{dark:true, color:'primary'}, class:'mb-3', contents:"New ICD10 Code",
        on:{click:{body:`resetEditObject(), dialog=true;`}}}
        ]
      },
      {
        component: 'dataTable',
        props: {":headers":"headers", ":items":"icd10Codes", "hide-default-footer":true, "disable-pagination":true},
        class:"elevation-1",
        scopedSlots: {
          item: {
            component: "tr",
            on: {
              click: {eventModifier: "stop", body: "editItem(item)"}  
            },
            contents:[
              { component:'td', 
                class:"d-flex justify-center align-center px-0",
                contents: [
                  {
                    component: "button", props:{icon:true},
                    contents: [{
                      component:"icon",
                      props:{medium:true},
                      on: {
                        click: {eventModifier: "stop", body: "editItem(item)"}  
                      },
                      contents:"mdi-pencil"
                    }]
                  },
                  {
                    component: "button", props:{icon:true},
                    contents: [{
                      component:"icon",
                      props:{medium:true},
                      on: {
                        click: {eventModifier: "stop", body: "deleteItem(item)"}  
                      },
                      contents:"mdi-trash-can"
                    }]
                  }
                ]
              },
              {component: 'template', template:"<td>{{item.code}}</td>"},
              {component: 'template', template:"<td>{{item.description}}</td>"}
            ]
          }
        }
      },
      {
        component: 'dialog',
        vmodel: 'dialog',
        style: 'background-color:white;',
        props: {"max-width":"500px"},
        on: {keydown:{args:["event"], body:`if (event.keyCode==27) { dialog=false; event.preventDefault(); }`}},
        contents: {
          component: "card",
          contents: [
            { component: "cardTitle", template: '<span class="text-h5">{{ formTitle }}</span>'},
            { component: "cardBody", contents: {
                component: "form",
                vmodel: "valid",
                contents: [
                  {
                    component: "textField",
                    vmodel:"editedItem.code",
                    props: {label:"Code"},
                    attrs: {required:true},
                    rules:[
                      "required",
                      { args:["v"], body: 'return /^[A-TV-Z][0-9][A-Z0-9](\.?[A-Z0-9]{0,4})?$/.test(v) || "Please enter a valid ICD10 code. "'}
                    ]
                  },
                  {
                    component: "textField",
                    vmodel:"editedItem.description",
                    props: {label:"Description"}
                  }
                ]
            }},
            {
              component: "cardActions",
              contents: [
                { component: "button", props:{elevation:"2", color:"blue darken-1", text:true}, on: {click:"cancel"}, contents:"Cancel" },
                { component: "spacer"},
                { component: "button", props:{elevation:"2", color:"blue darken-1", text:true}, on: {click:"save"},
                  contents:[{component:"icon", props:{left:true, dark:true}, contents:"mdi-content-save"}, 
                  "Save"
                ] }
              ]
            }
          ]
        }
      }
    ]
  }
};

import BaseAction from '../actions/baseaction'
import Roles from '../../models/workflowroles'
export class ICD10CodesPage extends BaseAction{
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.Scheduler];
  }
  
  route() {

    this.router.get("/", (req, res) => {
      res.json(uiConfig)
    });

    return this.router;
  }
}
