const dataModel ={
  error: '',
  errMsg: '',
  response: '',
  notesEntry: '',
  formTitle: 'Get Patient Acceptance',
  patientCase: {
    patient:{
      contactInfo:{
        preferredContactMethod:'',
        email: '',
        textPhone: '',
        phone: ''
      }
    }, payerInfo:{}, primaryPayer:{}, secondaryPayer:{}, procedure:{}, notesLog:[]},
};
const filters = {
  formattedNumber: {
    args: ["value", "decimalPlaces"],
    body: `
    decimalPlaces = decimalPlaces || 2;
    if (value == undefined || value===null || value==='') return '';
    var val = value.toLocaleString(undefined, {minimumFractionDigits: decimalPlaces||0, maximumFractionDigits: decimalPlaces||0});
    return val;`
  }
};
const computed = {
  fmtTotalDueFromPatient: {
    body:`
    return this.$options.filters.formattedNumber(this.patientCase.totalDueFromPatient);`
  },
  fmtPayer1ContractedRate: {
    body: `
    return this.$options.filters.formattedNumber(this.patientCase.primaryPayer.contractedRate);`
  },
  cancelDone: {
    body: `
    return this.response?'Done':'Go Back';`
  }
};

const uiMethods = {
  created: {
    body:`
    if (this._appParams.patientCaseId) {
      this._appGet('patientacceptance/'+this._appParams.patientCaseId, (response)=>{
        this.patientCase = response;
        this._getUserData(this.patientCase.patient.cloudHavenUserId, this.patientCase.patient, 
          {
            name: 'name',
            "contactInfo.preferredContactMethod":"preferredContactMethod",
            "contactInfo.email":"email",
            "contactInfo.textPhone": "textPhone",
            "contactInfo.phone": "phone"
          }
        );

//        this.$root.$emit('alerts available', this.patientCase.alerts.filter(a=>(!a.dismissed)));
      });
    } else {
      this._gotoAppPage('home')
    }`
  },
  accept: {
    body:`
    this.response = 'accept';
    this.submit('accept');`
  },
  refuse: {
    body:`
    this.response = 'refuse';
    this.submit('refuse')`
  },
  submit: {
    args: ["action"],
    body:`
      this._appPost('patientacceptance', {patientCaseId:this.patientCase._id, action:action, notesEntry: this.notesEntry}, (response)=>{
        if (response.success) {
          this._showNotification('Case '+this.patientCase.caseId+' patient acceptance recorded.');
          this._gotoAppPage('home');
        } else if (response.errMsg) {
          this._showError( response.errMsg );
        }
      });`
  },
  cancelForm: {
    body:`
    if (this._appParams.from == 'patientCase') {
      this._gotoAppPage('patientcase', {patientCaseId:this.$route.params.patientCaseId});
    } else {
      this._routerGoBack();
    }`
  }
}

const uiConfig = {
  requiredUserData: [],
  dataModel:dataModel,
  uiMethods: uiMethods,
  filters: filters,
  computed:computed,
  uiSchema:
  {
    component: "div", contents: [
      {component: "container", contents: [
        {component: "card", contents: [
          {component: "cardTitle", template: '<span class="text-h5">{{ formTitle }}</span>'},
          {component: "cardText", contents: [
            {component: "form", ref:"form", props:{"lazy-validation":true}, contents: [
              {component: "row", class:"justify-space-between align-start align-content-start fill-height flex-wrap", contents: [
                {component: "hover", scopedSlots:{
                  default: {
                    component: "col", props:{cols:12, sm:10, md:5, lg5:true}, contents: [
                      {component: "textField", props:{dense:true, readonly:true, ":value":"patientCase.patient.name",
                        label:"Patient Name"}},
                      {component: "div", show:"hover", style:"position:absolute; top:-30px; left:70px; padding:2px;", contents:[
                        {component: "card", props:{color:"white", elevation:8}, contents: [
                          {component: "cardText", template:"<div>{{patientCase.patient.contactInfo.fullAddress}}<br/>{{patientCase.patient.contactInfo.phone | formattedPhone}}</div"
                          }
                        ]}
                      ]}
                    ], style:"position:relative"}
                  }
                },
                {component: "col", props:{ cols:12, sm:10, md:5, lg:5}, contents: [
                  {component: "textField", props:{dense:true, readonly:true, ":value":"patientCase.caseId", label:"Patient Case"}},
                ]},
                {component: "col", props:{ cols:12, sm:10, md:5, lg:5}, contents: [
                  {component: "textField", props:{dense:true, readonly:true, ":value":"patientCase.procedure.name", label:"Procedure"}},
                ]},
                {component: "col", props:{ cols:12, sm:10, md:5, lg:5}, contents: [
                  {component: "textField", props:{dense:true, readonly:true, ":value":"fmtPayer1ContractedRate", label:"Treatment Cost"}},
                ]},
                {component: "col", props:{ cols:12, sm:10, md:5, lg:5}, contents: [
                  {component: "textField", props:{dense:true, readonly:true, ":value":"patientCase.patient.contactInfo.preferredContactMethod", label:"Preferred Contact Method"}},
                ]},
                {component: "col", props:{ cols:12, sm:10, md:5, lg:5}, contents: [
                  {component: "textField", props:{dense:true, readonly:true, ":value":"patientCase.patient.contactInfo.email||' '", label:"Patient Email"}},
                ]},
                {component: "col", props:{ cols:12, sm:10, md:5, lg:5}, contents: [
                  {component: "textField", props:{dense:true, readonly:true, ":value":"(patientCase.patient.contactInfo.phone||' ') /*| formattedPhone*/", label:"Patient Phone"}},
                ]},
                {component: "col", props:{ cols:12, sm:10, md:5, lg:5}, contents: [
                  {component: "textField", props:{dense:true, readonly:true, ":value":"(patientCase.patient.contactInfo.textPhone||' ') /*| formattedPhone*/", label:"Patient Mobile"}},
                ]},
                {component: "col", props:{ cols:12, sm:10, md:5, lg:5}, contents: [
                  {component: "textField", props:{readonly:true, ":value":"fmtTotalDueFromPatient", label:"Patient Amount Due"}},
                ]},
              ]},
              {component: "row", class:"justify-space-around flex-wrap py-0", contents: [
                {component: "col", props:{ cols:12, sm:10, md:5, lg:5}, class:"py-0", contents: [
                  {component: "textarea", vmodel:"notesEntry", props:{label:"Additional Notes", "hide-details":true}, class:"mb-1 pt-0"}
                ]},
              ]}
            ]}
          ]},
          { component: "cardActions", contents: [
            {component: "button", props:{elevation:2, color:"blue darken-1", text:true}, on:{click:"cancelForm()"}, contents: [
              {component: "icon", props:{left:true, dark:true}, contents:"mdi-arrow-left"},
              {component: "template", template:"<span>{{cancelDone}}</span>"},
            ]},
            {component: "spacer"},
            {component: "button", props:{elevation:2, color:"blue darken-1", text:true, ":disabled":"response=='refuse'"},
              on:{click:"refuse()"}, contents: "Refuse"},
              {component: "spacer"},
              {component: "button", props:{elevation:2, color:"blue darken-1", text:true, ":disabled":"response=='accept'"},
                on:{click:"accept()"}, contents: "Accept"}
          ]}
        ]}//card
      ]} //container
    ] //div
  }
};


import BaseAction from '../actions/baseaction'
import Roles from '../../models/workflowroles'
export class GetPatientAcceptancePage extends BaseAction {
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.Scheduler];
  }
  
  route() {

    this.router.get("/", (req, res) => {
      res.json(uiConfig)
    });

    return this.router;
  }
}
