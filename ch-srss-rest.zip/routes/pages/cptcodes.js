
const dataModel = {
  dialog: false,
  valid: true,
  headers: [
    { text: 'Actions', value: 'name', sortable: false, align:'center' },
    {
      text: 'Code',
      align: 'left',
      sortable: true,
      value: 'code'
    },
    { text: 'Description', align:'left', sortable:true, value: 'description' }
  ],
  editedIndex: -1,
  editedItem: {
    code: '',
    description: ''
  },
  cptCodes: []
};
const uiMethods = {
  initialize: {
    body: `
    this.loadCptCodes();
    `
  },
  loadCptCodes: {
    body: `
    this._appGet('cptcodes/list', function(data) {
      this.cptCodes = data;
    })
    `
  },
  resetEditObject: {
    body: `this.editedItem = {code: '', description: ''}; this.editedIndex = -1; `
  },
  required: {
    args: ["v"],
    body: `
    return !!v || "Required."
    `
  },
  editItem: {
    args: ["item"],
    body: `
    this.editedIndex = this.cptCodes.indexOf(item)
    this.editedItem = Object.assign({}, item)
    if (!this.editedItem._id) {
      this.$refs.form.reset()
    }
    this.dialog = true;
    `
  },
  deleteItem: {
    args: ["item"],
    body: `
    confirm('Are you sure you want to delete '+item.code+'?') && 
      this._appPost('cptcodes', {op:'delete', id:item._id}, function(){
        this._showNotification( item.code + ' deleted.');
        this.loadCptCodes();
      })
    `
  },
  cancel: {
    body: `
    this.dialog = false;`
  },
  close: {
    body: `
    setTimeout(() => {
      this.editedItem = {code: '', description: ''}
      this.editedIndex = -1
    }, 300)`
  },
  save: {
    body: `
    if (!this.valid) return;
    this._appPost('cptcodes', {op:this.editedIndex > -1?'update':'create', data:this.editedItem}, function(result) {
      if (result.errMsg) {
        this._showError( 'CPT Code ('+this.editedItem.code+'): '+result.errMsg );
      } else {
        this._showNotification( this.editedItem.code+' '+(this.editedIndex > -1?'updated':'added')+'.');
        this.loadCptCodes();
      }
      this.dialog = false;
    });
    `
  }
};
const computed = {
  formTitle: {
    body: "return this.editedIndex === -1 ? 'New CPT Code' : 'Edit CPT Code'"
  }
};

const uiConfig = {
  requiredUserData: [],
  dataModel:dataModel,
  uiMethods: uiMethods,
  computed:computed,
  uiSchema: {
    component: 'container',
    props: {fluid:true},
    contents: [
      {
        component: 'toolbar',
        props: {flat:true, color:'white'},
        contents: [
          {component: 'toolbarTitle', contents:"CPT Codes"},
          {component: 'divider', props:{insert:true, vertical:true}, attrs:{class:'mx-3'}},
          {component: 'spacer'},
          {component: 'button', props:{dark:true, color:'primary'}, class:'mb-3', contents:"New CPT Code",
        on:{click:{body:`this.resetEditObject(); this.dialog=true;`}}}
        ]
      },
      {
        component: 'dataTable',
        props: {headers:"this.headers", items:"this.cptCodes", "hide-default-footer":true, "disable-pagination":true},
        class:"elevation-1",
        scopedSlots: {
          item: {
            component: "tr",
            on: {
              click: {eventModifier: "stop", method: "editItem", scopedProp:"item"}  
            },
            contents:[
              { component:'td', 
                class:"d-flex justify-center align-center px-0",
                contents: [
                  {
                    component: "button", props:{icon:true},
                    contents: [{
                      component:"icon",
                      props:{medium:true},
                      on: {
                        click: {eventModifier: "stop", method: "editItem", scopedProp:"item"}  
                      },
                      contents:"mdi-pencil"
                    }]
                  },
                  {
                    component: "button", props:{icon:true},
                    contents: [{
                      component:"icon",
                      props:{medium:true},
                      on: {
                        click: {eventModifier: "stop", method: "deleteItem", scopedProp:"item"}  
                      },
                      contents:"mdi-trash-can"
                    }]
                  }
                ]
              },
              {
                component: 'td',
                contentsAsScopedProp: "item.code"
              },
              {
                component: 'td',
                contentsAsScopedProp: "item.description"
              }
            ]
          }
        }
      },
      {
        component: 'dialog',
        vmodel: 'dialog',
        style: 'background-color:white;',
        props: {"max-width":"500px"},
        on: {keydown:{args:["event"], body:`if (event.keyCode==27) { this.dialog=false; event.preventDefault(); }`}},
        contents: {
          component: "card",
          contents: [
            { component: "cardTitle", template: '<span class="text-h5">{{ formTitle }}</span>'},
            { component: "cardBody", contents: {
                component: "form",
                vmodel: "valid",
                contents: [
                  {
                    component: "textField",
                    vmodel:"editedItem.code",
                    props: {label:"Code"},
                    attrs: {required:true},
                    rules:[
                      "required",
                      { args:["v"], body: 'return /^\d{5}(-[A-Z0-9]{2})?$/.test(v) || "Please enter a valid CPT code. "'}
                    ]
                  },
                  {
                    component: "textField",
                    vmodel:"editedItem.description",
                    props: {label:"Description"}
                  }
                ]
            }},
            {
              component: "cardActions",
              contents: [
                { component: "button", props:{elevation:"2", color:"blue darken-1", text:true}, on: {click:"cancel"}, contents:"Cancel" },
                { component: "spacer"},
                { component: "button", props:{elevation:"2", color:"blue darken-1", text:true}, on: {click:"save"},
                  contents:[{component:"icon", props:{left:true, dark:true}, contents:"mdi-content-save"}, 
                            {component:'span', contents:"Save"}
                ] },
              ]
            }
          ]
        }
      }
    ]
  }
};

import BaseAction from '../actions/baseaction'
import Roles from '../../models/workflowroles'
export class CPTCodesPage extends BaseAction{
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.Scheduler];
  }
  
  route() {

    this.router.get("/", (req, res) => {
      res.json(uiConfig)
    });

    return this.router;
  }
}
