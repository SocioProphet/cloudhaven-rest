



const dataModel = {
  dialog: false,
  valid: true,
  headers: [
    { text: 'Actions', value: 'name', sortable: false, align:'center' },
    {
      text: 'Code',
      align: 'left',
      sortable: true,
      value: 'code'
    },
    { text: 'Description', align:'left', sortable:true, value: 'description' }
  ],
  editedIndex: -1,
  editedItem: {
    code: '',
    description: ''
  },
  cptCodes: [{code:'XX', description:'zzz zzz zzz'}]
};
const uiMethods = {
  initialize: {
    body: `
    this._appGet('cptcodes/list', function(ui, data) {
      ui.cptCode = data;
    })`
  },
  required: {
    args: ["v"],
    body: `
    return !!v || "Required."
    `
  },
  editItem: {
    args: ["item"],
    body: `
    this.$store.commit('SET_RESULTNOTIFICATION', '')
    this.editedIndex = this.cptcodes.indexOf(item)
    this.editedItem = Object.assign({}, item)
    if (!this.editedItem._id) {
      this.$refs.form.reset()
    }
    this.dialog = true;
    `
  },
  deleteItem: {
    args: ["item"],
    body: `
    this.$store.commit('SET_RESULTNOTIFICATION', '')
    confirm('Are you sure you want to delete '+item.code+'?') && this.$store.dispatch('deleteRecord', {model:'cptcodes', dbObject:item, label:item.code});
    `
  },
  cancel: {
    body: `
    this.$store.commit('SET_RESULTNOTIFICATION', '');
    this.dialog = false;`
  },
  close: {
    body: `
    setTimeout(() => {
      this.editedItem = {code: '', description: ''}
      this.editedIndex = -1
    }, 300)`
  },
  save: {
    body: `
    if (!this.valid) return;
    ((this.editedIndex > -1)?
      this.$store.dispatch('updateRecord', {model:'cptcodes', dbObject:this.editedItem, label:'CPT Code '+this.editedItem.code}):
      this.$store.dispatch('createRecord', {model:'cptcodes', dbObject:this.editedItem, label:'CPT Code '+this.editedItem.code})).then((newRec)=> {
          if (newRec) {
            this.$store.commit('SET_SUCCESS', this.editedItem.code+' '+(this.editedIndex > -1?'updated':'added')+'.');
            this.dialog = false;
            this.$store.dispatch('loadRecords', 'cptcodes')
          }
      })`
  }
};
const computed = {
  formTitle: {
    body: "return this.editedIndex === -1 ? 'New CPT Code' : 'Edit CPT Code'"
  }
};

const uiConfig = {
  requiredUserData: [],
  dataModel:dataModel,
  uiMethods: uiMethods,
  computed:computed,
  uiSchema: {
    component: 'container',
    props: {fluid:true},
    contents: [
      {
        component: 'toolbar',
        props: {flat:true, color:'white'},
        contents: [
          {component: 'toolbarTitle', contents:"CPT Codes"},
          {component: 'divider', props:{insert:true, vertical:true}, attrs:{class:'mx-3'}},
          {component: 'spacer'},
          {component: 'button', props:{dark:true, color:'primary'}, class:'mb-3', contents:"New CPT Code",
        on:{click:{body:`this.dialog=true;`}}}
        ]
      },
      {
        component: 'dataTable',
        props: {headers:"this.headers", items:"this.cptCodes", "hide-default-footer":true, "disable-pagination":true},
        class:"elevation-1",
        scopedSlots: {
          item: {
            component: "tr",
            nativeOn: {
              click: {eventModifier: "stop", method: "editItem", scopedProp:"item"}  
            },
            contents:[
              { component:'td', 
                class:"d-flex justify-center align-center px-0",
                contents: [
                  {
                    component: "button", props:{icon:true},
                    contents: [{
                      component:"icon",
                      props:{medium:true},
                      on: {
                        click: {eventModifier: "stop", method: "editItem", scopedProp:"item"}  
                      },
                      contents:"mdi-pencil"
                    }]
                  },
                  {
                    component: "button", props:{icon:true},
                    contents: [{
                      component:"icon",
                      props:{medium:true},
                      on: {
                        click: {eventModifier: "stop", method: "deleteItem", scopedProp:"item"}  
                      },
                      contents:"mdi-trash-can"
                    }]
                  }
                ]
              },
              {
                component: 'td',
                contentsAsScopedProp: "item.code"
              },
              {
                component: 'td',
                contentsAsScopedProp: "item.description"
              }
            ]
          }
        }
      },
      {
        component: 'dialog',
        vmodel: 'dialog',
        props: {"max-width":"500px"},
        on: {keydown:{args:["event"], body:`if (event.keyCode==27) { this.dialog=false; event.preventDefault(); }`}},
        defaultSlot: {
          component: "card",
          defaultSlot: [
            { component: "cardTitle", template: '<span class="text-h5">{{ formTitle }}</span>'},
            { component: "cardBody", defaultSlot: {
                component: "form",
                vmodel: "valid",
                defaultSlot: [
                  {
                    component: "textField",
                    vmodel:"editedItem.code",
                    props: {label:"Code"},
                    attrs: {required:true},
                    rules:[
                      "required",
                      { args:["v"], body: 'return /^\d{5}(-[A-Z0-9]{2})?$/.test(v) || "Please enter a valid CPT code. "'}
                    ]
                  },
                  {
                    component: "textField",
                    vmodel:"editedItem.description",
                    props: {label:"Description"}
                  }
                ]
            }},
            {
              component: "cardActions",
              defaultSlot: [
                { component: "button", props:{elevation:"2", color:"blue darken-1", text:true}, nativeOn: "cancel", contents:"Cancel" },
                { component: "spacer"},
                { component: "button", props:{elevation:"2", color:"blue darken-1", text:true}, nativeOn: "save",
                  defaultSlot:[{component:"icon", props:{left:true, dark:true}, contents:"mdi-content-save"}, "Save"] },
              ]
            }
          ]
        }
      }
    ]
  }
};

import BaseAction from '../actions/baseaction'
import Roles from '../../models/workflowroles'
export class CPTCodesPage extends BaseAction{
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.Scheduler];
  }
  
  route() {

    this.router.get("/", (req, res) => {
      res.json(uiConfig)
    });

    return this.router;
  }
}


    /*this.router.get("/formSubmitted", (req, res) => {
      res.json(uiConfig2)
    });
    this.router.get("/formData", (req, res) => {
      res.json([
        {firstName:'Bob', lastName: 'Smith', address: '1234 Bob Street, Bob City, CA 99999'},
        {firstName:'Dave', lastName: 'Anderson', address: '9999 Dave Street, Some City, CA 99999'},
        {firstName:'Xaviar', lastName: 'Gomez', address: '7777 Xav Street, Gomez City, CA 99999'}
      ]);
    });

    this.router.post("/submitform", (req, res) => {
      console.log('Form data:\n'+JSON.stringify(req.body));
      res.json({success:true, newPage:'formSubmitted'})
    });*/

