
import stateList from '../../_helpers/stateList.js'

const dataModel = {
  valid: true,
  error: '',
  vm: this,
  formattedDateOfBirth: '',
  patient: {
    patientId: '',
    firstName: '',
    middleName: '',
    lastName: '',
    contactInfo: {
      preferredContactMethod: '',
      phone: '',
      email: '',
      fax: '',
      textPhone: '',
      attn: '',
      streetAddress: '',
      city: '',
      stateOrProvince: '',
      zipOrPostalCode: '',
      country: 'USA',
      language: 'English',
    },
    ssn: '',
    dateOfBirth: null,
    gender: '',
    notes: ''
  },
  patientSSN: ''
};
var stateListJSON = JSON.stringify(stateList);
const uiMethods = {
  initialize: {
    body: `
    this._appGet('oscsetup', function(data) {
      this.setup = data;
      this.patient.dateOfBirth = new Date();
      if (!this.setup.operatingProvider) this.setup.operatingProvider = {};
      this.vendorTypes = (this.setup.vendorTypes||[]).join("\\n");
      this.paymentMethods = (this.setup.paymentMethods||[]).join("\\n");
      this.stateOptions = JSON.parse('${stateListJSON}')
      if (/*this.$route.params.patientId*/false) {
        this._appGet('/patients/'+this.$route.params.patientId, function(response) {
          this.patient = response.record;
//          this.formattedDateOfBirth = moment(this.patient.dateOfBirth).format('MM/DD/YYYY');
          this.patientSSN =this.$options.filters.formattedSSN(this.patient.ssn);
        })();
      }
//      this._getUserData();
    });
  `
  },
  requiredRule: {
    args: ["v"],
    body: `
    return !!v || "Required."
    `
  },
  decimalNumberRule: {
    args: ["value"],
    body: `value => (value && /^(\d*\.)?\d+$/.test(value)) || 'Enter decimal number.'`
  },
  emailRule: {
    args: ["v"],
    body: `return !v || /^[^@]+@[^.]+\..+$/.test(v) || 'Please enter a valid email.'`
  },
  requiredObjectRule: {
    args: ["value"],
    body: `return (value && value._id!='') || 'Required.'`
  },
  nonNegative: {
    args: ["value"],
    body: `return value >= 0 || 'Enter non-negative number.'`
  },
  phoneRule: {
    args:["v"],
    body: `return !v || /^(?:(?:\+?1\s*(?:[.-]\s*)?)?(?:\(\s*([2-9]1[02-9]|[2-9][02-8]1|[2-9][02-8][02-9])\s*\)|([2-9]1[02-9]|[2-9][02-8]1|[2-9][02-8][02-9]))\s*(?:[.-]\s*)?)?([2-9]1[02-9]|[2-9][02-9]1|[2-9][02-9]{2})\s*(?:[.-]\s*)?([0-9]{4})(?:\s*(?:#|x\.?|ext\.?|extension)\s*(\d+))?$/.test(v) || 'Please enter a valid phone number.'`
  },
  ssnRule: {
    args: ["v"],
    body: `return !v || /^(?!666|000|9\\d{2})\\d{3}-(?!00)\\d{2}-(?!0{4})\\d{4}$/.test(v) || 'Enter a valid social security number.';`
  },
  lookupUser: {
    body:`
    this._lookupCloudHavenUser({email:this.patient.contactInfo.email}, function(user) {
      debugger;
      if (user) {
        //cloudHavenUserId set transparently by _lookupCloudHavenUser
        this.patient.firstName = user.firstName;
        this.patient.middleName = user.middleName;
        this.patient.lastName = user.lastName;
      }
    })
    `
  },
  save: {
    body: `
    debugger;
    this.valid = this.$refs.form.validate();
    if (!this.valid) return;
    if (!this.patient.contactInfo.email) {
      if (!confirm('No patient email has been entered, ok to save without their email?')) return;
    }
//    this.patient.dateOfBirth = this.$digitsToDate(this.formattedDateOfBirth);
    this.patient.ssn = (this.patientSSN||'').replace(/-/g, "");
    if (!this.patient.ssn) {
      if (!confirm('No patient SSN has been entered, ok to save without their SSN?')) return;
    }
  
    this.patient.cloudHavenUserId = this.cloudHavenUserId;
    this._appPost('patients', {op:/*this.$route.params.patientId?'update':*/'create', data:this.patient}, function(newPatient) {
      if (newPatient) {
        this._showNotification('Patient '+newPatient.patientId+' '+(/*this.$route.params.patientId*/false?'updated':'added')+'.')
        if (!false/*this.$route.params.patientId*/) {
          this._gotoAppPage('patientCase');
        } else {
          this._routerGoBack();
        }
      } else if (response.errMsg) {
        this._showError(response.errMsg)
      }
    })
  `
  },
  cancelForm: {
    body: `this._routerGoBack();`
  }
};
const computed = {
  stateOptions() {
    return stateList;
  }
};

const uiConfig = {
  requiredUserData: [],
  dataModel:dataModel,
  uiMethods: uiMethods,
  computed:computed,
  uiSchema: {
    component: "card", 
    contents: [
      {component: "cardTitle", template:'<span class="text-h5">Patient Form</span>'},
      {component: "cardBody", contents:[
        {component:"row", contents:[
          {component:"col", props:{cols:"12", md:"6", sm:"12"}, 
            contents:[{component:"form", ref:"form", vmodel:"valid", props:{"lazy-validation":true}, contents:[
            {component:"textField", vmodel:"patient.contactInfo.email", tokenId:"email", on:{blur:"lookupUser"},
              props:{type:"email", label:"Email", rules:['emailRule']}},
            {component:"textField", vmodel:"patientSSN", tokenId:"ssn", props:{label:"SSN", rules:["ssnRule"]}, mask:'###-##-####'},
            {component:"textField", ref:"firstField", vmodel:"patient.firstName", tokenId:"firstName", 
              props:{label:"First Name", rules:['requiredRule'] }},
            {component:"textField", vmodel:"patient.middleName", tokenId:"middleName", props:{label:"Middle Name"}},
            {component:"textField", ref:"lastName", vmodel:"patient.lastName", tokenId:"lastName", 
              props:{label:"Last Name", rules:['requiredRule'] }},
            {component:"dateField", vmodel:"patient.dateOfBirth", props:{maxlength:"10", label:"Date of Birth", rules:['requiredRule']},
              mask:'##/##/####'},
            {component:"select", vmodel:"patient.contactInfo.preferredContactMethod", tokenId:"preferredContactMethod", 
              props:{label:"Preferred Contact Method", items:["Phone", "Mobile", "Email"], rules:['requiredRule']}},
            {component:"select", vmodel:"patient.gender", tokenId:"gender", 
              props:{label:"Gender", items:["Male","Female","Non-binary"],rules:['requiredRule']}},
          ]}]},
          {component:"col", props:{cols:"12", md:"6", sm:"12"}, contents:[
            {component:"textField", vmodel:"patient.contactInfo.phone", tokenId:"phone", props:{label:"Home Phone"}},
            {component:"textField", vmodel:"patient.contactInfo.textPhone", tokenId:"textPhone", props:{label:"Mobile Phone"}},
            {component:"textField", vmodel:"patient.contactInfo.streetAddress", tokenId:"streetAddress", props:{label:"Street Address"}},
            {component:"textField", vmodel:"patient.contactInfo.city", tokenId:"city", props:{label:"City"}},
            {component: "select", vmodel:"patient.contactInfo.stateOrProvince",tokenId:"stateOrProvince", 
              props:{items:"this.stateOptions", "item-value":"abbreviation", "item-text":"name", label:"State/Province"}},
            {component:"textField", vmodel:"patient.contactInfo.zipOrPostalCode", tokenId:"zipOrPostalCode", 
              props:{label:"Zip/Postal Code", hint:"(Zip Code determines city and state)", "persistent-hint":true}},
            {component:"textField", vmodel:"patient.contactInfo.country", tokenId:"country", props:{label:"Country", "maxlength":3 }},
            {component:"select", vmodel:"patient.contactInfo.language", tokenId:"language", 
              props:{label:"Language", items:["English","Spanish"], rules:['requiredRule']}},
          ]},
        ]}
      ]},
      {
        component: "cardActions",
        contents: [
          { component: "button", props:{elevation:"2", color:"blue darken-1", text:true}, on: {click:"cancel"}, contents:"Cancel" },
          { component: "spacer"},
          { component: "button", props:{elevation:"2", color:"blue darken-1", text:true}, on: {click:"save"},
            contents:[{component:"icon", props:{left:true, dark:true}, contents:"mdi-content-save"}, 
                      {component:'span', contents:"Save"}
          ] },
        ]
      }
]
  }
};

import BaseAction from '../actions/baseaction'
import Roles from '../../models/workflowroles'
export class PatientEditPage extends BaseAction{
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.Scheduler];
  }
  
  route() {

    this.router.get("/", (req, res) => {
      res.json(uiConfig)
    });

    return this.router;
  }
}
