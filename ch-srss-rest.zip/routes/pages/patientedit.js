
import stateList from '../../_helpers/stateList.js'



const dataModel = {
  valid: true,
  error: '',
  vm: this,
  formattedDateOfBirth: '',
  patient: {
    firstName: '',
    lastName: '',
    contactInfo: {
      preferredContactMethod: '',
      phone: '',
      email: '',
      fax: '',
      textPhone: '',
      attn: '',
      streetAddress: '',
      city: '',
      stateOrProvince: '',
      zipOrPostalCode: '',
      country: 'USA',
      language: 'English',
    },
    ssn: '',
    dateOfBirth:'',
    gender: '',
    notes: ''
  },
  patientSSN: ''
};
var stateListJSON = JSON.stringify(stateList);
const uiMethods = {
  initialize: {
    body: `
    this._appGet('oscsetup', function(data) {
      this.setup = data;
      if (!this.setup.operatingProvider) this.setup.operatingProvider = {};
      this.vendorTypes = (this.setup.vendorTypes||[]).join("\\n");
      this.paymentMethods = (this.setup.paymentMethods||[]).join("\\n");
      this.stateOptions = JSON.parse('${stateListJSON}')
    });
  `
  },
  requiredRule: {
    args: ["v"],
    body: `
    return !!v || "Required."
    `
  },
  decimalNumberRule: {
    args: ["value"],
    body: `value => (value && /^(\d*\.)?\d+$/.test(value)) || 'Enter decimal number.'`
  },
  emailRule: {
    args: ["v"],
    body: `(v) => !v || /^[^@]+@[^.]+\..+$/.test(v) || 'Please enter a valid email.'`
  },
  requiredObjectRule: {
    args: ["value"],
    body: `return (value && value._id!='') || 'Required.'`
  },
  nonNegative: {
    args: ["value"],
    body: `return value >= 0 || 'Enter non-negative number.'`
  },
  phoneRule: {
    args:["v"],
    body: `return !v || /^(?:(?:\+?1\s*(?:[.-]\s*)?)?(?:\(\s*([2-9]1[02-9]|[2-9][02-8]1|[2-9][02-8][02-9])\s*\)|([2-9]1[02-9]|[2-9][02-8]1|[2-9][02-8][02-9]))\s*(?:[.-]\s*)?)?([2-9]1[02-9]|[2-9][02-9]1|[2-9][02-9]{2})\s*(?:[.-]\s*)?([0-9]{4})(?:\s*(?:#|x\.?|ext\.?|extension)\s*(\d+))?$/.test(v) || 'Please enter a valid phone number.'`
  },
  saveForm: {
    body: `
    `
  },
  cancelForm: {
    body: `this._routerGoBack();`
  }
};
const computed = {
  stateOptions() {
    return stateList;
  }
};

const uiConfig = {
  requiredUserData: [],
  dataModel:dataModel,
  uiMethods: uiMethods,
  computed:computed,
  uiSchema: {
    component: "card",
    contents: [
      {component: "cardTitle", template:'<span class="text-h5">Patient Form</span>'},
      {component: "cardBody", contents:[
        {component:"row", contents:[
          {component:"col", props:{cols:"12", md:"6", sm:"12"}, contents:[
            {component:"textField", ref:"firstField", vmodel:"patient.firstName", tokenId:"firstName", 
              props:{label:"First Name", rules:['requiredRule'] }},
            {component:"textField", vmodel:"patient.middleName", tokenId:"middleName", props:{label:"Middle Name"}},
            {component:"textField", ref:"lastName", vmodel:"patient.lastName", tokenId:"lastName", 
              props:{label:"Last Name", rules:['requiredRule'] }},
            {component:"textField", vmodel:"formattedDateOfBirth", props:{maxlength:"10", label:"Date of Birth"},
              mask:'##/##/####', rules:['requiredRule']},
            {component:"textField", vmodel:"patientSSN", tokenId:"ssn", props:{label:"SSN"}, mask:'###-##-####'},
            {component:"radioGroup", vmodel:"patient.gender", tokenId:"gender", props:{column:false, "hide-details":true},
              rules:['requiredRule'], contents:[
              {component: "radio", props:{label:"Male", value:"Male"}},
              {component: "radio", props:{label:"Female", value:"Female"}}
              ]},
            {component:"radioGroup", vmodel:"patient.contactInfo.language", tokenId:"language", props:{column:false, "hide-details":true},
              rules:['requiredRule'], contents:[
              {component: "radio", props:{label:"English", value:"English"}},
              {component: "radio", props:{label:"Spanish", value:"Spanish"}}
              ]},
              {component:"radioGroup", vmodel:"patient.contactInfo.preferredContactMethod", tokenId:"preferredContactMethod", props:{column:false, "hide-details":true},
              rules:['requiredRule'], contents:[
              {component: "radio", props:{label:"Phone", value:"Phone"}},
              {component: "radio", props:{label:"Mobile", value:"Mobile"}},
              {component: "radio", props:{label:"Email", value:"Email"}}
              ]}
          ]},
          {component:"col", props:{cols:"12", md:"6", sm:"12"}, contents:[
            {component:"textField", vmodel:"patient.contactInfo.email", tokenId:"email", props:{type:"email", label:"Email"}, rules:['emailRule']},
            {component:"textField", vmodel:"patient.contactInfo.phone", tokenId:"phone", props:{label:"Home Phone"}, rules:['phoneRule']},
            {component:"textField", vmodel:"patient.contactInfo.textPhone", tokenId:"textPhone", props:{label:"Mobile Phone"}, rules:['phoneRule']},
            {component:"textField", vmodel:"patient.contactInfo.streetAddress", tokenId:"streetAddress", props:{label:"Street Address"}},
            {component:"textField", vmodel:"patient.contactInfo.city", tokenId:"city", props:{label:"City"}},
            {component: "select", vmodel:"patient.contactInfo.stateOrProvince",tokenId:"stateOrProvince", 
              props:{items:"this.stateOptions", "item-value":"abbreviation", "item-text":"name", label:"State/Province"}},
            {component:"textField", vmodel:"patient.contactInfo.zipOrPostalCode", tokenId:"zipOrPostalCode", 
              props:{label:"Zip/Postal Code", hint:"(Zip Code determines city and state)", "persistent-hint":true}},
            {component:"textField", vmodel:"patient.contactInfo.country", tokenId:"country", props:{label:"Country", "maxlength":3 }}
          ]},
        ]}
      ]}
    ]
  }
};

import BaseAction from '../actions/baseaction'
import Roles from '../../models/workflowroles'
export class PatientEditPage extends BaseAction{
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.Scheduler];
  }
  
  route() {

    this.router.get("/", (req, res) => {
      res.json(uiConfig)
    });

    return this.router;
  }
}
