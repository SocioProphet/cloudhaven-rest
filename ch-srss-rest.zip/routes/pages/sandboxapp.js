import demoImgBase64 from './misc/demoimg.js'

const dataModel = {
  formData: {
    firstName: '',
    lastName: '',
    textField3: '',
    textField4: ''
  },
  tab: 1,
  tabItems: ['tab1', 'tab2', 'tab3', 'User File'],
  dialog: false,
  row: {
    firstName: '',
    lastName: '',
    address: ''
  },
  formValid: true,
  testList: [
    {id:'1', text:'1111'},
    {id:'2', text:'2222'}
  ],
  omit: false,
  testModel: false,
  testModelArray:[],
  value: 1,
  userFile: null,
  imageSrc: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAnbSURBVHhevZsNUFTXFYDP22VhlwVBELRiUKnWYG1jRyOJmviTWlMnTiwMiabalqmTjsbJaPCPEqvJoGIFbJpGxwkaW9sxE5t26g+xGjMoWpVBowiKJRoRVBT5UeRn2Z/Xc+67bnjuLtl9775+M/edcx4r7j3v3HPPvfchwf+D9MJCvL6lGD7IXKqRIRP+mf0ptwzDxKVxpBeOx+sixfALPQTfJsFmlIZj5tIY5hSasCMfoTZKuRES/SF15h24fLiC24ZgbASY4FW8zlAMTRRCekF/rhuCcQ5IL+yH1/WKoZlIHA2/57ohGBkBr2Mbrqi6WIhR8BTXhWOMA9ILB+E1VzFEIBVxRThGRcA6bLGKKoTp6FTKJ8KhKUcs6YVT8HoIm5XZ4mgEc8Ng2LvFf92gEbERkF4Qjtd3sYnuPDEI3EOWcl0YfUbAXck2DoVdsRh9ev+1ZxeM/3zQKOPGqwydpf+OXvhEp6mL3womGq4Mh4U1XPchoAOw8z9EcRJbFLsRBN1mi2fMT1c5H1isEfyWUF5qsPS8Xx5pQTWUodtqAvfAofAbJ7dV+B0CzWCj+xuxBd15wup2mtZV0fAXT5RT8qysttITDzVv9feAOeCM5NcBbgkyULyoWKEx/3pFxOj7jT3cFMa86+HOJzpMWiMr92v4MJnrKnwcgKFPFVweNs0JMu9iidDZZYBDci2pidAzrMIwcAq4rsJfJ3+N7XuKqo3JTdcsP2uo9HBTN9nVVmc/p26fZn4NxT7rEpUD7ki2BBS/Uyx9rK886OKqLsY3mx0ZN8JFJVWfdYXKAejjd1AIqeAGODrCF9eecHBTE2YZ3KuqrJLFo304PsZYjIJfcZ3h/cU49ieiyFIsMeReOhI2wPFQcyTMuRHuHt8cRsWVSP5wHT70FmrMAU1gxSTBlq5CKziLx23OqyzRlAuinZKcg0+fmyKJkUGiJM9gDpAlaS6KqaSLJr2hMvzplhuPKreg+eXVcGe8Q6KixwiW4VAYSQrzMIb/FyimkW4ErVlZzmtLsinKOH1XsLJHlofPPytZax4aEQGPWIElcgF3gBU7L5EThCPF9IO4qrOyKSkppM50/us63J1zlFvCuYdtJDqgzfulMAr2oKChIJTIlW/J9vw87//T3NwMR44cgRMnTkBdXR3YbDZITk6G6dOnw6xZs/inFO6+fBg699VzSyhLsPMfkNLbAUkobmATNeWAaVCiHHfpgiTFxkB7ezvk5eVBcXExtLS08E+oSUlJgfz8fMjMzGS2s6YVbqb+g+kC+Q+2F9AB3WR4t8U3g6t9hWShHdhnlDv6iSrKly0Tn5VaW1tZp3bv3g1dXYHzIX1u7969LEooGswDbOC+1QE955r5J3RDK8Is7PxXitkrAgicDq04I1xHdaByRzuWF6bIsZ/tl9qxw3PnzoWSkhL+k+DIzc1lESN3OqE+aQ942vyuZkNlN3b+F1xnqMI9AbopLFYplnakiHCwr30blyBhsH379pA7T6xfvx5KS0tBwuV//010uKSb+9jwS6nxGe+JctefUZxWLG1EvJIhWyZPktra2mDjRtpW0EZBgbKAi359NFiepEWqLrbh06ccpyJQwtMcBZTw7AVKp48dOxYw4QUDRQ7lAyJ+K1XqmrmJbZOiqvHrAIyC4yj+plihYXtzMZgSElluKSsrY/e0IssynDp1iunWaUlgf2UY0zWwBp9+G9dV9DXlLQWb7IFIrNp6N1vgZvruEDly6Zv8n6Pbb5Lj9dH7d8RtSQNXGHhc5uAbfrPDEkh/5b/CB9Us0Jum30IciqvYgl4eS7Z4iM+9i4ri16ysLNi1axfTtbJz5072e4jTrY3wk5MHZIfThf36dnjnPnakL/q5ovrSVwRQHghpb0DuaobOYxu4BTB06FCuaWfEiBFMujEY375SDu3gknosYAqmOZT2GuzfRoc1fvHrAHz6P0LxhmKFRufna8HzoIHpM2boORlH78fGwtixY5n+8a2v4Oi9W0zXQMCXLXwccC+H3aM03vtAJHjwSXUcVA5wJk2aBKmpqUzXwvz58yE6OhoeuHpg9WVdM/PTGAULuK7CxwGyBFSIz1QsbTiqPgVn7WGmFxVpOyiKi4uDdevojBUn8LpqaOjuZLoO3oMDW332F1SvyGDoU7VBq8J4dkMH7sbzYE1bzMYw1f8nT9IhU3BERUXBjh07YNy4cXC7+yHM+/IodHvc/KeasbHsvOegatn/eAQsxKZrS/wRrsYqcJyjohIrkE2bYMOGb5JjX9C4p5kjI4POZgDera2ANqewc5bVsH+rqpjwOqAphy2AfGplPTwsWQayi606IScnB86fPw/z5s0Dk8ln5EFiYiIsX74camtrvZ0/1FQHu+prmS4IjHiJXtnz4q0D0AEfoLWYm8KwPbcc7C+qk3BHRwccP34cbt++DXa7HYYNGwZjxoxh+iMcGPI/Pr0PTrTc4XeEMgtmL/qMFOYAHPuTURzBZsS5PvTPvgrmuBRuBceO+suw8MIxbgmnGh0whpRHDvgEhbINYwBdT70sd84Mfn1FZd608v9KjY6QN5ND4VV0wieKA1bDbMwG+9htweC0Cn9PGwlXB8bwO8Fx6MHzUN3Ndq6NABdGcirMXtzIslFCPuxHYYgDar4TB9cSQ+s8MTX6DD4T3VNfIP5InSeldzrO5lIYjjAzlKUOZlEQKlbJARPtX3JLKNeweaszrwMSNgBtFBYrlhgqkwdAS5T2vDrBXgkx5nZuCSMHxz5tjzHUE7IMy/D6QDH00RFhgZNPDuaWNiT8QlOiznBLCAdA8qj22VUOSNgID1HkKJY+yrDz3Rb9L6OPjKiDlHCfrTwt0GJiHbz0huq0Wh0BiGyBbSiqFEsb9fFRUJWseznh5fmocq7p4i8Y+me57sXHAYnvsGl4pWKFjkeS4PioJHD5KXe1Eh92H35gu8ItTdDOrN83xfx+S0yIVCZScRQyl4bEQX1CNLfEMRVzgUXSfDiyGZ++3+3pwI/JCcu/5RTbBweO+dLRQ7gllnDs/HN2TX88chHn4fe57kOfMzSWyPS2KL04FRRffH/I5PIRg5RdDAOQQWr9U9OCZT2yJVAo+OvPeXz61Vz3QUOJ0jfZZ8bTvDVBsYSzpjCtwvt6iwjEZapvoFrCCK7giHyP68IQ7gB8QnT+rulUqQ8oG60qSqsQXhYaEQEERYHIlcw+j9tJCzbhGOIAjIImFKL+2qsD25otEy8Ie/W2N0ZFAMgyrEUh4gWfj9ChF7kuHMMcUPRMhRMHrt6XLVqxCXl3ORCGOYDApEVnDKWKpYkN+PTJCYZhqAM4K7gMlXNYpdDCzFAMdwA+Qapf6YSEprLHWyDc+MOcwgkVlAANBOB/4078ZW8H98UAAAAASUVORK5CYII=',
  userFileSrc: null,
  userFileName:''
};
const uiMethods = {
  mounted: {
    args:[],
    body: `
    this._appGetFile('getfile', '123456789', function(data, fileName, contentType) {
      this.imageSrc = URL.createObjectURL(data);
      var xxx = data;
      var y = xxx;
    });

    this._appGet('formData', function(data) {
      this.formData.textField3 = '2222222222222';
      this.formData.textField4 = '4444444444444';
      this._getUserData(this.$store.state.user._id);
    });

/*    this._getUserFile("5c4ca983e2ca210c78d4dc06", "60a3eae40c57554694fbef11", (file)=>{
      this.userFile = file;
    })*/
    
    `
  },
  submitForm: {
    args:[],
    body: `
    if (!this.formValid) return;
    this._appPost('submitform', this.formData, function(data) {
      this._gotoAppPage( 'formsubmitted' );
      console.log(data.success);
    });`
  },
  showDialog: {
    args: ["row"],
    body: `
      var x = row;
      this.row.firstName = row.firstName;
      this.row.lastName = row.lastName;
      this.row.address = row.address
      this.dialog = true;
    `
  },
  requiredRule: {
    args: ["v"],
    body: `
    return !!v || "Required.";
    `
  },
  onFileChange: {
    args: ["file"],
    body: `
      var payload = {filename: file.name, mimeType: file.type, files:{}};
      payload.files[file.name] = file;
      this._appPost( "postFile", payload, (cb) => {
        console.log('_appPost completed');
      })
    `
  },
  onUserFileChange: {
    args: ["file"],
    body: `
    debugger;
      var payload = {
        userId: this.cloudHavenUserId,
        operation:'add',
        name: this.userFileName || 'Not Specified',
        filename: file.name,
        mimeType: file.type,
        files:{}
      };
      payload.file = file;

      this._userFileOperation( payload, (results) => {
        console.log('results: '+results);
      })
    `
  }
  /*,
  doTest: {
    body: `
    this.testList = [
      {id:'3', text:'3333'},
      {id:'4', text:'4444'}
    ];
    this.omit = !this.omit;
    `
  }*/
};
const computed = {
  testval: {
    args:[],
    body: `
    debugger;
    return 'test worked!';
    `
  }
}
const watch = {
}
const externalComponents = [
  {vendorId:'component-vendor', componentId:'example-table'}
];

const uiConfig = {
  requiredUserData: ['firstName', 'lastName'],
  dataModel:dataModel,
  methods: uiMethods,
  computed: computed,
  externalComponents: externalComponents,
  appFrame: {
    name: 'Example App',
    appBarStyle: {background: 'linear-gradient(rgb(40, 54, 102) 0%, rgb(37, 114, 210) 100%)'},
    appBarTextClass: "yellow--text text--accent-2",
    nameTextClass: "white--text"
  },
  uiSchema: {
  component: 'container',
  contents: [
  /*      {
      component:"loop", dataList:"testList", itemAlias:"item", indexIsKey:false, key:'id', 
        contents: {component: "template", template:"<span>{{item.text}}</span>"}
    },
    {component:"button", label:"Test", on:{click:"doTest"}},*/
    {
      component: 'card',
      props: {
        elevation: 2
      },
      contents: [{
        component: 'cardTitle',
  //              contents: 'This is the title'
        template: '<span>Welcome {{ch_userData.firstName}} {{ch_userData.lastName}}</span>'
      },
      {
        component: 'cardText',
        contents: [
          {component: 'form', vmodel: "formValid", props: {'lazy-validation': true }, contents: [
              {component: 'row', class:"mx-4", contents: [
                  {
                    component: 'col',
                    props: {  cols:12, md:6, sm:12},
                    contents: [
                      {
                        component: 'textField',
                        vmodel: 'formData.firstName',
                        userData: 'firstName',
                        props: {
                          outlined: false,
                          label: 'First Name'
                        },
                        rules: ["requiredRule"]
                      },
                      {
                        component: 'textField',
                        vmodel: 'formData.lastName',
                        userData: 'lastName',
                        props: {
                          outlined: false,
                          label: 'Last Name'
                        }},
                        {
                          component: 'textField',
                          vmodel: 'formData.dummy',
                          props: {
                            outlined: false,
                            label: 'Dummy'
                          }}
                    ]
                  },
                  {
                    component: 'col',
                    props: { cols:12, md:6, sm:12},
                    contents: [
                      {
                        component: 'textField',
                        vmodel: 'formData.textField3',
                        props: {
                          outlined: false,
                          label: 'Field 3'
                        }},
                        {
                        component: 'textField',
                        vmodel: 'formData.textField4',
                        props: {
                          outlined: false,
                          label: 'Field 4'
                        }}
                    ]
                  }
                ]
              }
            ]
          }
        ]
      },
      {
        component: 'cardActions',
        contents: [{
          component: 'button',
          contents: 'Cancel'
        },
        {
          component: 'spacer'
        },
        {
          component: 'button',
          on: {
            click: 'this.submitForm'
          },
          contents: 'Save'
        }
        ]
      }
      ]
    },
    {
      component: 'tabs', props: {    'align-with-title': true }, vmodel: "tab", contents: [
        {
          component: 'tabsSlider',
          props:{ color: "yellow"}
        },
        {
          component: 'tab',
          template: '<span>{{tabItems[0]}}</span>'
        },
        {
          component: 'tab',
          template: '<span>{{tabItems[1]}}</span>'
        },
        {
          component: 'tab',
          template: '<span>{{tabItems[2]}}</span>'
        },
        {
          component: 'tab',
          template: '<span>{{tabItems[3]}}</span>'
        },
        {
          component: 'tabsItems',
          vmodel: "tab",
          contents: [
            {
              component: 'tabItem',
              contents: [
              {component: "div", contents:[
                {component: "dynamicComponent", name: "example-table"}
                /*{component: 'dataTable',
                  props: {":headers":"headers", ":items":"items", "hide-default-footer":true, "disable-pagination":true},
                  class:"elevation-1", scopedSlots: {
                    item: {component: 'tr', on: {click: "showDialog"}, contents: [
                    {component: 'td', template: '<span>{{item.firstName}}</span>'},
                    {component: 'td', template: '<span>{{item.lastName}}</span>' },
                    {component: 'td', template: '<span>{{item.address}}</span>'  }
                  ]}
                }},*/
                ]}
              ]
            },
            {
              component: 'tabItem',
              contents: [
                {component:"fileViewer", props:{mimeType:'application/vnd.openxmlformats-officedocument.wordprocessingml.document', ':dataString':"userFile"}}
              ]
            },
            {
              component: 'tabItem',
              contents: [
                {component: "fileInput", vmodel:"uploadedFile", props:{accept:"*/*", label:"File Input"}, on:{change:"onFileChange"}},
                {component: "image", props:{':src':"imageSrc"}}
              ]
            },
            {
              component: 'tabItem',
              contents: [
                {component: "textField", label:"User File Name", vmodel:"userFileName"},
                {component: "fileInput", vmodel:"uploadedFile", props:{accept:"*/*", label:"User File Input"}, on:{change:"onUserFileChange"}},
                {component: "image", props:{':src':"userFileSrc"}}
              ]
            }
          ]
        },
      ]
    },
    {
      component: 'dialog',
      props: {
        "max-width":"500px"
      },
      vmodel: "dialog",
      defaultSlot: {
        component: 'form',
        props: {
          light: "true"
        },
        style: {
          "background-color": "white"
        },
        contents: [
          {
            component: "cards",
            contents: [
              { component: "cardTitle", contents:"Edit Row"},
              {
                component: "cardText",
                contents: [
                  {
                    component: 'textField',
                    vmodel: 'row.firstName',
                    props: {
                      dense: true,
                      outlined: false,
                      label: 'First Name'
                    }
                  },
                  {
                    component: 'textField',
                    vmodel: 'row.lastName',
                    props: {
                      dense: true,
                      outlined: false,
                      label: 'Last Name'
                    }
                  },
                  {
                    component: 'textField',
                    vmodel: 'row.address',
                    tokenId: 'address',
                    props: {
                      dense: true,
                      outlined: false,
                      label: 'Last Name'
                    }
                  }
                ]
              },
              {
                component: 'cardActions',
                contents: [{
                  component: 'button',
                  contents: 'Cancel'
                },
                {
                  component: 'spacer'
                },
                {
                  component: 'button',
                  on: {
                    click: 'this.submitForm'
                  },
                  contents: 'Save'
                }
                ]
              }
      
            ]
          }
        ]
      }
    },
    {component: 'conversation', props: { ":application":"_app", topic: 'Test Topic'}  }
  ]
  }
};
const uiConfig2 = {
requiredUserData: ['firstName', 'lastName'],
dataModel:{},
methods: {},
uiSchema: {
component: 'container',
contents: [
  {
    component: 'card',
    props: {
      elevation: 2
    },
    contents: [{
      component: 'cardTitle',
      template: '<span>Form submitted for {{_userData.firstName}} {{_userData.lastName}}</span>'
    },
    {
      component: 'cardBody',
      contents: "More to come..."
    }],
  }
]
}
};

const tableDataModel = {
  headers: [
    { text: 'First Name', value:'firstName', sortable: true },
    { text: 'Last Name', value:'lastName', sortable: true },
    { text: 'Address', value:'address', sortable: true }
  ],
  items: [
    {firstName:'Big', lastName: 'Bork', address: '1234 Bork Street, Bob City, CA 99999'},

  ]
}
const tableMethods = {
  mounted: {
    body: `
    this._appGet('formData', function(data) {
      this.items = data;
    })`
  }
}
const exampleTableComponent = {
  name: "example-table",
  props: {},
  requiredUserData: [],
  dataModel:tableDataModel,
  methods: tableMethods,
  uiSchema:{component: 'dataTable',
  props: {":headers":"headers", ":items":"items", "hide-default-footer":true, "disable-pagination":true},
  class:"elevation-1", scopedSlots: {
    item: {component: 'tr', on: {click: "showDialog"}, contents: [
    {component: 'td', template: '<span>{{item.firstName}}</span>'},
    {component: 'td', template: '<span>{{item.lastName}}</span>' },
    {component: 'td', template: '<span>{{item.address}}</span>'  }
  ]}
  }}
}

const compVendExternalComponents = {
  "example-table": exampleTableComponent
}

import BaseAction from '../actions/baseaction'
import Roles from '../../models/workflowroles'
import fileUpload from 'express-fileupload'

export class SandboxApp extends BaseAction {
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.Scheduler];
  }
  
  route() {
    this.router.use(fileUpload());
    //{componentIds:[componentId, ...]}
    this.router.post("/compvend/getcomponents", (req, res) => {
      var retComps = req.body.componentIds.reduce((ar,cId)=>{
        if (compVendExternalComponents[cId]) {
          ar.push(compVendExternalComponents[cId]);
        }
        return ar;
      },[])
      res.json(retComps);
    });
    this.router.get("/apppages/home", (req, res) => {
      res.json(uiConfig)
    });
    this.router.get("/apppages/formsubmitted", (req, res) => {
      res.json(uiConfig2)
    });
    this.router.get("/formData", (req, res) => {
      res.json([
        {firstName:'Bob', lastName: 'Smith', address: '1234 Bob Street, Bob City, CA 99999'},
        {firstName:'Dave', lastName: 'Anderson', address: '9999 Dave Street, Some City, CA 99999'},
        {firstName:'Xaviar', lastName: 'Gomez', address: '7777 Xav Street, Gomez City, CA 99999'}
      ]);
    });
    
    this.router.post("/submitform", (req, res) => {
      console.log('Form data:\n'+JSON.stringify(req.body));
      res.json({success:true, newPage:'formSubmitted'})
    });

    this.router.get("/getfile/:fileId", (req, res) => {
      console.log('fileId: '+req.params.fileId);
      
      res.writeHead(200, [
        ['Content-Type', 'image/jpeg'],
        ["Content-Disposition", "attachment; filename='clouds.jpg'"]
      ]);
      const buffer = Buffer.from(demoImgBase64, "base64");
      res.end(buffer);
    });

    this.router.post("/postFile", (req, res) => {
      console.log('FIlename: '+req.body.filename+', mimeType: '+req.body.mimeType );
      var keys = Object.keys(req.files);
      var file = keys.length>0?req.files[keys[0]]:null;
      console.log(file);
      res.json({success:true});
    })
    
    return this.router;
  }
}
