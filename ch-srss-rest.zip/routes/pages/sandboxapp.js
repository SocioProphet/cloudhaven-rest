const dataModel = {
  formData: {
    firstName: '',
    lastName: '',
    textField3: '',
    textField4: ''
  },
  tab: 1,
  tabItems: ['tab1', 'tab2', 'tab3'],
  dialog: false,
  row: {
    firstName: '',
    lastName: '',
    address: ''
  },
  formValid: true,
  testList: [
    {id:'1', text:'1111'},
    {id:'2', text:'2222'}
  ],
  omit: false,
  testModel: false,
  testModelArray:[],
  value: 1
};
const uiMethods = {
  mounted: {
    args:[],
    body: `
    debugger;
    this._appGet('formData', function(data) {
      this.formData.textField3 = '2222222222222';
      this.formData.textField4 = '4444444444444';
      this._getUserData(this.$store.state.user._id);
    })`
  },
  submitForm: {
    args:[],
    body: `
    if (!this.formValid) return;
    this._appPost('submitform', this.formData, function(data) {
      this._gotoAppPage( 'formsubmitted' );
      console.log(data.success);
    });`
  },
  showDialog: {
    args: ["row"],
    body: `
      var x = row;
      this.row.firstName = row.firstName;
      this.row.lastName = row.lastName;
      this.row.address = row.address
      this.dialog = true;
    `
  },
  requiredRule: {
    args: ["v"],
    body: `
    return !!v || "Required.";
    `
  }/*,
  doTest: {
    body: `
    this.testList = [
      {id:'3', text:'3333'},
      {id:'4', text:'4444'}
    ];
    this.omit = !this.omit;
    `
  }*/
};
const computed = {
  testval: {
    args:[],
    body: `
    debugger;
    return 'test worked!';
    `
  }
}
const watch = {
}
const externalComponents = [
  {vendorId:'component-vendor', componentId:'example-table'}
];

const uiConfig = {
  requiredUserData: ['firstName', 'lastName'],
  dataModel:dataModel,
  uiMethods: uiMethods,
  computed: computed,
  externalComponents: externalComponents,
  appFrame: {
    name: 'Example App',
    appBarStyle: {background: 'linear-gradient(rgb(40, 54, 102) 0%, rgb(37, 114, 210) 100%)'},
    appBarTextClass: "yellow--text text--accent-2",
    nameTextClass: "white--text"
  },
  uiSchema: {
  component: 'container',
  contents: [
  /*      {
      component:"loop", dataList:"testList", itemAlias:"item", indexIsKey:false, key:'id', 
        contents: {component: "template", template:"<span>{{item.text}}</span>"}
    },
    {component:"button", label:"Test", on:{click:"doTest"}},*/
    {
      component: 'card',
      props: {
        elevation: 2
      },
      contents: [{
        component: 'cardTitle',
  //              contents: 'This is the title'
        template: '<span>Welcome {{ch_userData.firstName}} {{ch_userData.lastName}}</span>'
      },
      {
        component: 'cardText',
        contents: [
          {component: 'form', vmodel: "formValid", props: {'lazy-validation': true }, contents: [
              {component: 'row', class:"mx-4", contents: [
                  {
                    component: 'col',
                    props: {  cols:12, md:6, sm:12},
                    contents: [
                      {
                        component: 'textField',
                        vmodel: 'formData.firstName',
                        tokenId: 'firstName',
                        props: {
                          outlined: false,
                          label: 'First Name'
                        },
                        attrs: {
                          rules: ["requiredRule"]
                        }
                      },
                      {
                        component: 'textField',
                        vmodel: 'formData.lastName',
                        tokenId: 'lastName',
                        props: {
                          outlined: false,
                          label: 'Last Name'
                        }},
                        {
                          component: 'textField',
                          vmodel: 'formData.dummy',
                          props: {
                            outlined: false,
                            label: 'Dummy'
                          }}
                    ]
                  },
                  {
                    component: 'col',
                    props: { cols:12, md:6, sm:12},
                    contents: [
                      {
                        component: 'textField',
                        vmodel: 'formData.textField3',
                        props: {
                          outlined: false,
                          label: 'Field 3'
                        }},
                        {
                        component: 'textField',
                        vmodel: 'formData.textField4',
                        props: {
                          outlined: false,
                          label: 'Field 4'
                        }}
                    ]
                  }
                ]
              }
            ]
          }
        ]
      },
      {
        component: 'cardActions',
        contents: [{
          component: 'button',
          contents: 'Cancel'
        },
        {
          component: 'spacer'
        },
        {
          component: 'button',
          on: {
            click: 'this.submitForm'
          },
          contents: 'Save'
        }
        ]
      }
      ]
    },
    {
      component: 'tabs', props: {    'align-with-title': true }, vmodel: "tab", contents: [
        {
          component: 'tabsSlider',
          props:{ color: "yellow"}
        },
        {
          component: 'tab',
          template: '<span>{{tabItems[0]}}</span>'
        },
        {
          component: 'tab',
          template: '<span>{{tabItems[1]}}</span>'
        },
        {
          component: 'tab',
          template: '<span>{{tabItems[2]}}</span>'
        },
        {
          component: 'tabsItems',
          vmodel: "tab",
          contents: [
            {
              component: 'tabItem',
              contents: [
              {component: "div", contents:[
                {component: "dynamicComponent", name: "example-table"}
                /*{component: 'dataTable',
                  props: {":headers":"headers", ":items":"items", "hide-default-footer":true, "disable-pagination":true},
                  class:"elevation-1", scopedSlots: {
                    item: {component: 'tr', on: {click: "showDialog"}, contents: [
                    {component: 'td', template: '<span>{{item.firstName}}</span>'},
                    {component: 'td', template: '<span>{{item.lastName}}</span>' },
                    {component: 'td', template: '<span>{{item.address}}</span>'  }
                  ]}
                }},*/
                ]}
              ]
            },
            {
              component: 'tabItem',
              contents: 'Contents of Tab 2'
            },
            {
              component: 'tabItem',
              contents: 'Contents of Tab 3'
            }
          ]
        },    
      ]
    },
    {
      component: 'dialog',
      props: {
        "max-width":"500px"
      },
      vmodel: "dialog",
      defaultSlot: {
        component: 'form',
        props: {
          light: "true"
        },
        style: {
          "background-color": "white"
        },
        contents: [
          {
            component: "cards",
            contents: [
              { component: "cardTitle", contents:"Edit Row"},
              {
                component: "cardText",
                contents: [
                  {
                    component: 'textField',
                    vmodel: 'row.firstName',
                    props: {
                      dense: true,
                      outlined: false,
                      label: 'First Name'
                    }
                  },
                  {
                    component: 'textField',
                    vmodel: 'row.lastName',
                    props: {
                      dense: true,
                      outlined: false,
                      label: 'Last Name'
                    }
                  },
                  {
                    component: 'textField',
                    vmodel: 'row.address',
                    tokenId: 'address',
                    props: {
                      dense: true,
                      outlined: false,
                      label: 'Last Name'
                    }
                  }
                ]
              },
              {
                component: 'cardActions',
                contents: [{
                  component: 'button',
                  contents: 'Cancel'
                },
                {
                  component: 'spacer'
                },
                {
                  component: 'button',
                  on: {
                    click: 'this.submitForm'
                  },
                  contents: 'Save'
                }
                ]
              }
      
            ]
          }
        ]
      }
    },
    {component: 'conversation', attrs: { topic: 'Test Topic'  }
    }
  ]
  }
};
const uiConfig2 = {
requiredUserData: ['firstName', 'lastName'],
dataModel:{},
uiMethods: {},
uiSchema: {
component: 'container',
contents: [
  {
    component: 'card',
    props: {
      elevation: 2
    },
    contents: [{
      component: 'cardTitle',
      template: '<span>Form submitted for {{_userData.firstName}} {{_userData.lastName}}</span>'
    },
    {
      component: 'cardBody',
      contents: "More to come..."
    }],
  }
]
}
};

const tableDataModel = {
  headers: [
    { text: 'First Name', value:'firstName', sortable: true },
    { text: 'Last Name', value:'lastName', sortable: true },
    { text: 'Address', value:'address', sortable: true }
  ],
  items: [
    {firstName:'Big', lastName: 'Bork', address: '1234 Bork Street, Bob City, CA 99999'},

  ]
}
const tableMethods = {
  mounted: {
    body: `
    this._appGet('formData', function(data) {
      this.items = data;
    })`
  }
}
const exampleTableComponent = {
  name: "example-table",
  props: {},
  requiredUserData: [],
  dataModel:tableDataModel,
  uiMethods: tableMethods,
  uiSchema:{component: 'dataTable',
  props: {":headers":"headers", ":items":"items", "hide-default-footer":true, "disable-pagination":true},
  class:"elevation-1", scopedSlots: {
    item: {component: 'tr', on: {click: "showDialog"}, contents: [
    {component: 'td', template: '<span>{{item.firstName}}</span>'},
    {component: 'td', template: '<span>{{item.lastName}}</span>' },
    {component: 'td', template: '<span>{{item.address}}</span>'  }
  ]}
  }}
}

const compVendExternalComponents = {
  "example-table": exampleTableComponent
}

import BaseAction from '../actions/baseaction'
import Roles from '../../models/workflowroles'
export class SandboxApp extends BaseAction {
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.Scheduler];
  }
  
  route() {
    //{componentIds:[componentId, ...]}
    this.router.post("/compvend/getcomponents", (req, res) => {
      var retComps = req.body.componentIds.reduce((ar,cId)=>{
        if (compVendExternalComponents[cId]) {
          ar.push(compVendExternalComponents[cId]);
        }
        return ar;
      },[])
      res.json(retComps);
    });
    this.router.get("/apppages/home", (req, res) => {
      res.json(uiConfig)
    });
    this.router.get("/apppages/formsubmitted", (req, res) => {
      res.json(uiConfig2)
    });
    this.router.get("/formData", (req, res) => {
      res.json([
        {firstName:'Bob', lastName: 'Smith', address: '1234 Bob Street, Bob City, CA 99999'},
        {firstName:'Dave', lastName: 'Anderson', address: '9999 Dave Street, Some City, CA 99999'},
        {firstName:'Xaviar', lastName: 'Gomez', address: '7777 Xav Street, Gomez City, CA 99999'}
      ]);
    });
    
    this.router.post("/submitform", (req, res) => {
      console.log('Form data:\n'+JSON.stringify(req.body));
      res.json({success:true, newPage:'formSubmitted'})
    });
    
    return this.router;
  }
}
