export default {
      firstName:"firstName",
      middleName:"middleName",
      lastName:"lastName",
      ssn:"ssn",
      phone:"contactInfo.phone",
      email:"contactInfo.email",
      fax:"contactInfo.fax",
      textPhone:"contactInfo.textPhone",
      attn:"contactInfo.attn",
      streetAddress:"contactInfo.streetAddress",
      city:"contactInfo.city",
      stateOrProvince:"contactInfo.stateOrProvince",
      zipOrPostalCode:"contactInfo.zipOrPostalCode",
      country:"contactInfo.country",
      dateOfBirth:"dateOfBirth",
      gender:"gender",
      preferredContactMethod:"contactInfo.preferredContactMethod",
      language:"contactInfo.language"
}

