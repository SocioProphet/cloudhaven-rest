import workflowRouteMap from './components/workflowRouteMap'
import patientHdrCfg from './components/patientheader.js'
import stateList from '../../_helpers/stateList.js'


const dataModel = {
  valid: false,
  error: '',
  editMode: '',
  notesEntry: '',
  formTitle: 'Patient Case',
  patientCase: {status:'Open', patient:{contactInfo:{}}, payerInfo:{}, paymentsDue:[],
    primaryPayer:{claimsTransmission:{}, claimsPayer:{}},
    secondaryPayer:{claimsTransmission:{}, claimsPayer:null}, 
    calendarBooking:{status:"Tentative"}, day: new Date(), cptCode:{}, icd10Code:{}, 
    vendorFees:[], requiredVendorTypes:[],
    procedure:{diagnoses:[]},
    notesLog:[],
    claimUploadLog:[]
  },
  workflowAssignments:[],
  procedure: {procedureType:{vendorTypes:[]}},
  vendors: [],
  curScheduleMonth: '',
  dateOfService: '',
  sDateOfService: '',
  scheduleMonthOptions: [],
  scheduleMonthAvailableDates: [],
  orgTypesMap: {},
  confirmationsHeader: [
    { text: 'Vendor', value: 'vendor.name', sortable: true, align:'left' },
    { text: 'Date/time', align:'left', sortable:true, value: 'datetime' },
  ],
  destWorkflowState: '',
  patientCaseId: '',
  initializing: true,
  claimUploadHeaders: [
    { text: 'Date/Time', value: 'datetime', sortable: true, align:'left' },
    { text: 'Contents', align:'left', sortable:true, value: 'contents' }
  ],
  hadPendingAuth: false,
  hadAuth: false,
  canSave: false,
  alerts: [],
  procedures: [],
  payers: []
};
const uiMethods = {
  created: {
    body: `
/*    this.$root.$on('alert added', (alert) => {
      this.alerts.push({contents:alert});
    })*/
    this.editMode = this._appParams.mode || 'edit';
    this._appGet( 'procedures/list', (procedures)=>{
      this.procedures = procedures;
      this._appGet( 'payers/list', (payers)=>{
        this.payers = payers;
        if (!this._appParams.isForConfirmingBooking && this.serviceDateEditable) {
          this.scheduleMonthOptions = [];
          var mDate = this._moment();
          for (var i=0;i<24;i++) {
            mDate.date(1);
            var startDate = this._moment(mDate);
            mDate.add(1, "months");
            var endDate = this._moment(mDate).subtract(1, 'days');
            this.scheduleMonthOptions.push({value:startDate.format('YYYY-MM-DD')+':'+endDate.format('YYYY-MM-DD'), text: startDate.format('MMM YYYY')})
          }
        }
        debugger;
        this.patientCaseId = this._appParams.patientCaseId /* || this.routerParams.patientCaseId*/;
        this.patientId = this._appParams.patientId /* || this.routerParams.patientId*/;
        if (this._appParams.mode == 'create') {
          this.patientCaseId = null;
        } else if (!this.patientCaseId) {
          this.patientCaseId = this.currentPatientCaseId;
        } else {
    //FIXME      this.$store.commit('SET_CURRENTPATIENTCASE', this.patientCaseId );
        }
        if (!this.patientCaseId) {
          if (this._appParams.mode == 'create') {
            this.patientCase.caseId = '(auto-generated)';
            this._appGet( 'patients/'+this.patientId, (data) => {
//              data.dateOfBirth = this._moment(data.dateOfBirth).toDate()
              this.patientCase.patient = Object.assign({}, data) ;
            });
          }
        } else {
          this._appGet('patientcaseedit/'+this.patientCaseId, (data) => {
            this.patientCase = Object.assign({}, data.patientCase);
//            patientCase.patient.dateOfBirth = this._moment(patientCase.patient.dateOfBirth).toDate()
//            this.patientCase = Object.assign({}, patientCase);
            //            this.$root.$emit('alerts available', this.patientCase.alerts.filter(a=>(!a.dismissed)));
            this.workflowAssignments = data.workflowAssignments;
            if (this.patientCase.calendarBooking && this.patientCase.calendarBooking.day) {
              this.sDateOfService = this._moment(this.patientCase.calendarBooking.day).format('l');
              this.dateOfService = this._moment(this.patientCase.calendarBooking.day).format('YYYY-MM-DD');
            }
            if (this.patientCase.payerInfo.pendingAuthorizationCode) this.hadPendingAuth=true;
            if (this.patientCase.payerInfo.approvedAuthorizationCode) this.hadAuth=true;
            this.getOptions();
          });
        }
      });
    });
    `
  },
  requiredRule: {
    args: ["v"],
    body: `
    return !!v || "Required."
    `
  },
  requiredObjectRule: {
    args: ["value"],
    body: `return (value && value._id!='') || 'Required.'`
  },
  showCostEstimatePdf: {
    body: `
    this._pdfGet('patientacceptance/getcostestimate/'+this.patientCase._id, (response) => {
      const file = new Blob( [response], {type: 'application/pdf'});
      const fileURL = URL.createObjectURL(file);
      var width = screen.width<820?(screen.width-40):840;
      var win = window.open(fileURL, 'Cost Estimate', "height=960,width="+width+",toolbar=no,menubar=no,scrollbars=yes,location=no,status=no,top=5,left=0");
      try {
        win.focus();
      } catch(e){
        console.log(e);
      }
    });`
  },
  vendorEditable: {
  args: ["orgType"],
  body: `
    return this.editMode=='create' || (this.patientCase.isOpen && !this.patientCase.opReportUploaded);`
  },
  onPayerChange: {
    body: `
    this.canSave = false;
    if (!this._deepGet(this, 'patientCase.primaryPayer.claimsPayer._id')) {
      return;
    }
    var validProcedures = this.patientCase.primaryPayer.claimsPayer.procedures.reduce((mp,p)=>{
      mp[p.procedure._id] = true;
      return mp;
    },{});
    if (this._deepGet(this, 'patientCase.procedure._id')) {
      if (!validProcedures[this.patientCase.procedure._id]) {
        this.patientCase.procedure = null;
      }
    }
    this.patientCase.paymentMethod = this._deepGet(this, "patientCase.primaryPayer.claimsPayer.isSelfPayer")?'Cash':'Insurance';
    this.canSave = true;`
  },
  onProcedureChange: {
    body: `
    this.canSave = false;
    if (!this._deepGet(this, 'patientCase.procedure._id')) {
      this.patientCase.cptCode = {};
      this.patientCase.icd10Code = {};
      this.patientCase.requiredVendorTypes = [];
    } else {
      this.patientCase.totalCharges = this._deepGet(this, 'patientCase.procedure.totalCharges');
      this.patientCase.cptCode = this._deepGet(this, 'patientCase.procedure.cptCode');
      if (this.diagnoses.length==1) {
        this.patientCase.icd10Code = this.diagnoses[0];
      }
      var requiredVendorTypes = this.patientCase.procedure.procedureType.vendorTypes.concat(this.patientCase.primaryPayer.claimsPayer.additionalVendorTypes);
      requiredVendorTypes = requiredVendorTypes.reduce((mp,rvt)=>{
        mp[rvt] = rvt;
        return mp;
      },{});
      var tmp = Object.keys(requiredVendorTypes);
      this.patientCase.requiredVendorTypes = tmp;
      this.getOptions();
    }`
  },
  getOptions: {
    body: `
    this._appPost('caseoptions', 
        {procedureId: this._deepGet(this, 'patientCase.procedure._id')}, (response)=>{
      this.procedure = response.procedure;
      this.vendors = response.vendors;
      this.loadOrgTypes();
    });`
  },
  loadOrgTypes: {
    body:`
    var vendorFeeMap = {}
    this.orgTypesMap = this.vendors.reduce((mp,v)=>{
      v.vendorFees.forEach((vf)=>{
        vendorFeeMap[vf._id] = vf;
      })
      var curFeesMap = this.patientCase.vendorFees.reduce((mp,vf)=>{
        mp[vf.vendor.vendorType] = Object.assign({key:(vf.vendor._id+':'+vf.fee.description), text:vf.vendor.name+' ('+vf.fee.description+')'},vf);
        return mp;
      },{})
      var curVal = curFeesMap[v.vendorType]||null; 
      var inList = false;
      var obj = mp[v.vendorType] || (mp[v.vendorType]={options:[], value:curVal});
      if (v.vendorType == 'Device Maker') {
        obj.options = this.patientCase.procedure.devices.reduce((ar,d)=>{
          var vf = vendorFeeMap[d.vendorFeeId]
          if (vf) {
            ar.push({key:(d.vendor._id+':'+vf.description), text:(d.vendor.name+' ('+vf.description+')'), vendor:d.vendor._id, fee:vf});
          }
          return ar;
        }, []).sort((a,b)=>(a.text<b.text?-1:(a.text>b.text?1:0)));
      } else {
        v.vendorFees.forEach(vf=>{
          var feeObj = {key:(v._id+':'+vf.description), text:(v.name+' ('+vf.description+')'), vendor:v._id, fee:vf}
          if (curVal && curVal.key == feeObj.key) {
            inList = true;
            obj.value = curVal;
          }
          obj.options.push(feeObj);
        });
        if (!inList && curVal) {
          obj.options.unshift(curVal);
        }
      }
      return mp;
    }, {});
    Object.keys(this.orgTypesMap).forEach(orgType=>{
      this.orgTypesMap[orgType].options = this.orgTypesMap[orgType].options.sort((a,b)=>(a.text<b.text?-1:(a.text>b.text?1:0)));
    });
    var fixedPosOrgTypes = ['Surgeon', 'Surgery Center', 'Recovery Suite', 'Device Maker'];
    var orgTypes = fixedPosOrgTypes.reduce((ar, orgType)=>{
      if (this.orgTypesMap[orgType]) ar.push(orgType);
      return ar;
    },[]);
    Object.keys(this.orgTypesMap).forEach(orgType=>{
      if (!orgTypes.find(e=>(e==orgType))) orgTypes.push(orgType);
      var org = this.orgTypesMap[orgType];
      if (org.options.length==1 && this.vendorEditable(orgType)) {
        org.value = org.options[0];
      }
    })
    orgTypes = orgTypes.filter(orgType=>(this.vendorEditable(orgType) || this.$safeRef(this.orgTypesMap[orgType]).value));
    this.patientCase.requiredVendorTypes = orgTypes;
    this.$nextTick(()=>{
      window.setTimeout(()=>{
        this.initializing = false;
      },300)
    })
    this.canSave = true;`
  },
  dateOfServiceChange: {
    body: `
    if (this.dateOfService) {
      if (this.dateOfService == 'UNSCHEDULE') {
        this.sDateOfService = '';
        this.dateOfService = '';
      } else {
        this.sDateOfService = this._moment(this.dateOfService, 'YYYY-MM-DD').format('l');
      }
    }`
  },
  saveForm: {
    body:`
    if (!this.canSave) {
      alert("Save not allowed at this time - try again in a few seconds.");
      return;
    }
    var isValid = this.$refs.form.validate();
    if (isValid) {
      var gotError = false
      var vendorFees = [];
      this.patientCase.requiredVendorTypes.forEach(orgType=>{
        var vendorFee = this.orgTypesMap[orgType];
        if (vendorFee && vendorFee.value && vendorFee.value.key) {
          var newpf = Object.assign({},vendorFee.value);
          delete newpf.key;
          delete newpf.text;
          delete newpf.fee._id;
          delete newpf.fee.id;
          delete newpf.fee.createdAt;
          delete newpf.fee.updatedAt;
          vendorFees.push(newpf);
        } else {
          this._showError( 'Please select '+orgType+'.');
          gotError = true;
          return;
        }
      });
      if (gotError) return;
      this.patientCase.vendorFees = vendorFees;
      var mTreatmentDate = this.dateOfService?this._moment(this.dateOfService, 'YYYY-MM-DD'):null;
      if (!this.patientCase.calendarBooking) this.patientCase.calendarBooking = {status:'Tentative'};
      if (this.patientCase.calendarBooking.day && !this.sDateOfService) {
        this.patientCase.calendarBooking.day = null;
      }
      if (mTreatmentDate && (!this.patientCase.calendarBooking.day || !mTreatmentDate.isSame(this.patientCase.calendarBooking.day, 'day'))) {
        this.patientCase.calendarBooking.status = 'Tentative';
        this.patientCase.calendarBooking.day = mTreatmentDate.toDate();
        this.sDateOfService = mTreatmentDate.format('l');
      }
      if (!this.patientCase.id) {
        this.patientCase.alerts = this.alerts;
      }
      this._appPost(this.editMode=='create'?'/createpatientcase':'/updatepatientcase', {patientCase:this.patientCase, notesEntry: this.notesEntry}, 
        function(response) {
        if (response.record) {
          this._showNotification('Case '+response.record.caseId+' '+(this.editMode=='create'?'created':'updated')+'.');
          if (this.editMode=='create' && !this.patientCase.calendarBooking.day) {
            if (confirm('Do you wish to use the scheduling calendar to schedule the Date of Service?')) {
              this.gotoEventCalendarWithId(response.record._id);
              return;
            }
          }
          this._gotoAppPage('home');
        } else if (response.errMsg) {
          this._showError( response.errMsg );
        }
      });
    }`
  },
  confirmBooking: {
    body: `
      this._appPost('confirmbooking', {patientCaseId:this.patientCase._id, notesEntry:this.notesEntry}, (response)=> {
        if (response.success) {
          this._showNotification( 'Case '+this.patientCase.caseId+' booking confirmed.')
          this._gotoAppPage('home')
        } else if (response.errMsg) {
          this._showError('SET_ERRMSG', response.errMsg);
        }
      });`
  },
  gotoEventCalendarWithId: {
    args: ["patientCaseId"],
    body: `
    this._gotoAppPage('schedulingcalendar', 
      {patientCaseId:this.patientCase.calendarBooking.day?null:(patientCaseId?patientCaseId:this.patientCase.id)});`
  },
  gotoEventCalendar: {
    body: `
    this._gotoAppPage('schedulingcalendar', 
      {patientCaseId:this.patientCase.calendarBooking.day?null:this.patientCase.id});`
  },
  vendorChange: {
    body: `
    if (this.initializing) return;
    this.patientCase.calendarBooking.day = null;
    this.patientCase.calendarBooking.status = 'Tentative';
    this.scheduleMonthChange();`
  },
  scheduleMonthChange: {
    body: `
    if (this.curScheduleMonth) {
      this._appPost('calendarscheduling/scheduledateslist', 
          {requiredVendorTypes: this.patientCase.requiredVendorTypes,
           ignoreCaseId: this.patientCase._id,
           vendorIds: this.allVendors(this.patientCase.requiredVendorTypes),
           monthDateRange: this.curScheduleMonth
          }, (response)=>{
        this.scheduleMonthAvailableDates = response;
      });
    }`
  },
  deleteCase: {
    body: `
    var msg = '';
    if (this.patientCase.opReportUploaded) {
      msg += 'This surgery has already been completed\\n';
    }
    var paymentsMade = this.patientCase.paymentsDue.reduce((cnt,pd)=>{
      cnt += pd.transactions.filter(txn=>(txn.txnType=='Payment')).length;
      return cnt;
    },0);
    if (paymentsMade>0) {
      msg += 'This case already has '+paymentsMade+' payments received.\\n';
    }
    msg += 'Are you sure you want to delete this case?';
    if (!confirm(msg)) return;
      this._appDelete('patientcaseedit/'+this.patientCase._id, (response) => {
        if (response.success) {
          this._gotoAppPage('home');
          this._showNotification( 'Case '+this.patientCase.caseId+' deleted.');
        } else {
          this._showError( 'This case cannot be deleted at this time.');
        }
      });`
  },
  cancelCase: {
    body: `
      this._appPost('patientcaseedit/cancel', {patientCaseId:this.patientCase._id}, (response)=>{
        if (response.success) {
          this.patientCase.status = 'Canceled';
          this.$store.commit('SET_SUCCESS', 'Case '+this.patientCase.caseId+' canceled.');
        } else {
          this.$store.commit('SET_ERRMSG', 'This case cannot be canceled at this time.');
        }
      });`
  },
  reopenCase: {
    body: `
      this._appPost('patientcaseedit/reopen', {patientCaseId:this.patientCase._id.toString()}, (response) => {
        if (response.success) {
          this.patientCase.status = 'Open';
          this.$store.commit('SET_SUCCESS', 'Case '+this.patientCase.caseId+' has been reopened.')
        } else {
          this.$store.commit('SET_ERRMSG', 'Failed to reopen this case.');
        }
      });`
  },
  gotoWorkflowAction: {
    args:["destWorkflowState"],
    body: `
//FIXME    this.routerParams.caseId = this.patientCase.caseId;

    var params = Object.assign(workflowRouteMap[destWorkflowState].params||{}, {patientCaseId:this.patientCase._id, from:'patientCase', caseId:this.patientCase.caseId });
    this._gotoAppAge( workflowRouteMap[destWorkflowState].name, params );`
  },
  cancelForm: {
    body:`
    this.$store.commit('SET_RESULTNOTIFICATION', '')
    this._routerGoBack()`
  },
  showRemainingVendors: {
    args: ["orgType"],
    body: `
    return this.orgTypesMap[orgType] && (this.vendorEditable(orgType) || this._deepGet(this.orgTypesMap[orgType], 'value'));`
  },
  allVendors: {
    args: ["requiredVendorTypes"],
    body: `
    if (!requiredVendorTypes) return [];
    var vendorIds = [];
    requiredVendorTypes.forEach(orgType=>{
      var vendorFee = this.orgTypesMap[orgType];
      if (vendorFee.value && vendorFee.value.key) {
        var vf = Object.assign({}, vendorFee.value);
        vendorIds.push(vf.vendor._id || vf.vendor);
      }
    });
    return vendorIds;`
  },

};
const filters = {
  date: {
    args: ["value"],
    body: `return value?moment(value).format('l'):'';`
  }
}
const computed = {
  compVal: {
    body: `
    return JSON.stringify(this.payers);`
  },
  primaryClaimsPayerName: {
    body: `
    return this._deepGet(this.patientCase, "primaryPayer.claimsPayer.name");`
  },
  fmtDatePreopReportReceived: {
    body: `
    return this.$options.filters.date(this.patientCase.datePreopReportReceived);`
  },
  claimUploadLog: {
    body: `
    return this.patientCase.claimUploadLog || [];`
  },
  apOk: {
    body: `
    return true; //this.user.rolesMap['AP'] || this.user.rolesMap['BMCSYSADMIN'];`
  },
  payerEditable: {
    body: `
    return this.editMode=='create';`
  },
  openNotPatientAccepted: {
    body: `
    return this.patientCase.status=='Open' && !this.patientCase.patientTermsAcceptanceDate;`
  },
  payorInfoEditable: {
  body: `
    var retVal = (!this.patientCase.opReportUploaded || (
        !this._deepGet(this,'primaryPayerPaymentDue.transactions').length
      ) || (
        this._deepGet(this, 'secondaryPayerPaymentDue.payerType') && !this._deepGet(this,'secondaryPayerPaymentDue.transactions').length
      )
    );
    return retVal;`
  },
  surgeryCompleted: {
    body: `
    return this.patientCase.opReportUploaded;`
  },
  procedureEditable: {
    body: `
    return this.editMode=='create' || !this.hasPayerInfo || !this.patientCase.opReportUploaded;`
  },
  primaryPayerPaymentDue: {
    body: `
    if (!this.patientCase.paymentsDue) return {};
    return this.patientCase.paymentsDue.find(pd=>(pd.payerType=='Primary Payer')) || {};`
  },
  secondaryPayerPaymentDue: {
    body: `
    if (!this.patientCase.paymentsDue) return {};
    return this.patientCase.paymentsDue.find(pd=>(pd.payerType=='Secondary Payer')) || {};`
  },
  diagnosisEditable: {
    body: `
    return this.patientCase.status=='Open' && !this.primaryPayerPaymentDue.dateBillSent && !this._deepGet(this, 'patientCase.primaryPayer.claimsTransmission.claimProcessingState');`
  },
  serviceDateEditable: {
    body: `
    return this.patientCase.status=='Open' && !this.patientCase.opReportUploaded;`
  },
  paymentMethod: {
    body: `
    if (!this._deepGet(this,'patientCase.primaryPayer.claimsPayer._id')) {
      return '';
    }
    return ' '+(this._deepGet(this, 'patientCase.primaryPayer.claimsPayer.isSelfPayer')?'Self-payer':'Insurance');`
  },
  caseId: {
    body: `
    if (this._appParams.mode=='create') {
      return '(auto-generated)'
    }
    var caseId = this.patientCase.caseId || '';
    var status = this.patientCase.status || '';
    return caseId+((status && status!='Open')?(' ('+status+')'):'');`
  },
  workflowActions: {
    body: `
    debugger;
    return this.workflowAssignments.filter(wa=>(wa.workflowState!='Needs Tentative Scheduling' && wa.workflowState!='Book Confirmed Date' &&
      (wa.workflowState!='Disburse Payments' || this.apOk)))
      .map((wa)=>{
        var label = workflowRouteMap[wa.workflowState].label;
        if (wa.workflowState == 'Need Payer Authorization') {
          label = 'Get Primary Payer Authorization';
        } else if (wa.workflowState == 'Need Secondary Payer Authorization') {
          label = 'Get Secondary Payer Authorization';
        }
        return {name:wa.workflowState, label:label};
      })`
  },
  isEditable: {
    body: `
    return !this.patientCase.status || this.patientCase.status == 'Open';`
  },
  needBookingConfirmation: {
    body: `
    return this.isEditable && this.patientCase.calendarBooking && this._deepGet(this, "patientCase.calendarBooking.day") && this.patientCase.calendarBooking.status != 'Booked';`
  },
//  ...mapState([ 'currentPatientCaseId', 'user', 'routerParams']),
  diagnoses: {
    body: `
    return (this._deepGet(this, 'patientCase.procedure.diagnoses')||[]);`
  },
  icd10Readonly: {
    body: `
    return this.diagnoses.length<=1 && this.diagnosisEditable;`
  },
  isBooked: {
    body: `
    return this.patientCase.calendarBooking.status=='Booked';`
  },
  hasCalendarBooking: {
    body: `
    return this._deepGet(this, 'patientCase.calendarBooking.day');`
  },
  availableDatesList: {
    body: `
    if (!this.serviceDateEditable) return [];
    if (!this.curScheduleMonth) {
      return this.sDateOfService?[{value:'UNSCHEDULE', text:'UNSCHEDULE'}]:[];
    } else {
      var options =this.scheduleMonthAvailableDates.map((dt)=>{
        var m = this._moment(dt);
        return {value:m.format('YYYY-MM-DD'), text:m.format('l')+' '+m.format('ddd')};
      });
      if (this.sDateOfService) {
        if (this.editMode=='create') {
          options.unshift({value:'', text:''});
        }
      }
      return options;
    }`
  },
  hasPayerInfo: {
    body: `
    return this._deepGet(this, 'patientCase.primaryPayer.relationshipToPatient') != null;`
  },
  procedureOptions: {
    body: `
    if (!this.patientCase.primaryPayer || !this.patientCase.primaryPayer.claimsPayer  || !this.patientCase.primaryPayer.claimsPayer._id
        || this.patientCase.status != 'Open' || this.patientCase.opReportUploaded) {
        return [];
    }
    var validProcedures = this.patientCase.primaryPayer.claimsPayer.procedures.reduce((mp,p)=>{
      mp[p.procedure._id] = !this.hasPayerInfo || p.contractedRate==this.patientCase.primaryPayer.contractedRate || this.patientCase.procedure._id == p.procedure._id;
      return mp;
    },{});
    var procs = this.procedures.filter(p=>(validProcedures[p._id]));
    return procs;`
  },
  payerOptions: {
    body: `
    var retList = [].concat(this.payers).sort((a,b)=>(a.name<b.name?-1:(a.name>b.name?1:0)));
    return retList;`
  }
};

const components = [patientHdrCfg];
const uiConfig = {
  requiredUserData: [],
  dataModel:dataModel,
  methods: uiMethods,
  filters: filters,
  computed:computed,
  components: components,
  uiSchema: {
    component: "container", contents: [
      {component: "card", 
      contents: [
        {component: "cardTitle", template:'<span class="text-h5">{{ formTitle }} - {{caseId}}</span>'},
        {component: "cardText", contents:[
          {component: "form", ref:"form", vmodel:"valid", props:{"lazy-validation":true}, contents:[
            {component: "row", props:{wrap:true}, contents:[
              {component: "dynamicComponent", name: "PatientHeader", props:{isReadOnly:true, ":patientId":"patientCase.patient.patientId", 
                ":userId":"patientCase.patient.cloudHavenUserId", showAddress:true}}
            ]},
            {component: "row", contents:[
              {component: "col", props:{cols:12, md:6, sm:12}, contents:[
                {component: "textField", props:{":value":"caseId", readonly:true, label:"Case #"}},
                { component: "autocomplete", show:"payerEditable", vmodel:"patientCase.primaryPayer.claimsPayer",
                  props:{placeholder:"Enter some letters of the payer name", ":items":"payerOptions", "item-value":"_id", "item-text":"name", "return-object":true,
                  ":label":"'Payer'+paymentMethod"}, on:{change:"onPayerChange"}, rules:["requiredObjectRule"]},
                {component: "textField", omit:"payerEditable", props:{readonly:true, ":value":"primaryClaimsPayerName", ":label":"'Payer'+paymentMethod"}},
                {component: "select", show:"procedureEditable", vmodel:"patientCase.procedure",
                  props:{ ":items":"procedureOptions", "item-value":"_id", "item-text":"name", "return-object":true, label:"Procedure"},
                  rules:["requiredObjectRule"], on:{ change:"onProcedureChange"}},
                {component: "textField", omit:"procedureEditable", props:{readonly:true, ":value":"patientCase.procedure.name", label:"Procedure"}},
                {component: "textField", show:"icd10Readonly", props:{ ":value":"patientCase.icd10Code.name", label:"Diagnosis (ICD10 Code)", readonly:true}},
                {component: "select", omit:"icd10Readonly", vmodel:"patientCase.icd10Code", props:{":items":"diagnoses", "item-value":"_id", "item-text":"name", 
                  label:"ICD10 Code", "return-object":true}, rules:["requiredObjectRule"]},
                {component: "textField", props:{readonly:true, ":value":"patientCase.cptCode.name", label:"CPT Code"}}
              ]},
              {component: "col", props:{cols:12, md:6, sm:12}, contents:[
                {component: "loop", dataList:"patientCase.requiredVendorTypes", indexIsKey:true, itemAlias:"orgType", contents:
                  {component:"div", show:"showRemainingVendors(orgType)", contents:[
                    {component: "textField", omit:"vendorEditable(orgType)", props:{":value":"orgTypesMap[orgType].value.text", readonly:true,
                      ":label":"orgType"}},
                    {component: "select", show:"vendorEditable(orgType)", vmodel:"orgTypesMap[orgType].value",
                      props:{":items":"orgTypesMap[orgType].options", "item-value":"key", "item-text":"text", "return-object":true, ":label":"orgType"},
                      on:{change:"vendorChange"}, rules:["requiredObjectRule"]}
                  ]}
                }
              ]}
            ]},
            {component: "row", contents:[
              {component: "col", show:"hadPendingAuth", props:{sm:12, md:5, lg:5}, contents: [
              {component: "textField", show:"patientCase.status=='Open'", vmodel:"patientCase.payerInfo.pendingAuthorizationCode",
                props: {label:"Pending Authorization Code"}},
              {component: "textField", show:"patientCase.status=='Open'", props:{dense:true, readonly:true, ":value":"patientCase.payerInfo.pendingAuthorizationCode",
                label:"Pending Authorization Code"}}
              ]},
              {component: "col", show:"hadAuth", props:{sm:12, md:5, lg:5}, contents: [
                {component: "textField", show:"patientCase.status=='Open'", vmodel:"patientCase.payerInfo.approvedAuthorizationCode",
                  props:{label:"Approved Authorization Code"}},
                {component: "textField" , omit:"patientCase.status=='Open'", props:{dense:true, readonly:true, ":value":"patientCase.payerInfo.approvedAuthorizationCode",
                  label:"Approved Authorization Code"}}
              ]}
            ]},
            {component: "row", class:"justify-space-around flex-wrap mt-0 mb-2", contents:[
              {component:"col", props:{cols:12, sm:12, md:5, lg:5, xl:5}, contents: [
                {component: "textField", props:{dense:true, readonly:true, ":value":"sDateOfService", label:"Current Date of Service"}},
                {component: "textField", show:"patientCase.datePreopReportReceived", props:{dense:true, readonly:true, 
                  ":value":"fmtDatePreopReportReceived", label:"Date Pre-op Report Received"}},
                {component: "div", show:"workflowActions.length>0", contents: [
                  {component: "loop", debug:true, dataList:"workflowActions", indexIsKey:true, itemAlias:"action", contents:
                    {component:"template", template:'<span><a @click="gotoWorkflowAction(action.name)">{{action.label}}</a><br/></span>'}}
                ]}
              ]},
              {component:"col", props:{cols:12, sm:12, md:5, lg:5, xl:5}, contents: [
                {component: "select", show:"serviceDateEditable", vmodel:"curScheduleMonth", props:{ ":items":"scheduleMonthOptions", label:"Month", "persistent-hint":true,
                    hint:"Month filter for Date of Service"}, on:{change:"scheduleMonthChange"}},
                {component:"select", show:"serviceDateEditable", vmodel:"dateOfService", props:{":items":"availableDatesList", 
                  ":label":"(patientCase.calendarBooking.day?'Change ':'')+'Date of Service'", "persistent-hint":true, 
                    ":hint":"'Select a '+(patientCase.calendarBooking.day?'new ':'')+' Date of Service'", 
                    ":append-outer-icon":"editMode!='mdi-file-plus'?'mdi-calendar-plus':null", ":append-outer-icon-cb":"editMode!='create'?gotoEventCalendar:null"},
                    on:{change:"dateOfServiceChange"}}
              ]}
            ]},
            {component: "divider", class:"mt-4"},
            {component: "row", class:"justify-space-around flex-wrap px-10", contents: [
              {component: "col", show:"patientCase.status=='Open'", props:{ cols:12}},
              {component: "textarea", vmodel:"notesEntry", props:{label:"Additional Notes", "hide-details":true}, class:"mb-1"}
            ]}

          ]}
        ]},
        {
          component: "cardActions",
          contents: [
            {component: "button", show:"true; /*user.rolesMap['BMCSYSADMIN']*/", props: { elevation:2, color:"blue darken-1", text:true}, on:{click:"deleteCase"}, 
              contents: [
              {component: "icon", props:{left:true, dark:true}, contents:"mdi-trash-can"},
              "Delete"
            ]},
            {component: "spacer", show:"patientCase.status=='Open'"},
            {component: "button", show:"patientCase.status=='Open'", props: { elevation:2, color:"blue darken-1", text:true}, 
              on:{click:"cancelCase"}, contents:[
              {component: "icon", props:{left:true, dark:true}, contents:"mdi-cancel"},
              "Cancel Case"
            ]},
            {component: "spacer", show:"patientCase.status=='Open'"},
            {component: "button", show:"patientCase.status && patientCase.status!='Open'&& patientCase.status!='Closed'",
              props: { elevation:2, color:"blue darken-1", text:true}, on:{click:"reopenCase"}, contents: [
              {component: "icon", props:{ left:true, dark:true}, contents:"mdi-redo-variant"},
              "Re-open Case"
            ]},
            {component: "spacer"},
            {component: "button", props: { elevation:2, color:"blue darken-1", text:true}, nativeOn:{click:"showCostEstimatePdf"}, contents:[
              {component: "icon", props:{left:true, dark:true}, contents:"mdi-printer"},
              "Print Cost Estimate"
            ]},
            {component: "spacer", show:"needBookingConfirmation"},
            {component: "button", show:"needBookingConfirmation", props:{ elevation:2, color:"blue darken-1", text:true}, on:{click:"confirmBooking"}, contents:[
              {component: "icon", props:{ left:true, dark:true}, contents:"mdi-lock"},
              "Confirm Booking"
            ]},
            {component: "spacer", show:"isEditable && !_appParams.isForComfirmingBooking"},
            {component: "button", show:"isEditable && !_appParams.isForConfirmingBooking", props: { elevation:2, color:"blue darken-1",text:true}, 
              on:{click:"saveForm"}, contents:[
              {component: "icon", props:{left:true, dark:true}, contents:"mdi-content-save"},
              "Save"
            ]}
          ]
        }
    ]},
    {component: "tabs", show:"patientCaseId", props:{dark:true, "background-color":"#1E5AC8", color:"#FFF10E"}, contents: [
      {component: "tab", contents:"Payer Information"},
      {component: "tab", contents:"Payments Due"},
      {component: "tab", show:"apOk", contents:"Payables"},
      {component: "tab", contents:"Attachments"},
      {component: "tab", contents:"Vendor Accept Log"},
      {component: "tabItem", contents:[
        "CasePayorInfo"//<CasePayorInfo :isEditable="payorInfoEditable" :patientCase="patientCase"></CasePayorInfo>
      ]},
      {component: "tabItem", contents:[
        "CasePaymentsDue"//<CasePaymentsDue :patientCase="patientCase"></CasePaymentsDue>
      ]},
      {component: "tabItem", show:"apOk", contents:[
        "Payables"//<Payables :patientCase="patientCase" :payables="patientCase.payables" :canEdit="patientCase.status=='Open'"/>
      ]},
      {component: "tabItem", props:{lazy:true}, contents:[
        "Attachments"//<Attachments :patientCaseId="patientCaseId" :isEditable="isEditable"/>
      ]},
      {component: "tabItem", contents:[
        {component: "dataTable", props:{ ":headers":"confirmationsHeader", ":items":"patientCase.confirmations", "hide-default-footer":true,
         "disable-pagination":true}, class:"elevation-1", scopedSlots: {
           item: {
             component: "template", template:"tr><td>{{ item.vendor.name }}</td><td>{{ item.datetime | datetime }}</td></tr>"
           }
         }
        }
      ]},  
    ]}
  ]}
};

import BaseAction from '../actions/baseaction'
import Roles from '../../models/workflowroles'
export class CaseFormPage extends BaseAction{
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.Scheduler];
  }
  
  route() {

    this.router.get("/", (req, res) => {
      res.json(uiConfig)
    });

    return this.router;
  }
}
