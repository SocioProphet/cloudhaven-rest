const dataModel = {
  valid: false,
  error: '',
  payerNotesDlg: false,
  patientStatementDlg: false,
  statementNote: '',
  updateStatementSentDate: true,
  refCodeErrMsg: '',
  setup:{paymentMethods:[]},
  paymentMethod: '',
  creditCardOnFile: false,
  promissoryNoteSigned: false,
  amountReceived:'',
  receiptRefCode: '',
  adjustmentAmount: '',
  adjustmentReason: '',
  notesEntry: '',
  origReceivableAction: '',
  receivableAction: '',
  extensionDays: '',
  extDaysErrMsg:'',
  monthlyAmount: '',
  dueDayOfMonth: '',
  dueDayofMoErrMsg: '',
  sNewDueDate: '',
  moAmtErrMsg: '',
  amountReceivedErrMsg:'',
  sTxnDate:'',
  patientCase: {
    secondaryPayerAmountDue: null,
    primaryPayerAmountDue: null,
    patientAmountDue: null,
    secondaryPayerAmountReceived: null,
    primaryPayerAmountReceived: null,
    patientAmountReceived: null,
    secondaryPayerAmount: null,
    primaryPayerAmount: null,
    patient:{contactInfo:{}},
    payerInfo:{}, primaryPayer:{_id:'', name:''}, secondaryPayer:{_id:'', name:''}, procedure:{}, paymentsDue:[], notesLog:[]},
  submitDisable:false,
};
const filters = {
  formattedNumber: {
    args: ["value", "decimalPlaces"],
    body: `
    decimalPlaces = decimalPlaces || 2;
    if (value == undefined || value===null || value==='') return '';
    var val = value.toLocaleString(undefined, {minimumFractionDigits: decimalPlaces||0, maximumFractionDigits: decimalPlaces||0});
    return val;`
  }
};
const computed = {
  fmtPayer2AmtDue: "return this.$options.filters.formattedNumber(this.patientCase.secondaryPayerAmountDue);",
  fmtPayer1AmtDue: "return this.$options.filters.formattedNumber(this.patientCase.primaryPayerAmountDue);",
  fmtPatientAmtDue: "return this.$options.filters.formattedNumber(this.patientCase.patientAmountDue);",
  fmtPayer2AmtRcvd: "return this.$options.filters.formattedNumber(this.patientCase.secondaryPayerAmountReceived);",
  fmtPayer1AmtRcvd: "return this.$options.filters.formattedNumber(this.patientCase.primaryPayerAmountReceived);",
  fmtPatientAmtRcvd: "return this.$options.filters.formattedNumber(this.patientCase.patientAmountReceived);",
  fmtPayer2Amount: "return this.$options.filters.formattedNumber(this.patientCase.secondaryPayerAmount);",
  fmtPayer1Amount: "return this.$options.filters.formattedNumber(this.patientCase.primaryPayerAmount);",
  fmtPatientAmount: "return this.$options.filters.formattedNumber(this.patientCase.patientAmount);",
  curPayerId: "return this.$safeRef(this.patientCase[this.payerSelector].claimsPayer)._id;",
  payerName: "return this.$safeRef(this.patientCase[this.payerSelector].claimsPayer).name;",
  canTransferBalance: `
    if (this.payerType!='Primary Payer') return false;
    var paymentTxn = this.paymentDue.transactions.find(txn=>(txn.txnType=='Payment'));
    return this.patientCase.status == 'Open' && paymentTxn && this.paymentDue.currentAmountDue>0;`,
  overPaymentAmount: "return (parseFloat(this.amountReceived||0)-this.paymentDue.currentAmountDue).toFixed(2)",
  overpaymentMade: "return this.overPaymentAmount>0;",
  amountNowDue: `
    var origAmountDue = this.patientCase.patientAmountDue;
    if (this.payerType=='Primary Payer') {
      origAmountDue = this.patientCase.primaryPayerAmountDue;
    } else if (this.payerType=='Secondary Payer') {
      origAmountDue = this.patientCase.secondaryPayerAmountDue;
    }
    return origAmountDue - (this.adjustmentAmount + this.amountReceived);`,
  receivableActionEnabled: `
    if (this.paymentDue.payerType!='Patient') return false;
    var adjAmount = this.adjustmentAmount?parseFloat(this.adjustmentAmount):0;
    var amtReceived = this.amountReceived?parseFloat(this.amountReceived):0;
    if (this.paymentDue.currentAmountDue>(adjAmount+amtReceived) && 
      (this.patientCase[this.payerSelector+'AmountReceived']>0 || amtReceived>0)) {
      return true;
    } else {
      this.receivableAction == '';
      return false;
    }`,
  paymentOptions: "return this.payerType=='Patient'?['', 'Extend Due Date', 'Monthly Payment Plan', 'Written Off', 'Sent to Collections']:['Extend Due Date', 'Written Off', 'Sent to Collections'];",
  payerType: "return this._appParams.payerType;",
  payerSelector: "return this.payerType=='Patient'?'patient':(this.payerType=='Primary Payer'?'primaryPayer':'secondaryPayer');",
  paymentDue: "return this.patientCase.paymentsDue.find((pd)=>(pd.payerType==this.payerType)) || {}",
  sDueDate: `
    var sdd = this.paymentDue.dueDate?moment(this.paymentDue.dueDate).format('l'):'';
    if (this.paymentDue.dueDate) {
      var mDueDate = moment(this.paymentDue.dueDate).startOf('day');
      var mToday = moment().startOf('day');
      if (mDueDate.isAfter(mToday, 'day')) {
        sdd += ' ('+mDueDate.diff(mToday, 'days')+' days away)';
      } else if (mDueDate.isBefore(mToday, 'day')) {
        sdd += ' (*** '+mToday.diff(mDueDate, 'days')+' DAYS OVERDUE ***)';
      }
    }
    return sdd;`,
  contactDetails : "return this.contactDetailsList.join('\n');",
  contactDetailsList: `
    try {
      var details = this.payerType=='Patient'?this.patientCase.patient.contactInfo:this.patientCase[this.payerSelector].claimsPayer/*.claimsXContact.contactInfo*/;
      var list = [];
      if (this.payerType != 'Patient') {
        list.push(details.name)
      }
      if (details.phone) list.push(this.$options.filters.formattedPhone(details.phone)+((this.payerType=='Patient' && details.preferredContactMethod=='Phone')?' (preferred contact method)':''));
      if (details.email) list.push(details.email+((this.payerType=='Patient' && details.preferredContactMethod=='Email')?' (preferred contact method)':''));
      return list;
    } catch (e) {
      return [];
    }`,
  contactDetailRows: "   return this.contactDetailsList.length;"
};

const uiMethods = {
  requiredRule: {
    args: ["v"],
    body: `
    return !!v || "Required."
    `
  },
  decimalNumberRule: {
    args: ["value"],
    body: `value => (value && /^(\d*\.)?\d+$/.test(value)) || 'Enter decimal number.'`
  },
  requiredObjectRule: {
    args: ["value"],
    body: `return (value && value._id!='') || 'Required.'`
  },
  dueDate: {
    args: ["value"],
    body: `
    if (!value) return true;
    var isValid=false;
    try {
      isValid = moment(value, 'l').isValid();
      if (isValid && moment().startOf('day').isAfter(moment(value, 'l').startOf('day'))) {
        return 'Please enter a new Due Date after today.';
      }
    } catch (e) {
      console.log(e);
    }
    return isValid?true:'Please enter a valid date format.';`
  },
  mounted: `
    var amtRcvdEl = this.$refs.amountReceived;
    setTimeout(() => {
      amtRcvdEl.focus();
    });`,
  created: `
    this._appGet('oscsetup', function(data) {
      this.setup = data;
    });
    if (this._appParams.patientCaseId) {
      this._appGet('receivepayment/'+this._appParams.patientCaseId, (response)=>{
        this.patientCase = _merge( this.patientCase, response );
//        this.$root.$emit('alerts available', this.patientCase.alerts.filter(a=>(!a.dismissed)));
        var payerType = this._appParams.payerType;
        var paymentDueId = this._appParams.paymentDueId;
        var paymentDue = this.patientCase.paymentsDue.find((pd)=>((paymentDueId && pd._id==paymentDueId) || (payerType && pd.payerType==payerType)));
        this.origReceivableAction = paymentDue.receivableAction;
        if (paymentDue.receivableAction == 'Monthly Payment Plan' && paymentDue.currentAmountDue>0) {
          this.receivableAction = 'Monthly Payment Plan'; 
          this.dueDayOfMonth = paymentDue.dueDayOfMonth;
          this.monthlyAmount = paymentDue.monthlyAmount;
          this.creditCardOnFile = paymentDue.creditCardOnFile;
          this.promissoryNoteSigned = paymentDue.promissoryNoteSigned;
        }
      });
    } else {
      this._gotoAppPage( 'home')
    }'`,
  useFullAmount: {
    args: ["amount"],
    body: 'this.amountReceived = amount;'
  },
  showPayerNotes: "this.payerNotesDlg=true;",
  printStatement: `
    this._pdfGet('patientstatement', {patientId: this.patientCase.patient._id, statementNote:this.statementNote, updateStatementSentDate:this.updateStatementSentDate}, (response)=>{
      const file = new Blob( [response], {type: 'application/pdf'});
      const fileURL = URL.createObjectURL(file);
      var win = window.open(fileURL, 'Cost Estimate', "height=960,width=840,toolbar=no,menubar=no,scrollbars=yes,location=no,status=no");
      try {
        win.focus();
      } catch(e){
        console.log(e);
      }
    });`,
  onAmountReceivedChange: `
    this.sTxnDate = (this.amountReceived || this.adjustmentAmount)?moment().format('MM/DD/YYYY'):'';
    if (this.amountNowDue<=0) {
      this.receivableAction = '';
      this.monthlyAmount = 0;
      this.dueDayOfMonth = '';
      this.sNewDueDate = '';
      this.extensionDays = '';
    } else if (this.receivableAction=='Monthly Payment Plan') {
      this.sNewDueDate = this.amountReceived>=this.paymentDue.monthlyAmount? 
        moment(this.paymentDue.dueDate).add(1, 'months').format('MM/DD/YYYY'): moment(this.paymentDue.dueDate).format('MM/DD/YYYY');
    }`,
  onDueDayOfMonthChange: `
    if (this.receivableAction=='Monthly Payment Plan') {
      var mDueDate = moment().date(this.dueDayOfMonth);
      if (mDueDate<moment().endOf('day')) mDueDate = mDueDate.add(1, 'months');
      this.sNewDueDate = mDueDate.format('MM/DD/YYYY');
    } else {
      this.extensionDays = '';
    }`,
  onNewDueDateChange:`
    if (this.sNewDueDate) {
      if (this.receivableAction=='Extend Due Date') {
        this.extensionDays = moment(this.$digitsToDate(this.sNewDueDate)).startOf('day').diff(moment().startOf('day'), 'days');
      } else if (this.receivableAction=='Monthly Payment Plan') {
        this.dueDayOfMonth = moment(this.$digitsToDate(this.sNewDueDate)).date();
        if (this.dueDayOfMonth>28) this.dueDayOfMonth = 28;
      }
    }`,
  onExtensionDaysChange:`
    if (this.receivableAction=='Extend Due Date') {
      this.sNewDueDate = moment().add(this.extensionDays||0, 'days').format('MM/DD/YYYY');
    } else {
      this.sNewDueDate = '';
    }`,
  receivePayment: `
    this.refCodeErrMsg = '';
    this.amountReceivedErrMsg = '';
    if (this.payerType=='Patient' && this.paymentDue.currentAmountDue<this.amountReceived) {
      this.amountReceivedErrMsg = 'Must not be greater than Current Amount Due.';
      return;
    }
    if (this.payerType!='Patient' && this.amountReceived && !this.receiptRefCode) {
      this.refCodeErrMsg = 'Enter a Check/EFT #.';
      return;
    }

    this.moAmtErrMsg = '';
    this.dueDayofMoErrMsg = '';
    if (this.receivableAction == 'Monthly Payment Plan') {
      if (!this.monthlyAmount) {
        this.moAmtErrMsg = 'Required for Monthly Payment Plan.';
        return;
      }
      if (!this.dueDayOfMonth) {
        this.dueDayofMoErrMsg = 'Required for Monthly Payment Plan.';
        return;
      }
      if (this.origReceivableAction==this.receivableAction && this.amountReceived && this.monthlyAmount>this.amountReceived && !confirm('Amount being received is less than the payment plan monthly amount - ok to proceed?')) {
        return;
      }
    }
    this.extDaysErrMsg = '';
    if (this.receivableAction == 'Extend Due Date') {
      if (!this.extensionDays) {
        this.extDaysErrMsg = 'Required for Extend Due Date.';
        return;
      }
    }
    if (this.$refs.form.validate()) {
      var notesLines = [];
      if (this.adjustmentAmount) {
        notesLines.push('$'+this.adjustmentAmount.toLocaleString()+' adjustment made.');
      }
      if (this.amountReceived) {
        notesLines.push('$'+this.amountReceived.toLocaleString()+' '+(this.amountReceived<this.paymentDue.currentAmountDue?'PARTIAL':'FULL')+' '+this.payerType+' payment made.');
      }
      var sNewDueDate = this.sNewDueDate?moment(this.$digitsToDate(this.sNewDueDate)).format('L'):'';
      if (this.receivableAction == 'Extend Due Date' && this.extensionDays && sNewDueDate) {
        notesLines.push('Due date extended '+this.extensionDays+' days to '+sNewDueDate+'.');
      } else if (this.origReceivableAction!=this.receivableAction && this.receivableAction == 'Monthly Payment Plan' && this.monthlyAmount && this.dueDayOfMonth) {
        notesLines.push('Monthly Payment Plan established: $'+this.monthlyAmount+'/mo due on the '+this.$ordinalSuffix(this.dueDayOfMonth)+' day of the month - next payment due on '+sNewDueDate+'.');
      } else if (this.origReceivableAction!=this.receivableAction && this.receivableAction == 'Written Off') {
        notesLines.push('WRITTEN OFF');
      } else if (this.origReceivableAction!=this.receivableAction && this.receivableAction == 'Sent to Collections') {
        notesLines.push('SENT TO COLLECTIONS');
      } else if (sNewDueDate && this.paymentDue.originalDueDate != moment(sNewDueDate).toDate() ) {
        notesLines.push('New Due Date set to '+sNewDueDate+'.');
      }
      if (this.notesEntry) {
        notesLines.push(this.notesEntry);
      }
      this.submitDisable = true;
      var postObj = {
        patientCaseId: this.patientCase._id,
        amountReceived: this.amountReceived,
        paymentMethod: this.paymentMethod,
        receiptRefCode: this.receiptRefCode,
        adjustmentAmount: this.adjustmentAmount,
        adjustmentReason: this.adjustmentReason,
        payerType: this.payerType,
        receivableAction: this.receivableAction || null
      }
      if (notesLines.length>0) {
        postObj.notesEntry = notesLines.join('\n');
      }
      if (this.receivableAction == 'Extend Due Date') {
        postObj.monthlyAmount = null;
        postObj.dueDayOfMonth = null;
        postObj.extensionDays = this.extensionDays;
        if (this.sNewDueDate) {
          postObj.dueDate = this.$digitsToDate(this.sNewDueDate);
        }
      } else if (this.receivableAction == 'Monthly Payment Plan') {
        postObj.extensionDays = null;
        postObj.dueDayOfMonth = this.dueDayOfMonth;
        postObj.monthlyAmount = this.monthlyAmount;
        if (this.sNewDueDate) {
          postObj.dueDate = this.$digitsToDate(this.sNewDueDate);
        }
        postObj.creditCardOnFile = this.creditCardOnFile || false;
        postObj.promissoryNoteSigned = this.promissoryNoteSigned || false;
      } else {
        postObj.monthlyAmount = null;
        postObj.dueDayOfMonth = null;
        postObj.extensionDays = null;
      }
      if (this.payerType=='Patient') {
        postObj.requiredBeforeSurgery = this.paymentDue.requiredBeforeSurgery;
      }
      if (this.sTxnDate) {
        postObj.txnDate = moment(this.sTxnDate, 'MM/DD/YYYY');
      }
      this._appPost('receivepayment', postObj, (response)=>{
        if (response.success) {
          EventBus.$emit('refresh-pipeline');
          this._showNotification(this.payerType+' payment '+this.$options.filters.formattedNumber(this.amountReceived)+' received for Case '+this.patientCase.caseId+'.')
          this._gotoAppPage( 'home'})
        } else if (response.errMsg) {
          this._showError(response.errMsg)
        }
      });
    }`,
  goBack: `
    if (this._appParams.from == 'patientCase') {
      this._gotoAppPage( 'patientCase', params:{patientCaseId:this.patientCase._id}})
    } else {
      this._routerGoBack();
    }`
}

const uiConfig = {
  requiredUserData: [],
  dataModel:dataModel,
  uiMethods: uiMethods,
  filters: filters,
  computed:computed,
  uiSchema: {
    component: "div", contents: [
      {component: "container", contents: [
        {component: "card", contents: [
          {component: "cardTitle", template: '<span class="text-h5">Receive {{payerType}} Payment</span>'},
          {component: "cardText", contents: [
            {component: "form", ref:"form", vmodel:"valid", props:{"lazy-validation":true}, contents: [
              {component: "row", class:"justify-space-around flex-wrap fill-height pb-0", contents: [
                {component: "col", cols:"12", sm:"12", md:"5", lg:"5", class:"justify-start", contents: [
                  {component: "hover", style:"width:100%", class:"ml-3", scopedSlots: {
                    default: {
                      component: "div", style:"position:relative", contents: [
                        {component: "textField", props:{"readonly":true, ":value":"patientCase.patient.name", label:"Patient Name"}},
                        {component: "div", show:"hover", style:"position:absolute; top:-30px; left:60px; padding:4px;", contents: [
                          {component: "card", props:{color:"white", ":elevation":"8", class:"elevation-8"}, contents: [
                            {component: "cardText",
                              template:"<span>{{patientCase.patient.contactInfo.fullAddress}}<br/>{{patientCase.patient.contactInfo.phone | formattedPhone}}</span>"}
                          ]}
                        ]}
                      ]}
                    }
                  }
                ]},
                {component: "col", style:"width:100%", contents: [
                  {component: "textField", class:"pt-2", props:{readonly:true, ":value":"patientCase.caseId", label:"Case #"}}
                ]},
                {component: "col", style:"width:100%", contents: [
                  {component: "textField", class:"pt-0", props:{readonly:true, ":value":"patientCase.procedure.name", label:"Procedure"}}
                ]},
                {component: "col", style:"width:100%", contents: [
                  {component: "textField", show:"payerType=='Patient'", class:"pt-0", props: {readonly:true,
                            ":value":"fmtPatientAmount", label:"Amount"}},
                  {component: "textField", show:"payerType=='Primary Payer'", class:"pt-0", props: {readonly:true,
                            ":value":"fmtPayer1Amount", label:"Amount"}},
                  {component: "textField", show:"payerType=='Secondary Payer'", class:"pt-0", props: {readonly:true,
                            ":value":"fmtPayer2Amount", label:"Amount"}}
                ]},
                {component: "col", show:"(payerType=='Patient' && patientCase.patientAmountReceived) || payerType=='Primary Payer' || payerType=='Secondary Payer'", style:"width:100%", contents: [
                  {component: "textField",  show:"payerType=='Patient' && patientCase.patientAmountReceived", class:"pt-0", props: {readonly:true,
                            ":value":"fmtPatientAmtRcvd", label:"Amount Received to Date"}},
                  {component: "textField", show:"payerType=='Primary Payer'", class:"pt-0", props: {readonly:true,
                            ":value":"fmtPayer1AmtRcvd", label:"Amount Received to Date"}},
                  {component: "textField", show:"payerType=='Secondary Payer'", class:"pt-0", props: {readonly:true,
                             ":value":"fmtPayer2AmtRcvd", label:"Amount Received to Date"}}
                ]},
                {component: "col", style:"width:100%", contents: [
                  {component: "textField", class:"pt-0", readonly:true, ":value":"sDueDate", label:"Current Due Date"}
                ]},
                {component: "col", style:"width:100%", contents: [
                  {component: "textarea", class:"pt-0", props:{":value":"contactDetails", readonly:true, label:"Contact Info", 
                    ":rows":"contactDetailRows", "append-outer-icon":"mdi-note-multiple", ":append-outer-icon-cb":"showPayerNotes"}}
                ]},
              ]},
              {component: "col", cols:"12", sm:"12", md:"5", lg:"5", class:"justify-start pb-0", contents: [
                {component: "col", style:"width:100%", contents: [
                  {component: "textField",  show:"payerType=='Patient'", class:"pt-0", props: {readonly:true,
                    "append-outer-icon":"mdi-arrow-down-bold", ":value":"fmtPatientAmtDue", label:"Current Amount Due"},
                    on:{"click:append-outer":"useFullAmount(patientCase.patientAmountDue)"}},
                  {component: "textField", show:"payerType=='Primary Payer'", class:"pt-0", props: {readonly:true,
                    "append-outer-icon":"mdi-arrow-down-bold", ":value":"fmtPayer1AmtDue", label:"Current Amount Due"},
                    on:{"click:append-outer":"useFullAmount(patientCase.primaryPayerAmountDue)"}},
                  {component: "textField", show:"payerType=='Secondary Payer'", class:"pt-0", props: {readonly:true,
                    "append-outer-icon":"mdi-arrow-down-bold", ":value":"fmtPayer2AmtDue", label:"Current Amount Due"},
                    on:{"click:append-outer":"useFullAmount(secondaryPayerAmountDue)"}}
                ]},
                {component: "col", style:"width:100%", contents: [
                  {component: "textField",  class:"pt-0", props: {min:"0", step:"0.01", ":error-messages":"amountReceivedErrMsg", 
                            ref:"amountReceived", type:"number", label:"Amount Being Received"}, vmodel:"amountReceived", 
                            on:{change:"onAmountReceivedChange"}},
                  {component: "alert", class:"mt-0 mb-8", ":value":"overpaymentMade", props:{type:"warning"},
                    template:"<span style:'color:black'><b>{{overPaymentAmount}} OVERPAYMENT</b></span>"}
                ]},
                {component: "col", show:"paymentDue.payerType=='Patient'", style:"width:100%", contents: [
                  {component: "select", class:"pt-0", vmodel:"paymentMethod", ":items":"setup.paymentMethods", label:"Payment Method", ":rules":"amountReceived?[rules.required]:[]"}
                ]},
                {component: "col", style:"width:100%", contents: [
                  {component: "textField", class:"pt-0", ":error-messages":"refCodeErrMsg", vmodel:"receiptRefCode", ":label":"paymentDue.payerType=='Patient'?'Check #':'Check/EFT #'"}
                ]},
                {component: "col", show:"receivableActionEnabled", style:"width:100%", contents: [
                  {component: "select", class:"pt-0", vmodel:"receivableAction", props:{":items":"paymentOptions", label:"Payment Option"}}
                ]},
                {component: "col", show:"receivableActionEnabled && receivableAction=='Extend Due Date'", style:"width:100%; background-color:#F0F0F0", class:"pt-4", contents: [
                  {component: "textField", class:"pt-0", props:{min:"0", step:"1", ":error-messages":"extDaysErrMsg",
                            type:"number", label:"Extension Days"}, vmodel:"extensionDays", on:{change:"onExtensionDaysChange"}}
                ]},
                {component: "col", style:"width:100%; background-color:#F0F0F0", show:"receivableActionEnabled && receivableAction=='Monthly Payment Plan'", class:"pt-4", contents: [
                  {component: "row", class:"justify-space-around", contents: [
                    {component: "col", props:{sm:"6", md:"6", lg:"6"}, class:"mr-3", contents: [
                      {component: "textField", class:"pt-0", props:{min:"0", step:"0.01", ":error-messages":"moAmtErrMsg", type:"number", label:"Monthly Amount"},
                        vmodel:"monthlyAmount"}
                    ]},
                    {component: "col", props:{sm:"6", md:"6", lg:"6"}, contents: [
                      {component: "textField", class:"pt-0", props:{step:"1", min:"1", max:"28", ":error-messages":"dueDayofMoErrMsg",
                            type:"number", label:"Day of Month Payment Due"}, vmodel:"dueDayOfMonth", on:{change:"onDueDayOfMonthChange"}}
                    ]},
                  ]},
                  {component: "row", class:"justify-space-around", contents: [
                    {component: "col", props:{sm:"6", md:"6", lg:"6"}, contents: [
                      {component: "checkbox",  class:"pt-0 mt-0", vmodel:"creditCardOnFile", props:{label:"Credit Card on File"}}
                    ]},
                    {component: "col", props:{sm:"6", md:"6", lg:"6"}, contents: [
                      {component: "checkbox",  class:"pt-0 mt-0", vmodel:"promissoryNoteSigned", props:{label:"Promissory Note Signed"}}
                    ]},
                  ]}
                ]},
                {component: "col", style:"width:100%", show:"paymentDue.payerType=='Patient'", contents: [
                  {component: "textField", class:"pt-0", 
                          vmodel:"sNewDueDate", props:{label:"New Due Date"}, mask:"'##/##/####'", on:{change:"onNewDueDateChange"}}
                ]},
                {component: "col", style:"width:100%", contents: [
                  {component: "textField", class:"pt-0", vmodel:"sTxnDate", props:{label:"Date Received"},  mask:"'##/##/####'"}
                ]},
                {component: "col", style:"width:100%", contents: [
                  {component: "textField",  class:"pt-0", props:{min:"0", step:"0.01", label:"Adjustment Amount",
                            type:"number"}, vmodel:"adjustmentAmount", on:{change:"onAmountReceivedChange"}}
                ]},
                {component: "col", style:"width:100%", contents: [
                  {component: "textField",  class:"py-0", 
                            vmodel:"adjustmentReason", label:"Adjustment Reason"}
                ]},
                {component: "col", props:{"fill-height":true}}
              ]},
              {component: "row", props:{wrap:true}, class:"mx-6 mt-0 pt-0", contents: [
                {component: "col", cols:"12", sm:"12", md:"12", lg:"12", class:"mt-0 pt-0", contents: [
                  {component: "textarea", props:{"hide-details":true, label:"Additional Notes"}, class:"mb-1 mt-0 pt-0", vmodel:"notesEntry" }
                ]},
              ]}
            ]}, //form
            {component: "dialog", show:"payerType=='Patient'", vmodel:"patientStatementDlg", props:{"max-width":"500px"}, 
              on:{"keydown.esc.prevent":"patientStatementDlg = false"}, contents: [
              {component: "card", contents: [
                {component: "cardTitle", template:'<span class:"text-h5">Patient Statement</span>'},
                {component: "cardText", contents: [
                  {component: "form", vmodel:"valid", contents: [
                    {component: "textarea", vmodel:"statementNote", props: {label:"Statement Note", rows:"6"}},
                    {component: "checkbox", vmodel:"updateStatementSentDate", props: {label:"Update Date Statement Last Sent"}}
                  ]}
                ]},
                {component: "cardActions", contents: [
                  {component: "button", props:{elevation:"2", color:"blue darken-1", text:true}, on:{"click.native":"patientStatementDlg = false"}, contents:"Cancel"},
                  {component: "spacer"},
                  {component: "button", props:{elevation:"2", color:"blue darken-1", text:true}, on:{"click.native":"printStatement"}, contents: [
                    {component: "icon", props:{left:true, dark:true}, contents:"mdi-printer"},
                    "Print"
                  ]}
                ]}
              ]}
            ]} //dialog
          ]}, //cardText
          {component: "card-Actions", contents: [
            {component: "button", props:{elevation:"2", color:"blue darken-1", text:true}, on:{click:"goBack()"}, contents: [
              {component: "icon", props:{left:true, dark:true}, contents:"mdi-arrow-left"},
              "Go Back"
            ]},
            {component: "spacer", show:"payerType=='Patient'" },
            {component: "button", props:{elevation:"2", show:"payerType=='Patient'", color:"blue darken-1", text:true}, 
              on:{"click.native":"patientStatementDlg=true"}, contents:[
                {component: "icon", props:{left:true, dark:true}, contents:"mdi-printer"},
                "Patient Statement"
            ]},
            {component: "spacer"},
            {component: "button", props:{elevation:"2", color:"blue darken-1", text:true, ":disabled":"submitDisable"},
              on:{click:"receivePayment"}, contents:"Save"}
          ]}
        ]}, //card
      ]}, //container
    ]
  }
}
/*    <v-container>
      <NotesLog :logItems:"patientCase.notesLog", :defaultCategory:"this.$route.params.payerType+' Payments'"/>
    </v-container>
    <PayerNotes :show.sync:"payerNotesDlg", :payerId:"curPayerId", :payerName:"payerName", on:{close:"payerNotesDlg=false"/>*/
  

import BaseAction from '../actions/baseaction'
import Roles from '../../models/workflowroles'
export class ReceivePaymentPage extends BaseAction {
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.Scheduler];
  }
  
  route() {

    this.router.get("/", (req, res) => {
      res.json(uiConfig)
    });

    return this.router;
  }
}
