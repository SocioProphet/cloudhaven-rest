const dataModel = {
  sDate: '',
  modal: false,
  headers: [
    { text: 'Date', align: 'left', sortable: true, value: 'txnDate', class:"ReportHdrCell" },
    { text: 'Amount', align: 'right', sortable: true, value: 'amount', class:"ReportHdrCell" },
    { text: 'Patient', align: 'left', sortable: true, value: 'patient', class:"ReportHdrCell" },
    { text: 'Payer Type', align: 'left', sortable: true, value: 'payerType', class:"ReportHdrCell" },
    { text: 'Payer', align: 'left', sortable: true, value: 'payer', class:"ReportHdrCell" },
    { text: 'Procedure', align: 'left', sortable: true, value: 'procedure', class:"ReportHdrCell" },
  ],
  rows: []
};
const filters = {
  formattedNumber: {
    args: ["value", "decimalPlaces"],
    body: `
    decimalPlaces = decimalPlaces || 2;
    if (value == undefined || value===null || value==='') return '';
    var val = value.toLocaleString(undefined, {minimumFractionDigits: decimalPlaces||0, maximumFractionDigits: decimalPlaces||0});
    return val;`
  }
};
const computed = {
  totalAmount: `
    return this.rows.reduce((total,row)=>{
      total += row.amount;
      return total;
    },0).toFixed(2);`
};

const uiMethods = {
  created: `
    this.sDate = moment().format('MM/DD/YYYY');
    this._appPost('reports/receivedpayments', {date:this.sDate?moment(this.sDate,'MM/DD/YYYY').toDate():null}, (response)=>{
      this.rows = [].concat(response.data);
    })`
}


const uiConfig = {
  requiredUserData: [],
  dataModel:dataModel,
  uiMethods: uiMethods,
  filters: filters,
  computed:computed,
  uiSchema: {
    component: "div", contents: [
      {component: "container", contents: [
        {component: "card", contents: [
          {component: "cardTitle", template:'<span class="text-h5">Received Payments</span>'},
          {component: "cardText", contents: [
            {component: "form", contents: [
              {component: "row", class:"justify-start", contents: [
                {component: "col", props:{cols:"12", sm:"6", md:"2", lg:"2"}, contents: [
                 {component: "textField", vmodel:"sDate", props:{label:"Date"}, mask:"'##/##/####'"}
                ]},
                {component: "col", contents: [
                  {component: "button", class:"mt-2", props:{elevation:"2", color:"blue darken-1", text:true}, on:{click:"getContent"}, contents: [
                    {component: "icon", props:{left:true, dark:true}, contents:"mdi-content-save"}
                  ]}
                ]}
              ]}
            ]}
          ]}
        ]},
        {component: "dataTable", props:{":items":"rows", ":headers":"headers", "hide-default-footer":true, "disable-pagination":true},
          class:"elevation-1", scopedSlots: {
            item: {
              component:"template", template:`
                <tr>
                  <td >{{ item.txnDate | date }} </td>
                  <td align:"right">{{ item.amount.toFixed(2) | formattedNumber}} </td>
                  <td >{{ item.patient  }} </td>
                  <td >{{ item.payerType  }} </td>
                  <td >{{ item.payer  }} </td>
                  <td >{{ item.procedure  }} </td>
                </tr>`
            },
            "body.append": {
              component: "template", template:`
                <tr>
                <td>Totals</td>
                <td align:"right">{{totalAmount  | formattedNumber}}</td>
                <td colspan:"4">{{rows.length}}</td>
                </tr>`     
            }
          }
        }
      ]}
    ]
  }
}

import BaseAction from '../actions/baseaction'
import Roles from '../../models/workflowroles'
export class ReceivedPaymentsPage extends BaseAction {
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.Scheduler];
  }
  
  route() {

    this.router.get("/", (req, res) => {
      res.json(uiConfig)
    });

    return this.router;
  }
}
