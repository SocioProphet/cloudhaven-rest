
import stateList from '../../_helpers/stateList.js'



const dataModel = {
  valid: true,
  error: '',
  vendorTypes: '',
  paymentMethods: '',
  testEmail: '',
  testEmailErrMsg: '',
  setup: {billingProvider:{countryCode:'USA'}, operatingProvider:{}},
  stateOptions: []
};
var stateListJSON = JSON.stringify(stateList);
const uiMethods = {
  created: {
    body: `
    this._appGet('oscsetup', function(data) {
      this.setup = data;
      if (!this.setup.operatingProvider) this.setup.operatingProvider = {};
      this.vendorTypes = (this.setup.vendorTypes||[]).join("\\n");
      this.paymentMethods = (this.setup.paymentMethods||[]).join("\\n");
      this.stateOptions = JSON.parse('${stateListJSON}')
    });
  `
  },
  required: {
    args: ["v"],
    body: `
    return !!v || "Required."
    `
  },
  decimalNumberRule: {
    args: ["value"],
    body: `value => (value && /^(\d*\.)?\d+$/.test(value)) || 'Enter decimal number.'`
  },
  emailRule: {
    args: ["v"],
    body: `(v) => !v || /^[^@]+@[^.]+\..+$/.test(v) || 'Please enter a valid email.'`
  },
  emailTest: {
    body: `
    this._appPost('emailtest', {testEmail:this.testEmail}, function(result) {
      this.testEmailErrMsg = 'Sent - check event log.';
    });`
  },
  doScheduledNotifications: {
    body: `
      this._appGet('dodailyjob/schedulednotifications', function(response) {
        if (response.jobDone) {
          this._showNotification('Scheduled notifications check launched.')
        }
    });`
  },
  doOverduePayablesNotifications: {
    body: `
    this._appGet('dodailyjob/overduepayables', function(response) {
      if (response.jobDone) {
        this._showNotification('Overdue Payables check launched.')
      }
    })`
  },
  getClaimsStatus: {
    body: `
    this._appGet('dodailyjob/getclaimsstatus', function(response) {
      if (response.jobDone) {
        this._showNotification('Claims Status retrieval launched.')
      }
    })`
  },      
  saveForm: {
    body: `
    var isValid = this.$refs.form.validate();
    if (isValid) {
      this.setup.vendorTypes = this.vendorTypes.split(/[\\n;,]/g).filter(e=>(e!=''));
      this.setup.paymentMethods = this.paymentMethods.split(/[\\n;,]/g).filter(e=>(e!=''));
      this._appPost('oscsetup', this.setup, function(response) {
        if (response.success) {
          this._showNotification( 'OSC Setup updated.')
          this._gotoRoute({name:'home'})
        } else if (response.data.errMsg) {
          this._showError( response.data.errMsg )
        }
      });
    }`
  },
  cancelForm: {
    body: `this._routerGoBack();`
  }
};
const computed = {
  stateOptions() {
    return stateList;
  }
};

const uiConfig = {
  requiredUserData: [],
  dataModel:dataModel,
  uiMethods: uiMethods,
  computed:computed,
  uiSchema: {
    component: "card",
    contents: [
      {
        component: "cardTitle",
        template: "<span class='text-h5'>Outpatient Surgery Center Setup</span>"
      },
      {
        component: "cardBody",
        contents: [
          {
            component: "form",
            ref:"form",
            vmodel: "valid",
            props: {"lazy-validation":true},
            contents: [
              {
                component: "row",
                class: "justify-space-around flex-wrap ma-0 pa-0",
                props: {sm:"6", mg:"12", lg:"12"},
                contents: [
                  {
                    component: "col",
                    props: {sm:"12", mg:"5", lg:"5"},
                    contents: [
                      {
                        component: "textField",
                        vmodel:"setup.billingProvider.name",
                        props: {label:"Billing Provider Name"},
                        rules:["required"]
                      },
                      {
                        component: "textField",
                        vmodel:"setup.billingProvider.contactFirstName",
                        props: {label:"Contact First Name"},
                        rules:["required"]
                      },
                      {
                        component: "textField",
                        vmodel:"setup.billingProvider.contactLastName",
                        props: {label:"Contact Last Name"},
                        rules:["required"]
                      },
                      {
                        component: "textField",
                        vmodel:"setup.billingProvider.streetAddress",
                        props: {label:"Billing Provider Street Address"},
                        rules:["required"]
                      },
                      {
                        component: "textField",
                        vmodel:"setup.billingProvider.streetAddress2",
                        props: {label:"Billing Provider Street Address 2"}
                      }, 
                      {
                        component: "textField",
                        vmodel:"setup.billingProvider.city",
                        props: {label:"Billing Provider City"},
                        rules:["required"]
                      },
                      { component: "select",
                        vmodel:"setup.billingProvider.stateOrProvince",
                        props:{items:"stateOptions", "item-value":"abbreviation",
                               "item-text":"name", label:"Billing Provider State"}
                      },
                      {
                        component: "textField",
                        vmodel:"setup.billingProvider.postalCode",
                        props: {label:"Billing Provider Zip"},
                        rules:["required"]
                      },
                      {
                        component: "textField",
                        vmodel:"setup.billingProvider.countryCode",
                        props: {label:"Billing Provider Country"},
                        rules:["required"]
                      },
                      {
                        component: "textField",
                        vmodel:"setup.billingProvider.phone",
                        props: {label:"Billing Provider Phone"},
                        rules:["required"]
                        //:mask="(setup.billingProvider.phone||'').length>7?'(###) ###-####':'###-#### #'"
                       },
                      {
                        component: "textField",
                        vmodel:"setup.defaultFromEmail",
                        props: {label:"Default Email Sender"},
                        rules:["required", "emailRule"]
                      },
                      {
                        component: "textField",
                        vmodel:"setup.ccEmail",
                        props: {label:"CC Email"},
                        rules:["required", "emailRule"]
                      }, 
                      {
                        component: "textField",
                        vmodel:"setup.typeOfBill",
                        props: {label:"Type of Bill"},
                        rules:["required"]
                      },
                      {
                        component: "textField",
                        vmodel:"setup.ub04OffsetX",
                        props: {type:"number", label:"UB04 X Offset"},
                        attrs: {step:"0.001"}
                      },
                      {
                        component: "textField",
                        vmodel:"setup.ub04OffsetY",
                        props: {type:"number", label:"UB04 Y Offset"},
                        attrs: {step:"0.001"}
                      },
                      {
                        component: "textField",
                        vmodel:"setup.ub04ScalingFactor",
                        props: {type:"number", label:"UB04 Scaling Factor"},
                        attrs: {step:"0.001"}
                      }            
                    ]
                  },
                  {
                    component: "col",
                    props: {sm:"12", mg:"5", lg:"5"},
                    contents: [
                      {
                        component: "textField",
                        vmodel:"setup.taxonomyCode",
                        props: {label:"Taxonomy Code"},
                        rules:["required"]
                      },
                      {
                        component: "textField",
                        vmodel:"setup.federalTaxNumber",
                        props: {label:"Federal Tax Number"},
                        rules:["required"]
                      },
                      {
                        component: "textField",
                        vmodel:"setup.revenueCode",
                        props: {label:"Revenue Code"},
                        rules:["required"]
                      },
                      {
                        component: "textField",
                        vmodel:"setup.revenueDescription",
                        props: {label:"Revenue Description"},
                        rules:["required"]
                      },
                      {
                        component: "textField",
                        vmodel:"setup.billingProvider.NPI",
                        props: {label:"Billing Provider NPI"},
                        rules:["required"]
                      },
                      {
                        component: "textField",
                        vmodel:"setup.operatingProvider.NPI",
                        props: {label:"Operating Provider NPI"},
                        rules:["required"]
                      },
                      {
                        component: "textField",
                        vmodel:"setup.operatingProvider.lastName",
                        props: {label:"Operating Provider Last Name"},
                        rules:["required"]
                      },
                      {
                        component: "textField",
                        vmodel:"setup.operatingProvider.firstName",
                        props: {label:"Operating Provider First Name"},
                        rules:["required"]
                      },
                      {
                        component: "checkbox",
                        vmodel:"setup.patientSearchDateOfBirthRequired",
                        props: {label:"Date of Birth Required in Patient Search"}
                      },
                      {
                        component: "textarea",
                        vmodel:"vendorTypes",
                        props: {label:"Vendor Types", "hide-details":true, "auto-grow": true,
                                hint:"Enter Vendor Types separated by comma, semicolon or new lines.",
                                "persistent-hint":true},
                        class:"mb-1"
                      },
                      {
                        component: "textarea",
                        vmodel:"paymentMethods",
                        props: {label:"Payment Methods", "hide-details":true, "auto-grow":true,
                            hint:"Enter Payment Methods separated by comma, semicolon or new lines.", "persistent-hint":true}
                      },
                      {
                        component: "textField",
                        vmodel:"testEmail",
                        props: {label:"Test Email", "error-messages":"testEmailErrMsg", "append-icon":"mdi-send"},
                        rules:["email"],
                        on: {
                          "click-append": "emailTest"
                        }
                      }
                    ]
                  }
                ]
              }
            ]

          }
        ]
      },
      {
        component: "cardActions",
        contents: [
          { component: "button", props:{elevation:"2", color:"blue darken-1", text:true}, on: {click:"cancelForm"}, 
            contents:[{component:"icon", props:{left:true, dark:true}, contents:"mdi-arrow-left"}, 
                      {component:'span', contents:"Go Back"}
            ]
          },
          { component: "spacer"},
          { component: "button", props:{elevation:"2", color:"blue darken-1", text:true}, on: {click:"doScheduledNotifications"},
            contents: "Check Scheduled Notifications"},
            { component: "button", props:{elevation:"2", color:"blue darken-1", text:true}, on: {click:"doOverduePayablesNotifications"},
            contents: "Check Overdue Payables Notifications"},
          { component: "spacer"},
          { component: "button", props:{elevation:"2", color:"blue darken-1", text:true}, on: {click:"saveForm"},
            contents:[{component:"icon", props:{left:true, dark:true}, contents:"mdi-content-save"}, 
                      {component:'span', contents:"Save"}
          ] },

        ]
      }

    ]
  }
};

import BaseAction from '../actions/baseaction'
import Roles from '../../models/workflowroles'
export class OSCSetupPage extends BaseAction{
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.Scheduler];
  }
  
  route() {

    this.router.get("/", (req, res) => {
      res.json(uiConfig)
    });

    return this.router;
  }
}
