import BaseController  from './base';
import { randomId } from '../js/utils';
import {fail} from "./utils";
import User from '../models/user'
import CPTCode from '../models/cptcode';
import ICD10Code from '../models/icd10code';
import ProcedureType from '../models/proceduretype';
import Procedure from '../models/procedure';
import Vendor from '../models/vendor';
import Patient from '../models/patient';
import Payer from '../models/payer';
import AuditLog from '../models/auditlog'
import PatientCase from '../models/patientcase'
import NotificationType from '../models/notificationtype'
import PatientSequentialId from '../models/patientsequentialids'
import Roles from '../models/workflowroles'
import mongoose from 'mongoose'

//import CaseWorkflowAssignment from '../models/caseworkflowassignment';

const MAX_RESULTS = 100;

export class UserController extends BaseController{
  constructor(){
    super(User, '_id',
      [Roles.BMCSysAdmin],
      [Roles.BMCSysAdmin]
    );
  }
  list() {
    return this.model
    .find({})
    .populate({path:'vendor', select:{name:1}})
    .limit(MAX_RESULTS)
    .then((modelInstances) => {
      var response = {};
      response.records = modelInstances;
      return response;
    });
  }
  update(id, updates) {
    this.logAuditData( id, 'update', updates);
    return User.findOneAndUpdate({_id:id}, 
      {$set:{ email:updates.email, name:updates.name, language:updates.language, roles:updates.roles}},
      {new:true})
      .then((user) => {
        var response = {};
        response.record = user;
        return response;
      });
  }
  delete(id) {
    return mongoose.Promise.all([
      PatientCase.find({'payerInfo.eligibilityDeterminedBy':id}),
      AuditLog.find({user:id})
    ])
    .then(results=>{
      if (results[0].length>0 || results[1].length>0) {
        return mongoose.Promise.reject({name:'ValidationError', message:'In use - delete not allowed.'});
      } else {
        return super.delete(id);
      }
   })
  }
}

export class PatientController extends BaseController{
  constructor(){
    super(Patient, '_id', 
        [Roles.BMCSysAdmin, Roles.FCM, Roles.Scheduler, Roles.AuthMgr, Roles.AR, Roles.AP]
        [Roles.BMCSysAdmin, Roles.FCM, Roles.Scheduler]);
  }
  create(patient) {
    return PatientSequentialId.create({domain:'Patient'})
    .then((patientSeqId)=>{
      patient.patientId = randomId(patientSeqId.seqNumber)
      return super.create(patient);
    })
  }
  delete(id) {
    var self = this;
    return PatientCase.find({patient:id})
    .then(patientCases=>{
      self.logAuditData( id, 'delete');
      if (patientCases.length>0) {
        return mongoose.Promise.reject({name:'ValidationError', message:'In use - delete not allowed (disable all roles instead).'});
      } else {
        return Patient.deleteOne({_id:id})
        .then(() => {
          return {};
        })
      }
    })
  }
}

export class CPTCodeController extends BaseController{
    constructor(){
      super(CPTCode, '_id',
        [Roles.BMCSysAdmin, Roles.FCM, Roles.Scheduler, Roles.AuthMgr, Roles.AR, Roles.AP],
        [Roles.BMCSysAdmin]
      );
    }
    delete(id) {
      return mongoose.Promise.all([PatientCase.find({cptCode:id}),Procedure.find({cptCode:id})])
      .then(results=>{
        if (results[0].length>0 || results[1].length>0) {
          return mongoose.Promise.reject({name:'ValidationError', message:'In use - delete not allowed.'});
        } else {
          return super.delete(id);
        }
     })
    }  
}

export class ICD10CodeController extends BaseController{
  constructor(){
    super(ICD10Code, '_id',
      [Roles.BMCSysAdmin, Roles.FCM, Roles.Scheduler, Roles.AuthMgr, Roles.AR, Roles.AP],
      [Roles.BMCSysAdmin]);
  }
  delete(id) {
    return mongoose.Promise.all([
      PatientCase.find({icd10Code:id}),
      Procedure.find({diagnoses:id})
    ])
    .then(results=>{
      if (results[0].length>0 || results[1].length>0) {
        return mongoose.Promise.reject({name:'ValidationError', message:'In use - delete not allowed.'});
      } else {
        return super.delete(id);
      }
   })
  }  
}

export class ProcedureTypeController extends BaseController{
  constructor(){
    super(ProcedureType, '_id',
      [Roles.BMCSysAdmin, Roles.FCM, Roles.Scheduler, Roles.AuthMgr, Roles.AR, Roles.AP],
      [Roles.BMCSysAdmin]);
  }
  list() {
    return this.model
    .find({})
    .limit(MAX_RESULTS)
    .then((modelInstances) => {
      var response = {};
      response.records = modelInstances;
      return response;
    });
  }
  delete(id) {
    return Procedure.find({procedureType:id})
    .then(procedures=>{
      if (procedures.length>0) {
        return mongoose.Promise.reject({name:'ValidationError', message:'In use - delete not allowed.'});
      } else {
        return super.delete(id);
      }
    })
  }
}
export class ProcedureController extends BaseController{
  constructor(){
    super(Procedure, '_id',
      [Roles.BMCSysAdmin, Roles.FCM, Roles.Scheduler, Roles.AuthMgr, Roles.AR, Roles.AP],
      [Roles.BMCSysAdmin]);
  }
  list() {
    return this.model
    .find({})
    .populate('payer')
    .populate('procedureType')
    .populate('cptCode')
    .populate('diagnoses')
    .populate('devices.vendor')
    .limit(MAX_RESULTS)
    .then((modelInstances) => {
      var response = {};
      response.records = modelInstances;
      return response;
    });
  }
  read(id) {
    var filter = {};
    filter[this.key] = id;
    return this.model
    .findOne(filter)
    .populate('payer')
    .populate('procedureType')
    .populate('cptCode')
    .populate('diagnoses')
    .populate('devices.vendor')
    .then((modelInstance) => {
      this.logAuditData( id, 'read', modelInstance);
      var response = {};
      response.record = modelInstance;
      return response;
    });
  }

  delete(id) {
    return mongoose.Promise.all([
      Payer.find({'procedures.procedure':id}),
      PatientCase.find({procedure:id})
    ])
    .then(results=>{
      if (results[0].length>0 || results[1].length>0) {
        return mongoose.Promise.reject({name:'ValidationError', message:'In use - delete not allowed.'});
      } else {
        return super.delete(id);
      }
    })  
  }
}
export class VendorController extends BaseController{
  constructor(){
    super(Vendor, '_id',
      [Roles.BMCSysAdmin, Roles.FCM, Roles.Scheduler, Roles.AuthMgr, Roles.AR, Roles.AP],
      [Roles.BMCSysAdmin]);
  }
  list() {
    return this.model
    .find({})
    .limit(MAX_RESULTS)
    .then((modelInstances) => {
      var response = {};
      response.records = modelInstances;
      return response;
    });
  }
  delete(id) {
    return mongoose.Promise.all([
      Procedure.find({'devices.vendor':id}),
      PatientCase.find({'vendorFees.vendor':id})
    ])
    .then(results=>{
      if (results[0].length>0 || results[1].length>0) {
        return mongoose.Promise.reject({name:'ValidationError', message:'In use - delete not allowed.'});
      } else {
        return super.delete(id);
      }
    })  
  }
}
export class PayerController extends BaseController{
  constructor(){
    super(Payer, '_id',
      [Roles.BMCSysAdmin, Roles.FCM, Roles.Scheduler, Roles.AuthMgr, Roles.AR, Roles.AP],
      [Roles.BMCSysAdmin, Roles.FCM, Roles.Scheduler, Roles.AuthMgr, Roles.AR]);
  }
  list() {
    return this.model
    .find({})
    .populate('contacts')
    .populate('procedures.procedure')
    .limit(MAX_RESULTS)
    .then((modelInstances) => {
      var response = {};
      response.records = modelInstances;
      return response;
    });
  }
  read(id) {
    var filter = {};
    filter[this.key] = id;
    return this.model
    .findOne(filter)
    .populate('contacts')
    .populate('procedures.procedure')
    .then((modelInstance) => {
      this.logAuditData( id, 'read', modelInstance);
      var response = {};
      response.record = modelInstance;
      return response;
    });
  }

/*  create(payer) {
    if (payer.contacts.length>0) {
      return PayerXContact.insertMany(payer.contacts)
      .then(addedContacts=>{
        payer.contacts = addedContacts.map(c=>(c._id));
        return super.create(payer);
      })
    } else {
      return super.create(payer);
    }
  }*/
  delete(id) {
    var self = this;
    var promise = new mongoose.Promise(function( resolve, reject){
      PatientCase.find({$or:[
        {'payer':id}, {'primaryPayer.claimsPayer':id}, {'secondaryPayer.claimsPayer':id}
      ]})
      .then(patientCases=>{
        if (patientCases.length>0) {
          reject({name:'ValidationError', message:'In use - delete not allowed.'});
        } else {
          self.logAuditData( id, 'delete');
          var promises = [];
          promises.push(Payer.findById(id)
          .then(payer=>{
//            if (!payer || payer.contacts.length==0) {
              return mongoose.Promise.resolve(true);
//            } else {
//              return PayerXContact.remove({_id:{$in:payer.contacts}})
//            }
          }));
          promises.push(Payer.deleteOne({_id:id}));
          mongoose.Promise.all(promises)
          .then(results=>{
            resolve({})
          })
        }
      })
      .then(null, result=>{ reject(result); });
    });
    return promise;
  }
}
export class PatientCaseController extends BaseController{
  constructor(){
    super(PatientCase, '_id',
    [Roles.BMCSysAdmin, Roles.FCM, Roles.Scheduler, Roles.AuthMgr, Roles.AR, Roles.AP],
    [Roles.GRMSysAdmin, Roles.GRASysAdmin, Roles.BMCSysAdmin, Roles.Scheduler, Roles.FCM]);
  }
  read(id) {
    var filter = {};
    filter[this.key] = id;

    return this.model
    .findOne(filter)
    .populate({path:'payer', select:'name'})
    .populate('primaryPayer.claimsPayer')
//    .populate('primaryPayer.claimsContact')
    .populate('secondaryPayer.claimsPayer')
//    .populate('secondaryPayer.claimsContact')
//    .populate('payerInfo.authorizingPayer')
//    .populate('payerInfo.authorizingContact')
    .populate('cptCode')
    .populate('icd10Code')
    .populate('payer')
    .populate('patient')
    .populate({path:'vendorFees.vendor'})
    .populate({path: 'confirmations.vendor'})
    .populate({path:'procedure',  
                populate: [{ path: 'cptCode', model:'CPT_Code'}, 
                           {path: 'diagnoses', model:'ICD10_Code'},
                           {path: 'procedureType', model: 'ProcedureType'}
                          ]
              })
    .then((modelInstance) => {
      var response = {};
      response.record = modelInstance;
      return response;
    });
  }
}
export class NotificationTypeController extends BaseController{
  constructor(){
    super(NotificationType, '_id',
      [Roles.BMCSysAdmin, Roles.FCM, Roles.Scheduler, Roles.AuthMgr, Roles.AR, Roles.AP],
      [Roles.BMCSysAdmin]);
  }
}
/*export class WorkflowStateController extends BaseController{
  constructor(){
    super(WorkflowState, '_id');
  }
  list() {
    return this.model
      .find({})
      .populate('notifications.notificationType')
      .limit(MAX_RESULTS)
      .then((modelInstances) => {
        var response = {};
        response.records = modelInstances;
        return response;
    });
  }
}
export class CaseWorkflowAssignmentController extends BaseController{
  constructor(){
    super(CaseWorkflowAssignment, '_id');
  }
}*/
