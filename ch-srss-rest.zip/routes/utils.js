/**
  Returns a function that will write the result as a JSON to the response
*/
export function ok(res){
    return (data) => {
      res.json(data);
    };
  };
  
  export function fail(res){
    return (error) => {
      if (error.code == 11000 || error.code == 11001 || error.message.indexOf('duplicate key')>=0) {
        res.json({success:false, errMsg:'Duplicate record.'})
      } else if (error.name === 'ValidationError' || error.message) {
        res.json({success:false, errMsg:error.message})
      } else {
        res.sendStatus(404).end();
      }
    };
  };
  export function failResp(res, error){
      if (error.code == 11000 || error.code == 11001 || error.message.indexOf('duplicate key')>=0) {
        res.json({success:false, errMsg:'Duplicate record.'})
      } else if (error.name === 'ValidationError' || error.message) {
        res.json({success:false, errMsg:error.message})
      } else {
        res.sendStatus(404).end();
      }
  };

export function round(n, decimalPlaces) {
  if (isNaN(n)) return 'NaN';

  if (decimalPlaces === 0) {
    decimalPlaces = 0;
  } else if (!decimalPlaces) {
    decimalPlaces = 6;
  }
  var isNegative = (n<0);
  if (isNegative) n = -n;
  var retVal = Number((n||0).toFixed(decimalPlaces));
  if (isNegative & Number(retVal) === 0) isNegative = false;
  return Number((isNegative ? '-' : '')+retVal).toFixed(decimalPlaces);
}

export function roundFloat(n, decimalPlaces) {
  if (isNaN(n)) return 'NaN';

  if (decimalPlaces === 0) {
    decimalPlaces = 0;
  } else if (!decimalPlaces) {
    decimalPlaces = 6;
  }
  var isNegative = (n<0);
  if (isNegative) n = -n;
  var retVal = Number((n||0).toFixed(decimalPlaces));
  if (isNegative & Number(retVal) === 0) isNegative = false;
  return parseFloat(Number((isNegative ? '-' : '')+retVal).toFixed(decimalPlaces));

}

