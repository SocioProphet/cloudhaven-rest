/*import BaseAction from './baseaction'
import {ok, fail} from "../utils"
import PayerContact from '../../models/payercontact'
import Payer from '../../models/payer'
import PatientCase from '../../models/patientcase'
import Roles from '../../models/workflowroles'
import mongoose from 'mongoose'

export class PayerContactMgr extends BaseAction{
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.FCM, Roles.Scheduler];
  }
  
  route() {
    this.router.get("/:id", this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {
        PayerContact.findById(req.params.id)
        .then(payerContact=>{
          res.json(payerContact);
        })
        .then(null, fail(res));
    } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    this.router.post("/", this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {
        PayerContact.create(req.body.payerContact)
        .then(payerContact=>{
          Payer.findOneAndUpdate({_id:mongoose.Types.ObjectId(req.body.payerId)}, {$push:{contacts:payerContact._id}})
          .then(result=>{
            res.json({success:true, payerContact:payerContact});
          })
        })
        .then(null, fail(res));
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    this.router.put("/:id", this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {
        PayerContact.findById(req.params.id)
        .then((payerContact) => {
          this.copyAttributes(req.body, payerContact, '_id');
          return payerContact.save();
        })
        .then((result) => {
          res.json({success:true})
        });
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    this.router.delete("/:id/:payerId", this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {
        var id = req.params.id;
        PatientCase.find({$or:[
          {'payerInfo.authorizingXContact':id}, {'primaryPayer.claimsXContact':id}, {'secondaryPayer.claimsXContact':id}
        ]})
        .then(patientCases=>{
          if (patientCases.length>0) {
            res.json({success:false, errMsg:'In use - delete now allowed.'});
          } else {
            PayerContact.remove({_id:mongoose.Types.ObjectId(id)})
            .then(result=>{
              Payer.findOneAndUpdate({_id:mongoose.Types.ObjectId(req.params.payerId)}, {$pull:{contacts:mongoose.Types.ObjectId(id)}})
              .then(result=>{
                res.json({success:true});
              })
            })
            .then(null, fail(res));
          }
        })  
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });

    return this.router;
  }
}
*/
