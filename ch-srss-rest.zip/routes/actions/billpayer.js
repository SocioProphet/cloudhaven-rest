import BaseAction from './baseaction'
import {ok, fail} from "../utils"
import { safeRef } from '../../js/utils'
import OSCSetup from '../../models/oscsetup'
import PatientCase from '../../models/patientcase'
import WorkflowService from '../../services/workflowservice'
import Roles from '../../models/workflowroles'
import RecentListService from '../../services/recentlistservice'
import ub04PrintService from '../../services/ub04printservice'
import mongoose from 'mongoose'
import moment from 'moment'

export class BillPayer extends BaseAction{
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.AR];
  }
  
  route() {
    this.router.post("/", this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {
        if (!req.body.billSent) {
          res.json({errMsg:'Please indicate Bill Sent.'});
          return;
        }
        var payerSelector = req.body.payerType=='Primary Payer'?'primaryPayer':'secondaryPayer';
        return PatientCase.findById(req.body.patientCaseId)
        .populate({path:(payerSelector+'.claimsPayer')})
        .then(patientCase=>{
          var claimsPayer = patientCase[payerSelector].claimsPayer;
          var dueDate = moment().add((claimsPayer.paymentTerms?claimsPayer.paymentTerms:32),'days').toDate();
          return PatientCase.findOneAndUpdate(
            { _id: mongoose.Types.ObjectId(req.body.patientCaseId),
              'paymentsDue.payerType': req.body.payerType
            },
            {$set: {'paymentsDue.$.dateBillSent': new Date(), 'paymentsDue.$.arClockStartDate': new Date(), 'paymentsDue.$.dueDate':dueDate, 'paymentsDue.$.originalDueDate':dueDate}}
          )
        })
        .then(result=>{
          return WorkflowService.updateState( req.body.patientCaseId )
        })
        .then((result)=>{
          RecentListService.add( this.authData.user._id, req.body.patientCaseId )
          res.json({success:true})
        })
        .then(null, fail(res));
    } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });

    this.router.get("/:patientCaseId", this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {
        PatientCase.findById( req.params.patientCaseId )
        .populate('cptCode')
        .populate('icd10Code')
        .populate('primaryPayer.claimsPayer')
        .populate('secondaryPayer.claimsPayer')
//        .populate({path:'primaryPayer.claimsXContact'})
//        .populate({path:'secondaryPayer.claimsXContact'})
        .populate({path:'procedure', select: {name:1}})
        .populate({path:'patient', select: {'patientId':1, 'firstName':1, 'lastName':1, 'middleInitial':1, 'ssn':1, 'dateOfBirth':1,
                'contactInfo':1} })
        .then((patientCase) => {
          res.json(patientCase);
        })
        .then(null, fail(res));
    } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    this.router.get("/ub04/:patientCaseId/:payerType", this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {
        mongoose.Promise.all([PatientCase.findById(req.params.patientCaseId)
        .populate('cptCode')
        .populate('icd10Code')
        .populate('primaryPayer.claimsPayer')
        .populate('secondaryPayer.claimsPayer')
/*        .populate({path:'primaryPayer.claimsPayer', populate:{path:'contacts'}})
        .populate({path:'secondaryPayer.claimsPayer', populate:{path:'contacts'}})
        .populate({path:'primaryPayer.claimsXContact'})
        .populate({path:'secondaryPayer.claimsXContact'})*/
        .populate({path:'procedure', select: {name:1, totalCharges:1}})
        .populate({path:'patient' }),
        OSCSetup.findOne({})])
        .then(results=>{
          var patientCase = results[0];
          if (!patientCase) {
            res.json({ub04:null, errMsg:'Patient case not found.'});
            return;
          }
          var oscSetup = results[1];
          var isPrimary = req.params.payerType == 'Primary Payer';
          var payerSelector = isPrimary?'primaryPayer':'secondaryPayer';
          var hasSecondaryPayer = patientCase.secondaryPayer.claimsPayer && patientCase.secondaryPayer.claimsPayer._id;
          hasSecondaryPayer = hasSecondaryPayer!=null && hasSecondaryPayer!='';
          var primaryPayerPaymentDue = patientCase.paymentsDue.find(pd=>(pd.payerType=='Primary Payer'));
          var primaryPayerEstAmt = primaryPayerPaymentDue.totalAmountDue;
          var secondaryPayerPaymentDue = patientCase.paymentsDue.find(pd=>(pd.payerType=='Secondary Payer'));
          var secondaryPayerEstAmt = secondaryPayerPaymentDue?secondaryPayerPaymentDue.totalAmountDue:null;
          if (!isPrimary && !hasSecondaryPayer) {
            res.json({ub04:null, errMsg:'No secondary payer found.'});
            return;
          }
          res.writeHead(200, {
            'Content-Type': 'application/pdf',
            'Content-Disposition': 'attachment; filename=ub04.pdf'
          });
          var ub04Doc = ub04PrintService.createUB04();
          var mmddyyServiceDate = moment(patientCase.calendarBooking.day).format('MMDDYY');
          var claimsContact = patientCase[payerSelector].claimsPayer;/*.claimsContact.contactInfo*/
          try {
          var fldMap = {
            billingProviderName:  oscSetup.billingProvider.name,
            billingProviderStreetAddr: oscSetup.billingProvider.streetAddress+(oscSetup.billingProvider.streetAddress2?(' '+oscSetup.billingProvider.streetAddress2):''),
            billingProviderCityStateZip:  
              `${oscSetup.billingProvider.city}, ${oscSetup.billingProvider.stateOrProvince}  ${oscSetup.billingProvider.postalCode}`,
            billingProviderCountryPhone:  
              `${oscSetup.billingProvider.countryCode}, ${oscSetup.billingProvider.phone}`,
            patientControlNumber: patientCase.caseId+req.params.payerType.charAt(0),
            typeOfBill:  oscSetup.typeOfBill,
            federalTaxNumber:  oscSetup.federalTaxNumber,
            stmtCoversFromDate:  mmddyyServiceDate,
            stmtCoversToDate:  mmddyyServiceDate,
            patientId:  patientCase.patient.patientId,
            patientName:  patientCase.patient.nameLastFirst,
            patientStreetAddress:  patientCase.patient.contactInfo.streetAddress,
            patientCity:  patientCase.patient.contactInfo.city,
            patientState:  patientCase.patient.contactInfo.stateOrProvince,
            patientZip:  patientCase.patient.contactInfo.zipOrPostalCode,
            patientCountry:  patientCase.patient.contactInfo.country,
            patientBirthDate:  moment(patientCase.patient.dateOfBirth).format('MMDDYYYY'),
            patientGender:  patientCase.patient.gender?patientCase.patient.gender.charAt(0):'',
            patientVisitType:  '3',
            patientAdmissionPointOfOrigin:  '2',
            patientDischargeStatus:  '01',
            respPartyNameAddr:  
`\
${patientCase[payerSelector].claimsPayer.name}
${safeRef(claimsContact).streetAddress||''}
${claimsContact?(claimsContact.city+', '+claimsContact.stateOrProvince+'  '+(claimsContact.zipOrPostalCode||'')):''}
`,
            revenueCode1:  oscSetup.revenueCode,
            revenueDescription1:  oscSetup.revenueDescription,
            rateCodes1:  patientCase.cptCode.code,
            serviceDate1:  moment(patientCase.calendarBooking.day).format('MMDDYY'),
            serviceUnits1:  '1',
            totalCharges1:  (patientCase.totalCharges || patientCase.procedure.totalCharges).toFixed(2),
            revenueCode23:  '0001',
            claimPageNumber:  '1',
            totalClaimPages:  '1',
            creationDate:  moment().format('MMDDYY'),
            totalChargesTotal:  (patientCase.totalCharges || patientCase.procedure.totalCharges).toFixed(2),
            nonCoveredChargesTotal:  '0',
            primaryPayerEstAmtDue: (isPrimary?(primaryPayerEstAmt||0):primaryPayerPaymentDue.receivedAmount).toFixed(2),
            primaryPayerName:  patientCase.primaryPayer.claimsPayer.name,
            primaryPayerHealthPlanId:  patientCase.primaryPayer.healthPlanId,
            primaryPayerReleaseOfInfo:  'Y',
            primaryPayerAssignmentOfBenefits:  'Y',
            nonCoveredChargesTotal:  '0',
            secondaryPayerEstAmtDue: isPrimary?'':secondaryPayerEstAmt,
            secondaryPayerName:  isPrimary?'':patientCase.secondaryPayer.claimsPayer.name,
            secondaryPayerHealthPlanId:  isPrimary?'':patientCase.secondaryPayer.healthPlanId,
            secondaryPayerReleaseOfInfo:  isPrimary?'':'Y',
            secondaryPayerAssignmentOfBenefits:  isPrimary?'':'Y',
            nonCoveredChargesTotal:  isPrimary?'':'0',
//            secondaryPayerEstAmtDue:  '',
          
            billingProviderNPI:  oscSetup.billingProvider.NPI,
          
            primaryPlanInsuredsName:  patientCase.primaryPayer.insuredsName,
            primaryPlanPatientRelationship:  patientCase.primaryPayer.relationshipToPatient,
            primaryPlanInsuredsId:  patientCase.primaryPayer.policyNumber,
            primaryPlanInsuredsGroupNumber:  patientCase.primaryPayer.groupNumber,
            secondaryPlanInsuredsName:  isPrimary?'':patientCase.secondaryPayer.insuredsName,
            secondaryPlanPatientRelationship:  isPrimary?'':patientCase.secondaryPayer.relationshipToPatient,
            secondaryPlanInsuredsId:  isPrimary?'':patientCase.secondaryPayer.policyNumber,
            secondaryPlanInsuredsGroupNumber:  isPrimary?'':patientCase.secondaryPayer.groupNumber,
            primaryPlanTreatmentAuthCode:  patientCase.payerInfo.approvedAuthorizationCode,
            secondaryPlanTreatmentAuthCode: patientCase.payerInfo.approvedAuthorizationCode2,
          
            mainDiagnosisCode:  patientCase.icd10Code.code.replace(/[-\.]/g, ' '),
            admittingDiagnosisCode:  patientCase.icd10Code.code.replace(/[-\.]/g, ' '),

            attendingProviderNPI:  oscSetup.operatingProvider.NPI,
            attendingProviderLastName:  oscSetup.operatingProvider.lastName,
            attendingProviderFirstName:  oscSetup.operatingProvider.firstName,
            opPhysicianNPI:  oscSetup.operatingProvider.NPI,
            opPhysicianLastName:  oscSetup.operatingProvider.lastName,
            opPhysicianFirstName:  oscSetup.operatingProvider.firstName,
            otherProvider1Type:  'DN',
            otherProvider1NPI:  oscSetup.operatingProvider.NPI,
            otherProvider1LastName:  oscSetup.operatingProvider.lastName,
            otherProvider1FirstName:  oscSetup.operatingProvider.firstName
          };
        } catch(e) {
          console.log(e);
        }

          ub04PrintService.writeFields( ub04Doc, fldMap, oscSetup );

          ub04Doc.pipe(res);
          ub04Doc.end();
          })
        .then(null, fail(res));
    } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    return this.router;
  }
}

