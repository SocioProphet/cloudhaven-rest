import BaseAction from './baseaction'
import {ok, fail} from "../utils";
import Vendor from '../../models/vendor';
import Roles from '../../models/workflowroles'
import mongoose from 'mongoose';
import Procedure from '../../models/procedure';

export class CaseOptions extends BaseAction{
  constructor(){
    super();
    this.roles = [Roles.ANY];
  }
  
  route() {
    /*
      params procedureId, vendor
    */
    this.router.post("/", this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {
        return Procedure.findOne({_id:mongoose.Types.ObjectId(req.body.procedureId)})
        .populate({path:'procedureType'})
        .populate('cptCode')
        .populate({path:"diagnoses"})
        .then(procedure=>{
          Vendor.find({vendorType:{$in:procedure.procedureType.vendorTypes}})
          .then(vendors=>{
            res.json({procedure:procedure, vendors:vendors});
          })
        })
        .then(null, fail(res));
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    return this.router;
  }
}
