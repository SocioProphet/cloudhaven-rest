import BaseAction from './baseaction'
import {ok, fail} from "../utils"
import { safeRef } from '../../js/utils'
import PatientCase from '../../models/patientcase'
import WorkflowService from '../../services/workflowservice'
import Roles from '../../models/workflowroles'
import PayablesService from '../../services/payablesservice'
import RecentListService from '../../services/recentlistservice'
import PatientRecord from '../../models/patientrecord'
import NotificationService from '../../services/notificationservice'
import moment from 'moment'
import mongoose from 'mongoose'
import fileUpload from 'express-fileupload'

export class SurgeryCompleted extends BaseAction{
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.AR];
  }
  
  route() {
    this.router.use(fileUpload());
    this.router.post("/", this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {
          try {
            //patientCaseId, opReportFile, deviceFee
            var patientCase = null;
            PatientCase.findById( req.body.patientCaseId)
            .populate({path:'vendorFees.vendor'})
            .populate({path:'payables.vendor'})
            .then((pc)=>{
              patientCase = pc;
              var records = [];
              var update = {$set:{}};
              Object.keys(req.files).forEach(fKey=>{
                var file = req.files[fKey];
                records.push({ patient:patientCase.patient._id,
                  name: file.name,
                  fileName: file.name,
                  mimeType: file.mimetype,
                  body: file.data,
                  isOpReport: file.name==req.body.opReportFile,
                  patientCase: req.body.patientCaseId
                });
                update['$set'].opReportUploaded = req.body.opReportFile!=null;
              });
              PatientRecord.insertMany(records)
              .then((result)=>{
                return PatientCase.findById( req.body.patientCaseId)
                .populate('procedure')
                .populate({path:'primaryPayer.claimsPayer'})
                .populate({path:'payables.vendor'})
              })
              .then((pc)=>{
                patientCase = pc;
                var now = new Date();
                if (req.body.notesEntry) {
                  update['$push'] =  {notesLog: {author:this.authData.user.name, content:req.body.notesEntry, category:'Case'}}
                }
      
                for (var i=0;i<patientCase.payables.length;i++) {
                  var vd = patientCase.payables[i];
                  var paymentTerms = vd.vendor.paymentTerms;
                  update['$set']['payables.'+i+'.apClockStartDate'] =  now;
                  update['$set']['payables.'+i+'.dueDate'] = moment(now).add(paymentTerms||0, 'days').toDate();
                  if (req.body.deviceAdditionalCost) {
                    if (vd.vendor.vendorType == 'Device Maker') {
                      update['$set']['payables.'+i+'.additionalAmount'] = req.body.deviceAdditionalCost;
                    }
                    update['$set'].deviceAdditionalCost = req.body.deviceAdditionalCost;
                    update['$set'].deviceAddlCostReason = req.body.deviceAddlCostReason;
                  }
                }
                return PatientCase.updateOne({_id:patientCase._id}, update);
              })
              .then((result)=>{
                /*
                p1Amt = contractedRate - p1.totalDueFromPatient
                p2Amt = p1.totalDueFromPatient - p2.totalDueFromPatient
                */
                var primaryPayerAmt = 0;
                var hasSecondaryPayer = patientCase.secondaryPayer && patientCase.secondaryPayer.claimsPayer && patientCase.secondaryPayer.claimsPayer._id;
                hasSecondaryPayer = hasSecondaryPayer!=null && hasSecondaryPayer!='';
                if (!hasSecondaryPayer) {
                  primaryPayerAmt =  patientCase.primaryPayer.contractedRate - patientCase.primaryPayer.totalDueFromPatient;
                } else {
                  var patientDueAfterPrimary = patientCase.primaryPayer.totalDueFromPatient;
                  var patientDueAfterSecondary = patientCase.secondaryPayer.totalDueFromPatient;
                  var secondaryResp = patientDueAfterPrimary - patientDueAfterSecondary;
                  primaryPayerAmt = patientCase.primaryPayer.contractedRate - (patientDueAfterSecondary + secondaryResp);
                }
                if (patientCase.paymentMethod == 'Insurance' && primaryPayerAmt>0) {
                  return PatientCase.updateOne({_id:patientCase._id, 'paymentsDue':{'$not':{'$elemMatch':{'payerType':'Primary Payer'}}}},
                    {$push:{'paymentsDue': { payerType:'Primary Payer', amount:primaryPayerAmt} }})
                } else {
                  return mongoose.Promise.resolve(true);
                }
              })
              .then((result) => {
                return WorkflowService.updateState( req.body.patientCaseId )
              })
              .then((result)=>{
                return NotificationService.createNotifications(patientCase._id, 'Surgery Completed')
              })
              .then((result)=>{
                RecentListService.add( this.authData.user._id, req.body.patientCaseId )
                res.json({success:true})
              })
            })
            .then(null, fail(res));
          } catch (e) {
            console.log(e);
          }
    } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });

    this.router.get("/:patientCaseId", this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {
        var promises = [
          PatientCase.findById( req.params.patientCaseId )
          .populate("vendorFees.vendor")
          .populate({path:'primaryPayer.claimsPayer', select:{contractedRate:1}})
          .populate({path:'procedure', select: { name:1}})
          .populate({path:'patient', select: {patientId:1, firstName:1, lastName:1, name:1} }),
          PatientRecord.find({patientCase:req.params.patientCaseId}, {_id:1, name:1, fileName:1, mimeType:1, isOpReport:1})];
        mongoose.Promise.all(promises)
        .then(results => {
          res.json({patientCase:results[0], records:results[1]});
        })
        .then(null, fail(res));
    } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    return this.router;
  }
}

