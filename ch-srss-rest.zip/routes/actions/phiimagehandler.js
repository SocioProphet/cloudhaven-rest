import { Router } from 'express';
import PHIImageService from '../../services/phiimageservice'
import {ok, fail} from "../utils"

export class PHIImageHandler {
  constructor() {
    this.router = new Router();
  }
  route() {
    this.router.get("/:text", (req, res) => {
      PHIImageService.createPHIImageFromText(decodeURIComponent(req.params.text))
      .then((id)=>{
        console.log('id='+id);
        res.json({id:id})
      })
      .then(null, fail(res));
    });
    this.router.get("/getimage/:id", (req, res) => {
      PHIImageService.getPHIImageById(req.params.id)
      .then((imageData)=>{
        if (imageData) {
          res.writeHead(200, {'Content-Type': 'image/png' });
          res.end(imageData, 'binary');
        } else {
          res.writeHead(200, {'Content-Type': 'text/plain' });
          res.end('(Not found)\n');
        }
      })
      .then(null, fail(res));
    });
    return this.router;
  }
}

