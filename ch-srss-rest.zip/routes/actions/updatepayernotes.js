import BaseAction from './baseaction'
import {ok, fail} from "../utils"
import { safeRef } from '../../js/utils'
import Payer from '../../models/payer'
import Roles from '../../models/workflowroles'
import mongoose from 'mongoose'

export class UpdatePayerNotes extends BaseAction{
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.AR, Roles.FCM, Roles.AP, Roles.Scheduler];
  }
  
  route() {
    this.router.get("/:id", this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {
        Payer.findById(req.params.id, {notes:1})
        .then(payer=>{
          res.json({notes:payer.notes});
        })
        .then(null, fail(res));
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });

    this.router.post("/", this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {
        Payer.findByIdAndUpdate( req.body.payerId, {$set:{notes:req.body.notes}} )
        .then(patientCase=>{
          res.json({success:true});
        })
        .then(null, fail(res));
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    return this.router;
  }
}

