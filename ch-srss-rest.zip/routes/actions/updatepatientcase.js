import BaseAction from './baseaction'
import {ok, fail, round} from "../utils"
import { getPrevBizDay, safeRef } from '../../js/utils'
import PatientCase from '../../models/patientcase'
import PatientRecord from '../../models/patientrecord'
import CaseWorkflowAssignment from '../../models/caseworkflowassignment'
import CalendarSchedulingService from '../../services/calendarscheduling'
import WorkflowService from '../../services/workflowservice'
import PayablesService from '../../services/payablesservice'
import Roles from '../../models/workflowroles'
import NotificationService from '../../services/notificationservice'
import PatientAmtDueCalc from '../../services/patientAmtDueCalculator'
import moment from 'moment';
import mongoose from 'mongoose';

export class UpdatePatientCase extends BaseAction{
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.FCM, Roles.Scheduler, Roles.AuthMgr];
  }
  
  route() {
    this.router.post("/", this.authenticate(this.roles), (req, res) => {
      var updPatientCase = req.body.patientCase;
      var needNotification = false;
      var updatedCase = null;
      if (this.getToken(req.headers)) {
        PatientCase.findById( updPatientCase._id )
        .populate({path:'primaryPayer.claimsPayer'})
        .then((patientCase) => {
          return patientCase;
        })
        .then((patientCase)=>{
          var origDay = safeRef(patientCase.calendarBooking).day;
          var newDay = safeRef(updPatientCase.calendarBooking).day;
          if (newDay) newDay = moment(newDay).toDate();
          var serviceDateChanged = ((!newDay && origDay) ||
                                    (newDay!=null && (origDay==null || !moment(newDay).isSame(origDay,'day'))));
          var update = {$set:{}};
          var options = {new:true};
          if (patientCase.procedure._id.toString() != updPatientCase.procedure._id) {
            update.$set.procedure = updPatientCase.procedure._id;
          }
          if (patientCase.icd10Code._id.toString() != updPatientCase.icd10Code._id) {
            update.$set.icd10Code = updPatientCase.icd10Code._id;
          }
          if (patientCase.cptCode._id.toString() != updPatientCase.cptCode._id) {
            update.$set.cptCode = updPatientCase.cptCode._id;
          }
          update['$set']['paymentMethod'] = updPatientCase['paymentMethod'];
          if (updPatientCase.vendorFees && updPatientCase.vendorFees.length>0 && updPatientCase.vendorFees.length >= patientCase.requiredVendorTypes.length) {
            update['$set']['vendorFees'] = updPatientCase['vendorFees'];
          }
          if (patientCase.payerInfo.pendingAuthorizationCode && patientCase.payerInfo.pendingAuthorizationCode!=updPatientCase.payerInfo.pendingAuthorizationCode) {
            update['$set']['payerInfo.pendingAuthorizationCode'] = updPatientCase.payerInfo.pendingAuthorizationCode;
          }
          if (patientCase.payerInfo.approvedAuthorizationCode && patientCase.payerInfo.approvedAuthorizationCode!=updPatientCase.payerInfo.approvedAuthorizationCode) {
            update['$set']['payerInfo.approvedAuthorizationCode'] = updPatientCase.payerInfo.approvedAuthorizationCode;
          }
          if (req.body.notesEntry) {
            update['$push'] = {notesLog: {author:this.authData.user.name, content:req.body.notesEntry, category:'Case'}};
          }
          if (!patientCase.calendarBooking) {
            update['$set'].calendarBooking = updPatientCase.calendarBooking;
          } else if (serviceDateChanged) {
            update['$set']['calendarBooking.day'] = updPatientCase.calendarBooking.day;
            update['$set']['calendarBooking.status'] = 'Tentative';
            update['$set'].confirmations = [];
            var patientPaymentDue = patientCase.paymentsDue.find(pd=>(pd.payerType=='Patient'));
            if (patientPaymentDue && !patientPaymentDue.monthlyAmount && !patientPaymentDue.extensionDays && !patientPaymentDue.datePaidInFull) {
              update['$set']['paymentsDue.$[elem].dueDate'] = getPrevBizDay( updPatientCase.calendarBooking.day);
              options.arrayFilters = [{'elem.payerType':'Patient'}];
            }
          }
          return PatientCase.findOneAndUpdate({ _id: patientCase._id}, update, options)
        })
        .then((result)=>{
          updatedCase = result;
          var promises = [];
          if (updatedCase.patientTermsAcceptanceDate && !updatedCase.opReportUploaded) {
            promises.push(PayablesService.createPayables( updatedCase ));
          }
          return Promise.all(promises);
        })
        .then((result)=>{
          var newDay = safeRef(updatedCase.calendarBooking).day;
          return (newDay?CalendarSchedulingService.bookProcedure( updatedCase ):Promise.resolve({patientCase:updatedCase}))
        })
        .then(result=>{
          if (result.errMsg) {
            res.json({errMsg:result.errMsg});
          } else {
            var updatedCase = result.patientCase;
            return WorkflowService.updateState( updatedCase._id )
            .then(()=>{
              res.json({record:updatedCase})
              var newDay = safeRef(updatedCase.calendarBooking).day;
              return newDay?NotificationService.createNotifications(updatedCase._id, 'Tentatively Scheduled'):Promise.resolve(true);
            })
            .catch((error)=>{
              console.log(error);
            })
          }
        })
        .then(null, fail(res));
    } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    this.router.delete("/:patientCaseId", this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {
        var _id = mongoose.Types.ObjectId(req.params.patientCaseId);
        PatientCase.remove({_id:_id, $or:[{'calendarBooking.day':{$eq:null}}, {'calendarBooking.status:':'Tentative'}]})
        .then(result=>{
          if (!result.n) {
            res.json({success:false});
          } else {
            PatientRecord.remove({patientCase:_id})
            .then(result=>{
              CaseWorkflowAssignment.remove({patientCase:_id})
              .then(result=>{
                res.json({success:true});
              })
            })
          }
        })  
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    return this.router;
  }
}

