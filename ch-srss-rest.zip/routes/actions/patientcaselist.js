import BaseAction from './baseaction'
import {ok, fail} from "../utils";
import Patient from '../../models/patient';
import PatientCase from '../../models/patientcase';
import Procedure from '../../models/procedure';
import Vendor from '../../models/vendor';
import CaseWorkflowAssignment from '../../models/caseworkflowassignment';
import Roles from '../../models/workflowroles'
import {getVendorByOrgType} from "../../js/utils"
import { promises } from 'fs';
import mongoose, { isValidObjectId } from 'mongoose';
import moment from 'moment'

const ObjectId = mongoose.Types.ObjectId;

export class PatientCaseList extends BaseAction{
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.FCM, Roles.Scheduler, Roles.AP, Roles.AR];
  }
  

  route() {
    var vm = this;
    this.router.post("/patients", this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {

        var limit = req.body.options.itemsPerPage || 10;
        var skip = (req.body.options.page || 0) * limit;
        var sortBy = req.body.options.sortBy || 'patientId'
        var sortDir = (req.body.options.sortDesc || false)? -1 : 1;
        var sortMap = {}
        sortMap[sortBy] = sortDir;
        var coll = {locale: "en_US"}
        if (sortBy == 'dateOfBirth') {
          coll['numericOrdering'] = true;
        }
        var patients = null;
        var patientCount = 0;
        var promises = [];
        var filter = {};
        if (req.body.search) {
          var regex = new RegExp(req.body.search, 'i');
          filter = {$or: [
            {patientId:regex},
            {firstName:regex},
            {lastName:regex},
            {'contactInfo.email':regex},
            {'contactInfo.phone':regex},
            {'contactInfo.streetAddress':regex}]};
        }
        promises.push(Patient.find(filter).count());
        promises.push(Patient.find(filter).sort(sortMap).collation(coll).skip(skip).limit(limit))
        mongoose.Promise.all(promises)
        .then(results=>{
          patientCount = results[0];
          patients = results[1];
          var recIds = patients.map(p=>(p._id));
          return PatientCase.find( {patient: {$in: recIds}} )
          .populate({path:'patient'})
          .populate('procedure')
          .populate('vendorFees.vendor')
          .populate('patient')
        })
        .then(cases=>{
          var patientCasesMap = cases.reduce((mp,pc)=>{
            try {
              var patient = mp[pc.patient.patientId] || (mp[pc.patient.patientId]={caseCount:0});
               patient.caseCount++;
            } catch (e) {
            }
            return mp;
          },{});
          var patientList = patients.map(patient=>{
            var patientCase = patientCasesMap[patient.patientId];
            var patientObj = Object.assign({name: patient.name, sortKey:(patient.lastName+':'+patient.firstName), caseCount:0}, patient.toObject());
            if (patientCase) {
              patientObj.caseCount = patientCase.caseCount;
            }
            return patientObj;
          })
          res.json({list:patientList, count:patientCount});
        })
        .then(null, fail(res));
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    this.router.post("/cases", this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {

        var limit = req.body.options.itemsPerPage || 10;
        var skip = (req.body.options.page || 0) * limit;
        var sortBy = req.body.options.sortBy || 'caseId'
        var sortDir = (req.body.options.sortDesc || false)? -1 : 1;
        var sortMap = {}
        sortMap[sortBy] = sortDir;
        var cases = null;
        var caseCount = 0;
        var promises = [];
        var stages = [
          {$lookup: {
            from: 'procedures',
            localField: "procedure",
            foreignField: '_id',
            as: 'procedureData'
          }},
          {$unwind: "$procedureData"},
          {$lookup: {
            from: 'patients',
            localField: "patient",
            foreignField: '_id',
            as: 'patientData'
          }},
          {$unwind: "$patientData"},
          {$project: {
            '_id':1, 'calendarBooking':1, caseId:1, createdAt:1,
//              'patient.name': { $replaceAll: { input: {$concat: ['$patientData.firstName', " ", '$patientData.middleName', " ",'$patientData.lastName']}, find:"  ", replacement:" "}},
            'patient':'$patientData',
            'procedure.name':'$procedureData.name', 
            'vendors':'$vendorFees.vendor'
          }},
          {$lookup: {
            from: 'vendors',
            localField: "vendors",
            foreignField: '_id',
            as: 'vendorData'
          }},
          {$project: {
            '_id':1, 'calendarBooking':1, caseId:1, createdAt:1,
            'patient.firstName':1, 'patient.middleName':1, 'patient.lastName':1,
            'procedure.name':1, 
            'vendors':'$vendorData'
          }}
        ];
        if (req.body.options.patientId) {
          stages.unshift({$match: { patient: ObjectId(req.body.options.patientId)}})
        }
        if (req.body.search) {
          var regex = new RegExp(req.body.search, 'i');
          stages.push({ $match: 
            {$or: [
              {caseId: { $regex: regex, $options: 'i'}},
              {'patient.firstName': { $regex: regex, $options: 'i'}},
              {'patient.middleName': { $regex: regex, $options: 'i'}},
              {'patient.lastName': { $regex: regex, $options: 'i'}},
              {'procedure.name': { $regex: regex, $options: 'i'}},
              {'vendor.name': { $regex: regex, $options: 'i'}}
            ]}
          })
        }
        
        promises.push(PatientCase.aggregate(stages))
        promises.push(PatientCase.aggregate(req.body.fetchAll?stages.concat({ $sort: sortMap}):stages.concat({ $sort: sortMap}).concat([{$skip: skip}, {$limit: limit}])))

        mongoose.Promise.all(promises)
        .then(results=>{
            caseCount = results[0].length;
            cases = results[1];
            res.json({list:cases, count:caseCount});
          })
        .then(null, fail(res));
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    this.router.post("/", this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {
        return PatientCase.find( req.body.patientId?{ patient: req.body.patientId }:{$or:[{status:'Open'},{dateClosed:{$gt:moment().subtract(2, 'months').toDate()}}]} )
        .populate('procedure')
        .populate('vendorFees.vendor').populate('patient')
        .then((patientCases)=>{
          var list = patientCases.map(pc=>{
            var retCase = pc.toObject();
            retCase.surgeryCenter = getVendorByOrgType( pc, 'Surgery Center' );
            return retCase;
          });
          res.json({records:req.body.patientId?list:list.sort((a,b)=>(a.patient.name<b.patient.name?-1:(a.patient.name>b.patient.name?1:0)))})
        })
        .then(null, fail(res));
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    return this.router;
  }
}
