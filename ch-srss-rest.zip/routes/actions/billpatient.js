import BaseAction from './baseaction'
/*import {ok, fail} from "../utils"
import { safeRef } from '../../js/utils'
import PatientCase from '../../models/patientcase'
import WorkflowService from '../../services/workflowservice'
import Roles from '../../models/workflowroles'
import RecentListService from '../../services/recentlistservice'
import mongoose from 'mongoose'*/

//Obsolete
export class BillPatient extends BaseAction{
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.AR];
  }
  
  route() {

/*    this.router.post("/", this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {
        if (!req.body.billSent) {
          res.json({errMsg:'Please indicate Bill Sent.'});
          return;
        }
        PatientCase.findOneAndUpdate( 
          { _id: mongoose.Types.ObjectId(req.body.patientCaseId),
            'paymentsDue.payerType': 'Patient'
          },
          {$set: {'paymentsDue.$.dateBillSent': new Date()}}
        )
        .then((result) => {
            return WorkflowService.updateState( req.body.patientCaseId )
        })
        .then((result)=>{
          RecentListService.add( this.authData.user._id, req.body.patientCaseId )
          res.json({success:true})
        })
        .then(null, fail(res));
    } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });

    this.router.get("/:patientCaseId", this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {
        PatientCase.findById( req.params.patientCaseId )
//        .populate('paymentsdue')
        .populate({path:'procedure', select: {name:1}})
        .populate({path:'patient', select: {'patientId':1, 'firstName':1, 'lastName':1, 'middleInitial':1, 'ssn':1, 'dateOfBirth':1,
                'contactInfo':1} })
        .then((patientCase) => {
          res.json(patientCase);
        })
        .then(null, fail(res));
    } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });*/
    return this.router;
  }
}

