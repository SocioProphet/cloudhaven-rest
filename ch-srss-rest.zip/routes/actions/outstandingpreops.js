import BaseAction from './baseaction'
import {ok, fail} from "../utils";
import PatientCase from '../../models/patientcase';
import WorkflowService from '../../services/workflowservice'
import Roles from '../../models/workflowroles'
import moment from "moment"
import proceduretype from '../../models/proceduretype';

export class OutstandingPreops extends BaseAction{
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.FCM, Roles.Scheduler, Roles.AuthMgr];
  }
  
  route() {
    this.router.get("/", this.authenticate(this.roles, 'OutstandingPreops list'), (req, res) => {
      if (this.getToken(req.headers)) {
        PatientCase.find({datePreopReportReceived:{$eq:null}, 'calendarBooking.day':{$ne:null}, patientTermsAcceptanceDate:{$ne:null}, status:'Open'})
        .populate({path:'patient', select:{firstName:1, lastName:1, name:1, patientId:1}})
        .populate({path:'procedure', populate:{path:'procedureType', select:{name:1}}, select:{name:1, shortName:1}})
        .then(patientCases=>{
          res.json(patientCases);
        })
        .then(null, fail(res));
    } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    this.router.post("/", this.authenticate(this.roles, 'OutstandingPreops post'), (req, res) => {
      if (this.getToken(req.headers)) {
        PatientCase.findByIdAndUpdate(req.body.patientCaseId, {$set:{datePreopReportReceived:new Date()}})
        .then(result=>{
          WorkflowService.updateState( req.body.patientCaseId )
          res.json({success:true});
        })
        .then(null, fail(res));
    } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    return this.router;
  }
}
