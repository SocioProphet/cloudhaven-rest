import BaseAction from './baseaction'
import {ok, fail} from "../utils";
import CalendarSchedulingService from '../../services/calendarscheduling';
import moment from 'moment';
import Roles from '../../models/workflowroles'
import PatientCase from '../../models/patientcase'
import mongoose from 'mongoose';

//import Promise from 'promise';
export class CalendarScheduling extends BaseAction{
    constructor(){
      super();
      this.roles = [Roles.BMCSysAdmin, Roles.FCM, Roles.Scheduler, Roles.AuthMgr, Roles.Vendor, Roles.AP];
    }
    
    monthAvailableDaysSearch( requiredVendorTypes, vendorIds, ignoreCaseId, firstDayOfMonth) {
      var dateHigh = moment(firstDayOfMonth).add(1, 'months').toDate();
      var today = moment().startOf('day').toDate();
      var dateLow = firstDayOfMonth<today?today:firstDayOfMonth;
      return CalendarSchedulingService.availableDaysSearch(requiredVendorTypes, vendorIds, ignoreCaseId, dateLow, dateHigh);
    }
    route() {
      //params: procedureId, monthDateRange, vendorIds, ignoreCaseId
      this.router.post("/scheduledateslist", this.authenticate([Roles.ANY], 'CalendarScheduling scheduleddatelist'), (req, res) => {
        if (this.getToken(req.headers)) {
          var firstDayOfMonth = moment().date(1);
          if (req.body.monthDateRange) {
            var parts = req.body.monthDateRange.split(':')
            firstDayOfMonth = moment(parts[0], 'YYYY-MM-DD');
          }
          this.monthAvailableDaysSearch( req.body.requiredVendorTypes, req.body.vendorIds, req.body.ignoreCaseId, firstDayOfMonth.toDate())
          .then((dateList)=>{
            res.json(dateList);
          });
        } else {
          res.status(403).send({success: false, msg: 'Unauthorized.'});
        }
      });
      
      this.router.post("/schedulingcalendarcases", this.authenticate(this.roles, 'CalendarScheduling schedulingcalendarcases'), (req, res) => {
        if (this.getToken(req.headers)) {
          var searchCriteria = [
            {'calendarBooking.day':{$eq:null}},
            {'calendarBooking.day':{$gte:req.body.lowBound, $lt:req.body.highBound}}
          ];
          if (req.body.vendorId) {
            searchCriteria['vendorFees.vendor'] = req.body.vendorId;
          }
          if (req.body.includeCaseId) {
            searchCriteria.push({_id:mongoose.Types.ObjectId(req.body.includeCaseId)});
          }
          PatientCase.find({$or:searchCriteria, status:'Open'}, {calendarBooking:1, caseId:1, createdAt:1, opReportUploaded:1, vendorFees:1, primaryPayer:1, confirmations:1})
          .populate({path:'vendorFees.vendor'})
          .populate({path:'patient', select:{firstName:1, lastName:1, name:1, patientId:1}})
          .populate({path:'procedure', select:{name:1, shortName:1, procedureType:1}})
          .populate({path:'primaryPayer.claimsPayer', select:{name:1}})
          .then(caseList=>{
            res.json(caseList);
          })
        } else {
          res.status(403).send({success: false, msg: 'Unauthorized.'});
        }
      });
      return this.router;
    }
}
