import BaseAction from './baseaction'
import {ok, fail} from "../utils"
import { safeRef } from '../../js/utils'
import PatientCase from '../../models/patientcase'
import Roles from '../../models/workflowroles'
import mongoose from 'mongoose'

export class Alerts extends BaseAction{
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.Scheduler, Roles.FCM, Roles.AuthMgr, Roles.AR, Roles.AP];
  }
  
  route() {
    this.router.get("/", this.authenticate(this.roles, 'Alerts get'), (req, res) => {
      if (this.getToken(req.headers)) {
        PatientCase.find({alerts:{ $elemMatch: {dismissed: {$ne:true}}, $exists:true,$ne:[]} }, {caseId:1, alerts:1})
        .then((patientCases)=>{
          if (!patientCases) {
            res.json([]);
          } else {
            res.json(patientCases.reduce((ar, pc)=>{
              var alerts = pc.alerts.filter(a=>(!a.dismissed)).map((a)=>{
                var alert = a.toObject();
                alert.caseId = pc.caseId;
                if (!alert.dismissed) alert.dismissed = false;
                return alert;
              });
              if (alerts.length>0) {
                ar = ar.concat(alerts)
              }
              return ar;
            }, []));
          }
        })
        .then(null, fail(res));
    } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    // {refnum, payables, datePaid}
    this.router.post("/create", this.authenticate(this.roles, 'Alert Creation'), (req, res) => {
      if (this.getToken(req.headers)) {
        if (!req.body.alert) {
          res.json({success:true, count:0, amount: 0});
          return;
        }
        var user = this.getUser();
        var alert = {contents:req.body.alert, author: user}
        PatientCase.findByIdAndUpdate( req.body.patientCaseId,{$push:{alerts:alert}} )
        .then(results=>{
          res.json({success:true});
        })
        .then(null, fail(res));
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });

    this.router.post("/dismiss", this.authenticate(this.roles, 'Alert Dismissal'), (req, res) => {
      if (this.getToken(req.headers)) {
        PatientCase.findByIdAndUpdate( req.body.patientCaseId,{$pull:{alerts:{contents:req.body.key}}} )
        .then(results=>{
          res.json({success:true});
        })
        .then(null, fail(res));
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    
    return this.router;
  }
}

