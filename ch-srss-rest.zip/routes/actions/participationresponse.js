import { Router } from 'express';
import {ok, fail} from "../utils"
import WorkflowService from '../../services/workflowservice'
import PatientCase from '../../models/patientcase'
import mongoose from 'mongoose'
import moment from 'moment'

export class ParticipationResponse {
  constructor() {
    this.router = new Router();
  }
  route() {
    var patientCase = {};
    this.router.get("/:patientCaseId/:vendorId/:isFromPortal?", (req, res) => {
      PatientCase.findOneAndUpdate({_id:mongoose.Types.ObjectId(req.params.patientCaseId)},
        {$push:{confirmations:{vendor:req.params.vendorId}}}, {new:true})
      .populate('procedure')
     .then(pc=>{
       patientCase = pc;
        return WorkflowService.updateState( patientCase._id )
     })
    .then((result)=>{
      if (req.params.isFromPortal) {
        res.json({success:true})
      } else {
          res.send(`
          <html>
          <head>
          <script src="https://cdn.jsdelivr.net/npm/add-to-calendar-buttons@1.0.0/ouical.min.js" integrity="sha256-gAr1JsRCBAa4h9fwfSMaBHNg5AjR4bY/7zoQ6OCosdo=" crossorigin="anonymous"></script>
          <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/add-to-calendar-buttons@1.0.0/main.css" integrity="sha256-u9ISR4GwhxKep/RjrJb5hJ6v0yCYZc7c+auAtIxgOko=" crossorigin="anonymous">
          
          </head>
          <body style="margin:10px 20px;"><br/>
          <h2>${process.env.SURGICAL_CENTER} Appointment Confirmation</h2>
          You have <b>Confirmed</b> your participation in a ${patientCase.procedure.name} on 
          <b>${moment(patientCase.calendarBooking.day).format('l')}</b>.
          <p>
          <div id="calendarDiv"></div>
          <script language="Javascript">
            var calObj = createCalendar({
              data: {
                title: '${patientCase.procedure.name} appointment',
                start: new Date(${moment(patientCase.calendarBooking.day).valueOf()}),
                duration: 60,          
                address: '${process.env.SURGICAL_CENTER}',
            
                description: '${patientCase.procedure.name} surgical appointment'
              }
            });
            document.getElementById('calendarDiv').appendChild(calObj);
          </script>
          </body>
          </html>`)
        }
      })
      .then(null, fail(res));
    });
    return this.router;
  }
}

