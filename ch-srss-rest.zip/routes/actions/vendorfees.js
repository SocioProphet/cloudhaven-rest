import BaseAction from './baseaction'
import {ok, fail} from "../utils";
import Vendor from '../../models/vendor';
import Roles from '../../models/workflowroles'

export class VendorFees extends BaseAction{
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin];
  }
  
  route() {
    this.router.delete("/:vendorId/:vendorFeeId", this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {
        Vendor.findByIdAndUpdate( req.params.vendorId, {$pull:{vendorFees:{_id:req.params.vendorFeeId}}})
        .then(result=>{
          res.json({success:true})
        })
        .then(null, fail(res));
    } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    this.router.post("/", this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {
        var vendorId = req.body.vendorId;
        var vendorFee = req.body.vendorFee;
        var update = {};
        var searchCriteria = {_id:vendorId};
        if (!vendorFee._id) {
          update['$push'] = {vendorFees:vendorFee};
        } else {
          searchCriteria['vendorFees._id'] = vendorFee._id;
          update['$set'] = {'vendorFees.$.description':vendorFee.description, 'vendorFees.$.feeType':vendorFee.feeType, 
                            'vendorFees.$.fixedFee':vendorFee.fixedFee,'vendorFees.$.percentage':vendorFee.percentage,
                            'vendorFees.$.isRetired':vendorFee.isRetired};
        }
        Vendor.updateOne( searchCriteria, update)
        .then(result=>{
          res.json({success:true})
        })
        .then(null, fail(res));
    } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    return this.router;
  }
}
