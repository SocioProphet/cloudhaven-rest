import BaseAction from './baseaction'
import {ok, fail} from "../utils";
import PatientCase from '../../models/patientcase';
import Roles from '../../models/workflowroles'
import moment from 'moment'

export class VendorPayables extends BaseAction{
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.AP];
  }
  
  route() {
    this.router.get("/:vendorId", this.authenticate(this.roles, 'VendorPayables get'), (req, res) => {
      if (this.getToken(req.headers)) {
        PatientCase.find({'payables.vendor':req.params.vendorId })
        .populate({path:'payables.vendor', select:{name:1}})
        .then((patientCases)=>{
          if (!patientCases) {
            res.json([]);
          } else {
            res.json(patientCases.reduce((ar, pc)=>{
              var payables = pc.payables.filter(p=>(p.vendor.id==req.params.vendorId));
              payables = payables.map((p)=>{
                var payable = p.toObject();
                payable.caseId = pc.caseId;
                return payable;
              });
              ar = ar.concat(payables)
              return ar;
            }, []));
          }
        })
        .then(null, fail(res));
    } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    this.router.post("/fordaterange", this.authenticate(this.role, 'VendorPayables fordaterange'), (req, res) => {
      if (this.getToken(req.headers)) {
        var startDate = req.body.startDate?moment(req.body.startDate).toDate():moment().startOf('month').substract(1, 'month');
        PatientCase.find(
          {'payables.vendor':req.body.vendorId,
            $or:[{'payables.datePaid':{$eq:null}}, {'payables.datePaid':{$gte:startDate}}]
          })
        .populate({path:'payables.vendor', select:{name:1}})
        .populate({path:'patient', select:{patientId:1}})
        .populate({path:'procedure', select:{name:1}})
        .then((patientCases)=>{
          if (!patientCases) {
            res.json([]);
          } else {
            res.json(patientCases.reduce((ar, pc)=>{
              ar = ar.concat(pc.payables.filter(p=>(p.vendor.id==req.body.vendorId)).map(p=>(
                { patientId: pc.patient.patientId,
                  caseId: pc.caseId,
                  procedure: pc.procedure.name,
                  dueDate: p.dueDate,
                  amount: p.amount,
                  additionalAmount: p.additionalAmount,
                  datePaid: p.datePaid,
                  paymentRefNum: p.paymentRefNum,
                  daysOverdue: p.daysOverdue,
                  apBucket: p.apBucket
                }
              )))
              return ar;
            }, []));
          }
        })
        .then(null, fail(res));
    } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    return this.router;
  }
}
