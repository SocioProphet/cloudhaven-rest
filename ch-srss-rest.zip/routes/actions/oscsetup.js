import BaseAction from './baseaction'
import {ok, fail} from "../utils";
import Roles from '../../models/workflowroles'
import mongoose from 'mongoose';
import OSCSetup from '../../models/oscsetup';
import fs from 'fs';
import parser from "csv-parse/lib/sync"

export class OSCEdit extends BaseAction{
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin];
  }
  
  getPayersDomain() {
    var sCSV = fs.readFileSync('WayStarPayers.csv');
    var payerList = parser(sCSV, {columns:true, relax_column_count:true});
    var list = payerList.map(p=>({label:`${p['Payer Name']} (${p['Waystar Payer ID']})`, name:p['Payer Name'], payerId:p['Waystar Payer ID'], supportsElectronicClaims:p['Institutional Claims']}));
    return list;
  }
  route() {
    this.router.get("/payerdomain", this.authenticate(this.roles, 'OSCEdit payerdomain'), (req, res) => {
      if (this.getToken(req.headers)) {
        res.json(this.getPayersDomain());
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    this.router.get("/", this.authenticate([Roles.ANY], 'OSCEdit read'), (req, res) => {
      if (this.getToken(req.headers)) {
        OSCSetup.findOne({})
        .then(setup=>{
          res.json(setup?setup:{billingProvider:{}, operatingProvider:{}})
        })
        .then(null, fail(res));
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    this.router.post("/", this.authenticate(this.roles, 'OSCEdit update'), (req, res) => {
      if (this.getToken(req.headers)) {
        OSCSetup.findOne({})
        .then(setup=>{
          delete req.body['_id'];
          delete req.body['_v'];
          (setup?OSCSetup.findOneAndUpdate({_id:setup._id}, req.body):OSCSetup.create( req.body ))
          .then(result=>{
            res.json({success:true});
          })
        })
        .then(null, fail(res));
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    return this.router;
  }
}
