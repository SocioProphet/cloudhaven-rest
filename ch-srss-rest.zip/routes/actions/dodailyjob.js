import { Router } from 'express';
import DailyJobService from '../../services/dailyjobservice'
import ClearingHouse from '../../services/clearinghouse'

export class DoDailyJob {
  constructor() {
    this.router = new Router();
  }
  /*
    doScheduledNotifications(onDemand);
  doOverduePayablesNotifications();
 
  */
  route() {
    this.router.get("/schedulednotifications", (req, res) => {
      DailyJobService.doScheduledNotifications(true);
      res.json({jobDone:true})
    });
    this.router.get("/overduepayables", (req, res) => {
      DailyJobService.doOverduePayablesNotifications();
      res.json({jobDone:true})
    });
    this.router.get("/getclaimsstatus", (req, res) => {
      ClearingHouse.getClaimsStatus();
      res.json({jobDone:true})
    });

    
    return this.router;
  }
}

