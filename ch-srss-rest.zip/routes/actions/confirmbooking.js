import BaseAction from './baseaction'
import {ok, fail} from "../utils"
import PatientCase from '../../models/patientcase'
import CalendarSchedulingService from '../../services/calendarscheduling'
import WorkflowService from '../../services/workflowservice'
import Roles from '../../models/workflowroles'
import NotificationService from '../../services/notificationservice'

export class ConfirmBooking extends BaseAction{
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.FCM, Roles.Scheduler];
  }
  
  route() {
    this.router.post("/", this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {
        PatientCase.findById(req.body.patientCaseId)
        .populate({path:'vendorFees.vendor'})
        .then((patientCase) => {
          var vendorIds =  patientCase.vendorFees.map(pf=>pf.vendor._id);
          return CalendarSchedulingService.canBookDay(patientCase.requiredVendorTypes, vendorIds, patientCase.calendarBooking.day, patientCase._id)
          .then((canBook)=>{
            if (!canBook) {
              res.json({errMsg: 'Date of Service fully booked - please rescheduled on another date.'});
              return mongoose.Promise.resolve(null);
            } else {
              var update = {$set:{'calendarBooking.status':'Booked'}};
              if (req.body.notesEntry) {
                update['$push'] = {notesLog: {author:this.authData.user.name, content:req.body.notesEntry, category:'Case'}};
              }
              return PatientCase.updateOne({_id:patientCase._id}, update)
            }
          })
          .then((result)=>{
            res.json({success:true});
            return WorkflowService.updateState( patientCase._id )
          })
          .then((result)=>{
            return NotificationService.createNotifications(patientCase._id, 'Date of Service Booked')
          })
        })
        .then(null, fail(res));
    } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    return this.router;
  }
}
