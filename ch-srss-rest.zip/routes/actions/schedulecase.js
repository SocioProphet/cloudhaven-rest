import BaseAction from './baseaction'
import {ok, fail} from "../utils"
import { getPrevBizDay } from '../../js/utils'
import PatientCase from '../../models/patientcase'
import CalendarSchedulingService from '../../services/calendarscheduling'
import WorkflowService from '../../services/workflowservice'
import Roles from '../../models/workflowroles'
import NotificationService from '../../services/notificationservice'
import mongoose from 'mongoose'
import moment from 'moment'

export class ScheduleCase extends BaseAction{
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.Scheduler];
  }
  
  route() {
    this.router.post("/", this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {
        var thisCase = null;
        var newCase = null;
        var dateOfService = moment(req.body.scheduledDate).toDate();
        PatientCase.findById( req.body.patientCaseId)
        .then((patientCase) => {
          thisCase = patientCase;
          var vendorIds =  patientCase.vendorFees?patientCase.vendorFees.map(pf=>pf.vendor._id):[];
          return CalendarSchedulingService.canBookDay(patientCase.requiredVendorTypes, vendorIds, dateOfService, patientCase._id)
        })  
        .then((canBook)=>{
          if (canBook) {
            var update = {$set:{'calendarBooking.day': dateOfService}};
            var options = {new:true};
            var patientPaymentDue = thisCase.paymentsDue.find(pd=>(pd.payerType=='Patient'));
            if (patientPaymentDue && !patientPaymentDue.monthlyAmount && !patientPaymentDue.extensionDays && !patientPaymentDue.datePaidInFull) {
              var patientPaymentDueDate = getPrevBizDay( dateOfService );
              update['$set']['paymentsDue.$[elem].dueDate'] = patientPaymentDueDate;
              options.arrayFilters = [{'elem.payerType':'Patient'}];
            }
            return PatientCase.findOneAndUpdate( {_id: mongoose.Types.ObjectId(req.body.patientCaseId)}, update, options)
            .then(pc=>{
              newCase = pc;
              res.json({success:true})
              return WorkflowService.updateState( thisCase._id )
            })
            .then((result) => {
              if (newCase.calendarBooking.status=='Booked') {
                return NotificationService.createNotifications(thisCase._id,'Date of Service Booked')
              } else {
                return mongoose.Promise.resolve(true);
              }
            })
            .then(result=>{
              return mongoose.Promise.resolve(true);
            })
          } else {
            res.json({errMsg:'Booking not valid for this date.'});
            return mongoose.Promise.resolve(false);
          }
        })
        .then(null, fail(res));
    } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    return this.router;
  }
}

