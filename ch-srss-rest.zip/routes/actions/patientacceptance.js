import BaseAction from './baseaction'
import {ok, fail} from "../utils"
import { getPrevBizDay, safeRef } from '../../js/utils'
import PatientCase from '../../models/patientcase'
import WorkflowService from '../../services/workflowservice'
//import PayablesService from '../../services/payablesservice'
import RecentListService from '../../services/recentlistservice'
import Roles from '../../models/workflowroles'
import NotificationService from '../../services/notificationservice'
import mongoose from 'mongoose'
//import moment from 'moment'

export class PatientAcceptance extends BaseAction{
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.FCM, Roles.Scheduler];
  }
  
  route() {

    this.router.get('/getcostestimate/:patientCaseId', this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {
        NotificationService.getCostEstimateNotification( mongoose.Types.ObjectId(req.params.patientCaseId))
        .then(html=>{
          if (!html) {
            res.sendStatus(404).end()
          } else {
            res.pdfFromHTML({
              filename: 'costestimate.pdf',
              htmlContent: html,
              options: {format: 'Letter'}
            });
          }
        })
        .then(null, fail(res));
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    this.router.post("/", this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {
        PatientCase.findById( req.body.patientCaseId )
        .populate({path:'primaryPayer.claimsPayer', select:{contractedRate:1}})
        .populate({path:'procedure', select: {'name':1}})
        .then(patientCase => {
          var update = {};
          if (req.body.notesEntry) {
            update['$push'] =  {notesLog: {author:this.authData.user.name, content:req.body.notesEntry, category:'Case'}}
          }
          if (req.body.action == 'accept') {
            update['$set'] = {patientTermsAcceptanceDate:new Date()};
            var patientPaymentDue = patientCase.paymentsDue.find(pd=>(pd.payerType=='Patient'));
            if (patientCase.paymentMethod == 'Cash') {
              if (!patientPaymentDue) {
                if (!update['$push']) update['$push'] = {};
                update['$push']['paymentsDue'] = {payerType:'Patient', amount:patientCase.primaryPayer.contractedRate, arClockStartDate: new Date()};
              }
            } else {
              if (!patientPaymentDue) {
                if (!update['$push']) update['$push'] = {};
                update['$push']['paymentsDue'] = {payerType:'Patient', amount: Number((patientCase.totalDueFromPatient||0).toFixed(6))};
              }
            }
            var arrayFilters;
            if (patientCase.calendarBooking.day) {
              var dueDate = getPrevBizDay( patientCase.calendarBooking.day);
              if (!patientPaymentDue) {
                if (!update['$push']) update['$push'] = {};
                update['$push']['paymentsDue'] = {payerType:'Patient', amount: Number((patientCase.totalDueFromPatient||0).toFixed(6)), dueDate: dueDate};
              } else {
                arrayFilters = [{'elem.payerType':'Patient'}];
                update['$set']['paymentsDue.$[elem].dueDate'] = dueDate;
              }
            }
            return PatientCase.findOneAndUpdate({_id:patientCase._id}, update, {new:true, arrayFilters:arrayFilters} )
/*            .then((newCase)=>{
              return PayablesService.createPayables( newCase )
            })*/
            .then((result)=>{
              return WorkflowService.updateState( patientCase._id )
            })
            .then((result)=>{
              return patientCase;
            })
          } else {
            update['$set'] = {status:'Refused'};
            return PatientCase.findOneAndUpdate({_id:patientCase._id}, update )
            .then((result)=>{
              return patientCase;
            })
          }
        })
        .then((patientCase)=>{
          return NotificationService.createNotifications(patientCase._id, 
            req.body.action == 'accept'?'Patient Accepted':'Patient Refusal')
        })
        .then((result)=>{
//          RecentListService.add( this.authData.user._id, req.body.patientCaseId ) //perform aschronously
          res.json({success:true})
        })
        .then(null, fail(res));
    } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });

    this.router.get("/:patientCaseId", this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {
        PatientCase.findById( req.params.patientCaseId )
        .populate({path:'primaryPayer.claimsPayer'})
        .populate({path:'secondaryPayer.claimsPayer'})
        .populate({path:'procedure', select: {'name':1}})
        .populate({path:'patient' })
        .then((patientCase) => {
          res.json(patientCase);
        })
        .then(null, fail(res));
    } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    return this.router;
  }
}

