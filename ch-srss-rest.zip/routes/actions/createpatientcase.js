import BaseAction from './baseaction'
import {ok, fail} from "../utils"
import { randomId } from '../../js/utils';
import PatientCase from '../../models/patientcase'
import CalendarSchedulingService from '../../services/calendarscheduling'
import WorkflowService from '../../services/workflowservice'
import Roles from '../../models/workflowroles'
import CaseSequentialId from '../../models/casesequentialids'
import RecentListService from '../../services/recentlistservice'
import NotificationService from '../../services/notificationservice'
import mongoose from 'mongoose'
import { parseDate } from 'tough-cookie';

export class CreatePatientCase extends BaseAction{
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.FCM, Roles.Scheduler, Roles.AuthMgr];
  }
  
  route() {
    this.router.post("/", this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {
        var needNotification = false;
        CaseSequentialId.create({domain:'Case'})
        .then((caseSeqId)=>{
          return randomId(caseSeqId.seqNumber);
        })
        .then((caseId)=>{
          var patientCase = req.body.patientCase;
          patientCase.notesLog = req.body.notesEntry?[{author:this.authData.user.name, content:req.body.notesEntry, category:'Case'}]:[];
          patientCase.caseId = caseId;
          patientCase.vendorFees.forEach(pf=>{
            pf.vendor = mongoose.Types.ObjectId(pf.vendor);
          })
          var payerProcedure = patientCase.primaryPayer.claimsPayer.procedures.find(pp=>(pp.procedure._id==patientCase.procedure._id));
          patientCase.primaryPayer.contractedRate = payerProcedure?payerProcedure.contractedRate:null;
          if (patientCase.primaryPayer.claimsPayer.isSelfPayer) {
            patientCase.totalDueFromPatient = patientCase.primaryPayer.contractedRate;
          }
          return PatientCase.create(patientCase)
        })
        .then((patientCase) => {
          if (patientCase.calendarBooking && patientCase.calendarBooking.day) {
            needNotification = true;
            return CalendarSchedulingService.bookProcedure( patientCase )
            .then((result)=>{
              if (result.errMsg) {
                res.json(result);
              } else {
                return patientCase;
              }
            })
          } else {
            return patientCase
          }
        })
        .then((patientCase)=>{
          if (!patientCase.errMsg) {
            return WorkflowService.updateState( patientCase._id )
            .then((result)=>{
              res.json({record:patientCase})
              return NotificationService.createNotifications(patientCase._id, 'Tentatively Scheduled');
            })
/*            .then((result)=>{
              res.json({record:patientCase})
              return RecentListService.add( this.authData.user._id, patientCase._id.toString() );
            })
            .then((result) => {
              return NotificationService.createNotifications(patientCase._id, 'Tentatively Scheduled')
            })*/
          }
        })
        .then(null, fail(res));
    } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    return this.router;
  }
}
