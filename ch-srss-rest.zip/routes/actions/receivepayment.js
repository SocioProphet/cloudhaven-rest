import BaseAction from './baseaction'
import {ok, fail} from "../utils"
import { safeRef } from '../../js/utils'
import PatientCase from '../../models/patientcase'
import Roles from '../../models/workflowroles'
import RecentListService from '../../services/recentlistservice'
import WorkflowService from '../../services/workflowservice'
import mongoose from 'mongoose'
import moment from 'moment';

export class ReceivePayment extends BaseAction{
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.AR, Roles.FCM];
  }
  
  route() {
    this.router.get("/collections", this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {
        var mToday = moment().startOf('day');
        PatientCase.find({status:'Open', 
          $or:[{'paymentsDue.dueDate':{$lt:mToday.toDate()}},{'paymentsDue.receivableAction':{$in:['Extend Due Date', 'Monthly Payment Plan']}}]})
        .populate({path:'primaryPayer.claimsPayer', select:{name:1}})
        .populate({path:'secondaryPayer.claimsPayer', select:{name:1}})
        .populate({path:'patient', select:{name:1}})
        .then(patientCases=>{
          var retList = [];
          patientCases.forEach(patientCase=>{
            patientCase.paymentsDue.forEach(paymentDue=>{      
              if (((paymentDue.receivableAction!='Written Off' && paymentDue.receivableAction!='Sent to Collections' && moment(paymentDue.dueDate).startOf('day').isBefore(mToday)) || 
                 ((paymentDue.payerType=='Patient' && (paymentDue.receivableAction=='Extend Due Date' || paymentDue.receivableAction=='Monthly Payment Plan')))) && paymentDue.currentAmountDue>0) {
                  var latestPmt = paymentDue.transactions.reduce(function(latestTxn,txn) {
                    if (txn.txnType=='Payment' && (!latestTxn || txn.txnDate>latestTxn.txnDate)) {
                      latestTxn = txn;
                    }
                    return latestTxn;
                  }, null) || {};
                  if (latestPmt) latestPmt.txnDateVal = moment(latestPmt.txnDate).valueOf();
                  var daysUntilDue = paymentDue.dueDate?moment(paymentDue.dueDate).startOf('day').diff(mToday, 'days'):null;
                  var arAgeDays = paymentDue.arClockStartDate?mToday.diff(moment(paymentDue.arClockStartDate).startOf('day'), 'days'):'';
                  var arAgeBucket = '0-30';
                  if (arAgeDays>120) {
                    arAgeBucket = "120+";
                  } else if (arAgeDays>90) {
                    arAgeBucket = "90-120";
                  } else if (arAgeDays>60) {
                    arAgeBucket = "60-90";
                  } else if (arAgeDays>30) {
                    arAgeBucket = "30-60";
                  }
                  retList.push({
                    patientCaseId:patientCase._id,
                    _id: paymentDue._id,
                    daysUntilDue: daysUntilDue>=0?daysUntilDue:'',
                    daysOverdue: daysUntilDue<0?-daysUntilDue:'',
                    payerType: paymentDue.payerType,
                    dueDate: paymentDue.dueDate,
                    amount: paymentDue.amount,
                    arAgeBucket: arAgeBucket,
                    arAgeDays: arAgeDays,
                    balanceDue: paymentDue.currentAmountDue,
                    receivableAction: paymentDue.receivableAction,
                    latestPayment: latestPmt,
                    originalDueDate: paymentDue.originalDueDate
                  });
              }
            })
          })
          res.json(retList);
        })
        .then(null, fail(res));
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });

    this.router.post("/delete", this.authenticate(this.roles), (req, res) => {
      var paymentsDue = null;
      if (this.getToken(req.headers)) {
        var update = {$pull:{'paymentsDue.$[].transactions':{_id:req.body.payment._id}}};
        var note = `Deleted ${req.body.payer} ${req.body.payment.txnType} of ${req.body.payment.amount.toFixed(2)} made on ${moment(req.body.payment.txnDate).format('l')}`;
        update['$push'] = {notesLog: {author:this.authData.user.name, content:note, category:req.body.payerType+' Payments'}};
        PatientCase.findOneAndUpdate({_id: mongoose.Types.ObjectId(req.body.patientCaseId), status:'Open'}, update, {new:true} )
        .then(patientCase=>{
          paymentsDue = patientCase.paymentsDue;
          return WorkflowService.updateState( req.body.patientCaseId )
        })
        .then(result=>{
          res.json({success:true, paymentsDue:paymentsDue});
        })
        .then(null, fail(res));
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    this.router.post("/xferbalancetopatient", this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {
        var patientCaseId = req.body.patientCaseId;
        var paymentsDue = null;
        PatientCase.findById(patientCaseId)
        .then(patientCase=>{
          var primaryPayerPmtDue = patientCase.paymentsDue.find(pd=>(pd.payerType=='Primary Payer'));
          var balance =  primaryPayerPmtDue.currentAmountDue;
          if (balance <= 0) {
            return Promise.resolve(true);
          }
          var promises = [];
          var today = moment().toDate();
          var patientAdj = {txnType:'Adjustment', amount: -balance,
            refCodeReason: 'Balance transfer from payer', txnDate:today};
          var update = {};
          update['$push'] = {'paymentsDue.$[patient].transactions':patientAdj };
          promises.push(
            PatientCase.findOneAndUpdate(
              { _id:mongoose.Types.ObjectId(patientCaseId)},
            update, {new:true, arrayFilters: [{'patient.payerType':'Patient'}]})
          );
          var payerAdj = {txnType:'Adjustment', amount: balance, 
            refCodeReason: 'Balance transfer to patient', txnDate:today};
          var update = {};
          update['$push'] = {'paymentsDue.$[primaryPayer].transactions':payerAdj };
          promises.push(
            PatientCase.findOneAndUpdate(
            { _id:mongoose.Types.ObjectId(patientCaseId)},
            update, {new:true, arrayFilters: [{'primaryPayer.payerType':'Primary Payer'}]})
          );
          return mongoose.Promise.all(promises);
        })
        .then(patientCase=>{
          paymentsDue = patientCase.paymentsDue;
          return WorkflowService.updateState( patientCaseId )
        })
        .then(result=>{
          res.json({success:true, paymentsDue:paymentsDue});
        })
        .then(null, fail(res));
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    this.router.post("/xferbalance", this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {
        var patientCaseId = req.body.patientCaseId;
        var paymentsDue = null;
        PatientCase.findById(patientCaseId)
        .then(patientCase=>{
          var patientPmtDue = patientCase.paymentsDue.find(pd=>(pd.payerType=='Patient'));
          var payerPmtDue = patientCase.paymentsDue.find(pd=>(pd.id==req.body.paymentDueId));
          var payerType = payerPmtDue.payerType;
          var xferToSecondaryAmt = (req.body.xferToSecondaryAmt||0);
          var balance =  (payerPmtDue.currentAmountDue - (req.body.xferToPatientAmt+xferToSecondaryAmt)).toFixed(6);
          if (balance < 0) {
            return Promise.resolve(true);
          }
          var promises = [];
          var today = moment().toDate();
          var refCodeReason = (req.body.isCredit)?'Credit from payer overpayment':('Balance transfer from '+payerType);
          if (patientPmtDue) {
            var patientAdj = {txnType:'Adjustment', amount: -req.body.xferToPatientAmt,
              refCodeReason: refCodeReason, txnDate:today};
            var update = {};
            update['$push'] = {'paymentsDue.$[patient].transactions':patientAdj };
            promises.push(
              PatientCase.findOneAndUpdate(
                { _id:mongoose.Types.ObjectId(patientCaseId)},
              update, {new:true, arrayFilters: [{'patient.payerType':'Patient'}]})
            );
          } else {
            var update = {'$push':{}};
            update['$push']['paymentsDue'] = {payerType:'Patient', 
              amount: 0, arClockStartDate: today,
              dueDate: moment(patientCase.calendarBooking.day).toDate(),
              transactions:[{
                txnType:'Adjustment', amount: -req.body.xferToPatientAmt,
                  refCodeReason:refCodeReason, txnDate:today
              }]};
            promises.push(
              PatientCase.findOneAndUpdate({ _id:mongoose.Types.ObjectId(patientCaseId)}, update, {new:true })
            );
          }
          if (xferToSecondaryAmt) {
            var adj = {txnType:'Adjustment', amount: -xferToSecondaryAmt,
              refCodeReason: 'Balance transfer from '+payerType, txnDate:today};
            var update = {};
            update['$push'] = {'paymentsDue.$[secondary].transactions':adj };
            promises.push(
              PatientCase.findOneAndUpdate(
                { _id:mongoose.Types.ObjectId(patientCaseId)},
              update, {new:true, arrayFilters: [{'secondary.payerType':'Secondary Payer'}]})
            );
          }
          refCodeReason = req.body.isCredit?'Overpayment credit to patient':'Balance transfer';
          var payerAdj = {txnType:'Adjustment', amount: req.body.xferToPatientAmt+xferToSecondaryAmt, refCodeReason: refCodeReason, txnDate:today};
          var update = {};
          update['$push'] = {'paymentsDue.$[payer].transactions':payerAdj };
          promises.push(
            PatientCase.findOneAndUpdate(
            { _id:mongoose.Types.ObjectId(patientCaseId)},
            update, {new:true, arrayFilters: [{'payer.payerType':'Primary Payer'}]})
          );
          return mongoose.Promise.all(promises);
        })
        .then(results=>{
          return PatientCase.findById(patientCaseId)
        })
        .then(patientCase=>{
          paymentsDue = patientCase.paymentsDue;
          return WorkflowService.updateState( patientCaseId )
        })
        .then(result=>{
          res.json({success:true, paymentsDue:paymentsDue});
        })
        .then(null, fail(res));
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    this.router.post("/", this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {
        var update = {$set:{}};
        var refCodeReasons = [];
        var txns = [];
        if (req.body.amountReceived) {
          refCodeReasons.push(req.body.receiptRefCode);
          var txn = {txnType:'Payment', 
            amount: req.body.amountReceived,
            refCodeReason: req.body.receiptRefCode,
            paymentMethod: (req.body.paymentMethod || null)
          };
          if (req.body.txnDate) {
            txn.txnDate = moment(req.body.txnDate).toDate();
          }
          txns.push( txn );
        }
        if (req.body.adjustmentAmount) {
          refCodeReasons.push(req.body.adjustmentReason);
          var txn = {txnType:'Adjustment', amount: req.body.adjustmentAmount, refCodeReason: req.body.adjustmentReason};
          if (req.body.txnDate) {
            txn.txnDate = moment(req.body.txnDate).toDate();
          };
          txns.push(txn);
        }
        update['$push'] = {'paymentsDue.$[elem].transactions':{ $each:txns}};
        if (req.body.notesEntry) {
          update['$push']['notesLog'] = {author:this.authData.user.name, content:req.body.notesEntry, category:`${req.body.payerType} Payments`};
        }
        if (req.body.receivableAction == 'Extend Due Date') {
          update['$set']['paymentsDue.$[elem].monthlyAmount'] = null;
          update['$set']['paymentsDue.$[elem].dueDayOfMonth'] = null;
          update['$set']['paymentsDue.$[elem].extensionDays'] = req.body.extensionDays;
          if (req.body.dueDate) {
            update['$set']['paymentsDue.$[elem].dueDate'] = moment(req.body.dueDate).toDate();
          }
        } else if (req.body.receivableAction == 'Monthly Payment Plan') {
          update['$set']['paymentsDue.$[elem].extensionDays'] = null;
          update['$set']['paymentsDue.$[elem].promissoryNoteSigned'] = req.body.promissoryNoteSigned;
          update['$set']['paymentsDue.$[elem].creditCardOnFile'] = req.body.creditCardOnFile;
          update['$set']['paymentsDue.$[elem].dueDayOfMonth'] = req.body.dueDayOfMonth;
          update['$set']['paymentsDue.$[elem].monthlyAmount'] = req.body.monthlyAmount;
          if (req.body.dueDate) {
            update['$set']['paymentsDue.$[elem].dueDate'] = moment(req.body.dueDate).toDate();
          }
        } else {
          update['$set']['paymentsDue.$[elem].monthlyAmount'] = null;
          update['$set']['paymentsDue.$[elem].dueDayOfMonth'] = null;
          update['$set']['paymentsDue.$[elem].extensionDays'] = null;
        }
        update['$set']['paymentsDue.$[elem].receivableAction'] = req.body.receivableAction || null;
        PatientCase.findOneAndUpdate(
          { _id:mongoose.Types.ObjectId(req.body.patientCaseId)
          }, update, {new:true, arrayFilters: [{'elem.payerType':req.body.payerType}]})
        .populate({path:'primaryPayer.claimsPayer', model:'Payer'})
        .populate({path:'secondaryPayer.claimsPayer', model:'Payer'})
        .then(patientCase => {
          var promises = [];
          if (req.body.payerType!='Patient' && req.body.amountReceived) {
            update = {'$set':{'paymentsDue.$[patient].arClockStartDate': new Date()}};
            promises.push(PatientCase.findOneAndUpdate(
              { _id:mongoose.Types.ObjectId(req.body.patientCaseId)
              }, update, {new:false, arrayFilters: [{ 'patient.payerType':'Patient'}]})
              )
          }
  
          if (req.body.payerType == 'Primary Payer' && patientCase.secondaryPayer.claimsPayer && patientCase.secondaryPayer.claimsPayer._id) {
            var patientPaymentDue = patientCase.paymentsDue.find(pd=>(pd.payerType == 'Patient'));
            var patientAmountDue = (patientPaymentDue?patientPaymentDue.amount:0) || 0;
            var primaryPayerPaymentDue = patientCase.paymentsDue.find(pd=>(pd.payerType == 'Primary Payer'));
            var primaryPayerAmountDue = (primaryPayerPaymentDue?primaryPayerPaymentDue.amount:0) || 0;
            var secondaryPayerAmt = patientCase.primaryPayer.contractedRate - (patientAmountDue+primaryPayerAmountDue);
            var secondaryPayerAmt =  Number((secondaryPayerAmt||0).toFixed(6));
            var dueDate = moment().add((patientCase.secondaryPayer.claimsPayer.paymentTerms?patientCase.secondaryPayer.claimsPayer.paymentTerms:32),'days').toDate();
            if (patientCase.paymentMethod == 'Insurance') {
               promises.push(PatientCase.updateOne({_id:patientCase._id, 'paymentsDue':{'$not':{'$elemMatch':{'payerType':'Secondary Payer'}}}},
                 {$push:{'paymentsDue': { payerType:'Secondary Payer', amount:secondaryPayerAmt, arClockStartDate: new Date(), dueDate:dueDate} }}));
            }
          }
          return mongoose.Promise.all(promises)
        })
        .then((result=>{
          return WorkflowService.updateState( req.body.patientCaseId );
        }))
        .then((result)=>{
          RecentListService.add( this.authData.user._id, req.body.patientCaseId )
          res.json({success:true})
        })
        .then(null, fail(res));
    } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });

    this.router.get("/:patientCaseId", this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {
        PatientCase.findById( req.params.patientCaseId )
//        .populate('primaryPayer.claimsXContact')
//        .populate('secondaryPayer.claimsXContact')
        .populate({path:'procedure', select: {name:1}})
        .populate('primaryPayer.claimsPayer')
        .populate('secondaryPayer.claimsPayer')
        .populate({path:'patient'})
        .then((patientCase) => {
          res.json(patientCase);
        })
        .then(null, fail(res));
    } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    return this.router;
  }
}

