import BaseAction from './baseaction'
import {ok, fail} from "../utils"
import { safeRef } from '../../js/utils'
import PatientCase from '../../models/patientcase'
import OSCSetup from '../../models/oscsetup'
import WorkflowService from '../../services/workflowservice'
import RecentListService from '../../services/recentlistservice'
import Roles from '../../models/workflowroles'
import mongoose from 'mongoose'
import moment from 'moment'
import ftpClient  from 'ssh2-sftp-client'
import Logger from '../../services/eventlogger'
//import fs from 'fs'

function prep(s) {
  return (s||'').replace(/[^\w\s]/gi, '');
}
const stateAbbrMap =
{
  'alabama': 'AL',
  'alaska': 'AK',
  'american samoa': 'AS',
  'arizona': 'AZ',
  'arkansas': 'AR',
  'california': 'CA',
  'colorado': 'CO',
  'connecticut': 'CT',
  'delaware': 'DE',
  'district of columbia': 'DC',
  'federated states of micronesia': 'FM',
  'florida': 'FL',
  'georgia': 'GA',
  'guam': 'GU',
  'hawaii': 'HI',
  'idaho': 'ID',
  'illinois': 'IL',
  'indiana': 'IN',
  'iowa': 'IA',
  'kansas': 'KS',
  'kentucky': 'KY',
  'louisiana': 'LA',
  'maine': 'ME',
  'marshall islands': 'MH',
  'maryland': 'MD',
  'massachusetts': 'MA',
  'michigan': 'MI',
  'mnnesota': 'MN',
  'mississippi': 'MS',
  'missouri': 'MO',
  'montana': 'MT',
  'nebraska': 'NE',
  'nevada': 'NV',
  'new hampshire': 'NH',
  'new jersey': 'NJ',
  'new mexico': 'NM',
  'new york': 'NY',
  'north carolina': 'NC',
  'north dakota': 'ND',
  'northern mariana islands': 'MP',
  'ohio': 'OH',
  'oklahoma': 'OK',
  'oregon': 'OR',
  'palau': 'PW',
  'pennsylvania': 'PA',
  'puerto rico': 'PR',
  'rhode island': 'RI',
  'south carolina': 'SC',
  'south dakota': 'SD',
  'tennessee': 'TN',
  'texas': 'TX',
  'utah': 'UT',
  'vermont': 'VT',
  'virgin islands': 'VI',
  'virginia': 'VA',
  'washington': 'WA',
  'west virginia': 'WV',
  'wisconsin': 'WI',
  'wyoming': 'WY'
};
function prepState( state ) {
  if (!state) return '';
  if (state.length==2) return state.toUpperCase();
  var stateCode = stateAbbrMap[state.toLowerCase()];
  if (stateCode) return stateCode;
  return state.substring(0,2).toUpperCase();
}
function logClaimResult( patientCaseId, contents ) {
  PatientCase.updateOne({'_id':mongoose.Types.ObjectId(patientCaseId)}, {$push:{claimUploadLog:{contents:contents}}})
  .then((result)=>{
    var x = result;
    var y = x;
  })
  .catch((err)=>{
    var x = err;
    var y = x;
  })
}
function submitClaim( payerType, patientCase, oscSetup, cb ) {
  var promise = new Promise(function( resolve, reject){
  try {
    var yyyymmddServiceDate = moment(patientCase.calendarBooking.day).format('YYYYMMDD');
    var claimsContact = patientCase.primaryPayer.claimsPayer /*.claimsContact.contactInfo*/;
    var hasSecondaryPayer = patientCase.secondaryPayer.claimsPayer && patientCase.secondaryPayer.claimsPayer._id;
    hasSecondaryPayer = hasSecondaryPayer!=null && hasSecondaryPayer!='';
    var elements = [
      /*1-10*/
      oscSetup.billingProvider.name,
      oscSetup.billingProvider.streetAddress+(oscSetup.billingProvider.streetAddress2?(' '+oscSetup.billingProvider.streetAddress2):''),
      `${oscSetup.billingProvider.city}, ${prepState(oscSetup.billingProvider.stateOrProvince)}  ${oscSetup.billingProvider.postalCode}`,
      oscSetup.billingProvider.phone||'',
      oscSetup.billingProvider.fax||'',
      oscSetup.billingProvider.countryCode||'',
      oscSetup.billingProvider.city,
      prepState(oscSetup.billingProvider.stateOrProvince),
      oscSetup.billingProvider.postalCode,
      '',
      /*11-20*/
      '',
      '',
      '',
      '',
      '',
      '',
      patientCase.caseId+payerType.charAt(0),
      patientCase.caseId+payerType.charAt(0), //medicalHealthRecordNumber
      oscSetup.typeOfBill,
      '',
      /*21-30*/
      oscSetup.federalTaxNumber,
      yyyymmddServiceDate,
      yyyymmddServiceDate,
      '',
      '',
      '',
      patientCase.patient.patientId,
      patientCase.patient.nameLastFirst,
      patientCase.patient.contactInfo.streetAddress||'',
      patientCase.patient.contactInfo.city,
      /*32-40*/
      prepState(patientCase.patient.contactInfo.stateOrProvince),
      patientCase.patient.contactInfo.zipOrPostalCode,
      patientCase.patient.contactInfo.country,
      moment(patientCase.patient.dateOfBirth).format('YYYYMMDD'),
      patientCase.patient.gender?patientCase.patient.gender.charAt(0):'',
      '',
      '',
      '3',
      '2',
      '',
      /*41-50*/
      '1','','','','','','','','','',
      /*51-60*/
      '','','','','','','','','','',
      /*61-70*/
      '','','','','','','','','','',
      /*71-80*/
      '','','','','','','','','','',
      /*81-90*/
      '','','','','',
      patientCase.primaryPayer.claimsPayer.clearinghouseName,
      claimsContact.streetAddress, '', '',
      claimsContact.city+', '+prepState(claimsContact.stateOrProvince)+'  '+claimsContact.zipOrPostalCode,
      /*91-100*/
      '','','','','','','','','','',
      /*101-110*/
      '','','','','','','','','','',
      /*111-120*/
      '','','','',
      oscSetup.revenueCode,'','','','','',
      /*121-130*/
      '','','','','','','','','','',
      /*131-140*/
      '','','','','','','',oscSetup.revenueDescription,'','',
      /*141-150*/
      '','','','','','','','','','',
      /*151-160*/
      '','','','','','','','','','',
      /*161-170*/
      patientCase.cptCode.code,'','','','','','','','','',
      /*171-180*/
      '','','','','','','','','','',
      /*181-190*/
      '','','', moment(patientCase.calendarBooking.day).format('YYYYMMDD'),'','','','','','',
      /*191-200*/
      '','','','','','','','','','',
      /*201-210*/
      '','','','','','', '1','','','',
      /*211-220*/
      '','','','','','','','','','',
      /*221-230*/
      '','','','','','','','','', (patientCase.totalCharges || patientCase.procedure.totalCharges).toFixed(2),
      /*231-240*/
      '','','','','','','','','','',
      /*241-250*/
      '','','','','','','','','','',
      /*251-260*/
      '','','','','','','','','','',
      /*261-270*/
      '','','','','','','','','','',
      /*271-280*/
      '','','','','', patientCase.primaryPayer.claimsPayer.clearinghouseName,
      hasSecondaryPayer?(patientCase.secondaryPayer.claimsPayer.clearinghouseName||''):'',
      patientCase.primaryPayer.healthPlanId||'', hasSecondaryPayer?(patientCase.secondaryPayer.healthPlanId||''):'', '',
      /*281-290*/
      '', 'Y', 'Y', '', 'Y', 'Y', '', '','','',
      /*291-300*/
      patientCase.primaryPayer.contractedRate||0,
      hasSecondaryPayer?patientCase.secondaryPayer.contractedRate:'',
      '', oscSetup.billingProvider.NPI, '','','',
      patientCase.primaryPayer.insuredsName,
      hasSecondaryPayer?patientCase.secondaryPayer.insuredsName:'', '',
      /*301-310*/
      patientCase.primaryPayer.relationshipToPatient, hasSecondaryPayer?patientCase.secondaryPayer.relationshipToPatient:'', '',
      patientCase.primaryPayer.policyNumber, hasSecondaryPayer?patientCase.secondaryPayer.policyNumber:'', '',
      '', '', '', patientCase.primaryPayer.groupNumber,
      /*311-320*/
      hasSecondaryPayer?patientCase.secondaryPayer.groupNumber:'', '',
      patientCase.payerInfo.approvedAuthorizationCode, '', '',
      '', '', '', '', '',
      /*321-330*/
      '', '0', patientCase.icd10Code.code, 
      '','','','','','','',
      /*331-340*/
      '','','','','','','','','','',
      /*341-350*/
      '', '', patientCase.icd10Code.code,
      '', '', '', '', '', '', '',
      /*351-360*/
      '','','','','','','','','','',
      /*361-370*/
      '','','','','','','', 
      oscSetup.operatingProvider.NPI, '', '', 
      /*371-380*/
      oscSetup.operatingProvider.lastName, oscSetup.operatingProvider.firstName,
      oscSetup.operatingProvider.NPI, '', '', oscSetup.operatingProvider.lastName, oscSetup.operatingProvider.firstName,
      'DN', oscSetup.operatingProvider.NPI, '',
      /*381-390*/
      '', oscSetup.operatingProvider.lastName, oscSetup.operatingProvider.firstName, '','','','','','','',
      /*391-400*/
      '','','','','','','','','','',
      /*401-409*/
      '','','','','', 
      patientCase.primaryPayer.claimsPayer.clearinghouseName,
      claimsContact.streetAddress,
      '',
      claimsContact.city+', '+prepState(claimsContact.stateOrProvince)+' '+ claimsContact.zipOrPostalCode
    ];
  } catch (e) {
    console.log('Exception building claims file '+e);
    Logger.error('Claim Submission', 'Error building claim file ('+e+')')
    reject(e);
    return;
  }
/*    fs.writeFileSync(patientCase.caseId+'_'+(new Date()).getTime()+'.CLI', elements.join('|')+'\r\n');
    resolve(true);*/
    var buffer = new Buffer(elements.join('|')+'\r\n');
    if (elements.length != 409) {
      reject('Wrong number of elements in claim ('+elements.length+')');
      return;
    }
    let sftp = new ftpClient();
    sftp.connect({
      host: process.env.CLAIMS_FTP_DOMAIN,
      port: '22',
      username: process.env.CLAIMS_FTP_USER,
      password: process.env.CLAIMS_FTP_PWD,
      readyTimeout: 99999,
        algorithms: {
          kex: ['diffie-hellman-group16-sha512', 'diffie-hellman-group14-sha256', 'diffie-hellman-group-exchange-sha256', 
                'diffie-hellman-group14-sha1', 'diffie-hellman-group-exchange-sha1'],
          cipher: ['aes256-ctr', 'aes128-ctr', 'aes256-cbc', 'aes128-cbc'],
          serverHostKey: ['ssh-rsa' ], //, 'ssh-dss'
          hmac: ['hmac-sha2-512', 'hmac-sha2-256', 'hmac-sha1', 'hmac-sha1-96'],
          compress: ['zlib', 'none']
        }
    }).then(() => {
      console.log('connected');
      return sftp.put(buffer, '/Upload/'+patientCase.caseId+'.CLI');
    }).then(() => {
      console.log('sftp put succeeded!');
      try {
        Logger.log('Claim Submission', 'claim sent for '+patientCase.caseId);
      } catch (e) {
        console.log('Failed to Logger.log Claim Submission!');
      }
      try {
        logClaimResult( patientCase.id, elements.join('|'));
      } catch(e) {
        console.log('Failed to log Claim Result!');
      }
      sftp.end();
      resolve(true);
    }).catch(err => {
      try {
        Logger.error('Claim Submission', 'Claim send failure ('+err.message+')');
      } catch(e) {
        console.log('Failed to Logger.log Claim Failure!');
      }
      reject(err.message);
    });
  })
  return promise;
}

function traversErrors( errorLines, errorObj, prefix ) {
  Object.keys(errorObj).forEach(key=>{
    errorLines.push(prefix+key);
    var subObj = errorObj[key];
    if (Array.isArray(subObj)) {
      subObj.forEach(line=>{
        errorLines.push(prefix+'  '+line);
      })
    } else {
      traversErrors( errorLines, subObj, prefix+'  ');
    }
  })
}
function errorsToString(err) {
  var errorLines = [];
  traversErrors( errorLines, err.data.errors, '');
  return errorLines.join('\n');
}

export class ClearingHouse extends BaseAction{
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.FCM];
  }
  
  route() {
    this.router.post("/sendclaim", this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {
        var payerSelector = req.body.payerType=='Primary Payer'?'primaryPayer':'secondaryPayer';
        var promises = [PatientCase.findById(req.body.patientCaseId)
          .populate('patient')
          .populate('procedure')
          .populate('cptCode')
          .populate('icd10Code')
          .populate({path:payerSelector+'.claimsPayer'})
//          .populate(payerSelector+'.claimsXContact')
          ,
          OSCSetup.findOne({})];
        mongoose.Promise.all(promises)
        .then(results=>{
          var patientCase = results[0];
          if (!patientCase) {
            res.json({success:false, errMsg:'Patient Case not found.'});
          } else if (!patientCase[payerSelector].claimsPayer.clearinghouseName) {
            res.json({success:false, errMsg:'Clearinghouse payer name not defined.'});
          } else if (!results[1]) {
            res.json({success:false, errMsg:'OSC Setup not found.'});
//          } else if (patientCase[payerSelector].claimSentDatetime) {
//            res.json({success:false, errMsg:'A claim is already pending', state:patientCase[payerSelector].claimsTransmission.claimProcessingState});
          } else {
            submitClaim( req.body.payerType, patientCase, results[1])
            .then(result=>{
              var update = {'$set':{}};
              update['$set'][payerSelector+'.claimSentDatetime'] = new Date();
              PatientCase.updateOne(
                { _id: mongoose.Types.ObjectId(req.body.patientCaseId), 'paymentsDue.payerType': req.body.payerType }, update )
              .then(result=>{
                return WorkflowService.updateState( req.body.patientCaseId )
              })
              .then((result)=>{
//                RecentListService.add( this.authData.user._id, req.body.patientCaseId )
                res.json({success:true})
              })
            })
            .then(null,(error)=>{
              logClaimResult( req.body.patientCaseId, error+'');
              console.log(error);
            })
          }
        })
        .then(null, fail(res));
    } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    return this.router;
  }
}

