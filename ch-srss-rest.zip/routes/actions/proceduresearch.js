import BaseAction from './baseaction'
import {ok, fail} from "../utils";
import Procedure from '../../models/procedure';
import Roles from '../../models/workflowroles'

export class ProcedureSearch extends BaseAction{
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.FCM, Roles.Scheduler, Roles.AuthMgr];
  }
  
  route() {
    this.router.post("/", this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {
        var filter = {isPublished: true};
        if (req.body.payerId) {
          filter.payer = req.body.payerId;
        }
        Procedure.find( filter )
        .populate('cptCode')
        .populate('diagnoses')
        .populate('primaryPayer.claimsPayer')
        .populate('procedureType')
        .then(function(data){
          if (req.body.searchCriteria) {
            var criteria = req.body.searchCriteria.toLowerCase();
            data = data.filter((procedure) => {
              return procedure.name.toLowerCase().indexOf(criteria)>=0
            })
          }
          res.json({data:data});
        })
        .then(null, fail(res));
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    return this.router;
  }
}

