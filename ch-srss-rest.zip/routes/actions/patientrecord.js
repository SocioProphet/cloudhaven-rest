import BaseAction from './baseaction'
import {ok, fail} from "../utils";
import Roles from '../../models/workflowroles'
import PatientRecord from '../../models/patientrecord';

export class GetPatientRecord extends BaseAction{
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.FCM, Roles.Scheduler, Roles.AR];
  }
  
  route() {
    /*
      params procedureId, vendor
    */
   this.router.get("/:id", this.authenticate(this.roles), (req, res) => {
     var self = this;
    if (this.getToken(req.headers)) {
      PatientRecord.findById(req.params.id)
      .then(patientRecord=>{
        self.logAuditData( 'PatientRecord', req.params.id, 'read', patientRecord);
        res.contentType(patientRecord.mimeType)
        res.send(patientRecord.body)
      })
      .then(null, fail(res));
    } else {
      res.status(403).send({success: false, msg: 'Unauthorized.'});
    }
  });
    return this.router;
  }
}
