import BaseAction from './baseaction'
import {ok, fail} from "../utils"
import Vendor from '../../models/vendor'
import Roles from '../../models/workflowroles'
import mongoose from 'mongoose'

export class AddDevice extends BaseAction{
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.Scheduler];
  }
  
  route() {

    this.router.post("/", this.authenticate(this.roles, 'Add Device'), (req, res) => {
      if (this.getToken(req.headers)) {
        Vendor.findOneAndUpdate({_id:mongoose.Types.ObjectId(req.body.deviceMakerId), vendorType:'Device Maker',
          vendorFees:{$not:{$elemMatch:{description:req.body.device.description}}}},
          {$push:{vendorFees:req.body.device}}, {new:true})
        .then((result)=>{
          res.json({updatedRecord:result})
        })
        .then(null, fail(res));
    } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });

    return this.router;
  }
}

