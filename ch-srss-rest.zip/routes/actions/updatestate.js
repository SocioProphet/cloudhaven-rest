import BaseAction from './baseaction'
import {ok, fail} from "../utils"
import { safeRef } from '../../js/utils'
import WorkflowService from '../../services/workflowservice'
import Roles from '../../models/workflowroles'

export class UpdateState extends BaseAction{
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.FCM, Roles.Scheduler];
  }
  
  route() {

    this.router.post("/", this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {
        WorkflowService.updateState( req.body.patientCaseId )
        .then((result)=>{
          res.json(result);
        })
        .then(null, fail(res));
    } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });

    return this.router;
  }
}

