import BaseAction from './baseaction'
import {ok, fail} from "../utils"
import Payer from '../../models/payer'
import Roles from '../../models/workflowroles'
import mongoose from 'mongoose'

export class PayerProcedure extends BaseAction{
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.FCM, Roles.Scheduler];
  }
  
  route() {
    this.router.post("/", this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {
        Payer.findByIdAndUpdate(req.body.payerId, {$push:{procedures:req.body.procedure}}, {new:true})
        .populate('procedures.procedure')
        .then(payer=>{
          res.json({success:true, procedures:payer.procedures});
        })
        .then(null, fail(res));
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    this.router.put("/:payerId/:payerProcedureId", this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {
        var updProcedure = {};
        this.copyAttributes(req.body, updProcedure);
        var update = Object.keys(updProcedure).reduce((mp,fld)=>{
          mp['procedures.$[elem].'+fld] = updProcedure[fld];
          return mp;
        },{})
        Payer.findByIdAndUpdate(req.params.payerId, {$set:update}, {new:true, arrayFilters:[{'elem._id':mongoose.Types.ObjectId(req.params.payerProcedureId)}]})
        .then((payer) => {
          res.json({success:true})
        });
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    this.router.delete("/:payerId/:payerProcedureId", this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {
        Payer.findByIdAndUpdate( req.params.payerId, {$pull:{procedures:{_id:req.params.payerProcedureId}}} )
        .then(result=>{
          res.json({success:true});
        })  
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });

    return this.router;
  }
}
