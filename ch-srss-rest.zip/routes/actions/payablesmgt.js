import BaseAction from './baseaction'
import {ok, fail} from "../utils"
import { safeRef } from '../../js/utils'
import PatientCase from '../../models/patientcase'
import WorkflowService from '../../services/workflowservice'
import Logger from '../../services/eventlogger'
import Roles from '../../models/workflowroles'
import RecentListService from '../../services/recentlistservice'
import mongoose from 'mongoose'

export class PayablesMgt extends BaseAction{
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.AP];
  }
  
  route() {
    // {refnum, payables, datePaid}
    this.router.post("/bulkpay", this.authenticate(this.roles, 'PayablesMgt bulkpay'), (req, res) => {
      if (this.getToken(req.headers)) {
        if (req.body.payables.length==0) {
          res.json({success:true, count:0, amount: 0});
          return;
        }
        var successCount = 0;
        var totalAmount = 0;
        var payee = req.body.payee;

        var promises = [];
        req.body.payables.forEach((p)=>{
          promises.push(
            PatientCase.findOneAndUpdate(
              { _id: mongoose.Types.ObjectId(p.patientCaseId)},
              {$set:{'payables.$[elem].paymentRefNum':req.body.datePaid?req.body.refNum:null,'payables.$[elem].datePaid':req.body.datePaid}},
              {arrayFilters: [{'elem._id':mongoose.Types.ObjectId(p.payableId)}]}
            )
          );
        })
        mongoose.Promise.all(promises)
        .then((results) => {
          for (var i=0;i<req.body.payables.length;i++) {
            if (results[i].nModified) {
              successCount++;
              totalAmount += req.body.payables[i].amount;
            }
          }
          promises = [];
          req.body.payables.forEach((p)=>{
            promises.push( WorkflowService.updateState( p.patientCaseId ) );
          })
          return mongoose.Promise.all(promises);
        })
        .then((results)=>{
          Logger.log('Payables Bulk Pay', `${totalAmount} paid to ${payee}, ref #${req.body.refNum}.`);
          res.json({success:true, count:successCount, amount: totalAmount, payee:payee});
        })
        .then(null, fail(res));
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    // patientCaseId, payableId, paymentRefNum, datePaid
    this.router.post("/", this.authenticate(this.roles, 'PayablesMgt update'), (req, res) => {
      if (this.getToken(req.headers)) {
        PatientCase.findOneAndUpdate(
          { _id: mongoose.Types.ObjectId(req.body.patientCaseId)},
          {$set:{'payables.$[elem].paymentRefNum':req.body.datePaid?req.body.paymentRefNum:null,'payables.$[elem].datePaid':req.body.datePaid}},
          {arrayFilters: [{'elem._id':mongoose.Types.ObjectId(req.body.payableId)}]}
        )
        .then((result) => {
            return WorkflowService.updateState( req.body.patientCaseId )
        })
        .then((result)=>{
//          RecentListService.add( this.authData.user._id, req.body.patientCaseId )
          res.json({success:true})
        })
        .then(null, fail(res));
    } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });

    this.router.get("/", this.authenticate(this.roles, 'PayablesMgt list'), (req, res) => {
      if (this.getToken(req.headers)) {
        PatientCase.find( 
          { status:'Open', 
            payables: { $elemMatch:{apClockStartDate:{$ne:null}, datePaid:null}}
          }/*, 
          { caseId:1, 'calendarBooking.day': 1, payables: 1, paymentsDue:1}*/)
        .populate({path:'payables.vendor', select:{name:1, contacts:1, subjectToInsPmtHold:1}})
        .populate({path:'payables.patient', select:{firstName:1, lastName:1, name:1, contactInfo:1}})
        .populate('procedure')
        .populate({path:'primaryPayer.claimsPayer'})
//        .populate({path:'primaryPayer.claimsXContact'})
        .populate({path:'secondaryPayer.claimsPayer'})
//        .populate({path:'secondaryPayer.claimsXContact'})
        .populate({path:'patient', select:{'patientId':1, firstName:1, lastName:1, name:1, contactInfo:1}})
        .then((list) => {
          res.json(list);
        })
        .then(null, fail(res));
    } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    return this.router;
  }
}

