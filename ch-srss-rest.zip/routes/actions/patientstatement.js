import BaseAction from './baseaction'
import {ok, fail, round, roundFloat} from "../utils";
import { safeRef } from '../../js/utils'
import Patient from '../../models/patient';
import PatientCase from '../../models/patientcase';
import Roles from '../../models/workflowroles'
import moment from "moment"
import mongoose from 'mongoose';
import OSCSetup from '../../models/oscsetup';
import PDFDocument from 'pdfkit'

export class PatientStatement extends BaseAction{
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.FCM, Roles.AR];
  }
  
  formatPhone(phone) {
    var s = '';
    if (phone.length==10) {
      s = '('+phone.substring(0,3)+') ';
      phone = phone.substring(3);
    }
    s += phone.substring(0,3)+'-'+phone.substring(3);
    return s;
  }
  formatNumber(num) {
    return num.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,')
  }
  
  route() {
        //dateOfService, firstName, lastName
    this.router.post("/", /*this.authenticate(this.roles),*/ (req, res) => {
      if (true /*this.getToken(req.headers)*/) {
        mongoose.Promise.all([
          Patient.findById(req.body.patientId),
          PatientCase.find({patient:req.body.patientId, status: {$in: ['Open', 'Closed'] }})
            .populate({path:'procedure',populate:{path:'procedureType'}})
            .populate({path:'primaryPayer.claimsPayer', select:{name:1, isSelfPayer:1}})
            .populate({path:'secondaryPayer.claimsPayer', select:{name:1}}),
          OSCSetup.findOne({})
        ])
        .then((results)=>{
          var oscSetup = results[2];
          var patientCases = results[1];
          var patient = results[0];
          var rows = [];
          var totalPatientAmtDue = 0;
          var totalBalance = 0;
          var payerBalance = 0;
          var payerOverPayment = 0;
          patientCases.forEach((pc)=>{

            var balance = 0;
            if (pc.paymentsDue.length==0) return;
            var isSelfPayer = safeRef(safeRef(pc.primaryPayer).claimsPayer).isSelfPayer;
            var patientPaymentDue = pc.paymentsDue.find(pd=>(pd.payerType=='Patient'));
            var totalCharges = isSelfPayer?patientPaymentDue.amount:(pc.totalCharges || pc.procedure.totalCharges);
            balance += totalCharges;
            rows.push({
              date:pc.calendarBooking.day?moment(pc.calendarBooking.day).format('M-D-YY'):'',
              description: pc.procedure.procedureType.name+' (Case # '+pc.caseId+')',
              charges: '$'+this.formatNumber(round(totalCharges, 2)),
              hasPadding: rows.length>0? true : false
            });
            if (!isSelfPayer) {
              var primaryPayerPaymentDue = pc.paymentsDue.find(pd=>(pd.payerType=='Primary Payer'));
              if (pc.primaryPayer.id) {
                payerBalance = roundFloat(pc.primaryPayer.contractedRate - (patientPaymentDue?patientPaymentDue.amount:pc.totalDueFromPatient));
                var payerAdjustment = (totalCharges - pc.primaryPayer.contractedRate);
                balance -= payerAdjustment;
                rows.push({
                  date: moment(safeRef(primaryPayerPaymentDue).datePaidInFull?primaryPayerPaymentDue.datePaidInFull:pc.calendarBooking.day).format('M-D-YY'),
                  description: 'Adj by '+pc.primaryPayer.claimsPayer.name.substr(0,38),
                  credit: '$'+this.formatNumber(round(payerAdjustment, 2)),
                  balance: '$'+this.formatNumber(round(balance, 2))
                });
              }
              if (primaryPayerPaymentDue) {
  /*              if (primaryPayerPaymentDue.receivedAmount || primaryPayerPaymentDue.currentAmountDue == 0 ) {
                  balance -= primaryPayerPaymentDue.receivedAmount;
                  rows.push({
                    date: moment(primaryPayerPaymentDue.datePaidInFull).format('M-D-YY'),
                    description: 'Payment by '+pc.primaryPayer.claimsPayer.name,
                    credit: '$'+this.formatNumber(round(primaryPayerPaymentDue.receivedAmount, 2)),
                    balance: '$'+this.formatNumber(round(balance, 2))
                  });
                } else {*/
                  balance -= primaryPayerPaymentDue.receivedAmount;
                  payerBalance -= primaryPayerPaymentDue.receivedAmount;
                  rows.push({
                    date: '',
                    description: 'Amt Paid by '+pc.primaryPayer.claimsPayer.name.substr(0,33),
                    credit: '$'+this.formatNumber(round(primaryPayerPaymentDue.receivedAmount,2)),
                    balance: '$'+this.formatNumber(round(balance, 2))
                  });
  //              }
                if (primaryPayerPaymentDue.adjustmentAmount) {
                  balance -= primaryPayerPaymentDue.adjustmentAmount;
                  payerBalance -= primaryPayerPaymentDue.adjustmentAmount;
                  rows.push({
                    date: primaryPayerPaymentDue.lastAdjustmentDate?moment(primaryPayerPaymentDue.lastAdjustmentDate).format('M-D-YY'):'',
                    description: pc.primaryPayer.claimsPayer.name.substr(0,33)+' adjustments',
                    credit: '$'+this.formatNumber( round(primaryPayerPaymentDue.adjustmentAmount, 2)),
                    balance: '$'+this.formatNumber( round(balance, 2))
                  })
                }
              }
              var secondaryPayerPaymentDue = pc.paymentsDue.find(pd=>(pd.payerType=='Secondary Payer'));
              if (secondaryPayerPaymentDue) {
  /*              var payerAdjustment = (totalCharges - pc.secondaryPayer.contractedRate);
  //              balance -= payerAdjustment;
                var date = secondaryPayerPaymentDue.datePaidInFull || pc.calendarBooking.day || '';
                rows.push({
                  date: moment(date).format('M-D-YY'),
                  description: 'Adjustment by '+pc.secondaryPayer.claimsPayer.name,
                  credit: '$'+this.formatNumber( round(payerAdjustment, 2)),
                  balance: '$'+this.formatNumber( round(balance, 2))
                });*/
  /*              if (secondaryPayerPaymentDue.receivedAmount || secondaryPayerPaymentDue.currentAmountDue == 0 ) {
                  balance -= secondaryPayerPaymentDue.receivedAmount;
                  rows.push({
                    date: moment(secondaryPayerPaymentDue.datePaidInFull).format('M-D-YY'),
                    description: 'Payment by '+pc.secondaryPayer.claimsPayer.name,
                    credit: '$'+this.formatNumber( round(secondaryPayerPaymentDue.receivedAmount, 2)),
                    balance: '$'+this.formatNumber( round(balance, 2))
                  });
                } else {*/
                  balance -= secondaryPayerPaymentDue.receivedAmount;
                  payerBalance -= secondaryPayerPaymentDue.receivedAmount;
                  rows.push({
                    date: '',
                    description: 'Amount Due from '+pc.secondaryPayer.claimsPayer.name.substr(0,33),
                    credit: '$'+this.formatNumber( round(secondaryPayerPaymentDue.receivedAmount, 2)),
                    balance: '$'+this.formatNumber( round(balance, 2))
                  })
  //              }
                if (secondaryPayerPaymentDue.adjustmentAmount) {
                  balance -= secondaryPayerPaymentDue.adjustmentAmount;
                  payerBalance -= secondaryPayerPaymentDue.adjustmentAmount;
                  rows.push({
                    date: secondaryPayerPaymentDue.lastAdjustmentDate?moment(secondaryPayerPaymentDue.lastAdjustmentDate).format('M-D-YY'):'',
                    description: pc.secondaryPayer.claimsPayer.name.substr(0,33)+' adjustments',
                    credit: '$'+this.formatNumber( round(secondaryPayerPaymentDue.adjustmentAmount, 2)),
                    balance: '$'+this.formatNumber( round(balance, 2))
                  })
                }
              }
            }
            var patientBalance = 0;
            if (patientPaymentDue) {
              patientBalance = patientPaymentDue.amount;
              if (patientPaymentDue.receivedAmount>0) {
                var latestPaymentDate = patientPaymentDue.transactions.reduce((latestDate, txn)=>{
                  if (!latestDate || txn.txnDate>latestDate) latestDate = txn.txnDate;
                  return latestDate;
                },null);
                balance -= patientPaymentDue.receivedAmount;
                patientBalance -= patientPaymentDue.receivedAmount;
                rows.push({
                  date: latestPaymentDate?moment(latestPaymentDate).format('M-D-YY'):'',
                  description: 'You paid',
                  credit: '$'+this.formatNumber( round(patientPaymentDue.receivedAmount, 2)),
                  balance: '$'+this.formatNumber( round(balance, 2))
                });
              }
              if (patientPaymentDue.adjustmentAmount) {
                balance -= patientPaymentDue.adjustmentAmount;
                patientBalance -= patientPaymentDue.adjustmentAmount;
                rows.push({
                  date: patientPaymentDue.lastAdjustmentDate?moment(patientPaymentDue.lastAdjustmentDate).format('M-D-YY'):'',
                  description: 'Payment adjustments',
                  credit: '$'+this.formatNumber( round(patientPaymentDue.adjustmentAmount, 2)),
                  balance: '$'+this.formatNumber( round(balance, 2))
                })
              }
            } else {
              patientBalance = pc.totalDueFromPatient || 0;
            }
            totalPatientAmtDue += patientBalance;
            payerBalance = roundFloat(payerBalance);
            if (payerBalance < 0) {
              payerOverPayment -= payerBalance;
            }
            totalBalance += balance;
          });
          if (payerOverPayment > 0) {
            totalPatientAmtDue -= roundFloat(payerOverPayment);
          }
          if (payerBalance > 0) {
            rows.push({
              date: '',
              description: 'Balance Due from Payers',
              credit: '$'+this.formatNumber( round(payerBalance, 2) ),
              balance: '$'+this.formatNumber( round(totalBalance - payerBalance, 2)),
              hasPadding: true
            })
          }
        var refundDue = (Math.round(totalPatientAmtDue)<0);
          rows.push({
            date: '',
            description: refundDue?'Total Patient Credit':'Total Patient Amount Due',
            credit: '',
            balance: '$'+this.formatNumber( round(Math.abs(totalPatientAmtDue), 2))
          })

          var doc = new PDFDocument({autoFirstPage: true});
          doc.fontSize(10);
          doc.lineGap(3);
          doc.font('Helvetica');
          var topOfPage = doc.y;
          var leftStart = doc.x;
          doc.text(oscSetup.billingProvider.name.toUpperCase()+'\n'+
            oscSetup.billingProvider.streetAddress.toUpperCase()+'\n');
          if (oscSetup.billingProvider.streetAddress2) {
            doc.text(oscSetup.billingProvider.streetAddress2.toUpperCase()+'\n');
          }
          doc.text(`${oscSetup.billingProvider.city.toUpperCase()}, ${oscSetup.billingProvider.stateOrProvince.toUpperCase()} ${oscSetup.billingProvider.postalCode}\n`+
            this.formatPhone(oscSetup.billingProvider.phone)+'\n\n\n');

          doc.text('ACCOUNT # '+patient.patientId+'\n\n'+
            patient.name.toUpperCase()+'\n'+
            patient.contactInfo.fullAddress.toUpperCase()
          )
          var curY = doc.y;
          doc.text('DATE: '+moment().format('MM/DD/YY')+(refundDue?'\nCREDIT  ':'\nPLEASE PAY  ')+'$'+this.formatNumber( round(Math.abs(totalPatientAmtDue), 2)), 350, topOfPage);
          doc.text('\n\nCREDIT/DEBIT #___________________\nSIGNATURE_______________________\nEXP. DATE______/_______\nSECURITY CODE#_______\n__VISA  __MC  __DISC  __AMEX\nCHECK #____________');

          if (doc.y>curY) curY = doc.y;
          doc.fontSize(7);
          doc.text('------------ CUT HERE AND RETURN ABOVE PORTION WITH PAYMENT OR CALL (702) 932-8370 TO MAKE YOUR PAYMENT BY PHONE ------------', leftStart, curY+30, {align:'center'});
          doc.fontSize(10);
          doc.moveDown();
          doc.text('PATIENT: '+patient.nameLastFirst.toUpperCase()+'   ACCT # '+patient.patientId);
          doc.moveDown();
          curY = doc.y;

          doc.text('DATE       DESCRIPTION                               CHARGES     PAYMENTS/ADJUSTMENTS          BALANCE');
          curY = doc.y - 2;
          doc.moveTo( leftStart, curY);
          doc.lineWidth(1.2).lineTo(540, curY).stroke();
          curY += 6;

          var rowCnt = 0;
          rows.forEach(row=>{
            rowCnt++;
            if (row.hasPadding) curY += 10;
            if (row.description.indexOf('Total ')==0) {
              curY = curY - 2;
              doc.moveTo( leftStart+45, curY);
              doc.lineWidth(1.2).lineTo(540, curY).stroke();
              curY += 6;
            }
            doc.text(row.date, leftStart, curY);
            doc.text(row.description, leftStart+45, curY);
            doc.text(row.charges||'', leftStart+159, curY, {width:90, align:'right'});
            doc.text(row.credit||'', leftStart+275, curY, {width:90, align:'right'});
            doc.text(row.balance||'', leftStart+375, curY, {width:90, align:'right'});
            curY += 15;
          })
          curY += 25;
          var boxWidth = 120;
          doc.rect(leftStart+344, curY, boxWidth+4, 19).stroke();
          doc.text(refundDue?'CREDIT':'YOU OWE', leftStart+350, curY+5);
          doc.text('$'+this.formatNumber( round(Math.abs(totalPatientAmtDue), 2)), leftStart+375, curY+5, {width:90, align:'right'});

          doc.moveDown();
          doc.text(req.body.statementNote, leftStart, doc.y);
          doc.moveDown();
          doc.moveDown();
          doc.fontSize(8);
          doc.text('Thank you for having your surgery with us, we wish you all the best in your recovery!\n\nThe staff at the Coronado Surgical Recovery Suites', {align:'center'})

        
          try {
            res.writeHead(200, {
              'Content-Type': 'application/pdf',
              'Content-Disposition': 'attachment; filename=patientStatement.pdf'
            });
            doc.pipe(res);
            doc.end();
            if (req.body.updateStatementSentDate) {
              var today = moment().toDate();
              Patient.findOneAndUpdate({_id:mongoose.Types.ObjectId(req.body.patientId)}, {$set:{dateStatementLastPrinted: today}}, {new:true})
              .then((r)=>{
                var x = '';
                var y = '';
              })
            }
          } catch (e) {
            var x = e;
          }
        })
        .then(null, fail(res));
    } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    return this.router;
  }
}
