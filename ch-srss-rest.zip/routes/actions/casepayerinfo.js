import BaseAction from './baseaction'
import {ok, fail} from "../utils"
import { getPrevBizDay, safeRef } from '../../js/utils'
import PatientCase from '../../models/patientcase'
import WorkflowService from '../../services/workflowservice'
import Roles from '../../models/workflowroles'
import NotificationService from '../../services/notificationservice'
import RecentListService from '../../services/recentlistservice'

export class CasePayerInfo extends BaseAction{
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.FCM, Roles.Scheduler, Roles.AuthMgr];
  }
  
  
  route() {

    this.router.post("/authorized", this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {
        PatientCase.findById( req.body.patientCaseId )
        .then((patientCase) => {
          var notes = req.body.notesEntry || 'Authorized';
          if (req.body.approvedAuthorizationCode) {
            notes += '\nApproved Authorization Code: '+req.body.approvedAuthorizationCode;
          }
          var updates = {};
          if (req.body.payerType=='Primary Payer') {
            updates = { $set:{'payerInfo.pendingAuthorizationCode': req.body.pendingAuthorizationCode,
            'payerInfo.approvedAuthorizationCode': req.body.approvedAuthorizationCode,
            'payerInfo.authorizationContact': req.body.authorizationContact,
            'payerInfo.authorizationPhone': req.body.authorizationPhone,
            'payerInfo.authorizationFax': req.body.authorizationFax,
//            'payerInfo.authorizingXContact': req.body.authorizingXContact,
            'payerInfo.authorizationOutcome': 'Approved',
            'payerInfo.payerAuthorizationDate': new Date(),
            'payerInfo.payerDeniedDate': null,
            'payerInfo.eligibilityDeterminedBy': this.authData.user._id
            }};
          } else {
            updates = { $set:{'payerInfo.pendingAuthorizationCode2': req.body.pendingAuthorizationCode,
            'payerInfo.approvedAuthorizationCode2': req.body.approvedAuthorizationCode,
//            'payerInfo.authorizingXContact2': req.body.authorizingXContact,
            'payerInfo.authorizationOutcome2': 'Approved',
            'payerInfo.payerAuthorizationDate2': new Date(),
            'payerInfo.payerDeniedDate2': null,
            'payerInfo.eligibilityDeterminedBy2': this.authData.user._id
            }};
          }
          if (req.body.notesEntry) {
            if (!updates['$push']) updates['$push'] = {};
            updates['$push']['notesLog'] = {author:this.authData.user.name, notes, category:'Payer Authorization'};
          }
          PatientCase.findOneAndUpdate({_id:patientCase._id}, updates, {new:true} )
          .then((result)=>{
            return WorkflowService.updateState( patientCase._id )
          })
          .then((result)=>{
            return NotificationService.createNotifications(patientCase._id, 'Payer Authorization Received')
          })
          .then((result)=>{
            RecentListService.add( this.authData.user._id, req.body.patientCaseId )
            res.json({success:true})
          })
        })
        .then(null, fail(res));
    } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });

    this.router.post("/pending", this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {
        PatientCase.findById( req.body.patientCaseId )
        .then((patientCase) => {
          var notes = req.body.notesEntry || 'Pending';
          if (req.body.pendingAuthorizationCode) {
            notes += '\nPending Authorization Code: '+req.body.pendingAuthorizationCode;
          }
          var updates = {};
          if (req.body.payerType=='Primary Payer') {
            updates = {$set:
              {'payerInfo.pendingAuthorizationCode': req.body.pendingAuthorizationCode/*,  
            'payerInfo.authorizingXContact': req.body.authorizingXContact*/}
              };
          } else {
            updates = {$set:
              {'payerInfo.pendingAuthorizationCode2': req.body.pendingAuthorizationCode/*,  
            'payerInfo.authorizingXContact2': req.body.authorizingXContact*/}
              };
          }
          updates['$push'] = {notesLog: {author:this.authData.user.name, content:notes, category:'Payer Authorization'}};
          PatientCase.findByIdAndUpdate( req.body.patientCaseId, updates)
          .then((result)=>{
            RecentListService.add( this.authData.user._id, req.body.patientCaseId )
            res.json({success:true})
          })
        })
        .then(null, fail(res));
    } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });

    this.router.post("/denied", this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {
        PatientCase.findById( req.body.patientCaseId )
        .then((patientCase) => {
          var notes = req.body.notesEntry || 'Denied';
          var updates = {};
          if (req.body.payerType=='Primary Payer') {
            updates = { $set:{
              'payerInfo.authorizationOutcome': 'Denied',
              'payerInfo.payerAuthorizationDate': null,
              'payerInfo.payerDeniedDate': new Date(),
              'payerInfo.eligibilityDeterminedBy': this.authData.user._id
              }};
          } else {
            updates = { $set:{
              'payerInfo.authorizationOutcome2': 'Denied',
              'payerInfo.payerAuthorizationDate2': null,
              'payerInfo.payerDeniedDate2': new Date(),
              'payerInfo.eligibilityDeterminedBy2': this.authData.user._id
            }};
          }
          updates['$push'] = {notesLog: {author:this.authData.user.name, content:notes, category:'Payer Authorization'}};
          PatientCase.findByIdAndUpdate( req.body.patientCaseId, updates )
          then((result)=>{
            return WorkflowService.updateState( patientCase._id )
          })
          .then((result)=>{
            return NotificationService.createNotifications(patientCase._id, 'Payer Authorization Denied')
          })
          .then((result)=>{
            RecentListService.add( this.authData.user._id, req.body.patientCaseId )
            res.json({success:true})
          })
        })
        .then(null, fail(res));
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });

    this.router.put("/:patientCaseId", this.authenticate(this.roles), (req, res) => {
      var self = this;
      if (this.getToken(req.headers)) {
        var updPatientCase = req.body.patientCase;
        var arrayFilters = [];
        self.logAuditData( 'PatientCase', req.params.patientCaseId, 'update', updPatientCase);
        PatientCase.findById( req.params.patientCaseId )
        .populate('primaryPayer.claimsPayer')
        .populate('secondaryPayer.claimsPayer')
        .then((patientCase) => {
          var setMap = {totalDueFromPatient:updPatientCase.totalDueFromPatient};
          var notes = [];
          var payerInfo = updPatientCase.payerInfo;
          if (!patientCase.payerInfo) patientCase.payerInfo = {};
          for (var attribute in payerInfo){
            if (payerInfo.hasOwnProperty(attribute) && attribute !== '_id') {
              if (patientCase.payerInfo[attribute] != payerInfo[attribute]) {
                setMap['payerInfo.'+attribute] = payerInfo[attribute];
              }
            }
          }
          if (updPatientCase.primaryPayer.contractedRate!=patientCase.primaryPayer.contractedRate) {
            setMap['primaryPayer.contractedRate'] = updPatientCase.primaryPayer.contractedRate;
          }
          var primaryPayerPaymentDue = !patientCase.paymentsDue ? {} :
            (patientCase.paymentsDue.find(pd=>(pd.payerType=='Primary Payer')) || {});
          var secondaryPayerPaymentDue = !patientCase.paymentsDue ? {} :
            (patientCase.paymentsDue.find(pd=>(pd.payerType=='Secondary Payer')) || {});
          var isPayor1AmtsEditable = (!patientCase.opReportUploaded || !safeRef(primaryPayerPaymentDue.transactions).length);
          var isPayor2AmtsEditable = 
            (!patientCase.opReportUploaded || (
                safeRef(secondaryPayerPaymentDue).payerType && !(secondaryPayerPaymentDue.transactions).length
              )
            );
          var primaryPayer = updPatientCase.primaryPayer;
          if (!patientCase.primaryPayer) patientCase.primaryPayer = {};
          if (safeRef(patientCase.primaryPayer.claimsPayer).id != safeRef(primaryPayer.claimsPayer)._id) {
            notes.push({author:this.authData.user.name, 
                        content:`Primary payer changed from ${safeRef(patientCase.primaryPayer.claimsPayer).name} to ${safeRef(primaryPayer.claimsPayer).name}`,
                        category:'Payer Info'});
            setMap['primaryPayer.claimsPayer'] = safeRef(primaryPayer.claimsPayer)._id || null;
            arrayFilters.push({'primaryPayer.payerType':'Primary Payer'});
            setMap['paymentsDue.$[primaryPayer].dateBillSent'] = null;
            setMap['paymentsDue.$[primaryPayer].arClockStartDate'] = null;
          }
          var nonAmtFlds = ['relationshipToPatient', 'insuredsFirstName', 'insuredsMiddleName', 'insuredsLastName', 'insuredsSSN',
              'insuredsDateOfBirth', 'healthPlanId', 'groupNumber', 'policyNumber', 'eligibilityDate'];
          var amtFlds = ['oopAmountIncludesDeductible', 'copayAmount', 'deductible', 'deductibleMet', 'benefitPercent',
              'outOfPocket', 'outOfPocketMet', 'totalDueFromPatient', 'expectedAmountOverride'];
          nonAmtFlds.forEach((f)=>{
            setMap['primaryPayer.'+f] = primaryPayer[f];
          });
          if (isPayor1AmtsEditable) {
            amtFlds.forEach(f=>{
              setMap['primaryPayer.'+f] = primaryPayer[f];
            });
          }
          if (safeRef(updPatientCase.primaryPayer).contractedRate!=safeRef(patientCase.primaryPayer).contractedRate) {
            setMap['primaryPayer.contractedRate'] = safeRef(updPatientCase.primaryPayer).contractedRate || '';
          }
          var secondaryPayer = updPatientCase.secondaryPayer;
          if (!patientCase.secondaryPayer) patientCase.secondaryPayer = {};
          if (safeRef(patientCase.secondaryPayer.claimsPayer).id != safeRef(secondaryPayer.claimsPayer)._id) {
            var note = '';
            if (!safeRef(patientCase.secondaryPayer.claimsPayer).id) {
              if (safeRef(secondaryPayer.claimsPayer)._id) {
                note = `Secondary payer set to ${safeRef(secondaryPayer.claimsPayer).name}`;
              }
            } else {
              note = `Secondary payer changed from ${safeRef(patientCase.secondaryPayer.claimsPayer).name} to ${safeRef(secondaryPayer.claimsPayer).name || 'blank'}`;
            }
            notes.push({author:this.authData.user.name, 
              content:note,
              category:'Payer Info'});
            setMap['secondaryPayer.claimsPayer'] = safeRef(secondaryPayer.claimsPayer)._id || null;
            arrayFilters.push({'secondaryPayer.payerType':'Primary Payer'});
            setMap['paymentsDue.$[secondaryPayer].dateBillSent'] = null;
            setMap['paymentsDue.$[secondaryPayer].arClockStartDate'] = null;
          }
          nonAmtFlds.forEach((f)=>{
            setMap['secondaryPayer.'+f] = secondaryPayer[f];
          });
          if (isPayor2AmtsEditable) {
            amtFlds.forEach(f=>{
              setMap['secondaryPayer.'+f] = secondaryPayer[f];
            });
          }
          if (safeRef(updPatientCase.secondaryPayer).contractedRate!=safeRef(patientCase.secondaryPayer).contractedRate) {
            setMap['secondaryPayer.contractedRate'] = safeRef(updPatientCase.secondaryPayer).contractedRate || '';
          }
          var patientPaymentDue = patientCase.paymentsDue.find(pd=>(pd.payerType=='Patient'));
          var paymentsMade = patientPaymentDue?patientPaymentDue.transactions.find(pd=>(pd.amount>0)):false;
/*          if (patientPaymentDue && !paymentsMade && updPatientCase.totalDueFromPatient==0) {
            update['$pull'] = {paymentsDue:{payerType:'Patient'}};
          }*/
          if (patientPaymentDue && updPatientCase.totalDueFromPatient != patientPaymentDue.amount) {
            if (updPatientCase.totalDueFromPatient>=0 ) {
              arrayFilters.push({'patientPayer.payerType':'Patient'});
              setMap['paymentsDue.$[patientPayer].amount'] = updPatientCase.totalDueFromPatient;
            }
          }
          var update = {};
          if (Object.keys(setMap).length>0) {
            update['$set'] = setMap;
          } else if (!req.body.notesEntry) {
            res.json({record:patientCase});
            return;
          }
          if (req.body.notesEntry) {
            notes.push({author:this.authData.user.name, content:req.body.notesEntry, category:'Payer Info'});
          }
          if (notes.length>0) {
            if (!update['$push']) update['$push'] = {};
            update['$push']['notesLog'] = { $each: notes };
          }

          PatientCase.findByIdAndUpdate(req.params.patientCaseId, update, arrayFilters.length>0?{arrayFilters:arrayFilters}:null )
          .then((result)=>{
            return WorkflowService.updateState( patientCase._id )
          })
          .then(()=>{
            if (req.body.sendCostEstimate) {
              NotificationService.createNotifications(patientCase._id, 'Payer Info Received' )
            }
            res.json({record:patientCase})
          })
        })
        .then(null, fail(res));
    } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });

    this.router.post("/", this.authenticate([Roles.ANY]), (req, res) => {
      if (this.getToken(req.headers)) {
        PatientCase.findById( req.body.patientCaseId )
        .populate({path:'primaryPayer.claimsPayer'})
        .populate({path:'primaryPayer.claimsPayer', populate:{path:'contacts'}})
//        .populate('primaryPayer.claimsxContact')
        .populate({path:'secondaryPayer.claimsPayer'})
        .populate({path:'secondaryPayer.claimsPayer', populate:{path:'contacts'}})
//        .populate('secondaryPayer.claimsxContact')
//        .populate({path:'payerInfo.authorizingPayer', populate:{path:'contacts'}})
//        .populate({path:'payerInfo.authorizingxContact'})
        .populate({path:'procedure', select: {name:1}})
        .populate({path:'patient', select: {'patientId':1, 'firstName':1, 'lastName':1, 'middleInitial':1, 'ssn':1, 'dateOfBirth':1,
                'contactInfo':1} })
        .then((patientCase) => {
          res.json(patientCase);
        })
        .then(null, fail(res));
    } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    return this.router;
  }
}

