import BaseAction from './baseaction'
import {ok, fail} from "../utils";
import Patient from '../../models/patient';
import Roles from '../../models/workflowroles'
import moment from "moment"

export class PatientSearch extends BaseAction{
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.FCM, Roles.Scheduler, Roles.AuthMgr, Roles.AP];
  }
  
  route() {
        //dateOfService, firstName, lastName
    this.router.post("/dupcheck", this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {
        var lowBnd = moment(req.body.dateOfBirth).startOf('day')
        var highBnd = moment(lowBnd).add(1, 'days')
        Patient.findOne({
          dateOfBirth: { $gte: lowBnd.toDate(), $lt: highBnd.toDate()},
          firstName: req.body.firstName,
          lastName: req.body.lastName,
        })
        .then((patient)=>{
          res.json(patient?{patientId:patient._id}:{});
        })
        .then(null, fail(res));
    } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    this.router.post("/", this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {
        var phrase = req.body.searchCriteria.phrase;
        var searchCriteria = {
          $or: [{ firstName: { $regex: phrase, $options: 'i'} },
            { lastName: { $regex: phrase, $options: 'i'} },
            { ssn: { $regex: phrase, $options: 'i'} },
            { 'contactInfo.phone': { $regex: phrase, $options: 'i'} },
            { 'contactInfo.email': { $regex: phrase, $options: 'i'} }]
        }
        if (req.body.searchCriteria.dateOfBirth) {
          var lowBnd = moment(req.body.searchCriteria.dateOfBirth).startOf('day');
          var highBnd = moment(lowBnd).add(1, 'days');
          searchCriteria.dateOfBirth = { $gte: lowBnd.toDate(), $lt: highBnd.toDate()};
        }
        Patient.find( searchCriteria )
        .then(ok(res))
        .then(null, fail(res));
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    return this.router;
  }
}
