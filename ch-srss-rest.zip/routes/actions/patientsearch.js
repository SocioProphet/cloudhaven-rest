import BaseAction from './baseaction'
import {ok, fail} from "../utils";
import Patient from '../../models/patient';
import Roles from '../../models/workflowroles'
import moment from "moment"
import mongoose, { Mongoose } from 'mongoose';

export class PatientSearch extends BaseAction{
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.FCM, Roles.Scheduler, Roles.AuthMgr, Roles.AP];
  }
  
  route() {
        //dateOfService, firstName, lastName
    this.router.post("/dupcheck", this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {
        var lowBnd = moment(req.body.dateOfBirth).startOf('day')
        var highBnd = moment(lowBnd).add(1, 'days')
        Patient.findOne({
          dateOfBirth: { $gte: lowBnd.toDate(), $lt: highBnd.toDate()},
          firstName: req.body.firstName,
          lastName: req.body.lastName,
        })
        .then((patient)=>{
          res.json(patient?{patientId:patient._id}:{});
        })
        .then(null, fail(res));
    } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    //searchCriteria: [cloudHavenUserIds]
    this.router.post("/", this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {
        var userIds = req.body.searchCriteria.userIds;
        Patient.find( {cloudHavenUserId: {$in:userIds}} )
        .then((patients)=>{
          res.json(patients);
        })
        .catch((err)=>{
          res.json({success:false, errMsg:err+''});
        });
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    return this.router;
  }
}
