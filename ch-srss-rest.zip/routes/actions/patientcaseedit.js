import BaseAction from './baseaction'
import {ok, fail} from "../utils";
import Roles from '../../models/workflowroles'
import mongoose from 'mongoose';
import moment from 'moment';
import PatientCase from '../../models/patientcase';
import AuditLog from '../../models/auditlog';
import PatientRecord from '../../models/patientrecord';
import RecentListService from '../../services/recentlistservice'
import CaseWorkflowAssignment from '../../models/caseworkflowassignment';
import NotificationService from '../../services/notificationservice'
import WorkflowService from '../../services/workflowservice'
import fileUpload from 'express-fileupload'

export class PatientCaseEdit extends BaseAction{
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.FCM, Roles.Scheduler, Roles.AR, Roles.AP];
  }
  
  route() {
   this.router.use(fileUpload());
   this.router.post("/attachfiles", this.authenticate(this.roles), (req, res) => {
    if (this.getToken(req.headers)) {
        try {
          //patientCaseId, opReportFile, deviceFee
          var patientCase = null;
          PatientCase.findById( req.body.patientCaseId)
          .then((pc)=>{
            patientCase = pc;
            var records = [];
            Object.keys(req.files).forEach(fKey=>{
              var file = req.files[fKey];
              records.push({ patient:patientCase.patient._id,
                name: file.name,
                fileName: file.name,
                mimeType: file.mimetype,
                body: file.data,
                isOpReport: false,
                patientCase: req.body.patientCaseId
              });
            });
            PatientRecord.insertMany(records)
            .then((result)=>{
//              RecentListService.add( this.authData.user._id, req.body.patientCaseId )
              res.json({success:true})
            })
          })
          .then(null, fail(res));
        } catch (e) {
          console.log(e);
        }
  } else {
      res.status(403).send({success: false, msg: 'Unauthorized.'});
    }
  });

 this.router.post("/records", this.authenticate(this.roles), (req, res) => {
    if (this.getToken(req.headers)) {
      var promises = [];
      if (req.body.operation) {
        if (req.body.operation == 'delete') {
          promises.push(PatientRecord.deleteOne({_id:mongoose.Types.ObjectId(req.body.id)}));
        } else if (req.body.operation == 'setopreport') {
          if (req.body.isOpReport) {
            promises.push(PatientRecord.updateMany(
              {patientCaseId:mongoose.Types.ObjectId(req.body.patientCaseId), _id: {$ne:mongoose.Types.ObjectId(req.body.id)}},
              {$set:{isOpReport:false}}
              ));
          }
          promises.push(PatientRecord.findByIdAndUpdate( req.body.id, {$set:{isOpReport:req.body.isOpReport}} ));
        }
      }
      mongoose.Promise.all(promises)
      .then(results=>{
        var searchCriteria = req.body.patientCaseId?{patientCase:req.body.patientCaseId}:{patient:req.body.patientId};
        PatientRecord.find(searchCriteria)
        .populate({path:'patient', select:{firstName:1, lastName:1, name:1}})
        .then(results=>{
          if (req.body.operation == 'delete' && req.body.patientCaseId && results.length==0) {
            PatientCase.findOneAndUpdate({_id:mongoose.Types.ObjectId(req.body.patientCaseId)}, {$set:{opReportUploaded:false}}, {new:true})
            .then((pc)=>{
              WorkflowService.updateState( req.body.patientCaseId )
              .then((result)=>{
                res.json(results);
              })
            })
          } else {
            res.json(results);
          }
        })
      })
      .then(null, fail(res));
    } else {
      res.status(403).send({success: false, msg: 'Unauthorized.'});
    }
  });
  this.router.get("/lookup/:caseId", this.authenticate(this.roles), (req, res) => {
    var self = this;
      if (this.getToken(req.headers)) {
        PatientCase.findOne({caseId:req.params.caseId}, {_id:1})
        .then(patientCase=>{
          if (!patientCase) {
            res.json({success: false, msg: `Case not found for ${req.params.caseId}`});
          } else {
            res.json({patientCaseId:patientCase.id})
          }
        })
        .then(null, fail(res));
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
  });
  this.router.get("/claimhistory/:caseId", this.authenticate(this.roles), (req, res) => {
    var self = this;
      if (this.getToken(req.headers)) {
        PatientCase.findOne({caseId:req.params.caseId}, {patient:1, procedure:1, 'primaryPayer.claimHistory':1, 'secondaryPayer.claimHistory':1})
        .populate('patient').populate('procedure')
        .then(patientCase=>{
          res.json({patientCase:patientCase})
        })
        .then(null, fail(res));
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
  });
  this.router.get("/:patientCaseId", this.authenticate(this.roles), (req, res) => {
    var self = this;
      if (this.getToken(req.headers)) {
        PatientCase.findById(req.params.patientCaseId)
          .populate({path:'primaryPayer.claimsPayer', select:'name', isSelfPayer:1})
//          .populate('primaryPayer.claimsxContact')
          .populate({path:'primaryPayer.claimsPayer', populate:{path:'procedures.procedure'}})
          .populate('secondaryPayer.claimsPayer')
//          .populate('secondaryPayer.claimsxContact')
//          .populate('payerInfo.authorizingPayer')
//          .populate('payerInfo.authorizingxContact')
          .populate('cptCode')
          .populate('icd10Code')
          .populate('patient')
          .populate({path:'vendorFees.vendor'})
          .populate({path: 'confirmations.vendor'})
          .populate({path: 'payables.vendor', select:{name:1}})
          .populate({path: 'payables.patient', select:{firstName:1, lastName: 1, name:1}})
          .populate({path:'procedure',  
                      populate: [{ path: 'cptCode', model:'CPT_Code'}, 
                                {path: 'diagnoses', model:'ICD10_Code'},
                                {path: 'procedureType', model: 'ProcedureType'},
                                {path: 'devices.vendor'}
                                ]
                    })
        .then(patientCase=>{
//          self.logAuditData( 'PatientCase', req.params.patientCaseId, 'read', patientCase);
          var hasSysAdminRole = true;//this.authData.user.roles.find(role=>(role==Roles.BMCSysAdmin))
          var searchCriteria = {patientCase:mongoose.Types.ObjectId(req.params.patientCaseId)};
          if (!hasSysAdminRole) {
            searchCriteria.role = {$in: this.authData.user.roles}
          }
          CaseWorkflowAssignment.find(searchCriteria)
          .then(workflowAssignments=>{
            res.json({patientCase:patientCase, workflowAssignments:workflowAssignments})
          })
        })
        .then(null, fail(res));
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    this.router.post("/updatepaymentdue", this.authenticate(this.roles), (req, res) => {
      var retPatientCase = null;
      if (this.getToken(req.headers)) {
        var updates = {};
        updates['paymentsDue.$[elem].amount'] = req.body.paymentDue.amount || null;
        updates['paymentsDue.$[elem].monthlyAmount'] = req.body.paymentDue.monthlyAmount || null;
        updates['paymentsDue.$[elem].dueDayOfMonth'] = req.body.paymentDue.dueDayOfMonth || null;
        updates['paymentsDue.$[elem].extensionDays'] = req.body.paymentDue.extensionDays || null;
        updates['paymentsDue.$[elem].dueDate'] = moment(req.body.paymentDue.dueDate).toDate() || null;
        updates['paymentsDue.$[elem].receivableAction'] = req.body.paymentDue.receivableAction || null;
      
        if (req.body.notesEntry) {
          updates['$push'] = {notesLog: {author:this.authData.user.name, content:req.body.notesEntry, category:`${req.body.paymentDue.payerType} Payments`}};
        }

        PatientCase.findOneAndUpdate(
          { _id:mongoose.Types.ObjectId(req.body.patientCaseId), status:'Open'},
          {$set:updates}, {new:true, arrayFilters: [{'elem.payerType':req.body.paymentDue.payerType}]})
          .then(patientCase=>{
            retPatientCase = patientCase;
            return WorkflowService.updateState( patientCase._id )
          })
          .then(result=>{
            res.json({success:true, patientCase:retPatientCase})
          })
        .then(null, fail(res));
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    this.router.post("/updatepaymentduetxn", this.authenticate(this.roles), (req, res) => {
      var retPatientCase = null;
      if (this.getToken(req.headers)) {
        var updates = {};
        updates['paymentsDue.$[pd].transactions.$[txn].txnDate'] = req.body.transaction.txnDate || null;
        updates['paymentsDue.$[pd].transactions.$[txn].amount'] = req.body.transaction.amount || 0;
        updates['paymentsDue.$[pd].transactions.$[txn].paymentMethod'] = req.body.transaction.paymentMethod || null;
        updates['paymentsDue.$[pd].transactions.$[txn].refCodeReason'] = req.body.transaction.refCodeReason || '';
      
/*        if (req.body.notesEntry) {
          updates['$push'] = {notesLog: {author:this.authData.user.name, content:req.body.notesEntry, category:`${req.body.paymentDue.payerType} Payments`}};
        }*/

        PatientCase.findOneAndUpdate(
          { _id:mongoose.Types.ObjectId(req.body.patientCaseId), status:'Open'},
          {$set:updates}, 
            {new:true, arrayFilters:
               [{'pd._id':req.body.paymentDueId},
                {'txn._id': req.body.transaction._id}
              ]})
        .then(patientCase=>{
          retPatientCase = patientCase;
          return WorkflowService.updateState( patientCase._id )
        })
        .then(result=>{
          res.json({success:true, patientCase:retPatientCase})
        })
        .then(null, fail(res));
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    
    this.router.post("/zeropaymentsdue", this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {
        PatientCase.findById(req.body.patientCaseId)
        .then(patientCase=>{
          var paymentDue = patientCase.paymentsDue.find(pd=>(pd._id==req.body.paymentDueId));
          var txn = {txnType: 'Adjustment', amount:paymentDue.currentAmountDue, txnDate:new Date(), refCodeReason:'Zero-out adjustment'};
          return PatientCase.findOneAndUpdate(
            { _id:mongoose.Types.ObjectId(req.body.patientCaseId), status:'Open'},
            {$push:{'paymentsDue.$[pd].transactions':txn}}, 
              {new:true, arrayFilters:[{'pd._id':req.body.paymentDueId}]})
        })
        .then(patientCase=>{
          res.json({success:true, paymentsDue:patientCase.paymentsDue})
        })
        .then(null, fail(res));
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    this.router.delete("/:patientCaseId", this.authenticate(this.roles), (req, res) => {
      if (!this.getToken(req.headers) || !((this.roles||[]).find(r=>(r==Roles.BMCSysAdmin))!=null)) {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      } else {
        mongoose.Promise.all([
          PatientCase.remove({_id:mongoose.Types.ObjectId(req.params.patientCaseId)}),
          AuditLog.remove({model:'PatientCase', recordId:req.params.patientCaseId}),
          CaseWorkflowAssignment.remove({patientCase:req.params.patientCaseId}),
          PatientRecord.remove({patientCase:req.params.patientCaseId})
        ])
        .then(results=>{
          res.json({success:true});
        })
      }
    });
    this.router.post("/cancel", this.authenticate(this.roles), (req, res) => {
      var wasBooked = false;
      if (this.getToken(req.headers)) {
        PatientCase.findById(req.body.patientCaseId, {calendarBooking:1})
        .then(patientCase=>{
          return patientCase.calendarBooking.status=='Booked';
        })
        .then(was_Booked=>{
          wasBooked = was_Booked;
          return PatientCase.findOneAndUpdate(
            { _id:mongoose.Types.ObjectId(req.body.patientCaseId),
              opReportUploaded:false,
              'paymentsDue.transactions.0':{$exists:false}
            }, {$set:{
              status:'Canceled',
              'calendarBooking.day':null,
              'calendarBooking.status':'Tentative',
              'paymentsDue.$[elem].dueDate':null}}, {new:true, arrayFilters: [{'elem.payerType':req.body.payerType}]})
        })
        .then(patientCase=>{
          if (patientCase && wasBooked && patientCase.status == 'Canceled') {
            res.json({success:true, status:patientCase.status});
            return WorkflowService.updateState( patientCase._id )
            .then(result=>{
              return NotificationService.createNotifications(patientCase._id, 'Case Canceled')
            })
          } else {
            res.json({success:false, status:patientCase?patientCase.status:''})
          }
        })
        .then(null, fail(res));
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    this.router.post("/reopen", this.authenticate(this.roles), (req, res) => {
      if (this.getToken(req.headers)) {
        PatientCase.findOneAndUpdate(
          { _id:mongoose.Types.ObjectId(req.body.patientCaseId)}, {$set:{status:'Open', confirmations:[]}}, {new:true})
        .then(patientCase=>{
          if (patientCase.status == 'Open') {
            NotificationService.createNotifications(patientCase._id, 'Case Reopened')
            .then(result=>{
              res.json({success:true, status:patientCase.status})
            })
          } else {
            res.json({success:false, status:patientCase.status})
          }
        })
        .then(null, fail(res));
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    return this.router;
  }
}
