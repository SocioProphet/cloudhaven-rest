import BaseAction from './baseaction'
import Roles from '../../models/workflowroles'
import ReportService from '../../services/reportservice'
import User from '../../models/user';
import {ok, fail} from "../utils"

export class Reports extends BaseAction{
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin];
  }

  route() {
    this.router.post("/avgrevpermonth", this.authenticate([Roles.BMCSysAdmin, Roles.FCM]), (req, res) => {
      if (this.getToken(req.headers)) {
        ReportService.avgRevenuePerMonth()
        .then((result)=>{
          res.json(result);
        })
        .then(null, fail(res));
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    this.router.post("/vendorapdaysoverdue", this.authenticate([Roles.BMCSysAdmin, Roles.AP], 'vendorapdaysoverdue report'), (req, res) => {
      if (this.getToken(req.headers)) {
        ReportService.vendorAPDaysOverdue( req.body.vendorId )
        .then((result)=>{
          res.json(result);
        })
        .then(null, fail(res));
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    this.router.get("/vendoragedap", this.authenticate([Roles.BMCSysAdmin, Roles.AP]), (req, res) => {
      if (this.getToken(req.headers)) {
        ReportService.vendorAgedAP()
        .then((result)=>{
          res.json(result);
        })
        .then(null, fail(res));
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    this.router.post("/tentativecases", this.authenticate([Roles.BMCSysAdmin, Roles.SCHEDULER]), (req, res) => {
      if (this.getToken(req.headers)) {
        ReportService.getTentativeCases( req.body.surgeonId )
        .then((result)=>{
          res.json(result);
        })
        .then(null, fail(res));
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    this.router.post("/overpayments", this.authenticate([Roles.BMCSysAdmin, Roles.FCM]), (req, res) => {  
      if (this.getToken(req.headers)) {
        ReportService.overPayments( req.body.startDate, req.body.endDate )
        .then((result)=>{
          res.json(result.sort((a,b)=>(a.txnDate<b.txnDate?1:(a.txnDate>b.txnDate?-1:0))));
        })
        .then(null, fail(res));
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    this.router.post("/receivedpayments", this.authenticate([Roles.BMCSysAdmin, Roles.AR, Roles.FCM]), (req, res) => {
      if (this.getToken(req.headers)) {
        ReportService.receivedPayments( req.body.date )
        .then((result)=>{
          res.json(result.sort((a,b)=>(a.txnDate<b.txnDate?1:(a.txnDate>b.txnDate?-1:0))));
        })
        .then(null, fail(res));
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    this.router.post("/totalcasesytd", this.authenticate([Roles.BMCSysAdmin, Roles.FCM]), (req, res) => {
      if (this.getToken(req.headers)) {
        ReportService.getTotalCasesYTD( req.body )
        .then((result)=>{
          res.json(result);
        })
        .then(null, fail(res));
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    this.router.post("/totalcasesmtd", this.authenticate([Roles.BMCSysAdmin, Roles.FCM]), (req, res) => {
      if (this.getToken(req.headers)) {
        ReportService.getTotalCasesMTD( req.body )
        .then((result)=>{
          res.json(result);
        })
        .then(null, fail(res));
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    this.router.post("/agedar", this.authenticate([Roles.BMCSysAdmin, Roles.AR]), (req, res) => {
      if (this.getToken(req.headers)) {
        ReportService.getAgedAR(req.body)
        .then((result)=>{
          res.json(result);
        })
        .then(null, fail(res));
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    this.router.post("/patientagedar", this.authenticate([Roles.BMCSysAdmin, Roles.AR]), (req, res) => {
      if (this.getToken(req.headers)) {
        ReportService.getPatientAgedAR(req.body)
        .then((result)=>{
          res.json(result);
        })
        .then(null, fail(res));
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    this.router.post("/monthlyvendor", this.authenticate([Roles.BMCSysAdmin, Roles.AP]), (req, res) => {
      if (this.getToken(req.headers)) {
        ReportService.doMonthlyVendorReport(req.body)
        .then((results)=>{
          res.json(results);
        })
        .then(null, fail(res));
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    return this.router;
  }
}
