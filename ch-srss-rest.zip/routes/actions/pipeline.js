import BaseAction from './baseaction'
import {fail} from "../utils"
import { safeRef } from '../../js/utils'
import {getVendorByOrgType} from "../../js/utils"
import PatientCase from '../../models/patientcase';
import CaseWorkflowAssignment from '../../models/caseworkflowassignment';
import Roles from '../../models/workflowroles'
import mongoose from 'mongoose';

export class Pipeline extends BaseAction{
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.FCM, Roles.Scheduler, Roles.AuthMgr, Roles.AR, Roles.AP];
  }
  
  route() {
    this.router.post("/", this.authenticate(this.roles, 'Pipeline list'), (req, res) => {
      if (this.getToken(req.headers)) {
        var assignmentMap = {};
        var searchCriteria = {}; //FIXME req.body.role == 'BMCSYSADMIN'?{}:{ role: req.body.role };
        CaseWorkflowAssignment.find( searchCriteria, { _id: 1, patientCase: 1, workflowState: 1})
        .then((assignments)=>{
          assignmentMap = assignments.reduce(function(mp,a){
            var patientCaseId = a.patientCase._id.toString();
            var list = mp[patientCaseId] || (mp[patientCaseId]=[]);
            list.push(a.workflowState);
            return mp;
          },{})
          PatientCase.find({ _id: { $in: assignments.map((a)=>a.patientCase._id)}, status:'Open'})
                  .populate({path:'procedure', select: 'name'})
                  .populate({path:'patient', select: ['name', 'firstName', 'lastName']})
                  .populate({path: 'vendorFees.vendor', select: {name:1, vendorType:1}})
                  .sort({'calendarBooking.day':1})
          .then((patientCases)=>{
            var retList = patientCases.map((c)=>({
              _id: c._id,
              caseId: c.caseId,
              procedure:c.procedure,
              patient:c.patient,
              surgeryCenter: getVendorByOrgType(c, 'Surgery Center'),
              dateOfService: c.calendarBooking?c.calendarBooking.day:'',
              workflowStates: assignmentMap[c._id.toString()]
            }))
            res.json(retList);
          })
        })
        .then(null, fail(res));
      } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    return this.router;
  }
}
