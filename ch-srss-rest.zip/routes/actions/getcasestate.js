import BaseAction from './baseaction'
import {ok, fail} from "../utils"
import { safeRef } from '../../js/utils'
import CaseWorkflowAssignment from '../../models/caseworkflowassignment'
import Roles from '../../models/workflowroles'
import mongoose from 'mongoose'

export class GetCaseState extends BaseAction{
  constructor(){
    super();
    this.roles = [Roles.BMCSysAdmin, Roles.FCM, Roles.Scheduler, Roles.AuthMgr, Roles.AP, Roles.AR];
  }
  
  route() {
    this.router.post("/", this.authenticate(this.roles, 'GetCaseState'), (req, res) => {
      if (this.getToken(req.headers)) {
        CaseWorkflowAssignment.find( {patientCase:mongoose.Types.ObjectId(req.body.patientCaseId)}, {workflowState:1, role:1} )
        .then((waList) => {
          res.json({roles: this.authData.user.roles, workflowStates:waList});
        })
        .then(null, fail(res));
    } else {
        res.status(403).send({success: false, msg: 'Unauthorized.'});
      }
    });
    return this.router;
  }
}

