# ssrs-admin-rest
Surgical Recovery Suites System REST Server
