import mongoose from "mongoose";
var Schema = mongoose.Schema;

var patientRecordSchema = new Schema( {
  OSC: { type: Schema.ObjectId, ref: 'OSCSetup'},
  patient: { type: Schema.ObjectId, ref: 'Patient' },
  name: { type: String, required: true },
  fileName: { type: String, required: true },
  mimeType: { type: String, required: true },
  body: { type: Buffer, required: true },
  isOpReport: Boolean,
  patientCase: { type: Schema.ObjectId, ref: 'PatientCase' }
});
export default mongoose.model( 'PatientRecord', patientRecordSchema );
