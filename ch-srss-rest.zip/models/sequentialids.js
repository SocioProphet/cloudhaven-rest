import mongoose from "mongoose";
import MongooseSequence from 'mongoose-sequence'
const AutoIncrement = MongooseSequence(mongoose);
var Schema = mongoose.Schema;

var sequentialIdSchema = new Schema( {
  domain: {type: String, required:true, enum:['Patient', 'Case']},
  seqNumber: Number
});
sequentialIdSchema.plugin(AutoIncrement, {id: 'seqId', inc_field:'seqNumber', reference_fields:['domain']})
export default mongoose.model( 'SequentialId', sequentialIdSchema );