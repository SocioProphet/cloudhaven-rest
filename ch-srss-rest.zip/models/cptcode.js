import mongoose from "mongoose"
var Schema = mongoose.Schema;

var cptCodeSchema = new Schema( {
    OSC: { type: Schema.ObjectId, ref: 'OSCSetup'},
    code: {type:String, required: true, unique: true, match: [ /^\d{5}(\-[A-Z0-9]{2})?$/, 'Please enter a valid CPT Code']},
    description: {type: String, required:false}
});
cptCodeSchema.set('toJSON', { getters: true, virtuals: true });

cptCodeSchema.virtual('name').get(function() {
    return this.code + ' - ' + this.description;
});

export default mongoose.model( 'CPT_Code', cptCodeSchema );