var mongoose = require("mongoose");
var Schema = mongoose.Schema;

var notificationRequestSchema = new Schema( {
  OSC: { type: Schema.ObjectId, ref: 'OSCSetup'},
  patientCase : { type: Schema.ObjectId, ref: 'PatientCase', required: true },
  notificationType : { type: String, required: true },
  vendor : { type: Schema.ObjectId, ref: 'Vendor', required: true },
  language: { type: String, required: true },
  email: { type: String, required: true },
  isAccepted: Boolean,
  responseDatetime: { type: Date },
  dayTrigger: Number,
  datetimeLastSent: { type: Date, default: Date.now }
});
export default mongoose.model( 'NotificationRequest', notificationRequestSchema );
