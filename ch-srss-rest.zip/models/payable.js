import mongoose from "mongoose"
import moment from 'moment'
var Schema = mongoose.Schema;


var payableSchema = new Schema( {
  patient: { type: Schema.ObjectId, ref: 'Patient' },
  payer: { type: Schema.ObjectId, ref: 'Payer' },
  vendor : { type: Schema.ObjectId, ref: 'Vendor' },
  amount: {type: Number, required: true, default: 0, min: 0 },
  additionalAmount: {type: Number, default: 0, min: 0 },
  allowEarlyPayment: { type: Boolean, default: false},
  apClockStartDate: Date,
  dueDate: Date,
  datePaid: Date,
  overdueNotificationSent: { type: Boolean, default: false},
  paymentRefNum: String
});
payableSchema.virtual('totalAmount').get(function () {
    var val = (this.amount||0)+(this.additionalAmount||0);
    return Number((val||0).toFixed(6))
});
payableSchema.virtual('daysToPay').get(function () {
    if (!this.datePaid || !this.apClockStartDate) return null;
    return moment(this.datePaid).diff(moment(this.apClockStartDate), 'days');
});
payableSchema.virtual('monthPaid').get(function () {
    return this.datePaid ? moment(this.datePaid).month() : null;
});
payableSchema.virtual('yearPaid').get(function () {
    return this.datePaid ? moment(this.datePaid).year() : null;
});
payableSchema.virtual('monthDue').get(function () {
    return this.dueDate ? moment(this.dueDate).month() : null;
});
payableSchema.virtual('yearDue').get(function () {
    return this.dueDate ? moment(this.dueDate).year() : null;
});
payableSchema.virtual('daysOverdue').get(function () {
    if (this.datePaid && this.dueDate && this.datePaid>this.dueDate) {
        return moment(this.datePaid).diff(moment(this.dueDate), 'days');
    }
    return 0;
});
payableSchema.virtual('paymentType').get(function () {
    return 'VND';
});
payableSchema.virtual('apBucket').get(function () {
    if (this.datePaid) return null;
    
    var daysDiff = moment(this.dueDate).diff( Date.now(), 'days');
    if (daysDiff >= 90) return '90+';
    if (daysDiff >= 60) return '60-90';
    if (daysDiff >= 30) return '30-60';
    if (daysDiff <30) return '0-30';
});
payableSchema.virtual('apAge').get(function () {
    var mDueDate = moment(this.dueDate);
    var mAgeDate = moment(this.datePaid ? this.datePaid : Date.now());
    return mAgeDate.diff(mDueDate, 'days');
});

payableSchema.path('paymentRefNum').validate(function( value ) {
    return (this.datePaid && !value);
}, 'Please enter a payment reference number.');

payableSchema.set('toJSON', { virtuals: true });
export default mongoose.model( 'Payable', payableSchema );