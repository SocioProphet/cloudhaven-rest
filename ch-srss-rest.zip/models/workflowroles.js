export default {
    ANY: "ANY",
    BMCSysAdmin: "BMCSYSADMIN",
    Scheduler: "SCHEDULER",
    FCM: "FCM",
    AuthMgr: "AUTHMGR",
    AR: "AR",
    AP: "AP",
    Vendor: "VENDOR",
    VendorAssociate: "VENDOR_ASSOCIATE",
    ContractedPayer: "CONTRACTED_PAYER",
    PrimaryClaimsPayer: "PRIMARY_CLAIMS_PAYER",
    SecondaryClaimsPayer: "SECONDARY_CLAIMS_PAYER",
    AuthorizingPayer: "AUTHORIZING_PAYER"
}
