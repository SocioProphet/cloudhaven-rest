import mongoose from "mongoose";
import MongooseSequence from 'mongoose-sequence'
const AutoIncrement = MongooseSequence(mongoose);
var Schema = mongoose.Schema;

var sequentialIdSchema = new Schema( {
  seqNumber: Number
});
sequentialIdSchema.plugin(AutoIncrement, {id: 'caseSeqId', inc_field:'seqNumber'})
export default mongoose.model( 'CaseSequentialId', sequentialIdSchema );