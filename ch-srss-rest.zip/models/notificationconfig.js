import Roles from './workflowroles'
import * as WorkflowStates from './workflowstates'

//orgTypes: Surgery Center, Surgeon, Recovery Suite, Device Maker, Supporting Resource
export const NotificationConfig = {
  'Tentatively Scheduled': [
    { entityType:'role', entities:['FCM'], notificationType:'Case Opened'}
  ],
  'Patient Refusal': [
    { entityType: 'role', entities:['SCHEDULER'], notificationType:'Patient Refused Payment Terms'}
  ],
  'Patient Accepted': [
    { entityType: 'role', entities:['SCHEDULER'], notificationType:'Patient Accepted Payment Terms'}
  ],
  'Case Reopened': [
    { entityType: 'orgtype', entities:['Surgery Center', 'Recovery Suite', 'Surgeon', 'Supporting Resource'], 
        notificationType:'Case Reopened'}
  ],
  'Case Canceled': [
    { entityType: 'orgtype', entities:['Surgery Center', 'Recovery Suite', 'Surgeon', 'Supporting Resource'], 
        notificationType:'Case Cancelation'}
  ],
  'Date of Service Booked': [
    { entityType: 'orgtype', entities:['Surgery Center', 'Recovery Suite', 'Surgeon', 'Supporting Resource'], 
        notificationType:'Surgical Appointment Confirmation', requiresResponse:true, daysTrigger:[-1,-7]}
  ],
/* not needed
  'Payer Authorization Denied': [],
  'Payer Authorization Received': [
    { entityType: 'orgtype', entities:['Surgery Center', 'Recovery Suite', 'Surgeon', 'Supporting Resource'], 
        notificationType:'Payer Authorization Received'},
    { entityType: 'role', entities:['SCHEDULER'], notificationType:'Payer Authorization Received'}
  ],*/
  'Patient Payment Received': [

  ],
  'Payer Payment Received': [

  ],
  'Payer Info Received': [
    { entityType: 'patient', notificationType:'Patient Cost Estimate'}
  ],
  'Surgery Completed': [
    { entityType: 'role', entities:['A/R', 'A/P'], notificationType:'Surgery Completed'}
  ]

}
    
    