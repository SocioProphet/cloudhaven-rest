import mongoose from "mongoose";
import Contact from './contact.js';
var Schema = mongoose.Schema;

var contactSchema = Contact.schema;

var patientSchema = new Schema ({
    OSC: { type: Schema.ObjectId, ref: 'OSCSetup'},
    isArchived: {type: Boolean, default:false},
    patientId: { type: String, required: [true, 'Patient Id is required.']}, //cloudHavenUserId
    cloudHavenUserId: String,
    firstName: { type: String },
    middleName: String,
    lastName: { type: String },
    ssn: { type: String, matches : /^\d{3}-?\d{2}-?\d{4}$/ },
    dateOfBirth: { type: Date },
    dateStatementLastPrinted: { type: Date },
    gender: { type: String, enums: ['Male', 'Female', 'Non-binary'] },
    contactInfo: contactSchema,
    notes: String
}, {timestamps:true});
patientSchema.virtual('name').get(function () {
    return this.firstName+' '+(this.middleName?(this.middleName+' '):'')+this.lastName;
});
patientSchema.virtual('nameLastFirst').get(function () {
    return this.lastName+', '+this.firstName+(this.middleName?(' '+this.middleName):'');
});
patientSchema.set('toJSON', { virtuals: true });
patientSchema.set('toObject', { virtuals: true });
export default mongoose.model( 'Patient', patientSchema );