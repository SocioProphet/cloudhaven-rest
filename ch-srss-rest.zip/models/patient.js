import mongoose from "mongoose";
import Contact from './contact.js';
var Schema = mongoose.Schema;

var contactSchema = Contact.schema;

var patientSchema = new Schema ({
    OSC: { type: Schema.ObjectId, ref: 'OSCSetup'},
    isArchived: {type: Boolean, default:false},
    patientId: { type: String, required: [true, 'Patient Id is required.']}, //FIXME - to be randomly generated, managed by patient id table
    firstName: { type: String, required: [true, 'First Name is required.'] },
    middleName: String,
    lastName: { type: String, required: [true, 'Last Name is required.'] },
    ssn: { type: String, matches : /^\d{3}-?\d{2}-?\d{4}$/ },
    dateOfBirth: { type: Date, required: [true, 'Date of Birth is required'] },
    dateStatementLastPrinted: { type: Date },
    gender: { type: String, enums: ['Male', 'Female', 'Non-binary'], required: [true, 'Gender is required.'] },
    contactInfo: contactSchema,
    notes: String
}, {timestamps:true});
/* FIXME
    index firstName unique: ['lastName', 'ssn', 'dateOfBirth']
    def afterInsert() {
        AnonymousPatient.withNewSession {
            new AnonymousPatient( encryptedPatientId: PatientRefUtil.encryptPatientId( id ) ).save( )
            patientIdManagerService.allocPatientId( this.id )
        }
    }
*/
patientSchema.virtual('name').get(function () {
    return this.firstName+' '+(this.middleName?(this.middleName+' '):'')+this.lastName;
});
patientSchema.virtual('nameLastFirst').get(function () {
    return this.lastName+', '+this.firstName+(this.middleName?(' '+this.middleName):'');
});
patientSchema.set('toJSON', { virtuals: true });
patientSchema.set('toObject', { virtuals: true });
export default mongoose.model( 'Patient', patientSchema );