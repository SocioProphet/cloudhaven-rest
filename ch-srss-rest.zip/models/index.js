console.log('Entering models/index.js...');
var models = [
'alert',
'payable',
'casepayerinfo',
'caseworkflowassignment',
'contact',
'cptcode',
'icd9code',
'medicaldataaccessaudit',
'notificationtype',
'patientrecord',
'paymentdue',
'procedure',
'procedurevendorfee',
'user',
'workflownotification',
'vendor',
'proceduretype',
'patient',
'patientcase',
'payer'/*,
'gra',
'bmc',
'ascorgdaycapacity'*/
];
for (var i=0;i<models.length;i++) {
    console.log('requiring '+models[i]);
    require('./'+models[i]+'.js');
}
