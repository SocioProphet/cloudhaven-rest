import mongoose from "mongoose";
var Schema = mongoose.Schema;

var Percent = "Percent";
var Fixed = "Fixed";

var vendorFeeSchema = new Schema( {
    description: {type:String, default:''},
    feeType: { type: String, enum: [Fixed, Percent], required: true},
    fixedFee: { type:Number, min: 0 },
    percentage: { type: Number, min: 0, max:100 },
    isRetired: { type: Boolean, default: false}
}, {timestamps:true});

/*FIXME        description nullable: true, maxSize: 80, validator: { val, obj, errors ->
            if (obj.vendor.vendorType == DeviceMaker) {
                if (!val) {
                    errors.rejectValue('description', 'vendorFee.description.missing', 'Please enter a value for Description (device model) when the Vendor type is Device Maker.')
                    return
                }
            }
*/
/*FIXME        percentage nullable: true, min: 0f, max: 100f, validator: { val, obj, errors ->
            if (obj.feeType == Percent) {
                if ((obj.percentage?:0.0)==0.0) {
                    errors.rejectValue('percentage', 'vendorFee.percentage.missing', 'Please enter a value for Percentage when the Fee Type is Percent.')
                    return
                }
            }
        }
  
        fixedFee validator: { val, obj, errors ->
            if (obj.feeType == Fixed) {
                if (!obj.fixedFee || obj.fixedFee==0.0) {
                    errors.rejectValue('fixedFee', 'vendorFee.fixedFee.missing', 'Please enter a Fixed Fee when the Fee Type is Fixed.')
                    return
                }
            }
        }
    }*/

vendorFeeSchema.set('toJSON', { virtuals: true });
export default mongoose.model( 'VendorFee', vendorFeeSchema );

