import mongoose from "mongoose"
import WorkflowRolesMap from './workflowroles.js'
var Schema = mongoose.Schema;

var allWorkflowRoles = Object.keys(WorkflowRolesMap).map((k)=>WorkflowRolesMap[k])
var caseWorkflowAssignmentSchema = new Schema( {
  OSC: { type: Schema.ObjectId, ref: 'OSCSetup'},
  patientCase: { type: Schema.ObjectId, ref: 'PatientCase', required: true },
  role: { type: String, required: true, enum:allWorkflowRoles },
  workflowState: { type: String, required: true }
}, {timestamps:true});
caseWorkflowAssignmentSchema.index( { "patientCase": 1, "role": 1, "workflowState": 1}, { "unique": true})
export default mongoose.model( 'CaseWorkflowAssignment', caseWorkflowAssignmentSchema );