import mongoose from "mongoose"
var Schema = mongoose.Schema;
var icd10CodeSchema = new Schema( {
    OSC: { type: Schema.ObjectId, ref: 'OSCSetup'},
    code: {type:String, required: true, unique: true, match: [ /^[A-TV-Z][0-9][A-Z0-9](\.?[A-Z0-9]{0,4})?$/, 'Please enter a valid ICD10 Code.']},
    description: {type: String, required:false}
});

icd10CodeSchema.virtual('name').get(function() {
    return this.code + ' - ' + this.description;
});
icd10CodeSchema.set('toJSON', { getters: true, virtuals: true });

export default mongoose.model( 'ICD10_Code', icd10CodeSchema );
