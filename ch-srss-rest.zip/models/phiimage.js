import mongoose from "mongoose"
var Schema = mongoose.Schema;

var PHI_ImageSchema = new Schema( {
    text: {type:String, required: true, unique: true},
    image: {type: Buffer, required:true}
});
export default mongoose.model( 'PHI_Image', PHI_ImageSchema );