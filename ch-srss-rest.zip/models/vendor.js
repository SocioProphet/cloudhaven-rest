import mongoose from "mongoose";
import Contact from'./contact.js';
import VendorFee from './vendorfee.js';
var Schema = mongoose.Schema;

var contactSchema = Contact.schema;
var vendorFeeSchema = VendorFee.schema;

var vendorSchema = new Schema( {
    OSC: { type: Schema.ObjectId, ref: 'OSCSetup'},
    name: { type: String, required: true, unique:true },
    nationalProviderIdentifier: String,
    lastName: String,
    firstName: String,
    vendorType: { type:'String', required: true },
    paymentTerms: {type: Number, min: 0, required: true },
    paymentTermsAndConditions: String,
    preferredPaymentMethod: {type: String, enum: ["Check", "Cash"] },
    dailyCapacity: {
        sunday: {type: Number, min: 0},
        monday: {type: Number, min: 0},
        tuesday: {type: Number, min: 0},
        wednesday: {type: Number, min: 0},
        thursday: {type: Number, min: 0},
        friday: {type: Number, min: 0},
        saturday: {type: Number, min: 0},
    },
    serviceDateCapacities: [{date:Date, capacity: Number}],
    dailyAvailability: {
        sunday: {type: Boolean},
        monday: {type: Boolean},
        tuesday: {type: Boolean},
        wednesday: {type: Boolean},
        thursday: {type: Boolean},
        friday: {type: Boolean},
        saturday: {type: Boolean},
    },
    availableServiceDates: [{date:Date}],
    nonServiceDates: [{date:Date}],
    subjectToInsPmtHold: Boolean,
    contacts: [ {
        name: { type: String, required: true },
        contactType: { type: String, enum: ['Primary', 'Associate'], required: true },
        hasLoginAccess: { type:Boolean, default:false },
        contactInfo: contactSchema
    } ],
    vendorFees: [vendorFeeSchema]
}, {timestamps:true});

export default mongoose.model( 'Vendor', vendorSchema );