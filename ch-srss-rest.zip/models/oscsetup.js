import mongoose from "mongoose"
var Schema = mongoose.Schema;

var emailMatch = [/^[^@]+@[^\.]+\..+$/, "Please fill a valid email address"];

//Outpatient Surgery Center Setup
var OSCSetupSchema = new Schema( {
  billingProvider: {
    name: String,
    NPI: String,
    contactFirstName: String,
    contactLastName: String,
    streetAddress: String,
    streetAddress2: String,
    city: String,
    stateOrProvince: String,
    postalCode: String,
    countryCode: String,
    phone: String,
    fax: String
  },
/*  payTo: {
    name: String,
    streetAddress: String,
    city: String,
    stateOrProvince: String,
    postalCode: String,
    countryCode: String
  },*/
  defaultFromEmail: {type:String, match: emailMatch },
  ccEmail: {type:String, match: emailMatch },
  typeOfBill: String,
  federalTaxNumber: String,
  taxonomyCode: {type: String, default: '207X00000X'},
  revenueCode: String,
  revenueDescription: String,
  operatingProvider: { NPI:String, lastName: String, firstName: String},
  patientSearchDateOfBirthRequired: { type:Boolean, default:false},
  vendorTypes:[ { type: String}],
  paymentMethods:[ { type: String}],
  ub04OffsetX: {type: Number, default: 0},
  ub04OffsetY: {type: Number, default: 0},
  ub04ScalingFactor: {type: Number, default: 1.0},
  emailSendFailing: { type:Boolean, default:false}
});
export default mongoose.model( 'OSCSetup', OSCSetupSchema );