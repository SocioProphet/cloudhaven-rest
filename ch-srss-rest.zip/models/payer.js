import mongoose from "mongoose";
var Schema = mongoose.Schema;

import PayerContact from './payercontact.js';
function safeRef(o) {
  try {
    return o?o:{};
  } catch (e) {
    return {};
  }
}

var payerContactSchema = PayerContact.schema

var phoneMatch = [ /^[+]?([\d]{0,3})?[\(\.\-\s]?([\d]{3})[\)\.\-\s]*([\d]{3})[\.\-\s]?([\d]{4})$/,
    "Please enter a valid phone number."];
var emailMatch = [/^[^@]+@[^\.]+\..+$/, 
    "Please fill a valid email address"];

var payerSchema = new Schema( {
  version: Number,
  OSC: { type: Schema.ObjectId, ref: 'OSCSetup'},
  name: {type: String, required: true, unique:true},
  phone: {type: String, match: phoneMatch },
  email: {type: String, match: emailMatch },
  fax: {type: String, match: phoneMatch },
  streetAddress: String,
  city: String,
  stateOrProvince: String,
  zipOrPostalCode: String,
  country: String,
  authorizationEmail: {type: String, match: emailMatch },
  isSelfPayer: {type: Boolean, default: false},
  tradingPartnerId: {type: String},
  clearinghouseName: String,
  supportsElectronicClaims: {type: Boolean, default: false},
  requiresEnrollment: {type: Boolean, default: false},
  paymentTerms: { type: Number, default: 31, min:0},
  contacts : [ { type: Schema.ObjectId, ref: 'PayerContact' } ],
  healthPlanIds: [{type:String}],
  additionalVendorTypes: [{type:String}],
  procedures: [{
    procedure:{ type: Schema.ObjectId, ref: 'Procedure' },
    contractedRate: { type: Number, default: 0.0, min: 0 }
  }],
  notes: String
}, {timestamps:true});
payerSchema.virtual('fullAddress').get(function () {
  var addressLines = [];
  if (this.streetAddress) addressLines.push(this.streetAddress);
  if (this.city || this.stateOrProvince || this.zipOrPostalCode) {
    addressLines.push(this.city+', '+this.stateOrProvince+'  '+this.zipOrPostalCode)
  }
  if (this.country) addressLines.push(this.country);
  return addressLines.join('\n');
});
export default mongoose.model( 'Payer', payerSchema );
