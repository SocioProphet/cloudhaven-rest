
var SurgeryCenter = "SurgeryCenter";
var Surgeon = "Surgeon";
var RecoverySuite = "RecoverySuite";
var DeviceMaker = "DeviceMaker";
var keyOrgTypes = [SurgeryCenter, Surgeon, RecoverySuite, DeviceMaker];

export default isKeyOrgType = function ( keyOrgType ) {
    return this.keyOrgTypes.indexOf( keyOrgType) > 0;
};

