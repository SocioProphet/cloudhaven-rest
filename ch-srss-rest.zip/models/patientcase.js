import mongoose from "mongoose";
var Schema = mongoose.Schema;

import moment from 'moment';

import PaymentDue from './paymentdue.js';
var paymentDueSchema = PaymentDue.schema;
import VendorFee from './vendorfee.js';
var vendorFeeSchema = VendorFee.schema;
var paymentDueSchema = PaymentDue.schema;
import Payable from './payable.js';
var payableSchema = Payable.schema;
import CasePayerInfo from './casepayerinfo.js';
var casePayerInfoSchema = CasePayerInfo.schema;
var StatusOpen = 'Open';
var StatusClosed = 'Closed';
var StatusCanceled = 'Canceled';
var StatusRefused = 'Refused';
var StatusPostponed = 'Postponed';
var statusValues = [StatusOpen, StatusClosed, StatusCanceled, StatusRefused, StatusPostponed];
var Approved = 'Approved';
var Denied = 'Denied';

var paymentDueSchema = mongoose.model('PaymentDue').schema;
var payableSchema = mongoose.model('Payable').schema;
var patientCaseSchema = new Schema(  {
    OSC: { type: Schema.ObjectId, ref: 'OSCSetup'},
    caseId: String,
    calendarBooking : {
        day: { type:Date},
        status: { type: String, enum: ['Tentative', 'Booked']}
    },
    hasRequiredResources: Boolean,
    insuredsName: { type: String },
    payerInfo: {
      authorizationContact: String,
      authorizationPhone: String,
      authorizationFax: String,
      authorizingPayer: { type: Schema.ObjectId, ref: 'Payer' },
      authorizingContact: { type: Schema.ObjectId, ref: 'PayerContact' },
      authorizingContact2: { type: Schema.ObjectId, ref: 'PayerContact' },
      miscPatientAmountDue: { type: Number, default: 0.0, min: 0 },
      miscPatientAmountDueReason: String,
      pendingAuthorizationCode: String,
      approvedAuthorizationCode: String,
      authorizationOutcome: { type: String, enum: [Approved, Denied] },
      payerAuthorizationDate: Date,
      payerDeniedDate: Date,
      eligibilityDeterminedBy: { type: Schema.ObjectId, ref: 'User' },
      pendingAuthorizationCode2: String,
      approvedAuthorizationCode2: String,
      authorizationOutcome2: { type: String, enum: [Approved, Denied] },
      payerAuthorizationDate2: Date,
      payerDeniedDate2: Date,
      eligibilityDeterminedBy2: { type: Schema.ObjectId, ref: 'User' }
    },
    totalDueFromPatient: { type: Number, default: 0.0, min: 0 },
    primaryPayer: casePayerInfoSchema,
    secondaryPayer: casePayerInfoSchema,

    patient: { type: Schema.ObjectId, ref: 'Patient'},
    procedure: { type: Schema.ObjectId, ref: 'Procedure', required: true },
    totalCharges: { type: Number},
    cptCode: { type: Schema.ObjectId, ref: 'CPT_Code', required: true },
    icd10Code: { type: Schema.ObjectId, ref: 'ICD10_Code', required: true },
    paymentMethod: { type: String, enum: ['Insurance', 'Cash'], required: true},
    vendorFees:[{
        vendor: { type: Schema.ObjectId, ref: 'Vendor' },
        fee:vendorFeeSchema
    }],
    requiredVendorTypes:[String],
    confirmations:[{
        vendor: { type: Schema.ObjectId, ref: 'Vendor'},
        datetime: { type: Date, default: Date.now }
    }],
    opReportUploaded: { type: Boolean, default: false},
    datePreopReportReceived: { type: Date},
    status: {type: String, enum: statusValues, default: StatusOpen },
    dateClosed: Date,
    patientTermsAcceptanceDate: Date,
    paymentsDue: [paymentDueSchema],
    deviceAdditionalCost: Number,
    deviceAddlCostReason: String,
    payables: [payableSchema],
    notesLog: [{category: {type:String, enum:['Case', 'Payer Info', 'Payer Authorization', 'Patient Payments', 'Primary Payer Payments', 'Secondary Payer Payments', 'Complete Surgery']},
                    content:String, datetime: {type:Date, default: Date.now}, author: String}],
    claimUploadLog: [{ datetime: { type:Date, default: Date.now, required:true }, contents: String}],
    alerts: [{ datetime: { type:Date, default: Date.now, required:true }, contents: String, dismissed:Boolean, author: String}]
}, {timestamps:true});

patientCaseSchema.virtual('vendorList').get(function(){
    return this.vendorFees.reduce(function(s,vf){
        if (s) s+='<br/>'
        s += vf.vendor.name;
        return s;
    },'');
});
patientCaseSchema.virtual('isOpen').get(function () {
    return this.status == 'Open';
});

patientCaseSchema.virtual('isSurgeryCompleted').get(function () {
    return this.opReportUploaded;
});

patientCaseSchema.virtual('treatmentCost').get(function () {
    if (!this.paymentsDue) return 0.0;
    var val = this.paymentsDue.reduce( function( m, p){ return m + p.amount; }, 0 );
    return Number((val||0).toFixed(6));
});

patientCaseSchema.virtual('totalDue').get(function () {
    if (!this.paymentsDue) return 0.0;
    var val = this.paymentsDue.reduce( function( m, p){ return m + p.currentAmountDue; }, 0 );
    return Number((val||0).toFixed(6));
});

patientCaseSchema.virtual('patientAmount').get(function () {
    if (!this.paymentsDue) return 0.0;
    var val = this.paymentsDue.filter(function( payment) { return payment.payerType == 'Patient'; } )
        .reduce(function( m, p){ return m + p.amount; }, 0 );
    return Number((val||0).toFixed(6))
});
/*patientCaseSchema.virtual('patientAmountNotBilled').get(function () {
    if (!this.paymentsDue) return 0.0;
    return this.paymentsDue.filter(function( pmt) { return pmt.payerType == 'Patient' && !pmt.dateBillSent; } )
        .reduce(function( m, p){ return m + p.currentAmountDue; }, 0 );
});*/

patientCaseSchema.virtual('patientAmountDue').get(function () {
    if (!this.paymentsDue) return 0.0;
    var val = this.paymentsDue.filter(function( pmt) { return pmt.payerType == 'Patient' /*&& pmt.dateBillSent;*/ } )
        .reduce(function( m, p){ return m + p.currentAmountDue; }, 0 );
    return Number((val||0).toFixed(6))
});

patientCaseSchema.virtual('patientAmountReceived').get(function () {
    if (!this.paymentsDue) return 0.0;
    var val = this.paymentsDue.filter(function( pmt) { return pmt.payerType == 'Patient' /*&& !pmt.dateBillSent;*/ } )
        .reduce(function( m, p){ return m + p.receivedAmount; }, 0 );
    return Number((val||0).toFixed(6))
 });
    
patientCaseSchema.virtual('payerAmountNotBilled').get(function () {
    if (!this.paymentsDue) return 0.0;
    var val =  this.paymentsDue.filter(function( pmt) { return pmt.payerType.indexOf('Payer')>0 && !pmt.dateBillSent; } )
        .reduce(function( m, p){ return m + p.currentAmountDue; }, 0 );
    return Number((val||0).toFixed(6))
});

patientCaseSchema.virtual('payerAmountDue').get(function () {
    if (!this.paymentsDue) return 0.0;
    var val = this.paymentsDue.filter(function( pmt) { return pmt.payerType.indexOf('Payer')>0 && pmt.dateBillSent; } )
        .reduce(function( m, p){ return m + p.currentAmountDue; }, 0 );
    return Number((val||0).toFixed(6))
});
    
patientCaseSchema.virtual('primaryPayerAmountNotBilled').get(function () {
    if (!this.paymentsDue) return 0.0;
    var val = this.paymentsDue.filter(function( pmt) { return pmt.payerType == 'Primary Payer' && !pmt.dateBillSent; } )
        .reduce(function( m, p){ return m + p.currentAmountDue; }, 0 );
    return Number((val||0).toFixed(6))
});

patientCaseSchema.virtual('primaryPayerAmountDue').get(function () {
    if (!this.paymentsDue) return 0.0;
    var val = this.paymentsDue.filter(function( pmt) { return pmt.payerType == 'Primary Payer' && pmt.dateBillSent; } )
        .reduce(function( m, p){ return m + p.currentAmountDue; }, 0 );
    return Number((val||0).toFixed(6))
});
    
patientCaseSchema.virtual('primaryPayerAmount').get(function () {
    if (!this.paymentsDue) return 0.0;
    var val = this.paymentsDue.filter(function( pmt) { return pmt.payerType == 'Primary Payer'; } )
        .reduce(function( m, p){ return m + p.amount; }, 0 );
    return Number((val||0).toFixed(6))
});
    
patientCaseSchema.virtual('primaryPayerAmountReceived').get(function () {
    if (!this.paymentsDue) return 0.0;
    var val = this.paymentsDue.filter(function( pmt) { return pmt.payerType == 'Primary Payer' /*&& !pmt.dateBillSent;*/ } )
        .reduce(function( m, p){ return m + p.receivedAmount; }, 0 );
    return Number((val||0).toFixed(6))
});

patientCaseSchema.virtual('secondaryPayerAmountNotBilled').get(function () {
    if (!this.paymentsDue) return 0.0;
    var val = this.paymentsDue.filter(function( pmt) { return pmt.payerType == 'Secondary Payer' && !pmt.dateBillSent; } )
        .reduce(function( m, p){ return m + p.currentAmountDue; }, 0 );
    return Number((val||0).toFixed(6))
});

patientCaseSchema.virtual('secondaryPayerAmountDue').get(function () {
    if (!this.paymentsDue) return 0.0;
    var val = this.paymentsDue.filter(function( pmt) { return pmt.payerType == 'Secondary Payer' && pmt.dateBillSent; } )
        .reduce(function( m, p){ return m + p.currentAmountDue; }, 0 );
    return Number((val||0).toFixed(6))
});
    
patientCaseSchema.virtual('secondaryPayerAmount').get(function () {
    if (!this.paymentsDue) return 0.0;
    var val = this.paymentsDue.filter(function( pmt) { return pmt.payerType == 'Secondary Payer'; } )
        .reduce(function( m, p){ return m + p.amount; }, 0 );
    return Number((val||0).toFixed(6))
});
    
patientCaseSchema.virtual('secondaryPayerAmountReceived').get(function () {
    if (!this.paymentsDue) return 0.0;
    var val = this.paymentsDue.filter(function( pmt) { return pmt.payerType == 'Secondary Payer' /*&& !pmt.dateBillSent;*/ } )
        .reduce(function( m, p){ return m + p.receivedAmount; }, 0 );
    return Number((val||0).toFixed(6))
});

patientCaseSchema.virtual('expense').get(function () {
    if (!this.payables) return 0.0;
    var val = this.payables.reduce( function( m, vd){ return m + vd.amount; }, 0 );
    return Number((val||0).toFixed(6))
});
patientCaseSchema.virtual('payableAmountOwed').get(function () {
    if (!this.payables) return 0.0;
    var val = this.payables.filter(function( vd) { return !vd.datePaid; } )
        .reduce(function( m, vd){ return m + vd.amount; }, 0 );
    return Number((val||0).toFixed(6))
});

patientCaseSchema.virtual('payableAmountPayable').get(function () {
    if (!this.payables) return 0.0;
    var val = this.payables.filter(function( vd) { return vd.apClockStartDate && !vd.datePaid; } )
        .reduce(function( m, vd){ return m + vd.amount; }, 0 );
    return Number((val||0).toFixed(6))
});

patientCaseSchema.virtual('monthClosed').get(function () {
    return this.dateClosed ? moment(this.dateClosed).month() : null;
});
patientCaseSchema.virtual('yearClosed').get(function () {
    return this.dateClosed ? moment(this.dateClosed).year() : null;
});

patientCaseSchema.virtual('netRevenue').get(function () {
    var val = this.treatmentCost - this.expense;
    return Number((val||0).toFixed(6))
});
patientCaseSchema.virtual('daysUntilProcedure').get(function () {
    if (!this.calendarBooking) return null;
    var today = moment().startOf('day');
    return moment(this.calendarBooking.day).startOf('day').diff(today, 'days');
});
patientCaseSchema.virtual('dayOfMonth').get(function () {
    if (!this.calendarBooking) return null;
    return moment(this.calendarBooking.day).date();
});
patientCaseSchema.virtual('dayofyear').get(function () {
    if (!this.calendarBooking) return null;
    return moment(this.calendarBooking.day).dayOfYear();
});
patientCaseSchema.virtual('week').get(function () {
    if (!this.calendarBooking) return null;
    return moment(this.calendarBooking.day).week();
});
patientCaseSchema.virtual('month').get(function () {
    if (!this.calendarBooking) return null;
    return moment(this.calendarBooking.day).month();
});
patientCaseSchema.virtual('year').get(function () {
    if (!this.calendarBooking) return null;
    return moment(this.calendarBooking.day).year();
});
patientCaseSchema.set('toJSON', { virtuals: true });
patientCaseSchema.set('toObject', { virtuals: true })
export default mongoose.model( 'PatientCase', patientCaseSchema );
