import mongoose from "mongoose"
var Schema = mongoose.Schema;

var DailyVendorNotification = "Daily Vendor Notification";
var VendorPaid = "Vendor Paid";
var VendorMonthlyDigest = "Vendor Monthly Digest";
var emailMatch = [/^[^@]+@[^\.]+\..+$/, "Please fill a valid email address"];

var notificationTypeSchema = new Schema( {
  OSC: { type: Schema.ObjectId, ref: 'OSCSetup'},
  name: { type: String, required: true, unique:true},
  subject: { type: String, required: false},
  language: { type: String, enum:['English', 'Spanish'], required: true},
  fromEmail: { type: String, match: emailMatch },
  content: String
});
export default mongoose.model( 'NotificationType', notificationTypeSchema );

