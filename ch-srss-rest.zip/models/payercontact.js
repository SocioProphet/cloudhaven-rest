import mongoose from "mongoose";
var Schema = mongoose.Schema;
var contactSchema = mongoose.model('Contact').schema;

var Claims = "Claims"
var PreAuth = "Pre-authorization"
var Benefits = "Benefits and Eligibility"
var AR = "A/R"
var AP = "A/P"

var payerContactSchema = new Schema ({
  name: { type: String},
  contactType: { type: String, enum: [Claims, PreAuth, Benefits, AR, AP], required: true },
  isPrimary: { type: Boolean, default: false },
  contactInfo: contactSchema
});
payerContactSchema.virtual('label').get(function () {
  return this.name?this.name:this.contactType;
});
payerContactSchema.set('toJSON', { virtuals: true });
export default mongoose.model( 'PayerContact', payerContactSchema );