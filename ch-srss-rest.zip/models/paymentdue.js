import mongoose from "mongoose";
var Schema = mongoose.Schema;

import moment from 'moment';

var paymentDueTxnSchema = new Schema( {
    txnType: { type: String, enum: ['Payment', 'Adjustment'], required: true },
    txnDate: {type: Date, default: Date.now, required: true },
    amount: {type: Number, required: true },
    paymentMethod: String,
    refCodeReason: { type: String, required: true}
});

paymentDueTxnSchema.virtual('dayOfMonth').get(function () {
    return moment(txnDate).date(Number);
});
paymentDueTxnSchema.virtual('dayofyear').get(function () {
    return moment(txnDate).dayOfYear(Number);
});
paymentDueTxnSchema.virtual('month').get(function () {
    return moment(txnDate).month(Number);
});
paymentDueTxnSchema.virtual('year').get(function () {
    return moment(txnDate).year(Number);
});

var paymentDueSchema = new Schema({
    payerType: {type: String, enum: ['Patient', 'PrimaryPayer', 'SecondaryPayer'], required: true },
    amount: {type: Number, default: 0, min: 0, required: true},
    originalDueDate: Date,
    dueDate: Date,
    receivableAction: {type: String, enum: ['Extend Due Date', 'Monthly Payment Plan', 'Written Off', 'Sent to Collections']},
    monthlyAmount: {type: Number, default: 0, min: 0},
    dueDayOfMonth: {type: Number, min: 1, max: 28},
    creditCardOnFile: Boolean,
    promissoryNoteSigned: Boolean,
    extensionDays: {type: Number, min: 0},
    dateBillSent: Date,
    arClockStartDate: Date,
    transactions: [paymentDueTxnSchema]
}, {timestamps:true});
paymentDueSchema.virtual('hasPaymentPlan').get(function () {
    return this.receivableAction == 'Monthly Payment Plan';
});
paymentDueSchema.virtual('overpayment').get(function () {
    var adjustmentTotal = this.transactions.reduce(function(total, payment) {
        if (payment.txnType == 'Adjustment') total += payment.amount;
        return total;
    }, 0.0);
    var paymentDue = this.amount - adjustmentTotal;
    var paymentTotal = this.transactions.reduce(function(total, payment) {
        if (payment.txnType == 'Payment') total += payment.amount;
        return total;
    }, 0.0);
    var overpayment = Number((paymentTotal - paymentDue||0).toFixed(6));
    return overpayment>0?overpayment:0;
});
paymentDueSchema.virtual('datePaidInFull').get(function () {
//    var currentAmountDue = (this.amount - this.adjustmentAmount) - this.receivedAmount;
    var currentAmountDue = this.amount;
    var latestDate = null;
    this.transactions
        .sort((a,b)=>(a.txnDate<b.txnDate?-1:(a.txnDate>b.txnDate?1:0)))
        .forEach((txn)=>{
        currentAmountDue -= txn.amount;
        currentAmountDue = Number(currentAmountDue.toFixed(6));
        if (currentAmountDue <= 0.0 && !latestDate) latestDate = txn.txnDate;
      });
    return latestDate;
});
paymentDueSchema.virtual('lastAdjustmentDate').get(function () {
    return this.transactions.reduce((latestDate, txn)=>{
        if ((!latestDate || txn.txnDate>latestDate) && txn.txnType=='Adjustment') latestDate = txn.txnDate;
        return latestDate;
      },null);
});
paymentDueSchema.virtual('adjustments').get(function () {
    return this.transactions.filter(function(payment) { return payment.txnType == 'Adjustment'; });
});
paymentDueSchema.virtual('receivedPayments').get(function () {
    return this.transactions.filter(function(payment) { return payment.txnType == 'Payment'; });
});
paymentDueSchema.virtual('receivedAmount').get(function () {
    return this.receivedPayments.reduce(function( subTotal, payment) { return subTotal + payment.amount; }, 0 ); 
});
paymentDueSchema.virtual('adjustmentAmount').get(function () {
    return this.adjustments.reduce(function( subTotal, adjustment) { return subTotal + adjustment.amount; }, 0 );
});
paymentDueSchema.virtual('currentAmountDue').get(function () {
    if (this.receivableAction == 'Written Off'/* || this.receivableAction == 'Sent to Collections'*/) return 0;
    var val = (this.amount - this.adjustmentAmount) - this.receivedAmount;
    return Number((val||0).toFixed(6))
});
paymentDueSchema.virtual('totalAmountDue').get(function () {
    var val = (this.amount - this.adjustmentAmount);
    return Number((val||0).toFixed(6))
});
paymentDueSchema.virtual('arBucketNum').get(function () {
    if (this.datePaidInFull || !this.dueDate) return null;
    var today = moment(Date.now());
    
    if (today.isSameOrBefore(this.dueDate, 'day')) {
        return 0;
    } else {
        var daysDiff = moment(today).diff( this.dueDate, 'days');
        if (daysDiff <= 30) return 1;
        if (daysDiff <= 60) return 2;
        if (daysDiff <= 90) return 3;
        if (daysDiff <= 120) return 4;
        else return 5;
    }
});
paymentDueSchema.virtual('arBucket').get(function () {
  if (this.datePaidInFull || !this.dueDate) return null;
  return ['Current', '1-30 days past due', '31-60 days past due', '61-90 days past due', '91-120 days past due'][this.arBucketNum];
});
paymentDueSchema.virtual('arAge').get(function () {
  if (this.datePaidInFull || !this.dueDate) return null;
  var today = moment(Date.now());
  if (today.isSameOrBefore(this.dueDate, 'day')) {
    return 0;
  } else {
      return moment(today).diff( this.dueDate, 'days');
  }
});

paymentDueSchema.path('transactions').validate(function( value ) {
    return (this.currentAmountDue >= 0);
}, 'The current amount due cannot be negative.');

paymentDueSchema.set('toJSON', { virtuals: true });
paymentDueSchema.set('toObject', { virtuals: true });
export default mongoose.model( 'PaymentDue', paymentDueSchema );