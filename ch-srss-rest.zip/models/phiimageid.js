import mongoose from "mongoose"
var Schema = mongoose.Schema;
import PHI_Image from './phiimage.js';

var PHI_ImageIdSchema = new Schema( {
    image: { type: Schema.ObjectId, ref: PHI_Image.modelName }
}, {timestamps:true});
export default mongoose.model( 'PHI_ImageId', PHI_ImageIdSchema );