export const NeedsTentativeScheduling = "Needs Tentative Scheduling"
export const PayerInfoRequired = "Payer Info Required";
export const NeedPatientTermsAccept = "Need Patient Acceptance";
export const BookConfirmedDate = "Book Confirmed Date";
export const InsuranceAuthRequired = "Need Payer Authorization";
export const Insurance2AuthRequired = "Need Secondary Payer Authorization";
export const BillPatient = "Bill Patient";
export const PatientPaymentDue = "Patient Payment Due";
export const AwaitingSurgery = "Awaiting Surgery";
export const DisbursePayments = "Disburse Payments";
export const BillPrimaryPayer = "Bill Primary Payer";
export const PrimaryPayerPaymentDue = "Primary Payer Payment Due";
export const BillSecondaryPayer = "Bill Secondary Payer";
export const SecondaryPayerPaymentDue = "Secondary Payer Payment Due";

export  const allWorkflowStates = [
    NeedsTentativeScheduling, PayerInfoRequired,
    NeedPatientTermsAccept, BookConfirmedDate, InsuranceAuthRequired, Insurance2AuthRequired,
    BillPatient, PatientPaymentDue, AwaitingSurgery,
    DisbursePayments, BillPrimaryPayer, PrimaryPayerPaymentDue,
    BillSecondaryPayer, SecondaryPayerPaymentDue ];
