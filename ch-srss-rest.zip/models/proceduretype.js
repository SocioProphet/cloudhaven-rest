import mongoose from "mongoose";
var Schema = mongoose.Schema;

var procedureTypeSchema = new Schema( {
    name: { type: String, required: true, unique: true },
    vendorTypes: [{ type: 'String' }]/*,
    deviceTypes : [{ type: Schema.ObjectId, ref: 'DeviceType' }]*/
});

export default mongoose.model( 'ProcedureType', procedureTypeSchema );
