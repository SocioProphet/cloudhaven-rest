import mongoose from "mongoose";
var Schema = mongoose.Schema;

var procedureSchema = new Schema( {
    OSC: { type: Schema.ObjectId, ref: 'OSCSetup'},
    isPublished: { type: Boolean },
    name: { type: String, required: true},
    shortName: { type: String, required: true },
    procedureType: { type: Schema.ObjectId, ref: 'ProcedureType', required: true },
    cptCode: { type: Schema.ObjectId, ref: 'CPT_Code' },
    diagnoses: [{ type: Schema.ObjectId, ref: 'ICD10_Code' }],
    devices: [{vendor: { type: Schema.ObjectId, ref: 'Vendor' },
               vendorFeeId: String}],
    totalCharges: { type: Number, default: 0.0, min: 0, required: true }
    
}, {timestamps:true});

export default mongoose.model( 'Procedure', procedureSchema );