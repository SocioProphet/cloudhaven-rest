var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var bcrypt = require('bcryptjs');

var KPIS = 'KPIS';
var PIPELINE = 'PIPELINE';
var DISBURSEMENTS = 'DISBURSEMENTS';
var NONE = 'NONE';

var emailMatch = [/^[^@]+@[^\.]+\..+$/, "Please fill a valid email address"];

var UserSchema = new Schema({
  OSC: { type: Schema.ObjectId, ref: 'OSCSetup'},
  email: {
        type: String,
        unique: true,
        required: true,
        match: emailMatch
  },
  password: {
        type: String,
        required: true
  },
  name: String,
  kpis: [{ type: String} ],
  recentCases: [{ type: Schema.ObjectId, ref: 'PatientCase' }],
/*  alerts: [ {
    patientCase: { type: Schema.ObjectId, ref: 'PatientCase' },
    patientName: { type:String, required: true },
    subject: { type:String, required: true },
    content: { type:String, required: true },
    dismissed: {type: Boolean, default: false, required: true},
    dateCreated: { type: Date, default: Date.now }
  }],*/
  language: { type: String, required: true, enum: ['English', 'Spanish'], default:'English' },
  roles: [{type:String}],
  vendor: { type:Schema.ObjectId, ref:'Vendor', required: false },
  contactId: String
});

UserSchema.pre('save', function (next) {
    var user = this;
    if (this.isModified('password') || this.isNew) {
        bcrypt.genSalt(10, function (err, salt) {
            if (err) {
                return next(err);
            }
            bcrypt.hash(user.password, salt, function (err, hash) {
                if (err) {
                    return next(err);
                }
                user.password = hash;
                next();
            });
        });
    } else {
        return next();
    }
});

UserSchema.methods.comparePassword = function (passw, cb) {
    bcrypt.compare(passw, this.password, function (err, isMatch) {
        if (err) {
            return cb(err);
        }
        cb(null, isMatch);
    });
};

module.exports = mongoose.model('User', UserSchema);