import mongoose from "mongoose"
var Schema = mongoose.Schema;

var casePayerInfoSchema = new Schema ( {
    claimsPayer: { type: Schema.ObjectId, ref: 'Payer' },
    contractedRate: {type: Number, min: 0},
//    claimsXContact: { type: Schema.ObjectId, ref: 'PayerXContact' },
    relationshipToPatient: {type: String, enum:["Self","Parent", "Spouse", "Partner", "Guardian", "Employer"] },
    insuredsFirstName: String,
    insuredsMiddleName: String,
    insuredsLastName: String,
    insuredsSSN: { type: String, matches : /^\d{3}-?\d{2}-?\d{4}$/ },
    insuredsDateOfBirth: { type: Date },
    healthPlanId: String,
    groupNumber: String,
    policyNumber: { type: String },
    eligibilityDate: Date,
    copayAmount: { type: Number, default: 0.0, min: 0 },
    deductible: { type: Number, default: 0.0, min: 0 },
    deductibleMet: { type: Number, default: 0.0, min: 0 },
    benefitPercent: { type: Number, default: 0.0, min: 0, max: 100 },
    outOfPocket: { type: Number, default: 0.0, min: 0 },
    outOfPocketMet: { type: Number, default: 0.0, min: 0 },
    oopAmountIncludesDeductible: {type: Boolean, default: false },
    totalDueFromPatient: { type: Number, default: 0.0, min: 0 },
    expectedAmountOverride: { type: Number, min: 0 },
    claimSentDatetime: Date,
    claimProcessed: Boolean,
    claimHistory:[{
      datetime: Date,
      event: String,
      messages: [String]
    }]
});
casePayerInfoSchema.virtual('insuredsName').get(function () {
  return (this.insuredsFirstName||'')+' '+(this.insuredsMiddleName?(this.insuredsMiddleName+' '):'')+(this.insuredsLastName||'');
});

casePayerInfoSchema.set('toJSON', { virtuals: true });
export default mongoose.model( 'CasePayerInfo', casePayerInfoSchema );
