import User from '../models/user';
import mongoose from 'mongoose'
import sequence from 'promise-sequence'

var obj = {
};
//userId is ObjectId
//patientCaseId is String
obj.add = function( userId, patientCaseId ) {

  User.findOne({name:'Richard Vann'})
  .then((user)=>{
    if (!user) return null;
    var MAXCASES = 1;
    var deletedIds = (user.recentCases||[]).slice(MAXCASES);
    User.updateOne({ name: 'Richard Vann' }, {$pull:{ recentCases: { $in: [].concat(deletedIds) }}})
    .then((result)=>{
      var x = result;
      User.findOne({name:'Richard Vann'})
      .populate('recentCases')
      .then((user)=>{
        var u = user;
      })
    })
  })

  User.findOne({_id:userId})
  .then((user)=>{
    if (!user) return null;
    var promises = [];
    var MAXCASES = 9;
    if (user.recentCases.length>MAXCASES) {
      var deletedIds = (user.recentCases||[]).filter(rc=>(rc.valueOf()!=patientCaseId)).slice(MAXCASES);
      promises.push(User.updateOne({_id:userId}, {$pull:{ recentCases: { $in: [].concat(deletedIds) }}}));
    }
    promises.push(User.updateOne({_id:userId}, {$push:{ recentCases: { $each:[mongoose.Types.ObjectId(patientCaseId)], $position:0}}}));
    return sequence(promises);
  })
}
export default obj;