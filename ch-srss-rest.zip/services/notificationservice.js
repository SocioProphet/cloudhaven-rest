import { NotificationConfig } from '../models/notificationconfig'
import {getVendorByOrgType, getFeeAmount, safeRef} from "../js/utils"

import NotificationType from '../models/notificationtype'
import PatientCase from '../models/patientcase'
import NotificationRequest from '../models/notificationrequest'
//import NotificationSender from './notificationsender'
import User from '../models/user'
import Roles from '../models/workflowroles'
import moment from 'moment';
import mongoose from 'mongoose'
import nodemailer from 'nodemailer'
import Logger from './eventlogger'
import OSCSetup from '../models/oscsetup';
import Bottleneck from "bottleneck"
import mg from 'nodemailer-mailgun-transport'
//import PHIImageService from './phiimageservice'

const mergeTokenPattern = /\$\{([^\}]+)\}/g;

function formatNumber(num) {
  return num.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
}

function getVendorRate( patientCase, vendor) {
  if (!vendor) return 'N/A';
  var feeObj = patientCase.vendorFees.find(pf=>pf.vendor._id==vendor._id);
  return feeObj?getFeeAmount(feeObj.fee, patientCase.primaryPayer.contractedRate):'';
}
function getPatientField( patientCase, field ) {
      if (!patientCase) return 'N/A'
      return patientCase.patient[field];
/*
      def patientRecId = PatientRefUtil.decryptPatientReference(patientCase.patientRef.encryptedPatientId)
      def encrypted2patientId = AESEncryption.encrypt2( patientRecId.toString() )
      return PatientId.findByEncryptedPatientId( encrypted2patientId )?.patientId*/
}

  /*private Map getPatientIdMap( List encryptedPatientIds ) {
      HashMap<String, String> keysMap = new HashMap<String, String>()
      HashMap<String, String> patientIdMap = new HashMap<String, String>()
      encryptedPatientIds.each {
          keysMap.put( AESEncryption.encrypt2( PatientRefUtil.decryptPatientReference( it ).toString() ), it )
      }
      def patientIds = PatientId.findAllByEncryptedPatientIdInList( keysMap.keySet() )
      patientIds.each {
          def patientRefKey = keysMap.get(it.encryptedPatientId)
          patientIdMap.put(patientRefKey , it.patientId)
      }
      return patientIdMap
  }*/

function getUpcomingSurgeries( caseList, vendor) {
      if (!caseList || caseListlength==0) return '';
//      def locale = Locale.ENGLISH
      var s = /*getBmcLogoTag(BMC.list()[0])+*/"\
      <br/><div id='caseListDiv'><table id='caseListTable' style='reportTableStyle'><thead>\
      <th>Patient Id</th>\
      <th>Case #</th>\
      <th>Treatment</th>\
      <th>Surgeon</th>\
      <th>ASC</th>\
      <th>Fee</th>\
      </thead>";

      var today = moment({h:0, m:0, s:0, ms:0});
      var dayOfWeek = today.day();
      if (dayOfWeek == 1 /*MONDAY*/) {
          var casesByDayMap = caseList.reduce(function(mp,c){
            var dayOfWeek = moment(c.calendarBooking.day).day();
            var cases = mp[dayOfWeek] || (mp[dayOfWeek]=[])
            cases.push(c);
            return mp;
          },{})
          for (var i=0;i<7;i++) {
              s += getUpcomingSurgeriesDay(true, i, casesByDayMap[i], vendor)
          }
      } else {
          s += getUpcomingSurgeriesDay(false, 0, caseList, vendor)
      }
      s += "</table></div>"
      return s
}
function getUpcomingSurgeriesDay(forWeekVersion, dayOfWeek, caseList, vendor) {
      var s = ''
      if (forWeekVersion) {
          s += `<tr><td>${moment().isoWeekday(dayOfWeek)}</td><td colspan='5'></td></tr>`
      }
      if (caseList && caseList.length>0) {
/*          def encryptedPatientIds = caseList*.patientRef.encryptedPatientId
          def idMap = getPatientIdMap(encryptedPatientIds)*/

          var feesTotal = 0.0;
          caseList.forEach((c)=>{
              s +=
              `<tr>\
              <td>${c.caseId}</td>\
              <td>${c.patient.patientId}</td>\
              <td>${c.procedure.name}</td>\
              <td>${getVendorByOrgType(c, 'Surgeon').name}</td>\
              <td>${getVendorByOrgType(c, 'Surgery Center').name}</td>`;
              var pkgFee = c.vendorFees.find(pf=>pf.vendor._id == vendor._id);
              var fee = pkgFee?getFeeAmount(pkgFee, c.procedure.contractRate):0;
              feesTotal += fee
              s += `<td style='text-align:right'>${fee.toFixed(2)}</td>`
              s += "</tr>"
          })
          s += `<tr><td style='text-align:right'>Total</td><td colspan='4'>${caseList.length}</td><td style='text-align:right'>${feesTotal.toFixed(2)}<td></tr>`;
      } else {
          s += `<tr><td colspan='6'>None Found</td></tr>`;
      }
      if (forWeekVersion) {
          s += "<tr><td colspan='6'>&nbsp;</td></tr>"
      }
      s.replaceAll(/<td/, "<td style='reportTableStyle' ")
      s.replaceAll(/<th/, "<th style='reportTableStyle' ")
      return s;
  }
  /*private String getBmcLogoTag( BMC bmc ) {
      return "<img src=\"${grailsLinkGenerator.serverBaseURL}/bmclogo/${bmc.id}/logo.jpg\"/>"
  }*/
  function getVendorList( patientCase ) {
      if (!patientCase) return 'N/A'
      try {
        if (patientCase.calendarBooking.status != 'Booked') return "Not yet booked";
        var vendorNames = patientCase.vendorFees.map((vb)=>vb.vendor.name);
        return vendorNames?vendorNames.join(", "):''
      } catch (e) {
        return '';
      }
  }
  function getVendorPaymentTerms( vendor ) {
      if (!vendor) return 'N/A';
      try {
        return vendor.paymentTerms+'';
      } catch (e) {
        return '';
      }
  }
  function getPHIImageElement( text, style ) {
    return text;
/*    var params = {};
    if (style) {
      style.split(';').forEach(seg=>{
        var parts = seg.split(':');
        if (parts.length>=2) {
          params[parts[0]] = parts[1];
        }
      })
    }
    return PHIImageService.createPHIImageFromText( text, params ).then((imageId)=>{
      return `<img src="${process.env.PHI_IMG_DOMAIN}/api/phiimage/getimage/${imageId}"/>`;
    })*/
  }
  function createParticipationResponseElement( params ) {
    return `<a href='${process.env.SRSS_DOMAIN}/api/participationresponse/${params.patientCase.id}/${params.vendor.id}'>Accept</a>`;
  }
  function getPatientAmount( patientCase ) {
    var patientAmountDue = patientCase.paymentsDue.find(payment=>payment.payerType=='Patient')
    return (patientAmountDue?patientAmountDue.amount.toFixed(2):0)+'';
  }
  function getMergeValue( params, mergeCode, isPatient, isAlert ) {
    var promise = new mongoose.Promise(function( resolve, reject){
      var parts = /^\$\{phi:\[(.+)\](:(.+))?\}$/.exec(mergeCode);
      if (isPatient && parts && parts.length>1) {
        resolve(getPHIImageElement(parts[1], parts[3]));
      } else {
        switch (mergeCode ) {
            case '${patient_id}' :
              var patientId = getPatientField(params.patientCase, 'patientId');
              resolve((isPatient && !isAlert)?getPHIImageElement(patientId):patientId);
              break;
            case '${patient_name}' :
              var retVal = '';
              var patientName = getPatientField(params.patientCase, 'name');
              if (isPatient) {
                retVal = getPHIImageElement(patientName);
              } else if (isAlert) {
                retVal = patientName;
              }
              resolve(retVal);
              break;
  //          case '${bmc}' : resolve(bmc?.name
  //          case '${bmc_logo}' : resolve(getBmcLogoTag( bmc )
  //          case '${bmc_payment_terms}' : resolve(bmc?.bmcToGraPaymentTerms.toString()
            case '${payer}' : resolve(params.patientCase.primaryPayer.claimsPayer.name); break;
            case '${patient_amount}' :
              var retVal = '';
              var patientAmount = params.patientCase.totalDueFromPatient.toFixed(2);
              if (isPatient) {
                retVal = getPHIImageElement(patientAmount);
              } else if (isAlert) {
                retVal = patientName;
              }
              resolve(retVal);
              break;
            case '${relationship_to_patient}': resolve(params.patientCase.primaryPayer.relationshipToPatient); break;
            case '${procedure}' :
              var retVal = params.patientCase.procedure.name;
              if (isPatient) {
                retVal = getPHIImageElement(retVal);
              }
              resolve(retVal);
              break;
            case '${case_id}' : resolve(params.patientCase.caseId); break;
            case '${cptcode}' : resolve(safeRef(params.patientCase.cptCode).code); break;
            case '${diagnosis}' : resolve(safeRef(params.patientCase.icd10Code).code); break;
            case '${icd10code}' : resolve(safeRef(params.patientCase.icd10Code).code); break;
            case '${surgeon}' : resolve(getVendorByOrgType(params.patientCase, 'Surgeon').name); break;
            case '${surgery_center}' : resolve(getVendorByOrgType(params.patientCase, 'Surgery Center').name); break;
            case '${recovery_suite}' : resolve(getVendorByOrgType(params.patientCase, 'Recovery Suite').name); break;
            case '${device}' : resolve(getVendorByOrgType(params.patientCase, 'Device Maker').name); break;
            case '${date_of_service}' : resolve(params.patientCase.calendarBooking ? moment(params.patientCase.calendarBooking.day).format('l') : ''); break;
            case '${vendor_list}' : resolve(getVendorList( params.patientCase )); break;
            case '${vendor}' : resolve(params.vendor.name); break;
            case '${vendor_rate}' : resolve(getVendorRate(params.patientCase, params.vendor)); break;
            case '${vendor_payment_terms}': resolve(getVendorPaymentTerms( params.vendor )); break;
            case '${vendor_payment_terms_and_conditions}': resolve(params.vendor?(params.vendor.paymentTermsAndConditions||'(none)'):'N/A'); break;
            case '${daily_vendor_notification}' : resolve(getUpcomingSurgeries(params.caseList, params.vendor)); break;
            case '${vendor_monthly_digest}' : resolve(params.reportContent); break;
            case '${participation_accept}' : resolve(createParticipationResponseElement(params)); break;
            case '${payable_amount}' : resolve('$'+(params.payable.amount+params.payable.additionalAmount).toFixed(2)); break;
            case '${payable_vendor}' : resolve(params.payable.vendor.name); break;
            case '${payable_duedate}' : resolve(moment(params.payable.dueDate).format('MM/DD/YYYY')); break;
            case '${patient_payment_duedate}':
              var paymentDue = params.patientCase.paymentsDue.find(pd=>(pd.payerType=='Patient'));
              if (!paymentDue || !paymentDue.dueDate) resolve('');
              resolve(moment(paymentDue.dueDate).format('MM/DD/YYYY'));
              break;
            default: resolve('')
        }
      }
    })
    return promise;
  }

function createNotificationRequest(r, patientCase) {
  var promise = new mongoose.Promise(function( resolve, reject){
    if (r.requiresResponse) {
      var notificationRequest = {
        patientCase: patientCase._id,
        notificationType:r.notificationType,
        dayTrigger: r.dayTrigger,
        vendor: r.vendor,
        language: r.language,
        email: `${r.contactName} <${r.email}>`
      };
      NotificationRequest.create(notificationRequest)
      .then((notificationRequest)=>{
        r.notificationRequestId = notificationRequest._id.toString();
        resolve(r.notificationRequestId);
      });
    } else {
      resolve(null);
    }
  });
  return promise;
}
var obj = {};
function sendNotificationEmail (r, patientCase, notificationType) {
  var promise = new mongoose.Promise(function( resolve, reject){
    createNotificationRequest(r, patientCase)
    .then((notificationRequestId)=>{
      return obj.populateTemplate( { patientCase: patientCase,
        notificationRequestId: notificationRequestId,
        vendor:r.vendor,
        template:notificationType.content,
        isPatient:r.isPatient} )
    })
    .then((content)=>{
      obj.sendEmail(`${r.contactName} <${r.email}>`, notificationType.subject, content, notificationType.fromEmail);
      resolve(true);
    })
  });
  return promise;
}
obj.sendEmail = function( destEmail, subject, body, emailSender ) {
  var promise = new mongoose.Promise(function( resolve, reject){
    var isEmailSendDisabled = process.env.DISABLE_NOTIFICATIONS == "true";
    const auth = {
      auth: {
        api_key: 'de1fbb05532b00cc71332eb1988e9a6a-52b6835e-54396cc7',
        domain: 'surgicalrecoverysuites.com'
      }/*,
      proxy: 'http://user:pass@localhost:8080' // optional proxy, default is false */
    }
    
    var errMsg = 'Failed to create mailgun transport for nodemailer';
    var nodemailerMailgun = null;
    try {
      nodemailerMailgun = nodemailer.createTransport(mg(auth));
    } catch (e) {
      Logger.error('Email', errMsg);
      reject(errMsg);
      return;
    }
    if (!nodemailerMailgun) {
      Logger.error('Email', errMsg);
      reject(errMsg);
      return;
    }
 
    if (isEmailSendDisabled) {
      console.log(subject+'development: email would have sent to '+destEmail+'.');
    } else {
      OSCSetup.findOne({}, {emailSendFailing:1, ccEmail:1})
      .then((setup) =>{
        var mailOptions = {
          from: emailSender, // sender address
          to: isEmailSendDisabled ? 'rich@cloudhaven.net' : destEmail, // list of receivers
          subject: subject, // Subject line
          html: body
        };
        if (setup.ccEmail) {
          mailOptions.cc = setup.ccEmail;
        }
        nodemailerMailgun.sendMail(mailOptions, (err, info) => {
          if (err) {
            Logger.error('Email', 'sendEmail failed: '+err);
            if (!setup.emailSendFailing) {
              OSCSetup.findOneAndUpdate({}, {$set: {emailSendFailing: true}}, {new:true})
            }
            console.log(`Error: ${err}`);
          } else {
            Logger.log('Email', subject+' email successfully sent to '+destEmail+'.');
            if (setup.emailSendFailing) {
              OSCSetup.findOneAndUpdate({}, {$set: {emailSendFailing: false}}, {new:true})
            }
          }
          resolve(true);
        });
      });
    }
  })
  return promise;
}

obj.populateTemplate = function( params ) {
  if (params.template == null) return '';
  var template = params.template
  var result = '';
  var startPos = 0;
  var tokenValsMap = {};
  var mergePromises = [];
  var tokens = [];
  var matchData = null;
  while ((matchData = mergeTokenPattern.exec(template))) {
    tokens.push(matchData[0]);
    mergePromises.push(getMergeValue( params, matchData[0], params.isPatient, params.isAlert));
  }
  return mongoose.Promise.all(mergePromises)
  .then((results)=>{
    for (var i=0;i<results.length;i++) {
      tokenValsMap[tokens[i]] = results[i];
    }
    mergeTokenPattern.lastIndex = 0;
    while ((matchData = mergeTokenPattern.exec(template))) {
      result += template.substring(startPos, matchData.index);
      result += tokenValsMap[matchData[0]];
      var lastStartPos = startPos;
      startPos = matchData.index+matchData[0].length;
      if (lastStartPos == startPos) startPos++;
    }
    if (startPos < template.length) {
        result += template.substring(startPos)
    }
    return result
  })
}
  obj.createNotifications = function( patientCaseId, notificationEvent ) {
    var configList = NotificationConfig[notificationEvent];
    return obj.createNotificationsFromConfig( patientCaseId, configList );
  }
  obj.getCostEstimateNotification = function( patientCaseId) {
    var promise = new mongoose.Promise(function( resolve, reject){
      var notifications = NotificationConfig['Payer Info Received'] || [];
      var costEstimate = notifications.find(n=>n.notificationType == 'Patient Cost Estimate');
      if (costEstimate) {
        PatientCase.findOne({_id:patientCaseId})
        .populate('cptCode')
        .populate('icd10Code')
        .populate({path:'patient'})
        .populate({path:'procedure'})
        .populate({path:'vendorFees.vendor', select:'name'})
        .then(patientCase=>{
          NotificationType.findOne({name:costEstimate.notificationType})
          .then((notificationType) => {
            if (notificationType) {
              resolve(obj.populateTemplate( { patientCase: patientCase,
                template:notificationType.content,
                isPatient:true}));
            } else {
              resolve(true);
            }
          });
        })
      } else {
        resolve(true);
      }
    });
    return promise;
  };
  obj.createNotificationsFromConfig = function( patientCaseId, configList ) {
    if (!configList) configList = [];
    return PatientCase.findOne({_id:patientCaseId})
    .populate({path:'primaryPayer.claimsPayer', populate:{path:'contacts'}})
//    .populate({path:'primaryPayer.claimsXContact'})
//    .populate({path:'secondaryPayer.claimsXContact'})
//    .populate({path:'payerInfo.authorizingXContact'})
    .populate({path:"vendorFees.vendor"})
    .populate({path:'patient'})
    .populate({path:'procedure', populate: [{path:'cptCodes'}, {path:'diagnoses'}] })
    .populate('cptCode')
    .populate('icd10Code')
    .then((patientCase)=>{
      var caseOrgMap = patientCase.vendorFees.reduce((mp,vb)=>{
        var list = mp[vb.vendor.vendorType] || (mp[vb.vendor.vendorType]=[]);
        list.push(vb.vendor);
        return mp;
      },{});
      var notificationTypeIdsMap = {};
/*      var roleEntries = configList.filter(e=>e.entityType=='role');
      var alerts = [];
      roleEntries.forEach((entry)=>{
        var notificationTypeId = entry.notificationType;
        notificationTypeIdsMap[notificationTypeId] = true;
        entry.entities.forEach((role)=>{
          alerts.push({role:role, notificationTypeId:notificationTypeId, patientCase: patientCase});
        })
      });*/
      var requests = [];
      var patientEntries = configList.filter(e=>e.entityType=='patient');
      patientEntries.forEach(entry=>{
        notificationTypeIdsMap[entry.notificationType] = true;
        var email = safeRef(safeRef(patientCase.patient).contactInfo).email;
        if (email) {
          requests.push({notificationType:entry.notificationType, language:patientCase.patient.contactInfo.language, dayTrigger:entry.dayTrigger,
                          contactName:patientCase.patient.name, email:email, isPatient:true});
        }
      });
      var orgEntries = configList.filter((e)=>e.entityType=='orgtype');
      orgEntries.forEach((entry)=>{
        entry.entities.forEach((orgType)=>{
          if (orgType == Roles.PrimaryClaimsPayer) {
            var email = safeRef(patientCase.primaryPayer).email;
            if (email) {
              requests.push({ notificationType:notificationTypeId, language:contactInfo.language, dayTrigger:entry.dayTrigger, 
                              payer: patientCase.primaryPayer.claimsPayer, email:email});
            }
          } else if (orgType == Roles.SecondaryClaimsPayer) {
            var email = safeRef(patientCase.secondaryPayer).email;
            if (email) {
              requests.push({ notificationType:notificationTypeId, language:contactInfo.language, dayTrigger:entry.dayTrigger, 
                              payer: patientCase.secondaryPayer.claimsPayer, email:email});
            }
          } else {
            var orgs = null;
            if (orgType == 'Supporting Resource') {
              orgs = Object.keys(caseOrgMap).reduce((ar, orgType)=>{
                if (orgType != 'Surgeon' && orgType != 'Surgery Center' && orgType != 'Device Maker' && orgType != 'Recovery Suite') {
                  ar = ar.concat(caseOrgMap[orgType]||[]);
                }
                return ar;
              },[])
            } else {
              orgs = caseOrgMap[orgType] || [];
            }
            orgs.forEach((org)=>{
              org.contacts.forEach((c)=>{
                if ((c.contactType=='Primary' || c.contactType=='Associate') && safeRef(safeRef(c).contactInfo).email) {
                  notificationTypeIdsMap[entry.notificationType] = true;
                  requests.push({ notificationType: entry.notificationType,
                                  vendor: org, 
                                  dayTrigger: entry.dayTrigger,
                                  language: c.contactInfo.language,
                                  contactName: c.name,
                                  email: c.contactInfo.email,
                                  requiresResponse: entry.requiresResponse
                                });
                }
              })
            });
          }
        })
      });
      return NotificationType.find({name:{$in:Object.keys(notificationTypeIdsMap)}})
      .then((notificationTypes)=>{
        var notificationTypesMap = notificationTypes.reduce(function(mp,nt){
          mp[nt.name] = nt;
          return mp;
        },{})

        var promises = [];
        return User.find({})
        .then((userList)=>{
          return userList.reduce(function(mp,u){
            u.roles.forEach((r)=>{
              var userList = mp[r] || (mp[r]=[])
              userList.push(u);
            })
            return mp;
          },{});
        })
        .then((roleMap)=>{
          var userUpdatesMap = {};
/*          var alertPromises = [];
          alerts.forEach((a)=>{
            var notificationType = notificationTypesMap[a.notificationTypeId];
            a.subject = notificationType.subject;
            alertPromises.push(obj.populateTemplate( {patientCase: patientCase, template:notificationType.content, isAlert:true} ));
          })
          return mongoose.Promise.all(alertPromises)
          .then((results)=>{
            for (var i=0;i<alerts.length;i++) {
              var a = alerts[i];
              a.content = results[i];
              a.patientName = patientCase.patient.name;
              var userList = roleMap[a.role];
              if (userList) userList.forEach((u)=>{
                var updates = userUpdatesMap[u._id] || (userUpdatesMap[u._id]=[])
                updates.push(a);
              })
            }*/
            promises = Object.keys(userUpdatesMap).reduce(function(ar,userId) {
              if (userUpdatesMap[userId].length>0) {
                var updates = userUpdatesMap[userId].map((a)=>{
                  return {subject:a.subject, content:a.content, patientCase:a.patientCase._id, patientName: a.patientCase.patient.name}
                });
                ar.push(User.updateOne({_id:mongoose.Types.ObjectId(userId)}, {$push:{alerts: {$each:updates}}}))
              }
              return ar;
            }, []);
            mongoose.Promise.all(promises)
            .then((results) =>{
              if (requests.length>0) {
                var notifPromises = [];
                const limiter = new Bottleneck({
                  maxConcurrent: 2,
                  minTime: 3000
                });
                var throttledSendNotificationEmail = limiter.wrap(sendNotificationEmail);
                  requests.forEach((r)=>{
                  var notificationType = notificationTypesMap[r.notificationType];
                  if (notificationType) {
                    notifPromises.push(throttledSendNotificationEmail(r, patientCase, notificationType));
                  }
                });
                return mongoose.Promise.all(notifPromises);
              }
            })
//          })
        })
      })
    })
  }
  //destEmail, subject, body, emailSender
  obj.throttledSendEmails = function( emails ) {
    var notifPromises = [];
    const limiter = new Bottleneck({
      maxConcurrent: 2,
      minTime: 3000
    });
    var throttledSendEmail = limiter.wrap(obj.sendEmail.bind(obj));
    emails.forEach((email) => {
      notifPromises.push(throttledSendEmail(email.destEmail, email.subject, email.body, email.fromEmail ));
    });
    return mongoose.Promise.all(notifPromises);
}
  export default obj;