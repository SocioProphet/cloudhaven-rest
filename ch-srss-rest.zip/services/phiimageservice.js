import PHI_Image from '../models/phiimage'
import PHI_ImageId from '../models/phiimageid'
import mongoose from 'mongoose'
import text2png from 'text2png'

var obj = {};
obj.createPHIImageFromText = function(text, params) {
  if (!params) params = {};
  if (!params.font) params.font='bold 16px sans-serif';
  if (!params.color) params.color = 'black';
  var imageParams = {output:'buffer'};
  if (params.font) imageParams.font = params.font;
  if (params.color) imageParams.color = params.color;
  var imageData = text2png(text, imageParams);
  return PHI_Image.findOneAndUpdate({text:text}, {$set:{text:text, image:imageData}}, {upsert:true, new:true})
  .then((imageObj)=>{
    if (!imageObj) {
      console.log('imageObj null for '+text);
      return '';
    }
    return PHI_ImageId.create({image:imageObj._id})
    .then(imageIdObj=>{
      return imageIdObj._id.toString();
    });
  })
}
obj.getPHIImageById = function( id ) {
  return PHI_ImageId.findById(id)
  .populate('image')
  .then(imgObj=>{
    return imgObj?imgObj.image.image:null;
  })
}
export default obj;