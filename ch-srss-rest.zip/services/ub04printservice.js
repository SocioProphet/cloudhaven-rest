import OSCSetup from '../models/oscsetup';
import mongoose from 'mongoose'
import PDFDocument from 'pdfkit'
import fs from 'fs'

/*
make pdf with pdfkit.org
npm install pdfkit
print from hidden iframe:
<html>
<head>
    <title>Print PDF using inline iFrame</title>
</head>
<body>
    <iframe style="display: none" 
        src="../sample.pdf" id="myFrame" 
        frameborder="0" style="border:0;" 
        width="300" height="300">
    </iframe>
    <p>
        <input type="button" id="bt" onclick="print()" value="Print PDF" />
    </p>
</body>

<script>
    function print() {
        var objFra = document.getElementById('myFrame');
        objFra.contentWindow.focus();
        objFra.contentWindow.print();
    }
</script>
</html>
*/

var ub04FldCfg = {
  billingProviderName:{
     llx: 17.6581,
     lly: -24.712,
     urx: 190.672,
     ury: -12.946,
   width: 173.0139,
  height: 11.766
},
billingProviderStreetAddr:{ 
     llx: 17.6551,
     lly: -36.476,
     urx: 190.669,
     ury: -24.71,
   width: 173.0139,
  height: 11.766
},
billingProviderCityStateZip:{ 
     llx: 17.6581,
     lly: -48.842,
     urx: 190.672,
     ury: -37.076,
   width: 173.0139,
  height: 11.766
},
billingProviderCountryPhone:{ 
     llx: 17.6551,
     lly: -60.474,
     urx: 190.669,
     ury: -48.708,
   width: 173.0139,
  height: 11.766
},
payToName:{ 
     llx: 197.877,
     lly: -24.71,
     urx: 370.891,
     ury: -12.944,
   width: 173.014,
  height: 11.766
},
payToStreetAddr:{ 
     llx: 197.877,
     lly: -36.476,
     urx: 370.891,
     ury: -24.71,
   width: 173.014,
  height: 11.766
},
payToCityStateZip:{ 
     llx: 197.874,
     lly: -48.842,
     urx: 370.888,
     ury: -37.076,
   width: 173.014,
  height: 11.766
},
payToCountryPhone:{ 
     llx: 197.877,
     lly: -60.474,
     urx: 370.891,
     ury: -48.708,
   width: 173.014,
  height: 11.766
},
patientControlNumber:{ 
     llx: 392.62,
     lly: -24.712,
     urx: 564.458,
     ury: -12.946,
   width: 171.838,
  height: 11.766
},
medicalHealthRecordNumber:{ 
     llx: 392.62,
     lly: -36.476,
     urx: 564.46,
     ury: -24.71,
   width: 171.84,
  height: 11.766
},
typeOfBill:{ 
     llx: 564.341,
     lly: -36.476,
     urx: 601.997,
     ury: -24.71,
   width: 37.656,
  height: 11.766
},
federalTaxNumber:{ 
     llx: 371.352,
     lly: -60.474,
     urx: 443.105,
     ury: -48.708,
   width: 71.753,
  height: 11.766
},
stmtCoversFromDate:{ 
     llx: 442.79,
     lly: -60.474,
     urx: 492.592,
     ury: -48.708,
   width: 49.802,
  height: 11.766
},
stmtCoversToDate:{ 
     llx: 493.794,
     lly: -60.474,
     urx: 543.596,
     ury: -48.708,
   width: 49.802,
  height: 11.766
},
reserved:{ 
     llx: 551.374,
     lly: -60.607,
     urx: 601.995,
     ury: -36.475,
   width: 50.621,
  height: 24.132
},
patientId:{ 
     llx: 90.0061,
     lly: -72.376,
     urx: 226.543,
     ury: -60.61,
   width: 136.5369,
  height: 11.766
},
patientName:{ 
     llx: 18.5451,
     lly: -84.738,
     urx: 226.543,
     ury: -72.972,
   width: 207.9979,
  height: 11.766
},
patientStreetAddress:{ 
     llx: 306.679,
     lly: -72.376,
     urx: 601.995,
     ury: -60.61,
   width: 295.316,
  height: 11.766
},
patientCity:{ 
     llx: 234.295,
     lly: -84.738,
     urx: 464.879,
     ury: -72.972,
   width: 230.584,
  height: 11.766
},
patientState:{ 
     llx: 471.773,
     lly: -84.738,
     urx: 493.125,
     ury: -72.972,
   width: 21.352,
  height: 11.766
},
patientZip:{ 
     llx: 500.717,
     lly: -84.738,
     urx: 572.57,
     ury: -72.972,
   width: 71.853,
  height: 11.766
},
patientCountry:{ 
     llx: 579.888,
     lly: -84.738,
     urx: 601.394,
     ury: -72.972,
   width: 21.506,
  height: 11.766
},
patientBirthDate:{ 
     llx: 10.5801,
     lly: -108.268,
     urx: 75.3221,
     ury: -96.502,
   width: 64.742,
  height: 11.766
},
patientGender:{ 
     llx: 75.3261,
     lly: -108.268,
     urx: 97.1001,
     ury: -96.502,
   width: 21.774,
  height: 11.766
},
patientAdmissionDate:{ 
     llx: 97.1021,
     lly: -108.268,
     urx: 140.05,
     ury: -96.502,
   width: 42.9479,
  height: 11.766
},
patientAdmissionHour:{ 
     llx: 140.048,
     lly: -108.268,
     urx: 161.822,
     ury: -96.502,
   width: 21.774,
  height: 11.766
},
patientVisitType:{ 
     llx: 161.822,
     lly: -108.268,
     urx: 183.596,
     ury: -96.502,
   width: 21.774,
  height: 11.766
},
patientAdmissionPointOfOrigin:{ 
     llx: 183.018,
     lly: -108.268,
     urx: 204.792,
     ury: -96.502,
   width: 21.774,
  height: 11.766
},
patientDischargeHour:{ 
     llx: 204.792,
     lly: -108.268,
     urx: 226.566,
     ury: -96.502,
   width: 21.774,
  height: 11.766
},
patientDischargeStatus:{ 
     llx: 226.543,
     lly: -108.268,
     urx: 248.317,
     ury: -96.502,
   width: 21.774,
  height: 11.766
},
conditionCode1:{ 
     llx: 247.739,
     lly: -108.268,
     urx: 269.513,
     ury: -96.502,
   width: 21.774,
  height: 11.766
},
conditionCode2:{ 
     llx: 269.513,
     lly: -108.268,
     urx: 291.287,
     ury: -96.502,
   width: 21.774,
  height: 11.766
},
conditionCode3:{ 
     llx: 291.264,
     lly: -108.268,
     urx: 313.038,
     ury: -96.502,
   width: 21.774,
  height: 11.766
},
conditionCode4:{ 
     llx: 312.462,
     lly: -108.268,
     urx: 334.236,
     ury: -96.502,
   width: 21.774,
  height: 11.766
},
conditionCode5:{ 
     llx: 334.235,
     lly: -108.268,
     urx: 356.009,
     ury: -96.502,
   width: 21.774,
  height: 11.766
},
conditionCode6:{ 
     llx: 355.986,
     lly: -108.268,
     urx: 377.76,
     ury: -96.502,
   width: 21.774,
  height: 11.766
},
conditionCode7:{ 
     llx: 377.783,
     lly: -108.268,
     urx: 399.557,
     ury: -96.502,
   width: 21.774,
  height: 11.766
},
conditionCode8:{ 
     llx: 399.557,
     lly: -108.268,
     urx: 421.331,
     ury: -96.502,
   width: 21.774,
  height: 11.766
},
conditionCode9:{ 
     llx: 421.308,
     lly: -108.268,
     urx: 443.082,
     ury: -96.502,
   width: 21.774,
  height: 11.766
},
conditionCode10:{ 
     llx: 442.968,
     lly: -108.268,
     urx: 464.742,
     ury: -96.502,
   width: 21.774,
  height: 11.766
},
conditionCode11:{ 
     llx: 464.879,
     lly: -108.268,
     urx: 485.779,
     ury: -96.502,
   width: 20.9,
  height: 11.766
},
accidentState:{ 
     llx: 485.474,
     lly: -108.268,
     urx: 509.004,
     ury: -96.502,
   width: 23.53,
  height: 11.766
},
reserved30:{ 
     llx: 509.778,
     lly: -108.268,
     urx: 601.394,
     ury: -96.502,
   width: 91.616,
  height: 11.766
},
occurrenceCode31a:{ 
     llx: 10.4001,
     lly: -132.402,
     urx: 31.5721,
     ury: -120.636,
   width: 21.172,
  height: 11.766
},
occurrenceDate31a:{ 
     llx: 32.1731,
     lly: -132.402,
     urx: 82.1901,
     ury: -120.636,
   width: 50.017,
  height: 11.766
},
occurrenceCode32a:{ 
     llx: 82.7101,
     lly: -132.402,
     urx: 103.882,
     ury: -120.636,
   width: 21.1719,
  height: 11.766
},
occurrenceDate32a:{ 
     llx: 104.49,
     lly: -132.402,
     urx: 154.507,
     ury: -120.636,
   width: 50.017,
  height: 11.766
},
occurrenceCode33a:{ 
     llx: 154.58,
     lly: -132.402,
     urx: 175.752,
     ury: -120.636,
   width: 21.172,
  height: 11.766
},
occurrenceDate33a:{ 
     llx: 176.31,
     lly: -132.402,
     urx: 226.275,
     ury: -120.636,
   width: 49.965,
  height: 11.766
},
occurrenceCode34a:{ 
     llx: 226.897,
     lly: -132.402,
     urx: 248.069,
     ury: -120.636,
   width: 21.172,
  height: 11.766
},
occurrenceDate34a:{ 
     llx: 248.626,
     lly: -132.402,
     urx: 298.591,
     ury: -120.636,
   width: 49.965,
  height: 11.766
},
occurrenceCode31b:{ 
     llx: 10.4001,
     lly: -144.757,
     urx: 31.5721,
     ury: -132.991,
   width: 21.172,
  height: 11.766
},
occurrenceDate31b:{ 
     llx: 32.1731,
     lly: -144.757,
     urx: 82.1901,
     ury: -132.991,
   width: 50.017,
  height: 11.766
},
occurrenceCode32b:{ 
     llx: 82.7101,
     lly: -144.757,
     urx: 103.882,
     ury: -132.991,
   width: 21.1719,
  height: 11.766
},
occurrenceDate32b:{ 
     llx: 104.49,
     lly: -144.757,
     urx: 154.507,
     ury: -132.991,
   width: 50.017,
  height: 11.766
},
occurrenceCode33b:{ 
     llx: 154.58,
     lly: -144.757,
     urx: 175.752,
     ury: -132.991,
   width: 21.172,
  height: 11.766
},
occurrenceDate33b:{ 
     llx: 176.31,
     lly: -144.757,
     urx: 226.275,
     ury: -132.991,
   width: 49.965,
  height: 11.766
},
occurrenceCode34b:{ 
     llx: 226.897,
     lly: -144.757,
     urx: 248.069,
     ury: -132.991,
   width: 21.172,
  height: 11.766
},
occurrenceDate34b:{ 
     llx: 248.626,
     lly: -144.757,
     urx: 298.591,
     ury: -132.991,
   width: 49.965,
  height: 11.766
},
occurrenceSpanCode35a:{ 
     llx: 298.962,
     lly: -132.402,
     urx: 320.134,
     ury: -120.636,
   width: 21.172,
  height: 11.766
},
occurrenceSpanFromDate35a:{ 
     llx: 320.713,
     lly: -132.402,
     urx: 370.678,
     ury: -120.636,
   width: 49.965,
  height: 11.766
},
occurrenceSpanToDate35a:{ 
     llx: 371.314,
     lly: -132.402,
     urx: 421.279,
     ury: -120.636,
   width: 49.965,
  height: 11.766
},
occurrenceSpanCode36a:{ 
     llx: 421.714,
     lly: -132.402,
     urx: 442.886,
     ury: -120.636,
   width: 21.172,
  height: 11.766
},
occurrenceSpanFromDate36a:{ 
     llx: 443.466,
     lly: -132.402,
     urx: 493.431,
     ury: -120.636,
   width: 49.965,
  height: 11.766
},
occurrenceSpanToDate36a:{ 
     llx: 494.067,
     lly: -132.402,
     urx: 544.032,
     ury: -120.636,
   width: 49.965,
  height: 11.766
},
occurrenceSpanCode35b:{ 
     llx: 298.962,
     lly: -144.757,
     urx: 320.134,
     ury: -132.991,
   width: 21.172,
  height: 11.766
},
occurrenceSpanFromDate35b:{ 
     llx: 320.713,
     lly: -144.949,
     urx: 370.678,
     ury: -132.991,
   width: 49.965,
  height: 11.958
},
occurrenceSpanToDate35b:{ 
     llx: 371.314,
     lly: -144.757,
     urx: 421.279,
     ury: -132.991,
   width: 49.965,
  height: 11.766
},
occurrenceSpanCode36b:{ 
     llx: 421.714,
     lly: -144.757,
     urx: 442.886,
     ury: -132.991,
   width: 21.172,
  height: 11.766
},
occurrenceSpanFromDate36b:{ 
     llx: 443.466,
     lly: -144.757,
     urx: 493.431,
     ury: -132.991,
   width: 49.965,
  height: 11.766
},
occurrenceSpanToDate36b:{ 
     llx: 494.067,
     lly: -144.757,
     urx: 544.032,
     ury: -132.991,
   width: 49.965,
  height: 11.766
},
reserved37a:{ 
     llx: 544.323,
     lly: -132.402,
     urx: 601.33,
     ury: -120.636,
   width: 57.007,
  height: 11.766
},
reserved37b:{ 
     llx: 544.323,
     lly: -144.757,
     urx: 601.33,
     ury: -132.991,
   width: 57.007,
  height: 11.766
},
respPartyNameAddr:{ 
     llx: 20.5911,
     lly: -204.796,
     urx: 313.061,
     ury: -144.767,
   width: 292.4699,
  height: 60.029
},
valueCode39a:{ 
     llx: 320.115,
     lly: -169.036,
     urx: 341.889,
     ury: -157.27,
   width: 21.774,
  height: 11.766
},
valueAmount39a:{ 
     llx: 342.5,
     lly: -169.036,
     urx: 414.089,
     ury: -157.27,
   width: 71.589,
  height: 11.766
},
valueCode40a:{ 
     llx: 413.679,
     lly: -169.036,
     urx: 435.453,
     ury: -157.27,
   width: 21.774,
  height: 11.766
},
valueAmount40a:{ 
     llx: 436.057,
     lly: -169.036,
     urx: 507.666,
     ury: -157.27,
   width: 71.609,
  height: 11.766
},
valueCode41a:{ 
     llx: 507.848,
     lly: -169.036,
     urx: 529.622,
     ury: -157.27,
   width: 21.774,
  height: 11.766
},
valueAmount41a:{ 
     llx: 529.455,
     lly: -169.036,
     urx: 601.676,
     ury: -157.27,
   width: 72.221,
  height: 11.766
},
valueCode39b:{ 
     llx: 320.115,
     lly: -180.778,
     urx: 341.889,
     ury: -169.012,
   width: 21.774,
  height: 11.766
},
valueAmount39b:{ 
     llx: 342.5,
     lly: -180.778,
     urx: 414.089,
     ury: -169.012,
   width: 71.589,
  height: 11.766
},
valueCode40b:{ 
     llx: 413.679,
     lly: -180.778,
     urx: 435.453,
     ury: -169.012,
   width: 21.774,
  height: 11.766
},
valueAmount40b:{ 
     llx: 436.057,
     lly: -180.778,
     urx: 507.666,
     ury: -169.012,
   width: 71.609,
  height: 11.766
},
valueCode41b:{ 
     llx: 507.848,
     lly: -180.778,
     urx: 529.622,
     ury: -169.012,
   width: 21.774,
  height: 11.766
},
valueAmount41b:{ 
     llx: 529.455,
     lly: -180.778,
     urx: 601.676,
     ury: -169.012,
   width: 72.221,
  height: 11.766
},
valueCode39c:{ 
     llx: 320.115,
     lly: -192.522,
     urx: 341.889,
     ury: -180.756,
   width: 21.774,
  height: 11.766
},
valueAmount39c:{ 
     llx: 342.5,
     lly: -192.522,
     urx: 414.089,
     ury: -180.756,
   width: 71.589,
  height: 11.766
},
valueCode40c:{ 
     llx: 413.679,
     lly: -192.687,
     urx: 435.453,
     ury: -180.756,
   width: 21.774,
  height: 11.931
},
valueAmount40c:{ 
     llx: 436.057,
     lly: -192.522,
     urx: 507.666,
     ury: -180.756,
   width: 71.609,
  height: 11.766
},
valueCode41c:{ 
     llx: 507.848,
     lly: -192.522,
     urx: 529.622,
     ury: -180.756,
   width: 21.774,
  height: 11.766
},
valueAmount41c:{ 
     llx: 529.455,
     lly: -192.522,
     urx: 601.676,
     ury: -180.756,
   width: 72.221,
  height: 11.766
},
valueCode39d:{ 
     llx: 320.115,
     lly: -204.265,
     urx: 341.889,
     ury: -192.499,
   width: 21.774,
  height: 11.766
},
valueAmount39d:{ 
     llx: 342.5,
     lly: -204.265,
     urx: 414.089,
     ury: -192.499,
   width: 71.589,
  height: 11.766
},
valueCode40d:{ 
     llx: 413.679,
     lly: -204.265,
     urx: 435.453,
     ury: -192.499,
   width: 21.774,
  height: 11.766
},
valueAmount40d:{ 
     llx: 436.057,
     lly: -204.265,
     urx: 507.666,
     ury: -192.499,
   width: 71.609,
  height: 11.766
},
valueCode41d:{ 
     llx: 507.848,
     lly: -204.265,
     urx: 529.622,
     ury: -192.499,
   width: 21.774,
  height: 11.766
},
valueAmount41d:{ 
     llx: 529.455,
     lly: -204.265,
     urx: 601.676,
     ury: -192.499,
   width: 72.221,
  height: 11.766
},
revenueCode1:{ 
     llx: 10.5801,     lly: -229.064,
     urx: 44.1181,
     ury: -217.299,
   width: 33.538,
  height: 11.765
},
revenueDescription1:{ 
     llx: 44.7731,     lly: -229.064,
     urx: 223.619,
     ury: -217.299,
   width: 178.8459,
  height: 11.765
},
rateCodes1:{ 
     llx: 224.348,
     lly: -229.064,
     urx: 331.904,
     ury: -217.299,
   width: 107.556,
  height: 11.765
},
serviceDate1:{ 
     llx: 332.478,
     lly: -229.064,
     urx: 382.496,
     ury: -217.299,
   width: 50.018,
  height: 11.765
},
serviceUnits1:{ 
     llx: 383.115,
     lly: -229.064,
     urx: 439.606,
     ury: -217.299,
   width: 56.491,
  height: 11.765
},
totalCharges1:{ 
     llx: 440.182,
     lly: -229.064,
     urx: 512.031,
     ury: -217.299,
   width: 71.849,
  height: 11.765
},
nonCoveredCharges1:{ 
     llx: 512.55,
     lly: -229.064,
     urx: 583.051,
     ury: -217.299,
   width: 70.501,
  height: 11.765
},
revReserved1:{ 
     llx: 583.498,
     lly: -229.064,
     urx: 601.569,
     ury: -217.299,
   width: 18.071,
  height: 11.765
},
revenueCode2:{ 
     llx: 10.5801,
     lly: -240.725,
     urx: 44.1181,
     ury: -228.96,
   width: 33.538,
  height: 11.765
},
revenueDescription2:{ 
     llx: 44.7731,
     lly: -240.725,
     urx: 223.619,
     ury: -228.96,
   width: 178.8459,
  height: 11.765
},
rateCodes2:{ 
     llx: 224.349,
     lly: -240.725,
     urx: 331.905,
     ury: -228.96,
   width: 107.556,
  height: 11.765
},
serviceDate2:{ 
     llx: 332.478,
     lly: -240.725,
     urx: 382.496,
     ury: -228.96,
   width: 50.018,
  height: 11.765
},
serviceUnits2:{ 
     llx: 383.115,
     lly: -240.725,
     urx: 439.606,
     ury: -228.96,
   width: 56.491,
  height: 11.765
},
totalCharges2:{ 
     llx: 440.182,
     lly: -240.725,
     urx: 512.031,
     ury: -228.96,
   width: 71.849,
  height: 11.765
},
nonCoveredCharges2:{ 
     llx: 512.55,
     lly: -240.725,
     urx: 583.051,
     ury: -228.96,
   width: 70.501,
  height: 11.765
},
revReserved2:{ 
     llx: 583.498,
     lly: -240.725,
     urx: 601.569,
     ury: -228.96,
   width: 18.071,
  height: 11.765
},
revenueCode3:{ 
     llx: 10.5801,
     lly: -252.85,
     urx: 44.1181,
     ury: -241.085,
   width: 33.538,
  height: 11.765
},
revenueDescription3:{ 
     llx: 44.7741,
     lly: -252.85,
     urx: 223.62,
     ury: -241.085,
   width: 178.8459,
  height: 11.765
},
rateCodes3:{ 
     llx: 224.348,
     lly: -252.85,
     urx: 331.904,
     ury: -241.085,
   width: 107.556,
  height: 11.765
},
serviceDate3:{ 
     llx: 332.478,
     lly: -252.85,
     urx: 382.496,
     ury: -241.085,
   width: 50.018,
  height: 11.765
},
serviceUnits3:{ 
     llx: 383.115,
     lly: -252.85,
     urx: 439.606,
     ury: -241.085,
   width: 56.491,
  height: 11.765
},
totalCharges3:{ 
     llx: 440.182,
     lly: -252.85,
     urx: 512.031,
     ury: -241.085,
   width: 71.849,
  height: 11.765
},
nonCoveredCharges3:{ 
     llx: 512.55,
     lly: -252.85,
     urx: 583.051,
     ury: -241.085,
   width: 70.501,
  height: 11.765
},
revReserved3:{ 
     llx: 583.499,
     lly: -252.85,
     urx: 601.57,
     ury: -241.085,
   width: 18.071,
  height: 11.765
},
revenueCode4:{ 
     llx: 10.5801,
     lly: -264.708,
     urx: 44.1181,
     ury: -252.943,
   width: 33.538,
  height: 11.765
},
revenueDescription4:{ 
     llx: 44.7731,
     lly: -264.708,
     urx: 223.619,
     ury: -252.943,
   width: 178.8459,
  height: 11.765
},
rateCodes4:{ 
     llx: 224.347,
     lly: -264.708,
     urx: 331.903,
     ury: -252.943,
   width: 107.556,
  height: 11.765
},
serviceDate4:{ 
     llx: 332.478,
     lly: -264.708,
     urx: 382.496,
     ury: -252.943,
   width: 50.018,
  height: 11.765
},
serviceUnits4:{ 
     llx: 383.115,
     lly: -264.708,
     urx: 439.606,
     ury: -252.943,
   width: 56.491,
  height: 11.765
},
totalCharges4:{ 
     llx: 440.182,
     lly: -264.708,
     urx: 512.031,
     ury: -252.943,
   width: 71.849,
  height: 11.765
},
nonCoveredCharges4:{ 
     llx: 512.55,
     lly: -264.708,
     urx: 583.051,
     ury: -252.943,
   width: 70.501,
  height: 11.765
},
revReserved4:{ 
     llx: 583.498,
     lly: -264.708,
     urx: 601.569,
     ury: -252.943,
   width: 18.071,
  height: 11.765
},
revenueCode5:{ 
     llx: 10.5801,
     lly: -276.372,
     urx: 44.1181,
     ury: -264.607,
   width: 33.538,
  height: 11.765
},
revenueDescription5:{ 
     llx: 44.7741,
     lly: -276.372,
     urx: 223.62,
     ury: -264.607,
   width: 178.8459,
  height: 11.765
},
rateCodes5:{ 
     llx: 224.348,
     lly: -276.372,
     urx: 331.904,
     ury: -264.607,
   width: 107.556,
  height: 11.765
},
serviceDate5:{ 
     llx: 332.478,
     lly: -276.372,
     urx: 382.496,
     ury: -264.607,
   width: 50.018,
  height: 11.765
},
serviceUnits5:{ 
     llx: 383.115,
     lly: -276.372,
     urx: 439.606,
     ury: -264.607,
   width: 56.491,
  height: 11.765
},
totalCharges5:{ 
     llx: 440.182,
     lly: -276.372,
     urx: 512.031,
     ury: -264.607,
   width: 71.849,
  height: 11.765
},
nonCoveredCharges5:{ 
     llx: 512.55,
     lly: -276.372,
     urx: 583.051,
     ury: -264.607,
   width: 70.501,
  height: 11.765
},
revReserved5:{ 
     llx: 583.499,
     lly: -276.372,
     urx: 601.57,
     ury: -264.607,
   width: 18.071,
  height: 11.765
},
revenueCode6:{ 
     llx: 10.5801,
     lly: -288.231,
     urx: 44.1181,
     ury: -276.466,
   width: 33.538,
  height: 11.765
},
revenueDescription6:{ 
     llx: 44.7731,
     lly: -288.231,
     urx: 223.619,
     ury: -276.466,
   width: 178.8459,
  height: 11.765
},
rateCodes6:{ 
     llx: 224.347,
     lly: -288.231,
     urx: 331.903,
     ury: -276.466,
   width: 107.556,
  height: 11.765
},
serviceDate6:{ 
     llx: 332.478,
     lly: -288.231,
     urx: 382.496,
     ury: -276.466,
   width: 50.018,
  height: 11.765
},
serviceUnits6:{ 
     llx: 383.115,
     lly: -288.231,
     urx: 439.606,
     ury: -276.466,
   width: 56.491,
  height: 11.765
},
totalCharges6:{ 
     llx: 440.182,
     lly: -288.231,
     urx: 512.031,
     ury: -276.466,
   width: 71.849,
  height: 11.765
},
nonCoveredCharges6:{ 
     llx: 512.55,
     lly: -288.231,
     urx: 583.051,
     ury: -276.466,
   width: 70.501,
  height: 11.765
},
revReserved6:{ 
     llx: 583.498,
     lly: -288.231,
     urx: 601.569,
     ury: -276.466,
   width: 18.071,
  height: 11.765
},
revenueCode7:{ 
     llx: 10.5801,
     lly: -300.341,
     urx: 44.1181,
     ury: -288.576,
   width: 33.538,
  height: 11.765
},
revenueDescription7:{ 
     llx: 44.7741,
     lly: -300.341,
     urx: 223.62,
     ury: -288.576,
   width: 178.8459,
  height: 11.765
},
rateCodes7:{ 
     llx: 224.348,
     lly: -300.341,
     urx: 331.904,
     ury: -288.576,
   width: 107.556,
  height: 11.765
},
serviceDate7:{ 
     llx: 332.478,
     lly: -300.341,
     urx: 382.496,
     ury: -288.576,
   width: 50.018,
  height: 11.765
},
serviceUnits7:{ 
     llx: 383.115,
     lly: -300.341,
     urx: 439.606,
     ury: -288.576,
   width: 56.491,
  height: 11.765
},
totalCharges7:{ 
     llx: 440.182,
     lly: -300.341,
     urx: 512.031,
     ury: -288.576,
   width: 71.849,
  height: 11.765
},
nonCoveredCharges7:{ 
     llx: 512.55,
     lly: -300.341,
     urx: 583.051,
     ury: -288.576,
   width: 70.501,
  height: 11.765
},
revReserved7:{ 
     llx: 583.499,
     lly: -300.341,
     urx: 601.57,
     ury: -288.576,
   width: 18.071,
  height: 11.765
},
revenueCode8:{ 
     llx: 10.5801,
     lly: -312.199,
     urx: 44.1181,
     ury: -300.434,
   width: 33.538,
  height: 11.765
},
revenueDescription8:{ 
     llx: 44.7731,
     lly: -312.199,
     urx: 223.619,
     ury: -300.434,
   width: 178.8459,
  height: 11.765
},
rateCodes8:{ 
     llx: 224.347,
     lly: -312.199,
     urx: 331.903,
     ury: -300.434,
   width: 107.556,
  height: 11.765
},
serviceDate8:{ 
     llx: 332.478,
     lly: -312.199,
     urx: 382.496,
     ury: -300.434,
   width: 50.018,
  height: 11.765
},
serviceUnits8:{ 
     llx: 383.115,
     lly: -312.199,
     urx: 439.606,
     ury: -300.434,
   width: 56.491,
  height: 11.765
},
totalCharges8:{ 
     llx: 440.182,
     lly: -312.199,
     urx: 512.031,
     ury: -300.434,
   width: 71.849,
  height: 11.765
},
nonCoveredCharges8:{ 
     llx: 512.55,
     lly: -312.199,
     urx: 583.051,
     ury: -300.434,
   width: 70.501,
  height: 11.765
},
revReserved8:{ 
     llx: 583.498,
     lly: -312.199,
     urx: 601.569,
     ury: -300.434,
   width: 18.071,
  height: 11.765
},
revenueCode9:{ 
     llx: 10.5801,
     lly: -324.331,
     urx: 44.1181,
     ury: -312.566,
   width: 33.538,
  height: 11.765
},
revenueDescription9:{ 
     llx: 44.7741,
     lly: -324.331,
     urx: 223.62,
     ury: -312.566,
   width: 178.8459,
  height: 11.765
},
rateCodes9:{ 
     llx: 224.348,
     lly: -324.331,
     urx: 331.904,
     ury: -312.566,
   width: 107.556,
  height: 11.765
},
serviceDate9:{ 
     llx: 332.478,
     lly: -324.331,
     urx: 382.496,
     ury: -312.566,
   width: 50.018,
  height: 11.765
},
serviceUnits9:{ 
     llx: 383.115,
     lly: -324.331,
     urx: 439.606,
     ury: -312.566,
   width: 56.491,
  height: 11.765
},
totalCharges9:{ 
     llx: 440.182,
     lly: -324.331,
     urx: 512.031,
     ury: -312.566,
   width: 71.849,
  height: 11.765
},
nonCoveredCharges9:{ 
     llx: 512.55,
     lly: -324.331,
     urx: 583.051,
     ury: -312.566,
   width: 70.501,
  height: 11.765
},
revReserved9:{ 
     llx: 583.499,
     lly: -324.331,
     urx: 601.57,
     ury: -312.566,
   width: 18.071,
  height: 11.765
},
revenueCode10:{ 
     llx: 10.5801,
     lly: -336.485,
     urx: 44.1181,
     ury: -324.72,
   width: 33.538,
  height: 11.765
},
revenueDescription10:{ 
     llx: 44.7731,
     lly: -336.485,
     urx: 223.619,
     ury: -324.72,
   width: 178.8459,
  height: 11.765
},
rateCodes10:{ 
     llx: 224.347,
     lly: -336.485,
     urx: 331.903,
     ury: -324.72,
   width: 107.556,
  height: 11.765
},
serviceDate10:{ 
     llx: 332.478,
     lly: -336.485,
     urx: 382.496,
     ury: -324.72,
   width: 50.018,
  height: 11.765
},
serviceUnits10:{ 
     llx: 383.115,
     lly: -336.485,
     urx: 439.606,
     ury: -324.72,
   width: 56.491,
  height: 11.765
},
totalCharges10:{ 
     llx: 440.182,
     lly: -336.485,
     urx: 512.031,
     ury: -324.72,
   width: 71.849,
  height: 11.765
},
nonCoveredCharges10:{ 
     llx: 512.55,
     lly: -336.485,
     urx: 583.051,
     ury: -324.72,
   width: 70.501,
  height: 11.765
},
revReserved10:{ 
     llx: 583.498,
     lly: -336.485,
     urx: 601.569,
     ury: -324.72,
   width: 18.071,
  height: 11.765
},
revenueCode11:{ 
     llx: 10.5801,
     lly: -348.739,
     urx: 44.1181,
     ury: -336.974,
   width: 33.538,
  height: 11.765
},
revenueDescription11:{ 
     llx: 44.7741,
     lly: -348.739,
     urx: 223.62,
     ury: -336.974,
   width: 178.8459,
  height: 11.765
},
rateCodes11:{ 
     llx: 224.348,
     lly: -348.739,
     urx: 331.904,
     ury: -336.974,
   width: 107.556,
  height: 11.765
},
serviceDate11:{ 
     llx: 332.478,
     lly: -348.739,
     urx: 382.496,
     ury: -336.974,
   width: 50.018,
  height: 11.765
},
serviceUnits11:{ 
     llx: 383.115,
     lly: -348.739,
     urx: 439.606,
     ury: -336.974,
   width: 56.491,
  height: 11.765
},
totalCharges11:{ 
     llx: 440.182,
     lly: -348.739,
     urx: 512.031,
     ury: -336.974,
   width: 71.849,
  height: 11.765
},
nonCoveredCharges11:{ 
     llx: 512.55,
     lly: -348.739,
     urx: 583.051,
     ury: -336.974,
   width: 70.501,
  height: 11.765
},
revReserved11:{ 
     llx: 583.499,
     lly: -348.739,
     urx: 601.57,
     ury: -336.974,
   width: 18.071,
  height: 11.765
},
revenueCode12:{ 
     llx: 10.5801,
     lly: -360.598,
     urx: 44.1181,
     ury: -348.833,
   width: 33.538,
  height: 11.765
},
revenueDescription12:{ 
     llx: 44.7731,
     lly: -360.598,
     urx: 223.619,
     ury: -348.833,
   width: 178.8459,
  height: 11.765
},
rateCodes12:{ 
     llx: 224.347,
     lly: -360.598,
     urx: 331.903,
     ury: -348.833,
   width: 107.556,
  height: 11.765
},
serviceDate12:{ 
     llx: 332.478,
     lly: -360.598,
     urx: 382.496,
     ury: -348.833,
   width: 50.018,
  height: 11.765
},
serviceUnits12:{ 
     llx: 383.115,
     lly: -360.598,
     urx: 439.606,
     ury: -348.833,
   width: 56.491,
  height: 11.765
},
totalCharges12:{ 
     llx: 440.182,
     lly: -360.598,
     urx: 512.031,
     ury: -348.833,
   width: 71.849,
  height: 11.765
},
nonCoveredCharges12:{ 
     llx: 512.55,
     lly: -360.598,
     urx: 583.051,
     ury: -348.833,
   width: 70.501,
  height: 11.765
},
revReserved12:{ 
     llx: 583.498,
     lly: -360.598,
     urx: 601.569,
     ury: -348.833,
   width: 18.071,
  height: 11.765
},
revenueCode13:{ 
     llx: 10.5801,
     lly: -372.73,
     urx: 44.1181,
     ury: -360.965,
   width: 33.538,
  height: 11.765
},
revenueDescription13:{ 
     llx: 44.7741,
     lly: -372.73,
     urx: 223.62,
     ury: -360.965,
   width: 178.8459,
  height: 11.765
},
rateCodes13:{ 
     llx: 224.348,
     lly: -372.73,
     urx: 331.904,
     ury: -360.965,
   width: 107.556,
  height: 11.765
},
serviceDate13:{ 
     llx: 332.478,
     lly: -372.73,
     urx: 382.496,
     ury: -360.965,
   width: 50.018,
  height: 11.765
},
serviceUnits13:{ 
     llx: 383.115,
     lly: -372.73,
     urx: 439.606,
     ury: -360.965,
   width: 56.491,
  height: 11.765
},
totalCharges13:{ 
     llx: 440.182,
     lly: -372.73,
     urx: 512.031,
     ury: -360.965,
   width: 71.849,
  height: 11.765
},
nonCoveredCharges13:{ 
     llx: 512.55,
     lly: -372.73,
     urx: 583.051,
     ury: -360.965,
   width: 70.501,
  height: 11.765
},
revReserved13:{ 
     llx: 583.499,
     lly: -372.73,
     urx: 601.57,
     ury: -360.965,
   width: 18.071,
  height: 11.765
},
revenueCode14:{ 
     llx: 10.5801,
     lly: -384.581,
     urx: 44.1181,
     ury: -372.816,
   width: 33.538,
  height: 11.765
},
revenueDescription14:{ 
     llx: 44.7731,
     lly: -384.581,
     urx: 223.619,
     ury: -372.816,
   width: 178.8459,
  height: 11.765
},
rateCodes14:{ 
     llx: 224.347,
     lly: -384.581,
     urx: 331.903,
     ury: -372.816,
   width: 107.556,
  height: 11.765
},
serviceDate14:{ 
     llx: 332.478,
     lly: -384.581,
     urx: 382.496,
     ury: -372.816,
   width: 50.018,
  height: 11.765
},
serviceUnits14:{ 
     llx: 383.115,
     lly: -384.581,
     urx: 439.606,
     ury: -372.816,
   width: 56.491,
  height: 11.765
},
totalCharges14:{ 
     llx: 440.182,
     lly: -384.581,
     urx: 512.031,
     ury: -372.816,
   width: 71.849,
  height: 11.765
},
nonCoveredCharges14:{ 
     llx: 512.55,
     lly: -384.581,
     urx: 583.051,
     ury: -372.816,
   width: 70.501,
  height: 11.765
},
revReserved14:{ 
     llx: 583.498,
     lly: -384.581,
     urx: 601.569,
     ury: -372.816,
   width: 18.071,
  height: 11.765
},
revenueCode15:{ 
     llx: 10.5801,
     lly: -396.699,
     urx: 44.1181,
     ury: -384.934,
   width: 33.538,
  height: 11.765
},
revenueDescription15:{ 
     llx: 44.7741,
     lly: -396.699,
     urx: 223.62,
     ury: -384.934,
   width: 178.8459,
  height: 11.765
},
rateCodes15:{ 
     llx: 224.348,
     lly: -396.699,
     urx: 331.904,
     ury: -384.934,
   width: 107.556,
  height: 11.765
},
serviceDate15:{ 
     llx: 332.478,
     lly: -396.699,
     urx: 382.496,
     ury: -384.934,
   width: 50.018,
  height: 11.765
},
serviceUnits15:{ 
     llx: 383.115,
     lly: -396.699,
     urx: 439.606,
     ury: -384.934,
   width: 56.491,
  height: 11.765
},
totalCharges15:{ 
     llx: 440.182,
     lly: -396.699,
     urx: 512.031,
     ury: -384.934,
   width: 71.849,
  height: 11.765
},
nonCoveredCharges15:{ 
     llx: 512.55,
     lly: -396.699,
     urx: 583.051,
     ury: -384.934,
   width: 70.501,
  height: 11.765
},
revReserved15:{ 
     llx: 583.499,
     lly: -396.699,
     urx: 601.57,
     ury: -384.934,
   width: 18.071,
  height: 11.765
},
revenueCode16:{ 
     llx: 10.5801,
     lly: -408.55,
     urx: 44.1181,
     ury: -396.785,
   width: 33.538,
  height: 11.765
},
revenueDescription16:{ 
     llx: 44.7731,
     lly: -408.55,
     urx: 223.619,
     ury: -396.785,
   width: 178.8459,
  height: 11.765
},
rateCodes16:{ 
     llx: 224.349,
     lly: -408.55,
     urx: 331.905,
     ury: -396.785,
   width: 107.556,
  height: 11.765
},
serviceDate16:{ 
     llx: 332.478,
     lly: -408.55,
     urx: 382.496,
     ury: -396.785,
   width: 50.018,
  height: 11.765
},
serviceUnits16:{ 
     llx: 383.115,
     lly: -408.55,
     urx: 439.606,
     ury: -396.785,
   width: 56.491,
  height: 11.765
},
totalCharges16:{ 
     llx: 440.182,
     lly: -408.551,
     urx: 512.031,
     ury: -396.786,
   width: 71.849,
  height: 11.765
},
nonCoveredCharges16:{ 
     llx: 512.55,
     lly: -408.551,
     urx: 583.051,
     ury: -396.786,
   width: 70.501,
  height: 11.765
},
revReserved16:{ 
     llx: 583.498,
     lly: -408.551,
     urx: 601.569,
     ury: -396.786,
   width: 18.071,
  height: 11.765
},
revenueCode17:{ 
     llx: 10.5801,
     lly: -420.667,
     urx: 44.1181,
     ury: -408.902,
   width: 33.538,
  height: 11.765
},
revenueDescription17:{ 
     llx: 44.7741,
     lly: -420.667,
     urx: 223.62,
     ury: -408.902,
   width: 178.8459,
  height: 11.765
},
rateCodes17:{ 
     llx: 224.348,
     lly: -420.667,
     urx: 331.904,
     ury: -408.902,
   width: 107.556,
  height: 11.765
},
serviceDate17:{ 
     llx: 332.478,
     lly: -420.667,
     urx: 382.496,
     ury: -408.902,
   width: 50.018,
  height: 11.765
},
serviceUnits17:{ 
     llx: 383.115,
     lly: -420.667,
     urx: 439.606,
     ury: -408.902,
   width: 56.491,
  height: 11.765
},
totalCharges17:{ 
     llx: 440.182,
     lly: -420.667,
     urx: 512.031,
     ury: -408.902,
   width: 71.849,
  height: 11.765
},
nonCoveredCharges17:{ 
     llx: 512.55,
     lly: -420.667,
     urx: 583.051,
     ury: -408.902,
   width: 70.501,
  height: 11.765
},
revReserved17:{ 
     llx: 583.499,
     lly: -420.667,
     urx: 601.57,
     ury: -408.902,
   width: 18.071,
  height: 11.765
},
revenueCode18:{ 
     llx: 10.5801,
     lly: -432.519,
     urx: 44.1181,
     ury: -420.754,
   width: 33.538,
  height: 11.765
},
revenueDescription18:{ 
     llx: 44.7731,
     lly: -432.519,
     urx: 223.619,
     ury: -420.754,
   width: 178.8459,
  height: 11.765
},
rateCodes18:{ 
     llx: 224.347,
     lly: -432.519,
     urx: 331.903,
     ury: -420.754,
   width: 107.556,
  height: 11.765
},
serviceDate18:{ 
     llx: 332.478,
     lly: -432.519,
     urx: 382.496,
     ury: -420.754,
   width: 50.018,
  height: 11.765
},
serviceUnits18:{ 
     llx: 383.115,
     lly: -432.519,
     urx: 439.606,
     ury: -420.754,
   width: 56.491,
  height: 11.765
},
totalCharges18:{ 
     llx: 440.182,
     lly: -432.519,
     urx: 512.031,
     ury: -420.754,
   width: 71.849,
  height: 11.765
},
nonCoveredCharges18:{ 
     llx: 512.55,
     lly: -432.519,
     urx: 583.051,
     ury: -420.754,
   width: 70.501,
  height: 11.765
},
revReserved18:{ 
     llx: 583.498,
     lly: -432.519,
     urx: 601.569,
     ury: -420.754,
   width: 18.071,
  height: 11.765
},
revenueCode19:{ 
     llx: 10.5801,
     lly: -444.651,
     urx: 44.1181,
     ury: -432.886,
   width: 33.538,
  height: 11.765
},
revenueDescription19:{ 
     llx: 44.7741,
     lly: -444.651,
     urx: 223.62,
     ury: -432.886,
   width: 178.8459,
  height: 11.765
},
rateCodes19:{ 
     llx: 224.348,
     lly: -444.651,
     urx: 331.904,
     ury: -432.886,
   width: 107.556,
  height: 11.765
},
serviceDate19:{ 
     llx: 332.478,
     lly: -444.651,
     urx: 382.496,
     ury: -432.886,
   width: 50.018,
  height: 11.765
},
serviceUnits19:{ 
     llx: 383.115,
     lly: -444.651,
     urx: 439.606,
     ury: -432.886,
   width: 56.491,
  height: 11.765
},
totalCharges19:{ 
     llx: 440.182,
     lly: -444.651,
     urx: 512.031,
     ury: -432.886,
   width: 71.849,
  height: 11.765
},
nonCoveredCharges19:{ 
     llx: 512.55,
     lly: -444.651,
     urx: 583.051,
     ury: -432.886,
   width: 70.501,
  height: 11.765
},
revReserved19:{ 
     llx: 583.499,
     lly: -444.651,
     urx: 601.57,
     ury: -432.886,
   width: 18.071,
  height: 11.765
},
revenueCode20:{ 
     llx: 10.5801,
     lly: -456.509,
     urx: 44.1181,
     ury: -444.744,
   width: 33.538,
  height: 11.765
},
revenueDescription20:{ 
     llx: 44.7731,
     lly: -456.509,
     urx: 223.619,
     ury: -444.744,
   width: 178.8459,
  height: 11.765
},
rateCodes20:{ 
     llx: 224.347,
     lly: -456.509,
     urx: 331.903,
     ury: -444.744,
   width: 107.556,
  height: 11.765
},
serviceDate20:{ 
     llx: 332.478,
     lly: -456.509,
     urx: 382.496,
     ury: -444.744,
   width: 50.018,
  height: 11.765
},
serviceUnits20:{ 
     llx: 383.115,
     lly: -456.509,
     urx: 439.606,
     ury: -444.744,
   width: 56.491,
  height: 11.765
},
totalCharges20:{ 
     llx: 440.182,
     lly: -456.509,
     urx: 512.031,
     ury: -444.744,
   width: 71.849,
  height: 11.765
},
nonCoveredCharges20:{ 
     llx: 512.55,
     lly: -456.509,
     urx: 583.051,
     ury: -444.744,
   width: 70.501,
  height: 11.765
},
revReserved20:{ 
     llx: 583.498,
     lly: -456.509,
     urx: 601.569,
     ury: -444.744,
   width: 18.071,
  height: 11.765
},
revenueCode21:{ 
     llx: 10.5801,
     lly: -468.619,
     urx: 44.1181,
     ury: -456.854,
   width: 33.538,
  height: 11.765
},
revenueDescription21:{ 
     llx: 44.7741,
     lly: -468.619,
     urx: 223.62,
     ury: -456.854,
   width: 178.8459,
  height: 11.765
},
rateCodes21:{ 
     llx: 224.348,
     lly: -468.619,
     urx: 331.904,
     ury: -456.854,
   width: 107.556,
  height: 11.765
},
serviceDate21:{ 
     llx: 332.478,
     lly: -468.619,
     urx: 382.496,
     ury: -456.854,
   width: 50.018,
  height: 11.765
},
serviceUnits21:{ 
     llx: 383.115,
     lly: -468.619,
     urx: 439.606,
     ury: -456.854,
   width: 56.491,
  height: 11.765
},
totalCharges21:{ 
     llx: 440.182,
     lly: -468.619,
     urx: 512.031,
     ury: -456.854,
   width: 71.849,
  height: 11.765
},
nonCoveredCharges21:{ 
     llx: 512.55,
     lly: -468.619,
     urx: 583.051,
     ury: -456.854,
   width: 70.501,
  height: 11.765
},
revReserved21:{ 
     llx: 583.499,
     lly: -468.619,
     urx: 601.57,
     ury: -456.854,
   width: 18.071,
  height: 11.765
},
revenueCode22:{ 
     llx: 10.5801,
     lly: -480.478,
     urx: 44.1181,
     ury: -468.713,
   width: 33.538,
  height: 11.765
},
revenueDescription22:{ 
     llx: 44.7731,
     lly: -480.478,
     urx: 223.619,
     ury: -468.713,
   width: 178.8459,
  height: 11.765
},
rateCodes22:{ 
     llx: 224.347,
     lly: -480.478,
     urx: 331.903,
     ury: -468.713,
   width: 107.556,
  height: 11.765
},
serviceDate22:{ 
     llx: 332.478,
     lly: -480.478,
     urx: 382.496,
     ury: -468.713,
   width: 50.018,
  height: 11.765
},
serviceUnits22:{ 
     llx: 383.115,
     lly: -480.478,
     urx: 439.606,
     ury: -468.713,
   width: 56.491,
  height: 11.765
},
totalCharges22:{ 
     llx: 440.182,
     lly: -480.479,
     urx: 512.031,
     ury: -468.714,
   width: 71.849,
  height: 11.765
},
nonCoveredCharges22:{ 
     llx: 512.55,
     lly: -480.479,
     urx: 583.051,
     ury: -468.714,
   width: 70.501,
  height: 11.765
},
revReserved22:{ 
     llx: 583.498,
     lly: -480.479,
     urx: 601.569,
     ury: -468.714,
   width: 18.071,
  height: 11.765
},
revenueCode23:{ 
     llx: 10.5831,
     lly: -492.524,
     urx: 44.1211,
     ury: -480.758,
   width: 33.538,
  height: 11.766
},
claimPageNumber:{ 
     llx: 77.0841,
     lly: -492.524,
     urx: 98.2791,
     ury: -480.758,
   width: 21.195,
  height: 11.766
},
totalClaimPages:{ 
     llx: 119.493,
     lly: -492.524,
     urx: 140.688,
     ury: -480.758,
   width: 21.195,
  height: 11.766
},
creationDate:{ 
     llx: 332.478,
     lly: -492.524,
     urx: 382.496,
     ury: -480.758,
   width: 50.018,
  height: 11.766
},
totalChargesTotal:{ 
     llx: 440.182,
     lly: -492.524,
     urx: 512.026,
     ury: -480.758,
   width: 71.844,
  height: 11.766
},
nonCoveredChargesTotal:{ 
     llx: 512.55,
     lly: -492.524,
     urx: 583.051,
     ury: -480.758,
   width: 70.501,
  height: 11.766
},
revReserved23:{ 
     llx: 583.498,
     lly: -492.524,
     urx: 601.15,
     ury: -480.758,
   width: 17.652,
  height: 11.766
},
primaryPayerName:{ 
     llx: 10.3711,
     lly: -516.658,
     urx: 175.496,
     ury: -504.893,
   width: 165.1249,
  height: 11.765
},
primaryPayerHealthPlanId:{ 
     llx: 176.158,
     lly: -516.658,
     urx: 283.836,
     ury: -504.893,
   width: 107.678,
  height: 11.765
},
primaryPayerReleaseOfInfo:{ 
     llx: 284.267,
     lly: -516.658,
     urx: 298.137,
     ury: -504.893,
   width: 13.87,
  height: 11.765
},
primaryPayerAssignmentOfBenefits:{ 
     llx: 306.009,
     lly: -516.658,
     urx: 319.879,
     ury: -504.893,
   width: 13.87,
  height: 11.765
},
primaryPayerPriorPayments:{ 
     llx: 320.238,
     lly: -516.658,
     urx: 392.073,
     ury: -504.893,
   width: 71.835,
  height: 11.765
},
primaryPayerEstAmtDue:{ 
     llx: 392.029,
     lly: -516.658,
     urx: 471.355,
     ury: -504.893,
   width: 79.326,
  height: 11.765
},
secondaryPayerName:{ 
     llx: 10.3711,
     lly: -528.567,
     urx: 175.496,
     ury: -516.802,
   width: 165.1249,
  height: 11.765
},
secondaryPayerHealthPlanId:{ 
     llx: 176.158,
     lly: -528.567,
     urx: 283.836,
     ury: -516.802,
   width: 107.678,
  height: 11.765
},
secondaryPayerReleaseOfInfo:{ 
     llx: 284.266,
     lly: -528.567,
     urx: 298.136,
     ury: -516.802,
   width: 13.87,
  height: 11.765
},
secondaryPayerAssignmentOfBenefits:{ 
     llx: 306.01,
     lly: -528.567,
     urx: 319.88,
     ury: -516.802,
   width: 13.87,
  height: 11.765
},
secondaryPayerPriorPayments:{ 
     llx: 320.238,
     lly: -528.567,
     urx: 392.073,
     ury: -516.802,
   width: 71.835,
  height: 11.765
},
secondaryPayerEstAmtDue:{ 
     llx: 392.029,
     lly: -528.567,
     urx: 471.355,
     ury: -516.802,
   width: 79.326,
  height: 11.765
},
tertiaryPayerName:{ 
     llx: 10.3711,
     lly: -540.475,
     urx: 175.496,
     ury: -528.71,
   width: 165.1249,
  height: 11.765
},
tertiaryPayerHealthPlanId:{ 
     llx: 176.158,
     lly: -540.475,
     urx: 283.836,
     ury: -528.71,
   width: 107.678,
  height: 11.765
},
tertiaryPayerReleaseOfInfo:{ 
     llx: 284.266,
     lly: -540.475,
     urx: 298.136,
     ury: -528.71,
   width: 13.87,
  height: 11.765
},
tertiaryPayerAssignmentOfBenefits:{ 
     llx: 306.01,
     lly: -540.475,
     urx: 319.88,
     ury: -528.71,
   width: 13.87,
  height: 11.765
},
tertiaryPayerPriorPayments:{ 
     llx: 320.238,
     lly: -540.475,
     urx: 392.073,
     ury: -528.71,
   width: 71.835,
  height: 11.765
},
tertiaryPayerEstAmtDue:{ 
     llx: 392.029,
     lly: -540.475,
     urx: 471.355,
     ury: -528.71,
   width: 79.326,
  height: 11.765
},
billingProviderNPI:{ 
     llx: 493.491,
     lly: -504.512,
     urx: 601.149,
     ury: -492.746,
   width: 107.658,
  height: 11.766
},
otherBillingProviderIda:{ 
     llx: 493.491,
     lly: -516.658,
     urx: 601.149,
     ury: -504.893,
   width: 107.658,
  height: 11.765
},
otherBillingProviderIdb:{ 
     llx: 493.489,
     lly: -528.567,
     urx: 601.147,
     ury: -516.802,
   width: 107.658,
  height: 11.765
},
otherBillingProviderIdc:{ 
     llx: 493.492,
     lly: -540.475,
     urx: 601.15,
     ury: -528.71,
   width: 107.658,
  height: 11.765
},
primaryPlanInsuredsName:{ 
     llx: 10.8751,
     lly: -564.892,
     urx: 197.037,
     ury: -553.126,
   width: 186.1619,
  height: 11.766
},
primaryPlanPatientRelationship:{ 
     llx: 197.665,
     lly: -564.892,
     urx: 218.971,
     ury: -553.126,
   width: 21.306,
  height: 11.766
},
primaryPlanInsuredsId:{ 
     llx: 218.914,
     lly: -564.892,
     urx: 362.918,
     ury: -553.126,
   width: 144.004,
  height: 11.766
},
primaryPlanInsuredsGroupName:{ 
     llx: 363.891,
     lly: -564.892,
     urx: 471.443,
     ury: -553.126,
   width: 107.552,
  height: 11.766
},
primaryPlanInsuredsGroupNumber:{ 
     llx: 471.718,
     lly: -564.892,
     urx: 601.44,
     ury: -553.126,
   width: 129.722,
  height: 11.766
},
secondaryPlanInsuredsName:{ 
     llx: 10.8751,
     lly: -576.642,
     urx: 197.037,
     ury: -564.876,
   width: 186.1619,
  height: 11.766
},
secondaryPlanPatientRelationship:{ 
     llx: 197.665,
     lly: -576.642,
     urx: 218.971,
     ury: -564.876,
   width: 21.306,
  height: 11.766
},
secondaryPlanInsuredsId:{ 
     llx: 218.914,
     lly: -576.642,
     urx: 362.918,
     ury: -564.876,
   width: 144.004,
  height: 11.766
},
secondaryPlanInsuredsGroupName:{ 
     llx: 363.891,
     lly: -576.642,
     urx: 471.443,
     ury: -564.876,
   width: 107.552,
  height: 11.766
},
secondaryPlanInsuredsGroupNumber:{ 
     llx: 471.718,
     lly: -576.642,
     urx: 601.44,
     ury: -564.876,
   width: 129.722,
  height: 11.766
},
tertiaryPlanInsuredsName:{ 
     llx: 10.8751,
     lly: -588.572,
     urx: 197.037,
     ury: -576.806,
   width: 186.1619,
  height: 11.766
},
tertiaryPlanPatientRelationship:{ 
     llx: 197.665,
     lly: -588.572,
     urx: 218.971,
     ury: -576.806,
   width: 21.306,
  height: 11.766
},
tertiaryPlanInsuredsId:{ 
     llx: 218.914,
     lly: -588.572,
     urx: 362.918,
     ury: -576.806,
   width: 144.004,
  height: 11.766
},
tertiaryPlanInsuredsGroupName:{ 
     llx: 363.891,
     lly: -588.572,
     urx: 471.443,
     ury: -576.806,
   width: 107.552,
  height: 11.766
},
tertiaryPlanInsuredsGroupNumber:{ 
     llx: 471.718,
     lly: -588.572,
     urx: 601.44,
     ury: -576.806,
   width: 129.722,
  height: 11.766
},
primaryPlanTreatmentAuthCode:{ 
     llx: 10.8541,
     lly: -612.512,
     urx: 233.716,
     ury: -600.746,
   width: 222.8619,
  height: 11.766
},
primaryPlanDCN:{ 
     llx: 234.298,
     lly: -612.512,
     urx: 421.203,
     ury: -600.746,
   width: 186.905,
  height: 11.766
},
primaryPlanEmployer:{ 
     llx: 421.563,
     lly: -612.512,
     urx: 601.563,
     ury: -600.746,
   width: 180,
  height: 11.766
},
secondaryPlanTreatmentAuthCode:{ 
     llx: 10.8541,
     lly: -624.27,
     urx: 233.716,
     ury: -612.504,
   width: 222.8619,
  height: 11.766
},
secondaryPlanDCN:{ 
     llx: 234.298,
     lly: -624.27,
     urx: 421.203,
     ury: -612.504,
   width: 186.905,
  height: 11.766
},
secondaryPlanEmployer:{ 
     llx: 421.563,
     lly: -624.27,
     urx: 601.563,
     ury: -612.504,
   width: 180,
  height: 11.766
},
tertiaryPlanTreatmentAuthCode:{ 
     llx: 10.8541,
     lly: -636.193,
     urx: 233.716,
     ury: -624.427,
   width: 222.8619,
  height: 11.766
},
tertiaryPlanDCN:{ 
     llx: 234.298,
     lly: -636.193,
     urx: 421.203,
     ury: -624.427,
   width: 186.905,
  height: 11.766
},
tertiaryPlanEmployer:{ 
     llx: 421.563,
     lly: -636.193,
     urx: 601.563,
     ury: -624.427,
   width: 180,
  height: 11.766
},
reserved327:{ 
     llx: 10.6301,
     lly: -660.695,
     urx: 17.9021,
     ury: -648.929,
   width: 7.272,
  height: 11.766
},
mainDiagnosisCode:{ 
     llx: 18.4421,
     lly: -648.246,
     urx: 68.9691,
     ury: -636.48,
   width: 50.527,
  height: 11.766
},
mainDiagnosisPOA:{ 
     llx: 69.3541,
     lly: -648.246,
     urx: 76.6261,
     ury: -636.48,
   width: 7.272,
  height: 11.766
},
otherDiagnosisCodeA:{ 
     llx: 75.8341,
     lly: -648.246,
     urx: 126.361,
     ury: -636.48,
   width: 50.5269,
  height: 11.766
},
otherDiagnosisPOAA:{ 
     llx: 126.73,
     lly: -648.246,
     urx: 134.002,
     ury: -636.48,
   width: 7.272,
  height: 11.766
},
otherDiagnosisCodeB:{ 
     llx: 133.599,
     lly: -648.246,
     urx: 184.126,
     ury: -636.48,
   width: 50.527,
  height: 11.766
},
otherDiagnosisPOAB:{ 
     llx: 183.953,
     lly: -648.246,
     urx: 191.225,
     ury: -636.48,
   width: 7.272,
  height: 11.766
},
otherDiagnosisCodeC:{ 
     llx: 190.802,
     lly: -648.246,
     urx: 241.51,
     ury: -636.48,
   width: 50.708,
  height: 11.766
},
otherDiagnosisPOAC:{ 
     llx: 241.916,
     lly: -648.246,
     urx: 249.188,
     ury: -636.48,
   width: 7.272,
  height: 11.766
},
otherDiagnosisCodeD:{ 
     llx: 249.073,
     lly: -648.246,
     urx: 299.595,
     ury: -636.48,
   width: 50.522,
  height: 11.766
},
otherDiagnosisPOAD:{ 
     llx: 299.47,
     lly: -648.246,
     urx: 306.742,
     ury: -636.48,
   width: 7.272,
  height: 11.766
},
otherDiagnosisCodeE:{ 
     llx: 306.464,
     lly: -648.246,
     urx: 356.992,
     ury: -636.48,
   width: 50.528,
  height: 11.766
},
otherDiagnosisPOAE:{ 
     llx: 356.869,
     lly: -648.246,
     urx: 364.141,
     ury: -636.48,
   width: 7.272,
  height: 11.766
},
otherDiagnosisCodeF:{ 
     llx: 364.23,
     lly: -648.246,
     urx: 414.757,
     ury: -636.48,
   width: 50.527,
  height: 11.766
},
otherDiagnosisPOAF:{ 
     llx: 414.807,
     lly: -648.246,
     urx: 422.079,
     ury: -636.48,
   width: 7.272,
  height: 11.766
},
otherDiagnosisCodeG:{ 
     llx: 421.614,
     lly: -648.246,
     urx: 472.617,
     ury: -636.48,
   width: 51.003,
  height: 11.766
},
otherDiagnosisPOAG:{ 
     llx: 472.213,
     lly: -648.246,
     urx: 479.485,
     ury: -636.48,
   width: 7.272,
  height: 11.766
},
otherDiagnosisCodeH:{ 
     llx: 479.703,
     lly: -648.246,
     urx: 530.708,
     ury: -636.48,
   width: 51.005,
  height: 11.766
},
otherDiagnosisPOAH:{ 
     llx: 530.636,
     lly: -648.246,
     urx: 537.908,
     ury: -636.48,
   width: 7.272,
  height: 11.766
},
otherDiagnosisCodeI:{ 
     llx: 18.4421,
     lly: -660.695,
     urx: 68.9691,
     ury: -648.929,
   width: 50.527,
  height: 11.766
},
otherDiagnosisPOAI:{ 
     llx: 69.3541,
     lly: -660.695,
     urx: 76.6261,
     ury: -648.929,
   width: 7.272,
  height: 11.766
},
otherDiagnosisCodeJ:{ 
     llx: 75.8341,
     lly: -660.695,
     urx: 126.361,
     ury: -648.929,
   width: 50.5269,
  height: 11.766
},
otherDiagnosisPOAJ:{ 
     llx: 126.73,
     lly: -660.695,
     urx: 134.002,
     ury: -648.929,
   width: 7.272,
  height: 11.766
},
otherDiagnosisCodeK:{ 
     llx: 133.599,
     lly: -660.695,
     urx: 184.126,
     ury: -648.929,
   width: 50.527,
  height: 11.766
},
otherDiagnosisPOAK:{ 
     llx: 183.953,
     lly: -660.695,
     urx: 191.225,
     ury: -648.929,
   width: 7.272,
  height: 11.766
},
otherDiagnosisCodeL:{ 
     llx: 190.983,
     lly: -660.695,
     urx: 241.51,
     ury: -648.929,
   width: 50.527,
  height: 11.766
},
otherDiagnosisPOAL:{ 
     llx: 241.916,
     lly: -660.695,
     urx: 249.188,
     ury: -648.929,
   width: 7.272,
  height: 11.766
},
otherDiagnosisCodeM:{ 
     llx: 249.073,
     lly: -660.695,
     urx: 299.595,
     ury: -648.929,
   width: 50.522,
  height: 11.766
},
otherDiagnosisPOAM:{ 
     llx: 299.47,
     lly: -660.695,
     urx: 306.742,
     ury: -648.929,
   width: 7.272,
  height: 11.766
},
otherDiagnosisCodeN:{ 
     llx: 306.464,
     lly: -660.695,
     urx: 357.089,
     ury: -648.929,
   width: 50.625,
  height: 11.766
},
otherDiagnosisPOAN:{ 
     llx: 356.869,
     lly: -660.695,
     urx: 364.141,
     ury: -648.929,
   width: 7.272,
  height: 11.766
},
otherDiagnosisCodeO:{ 
     llx: 364.23,
     lly: -660.695,
     urx: 414.757,
     ury: -648.929,
   width: 50.527,
  height: 11.766
},
otherDiagnosisPOAO:{ 
     llx: 414.807,
     lly: -660.695,
     urx: 422.079,
     ury: -648.929,
   width: 7.272,
  height: 11.766
},
otherDiagnosisCodeP:{ 
     llx: 421.614,
     lly: -660.695,
     urx: 472.619,
     ury: -648.929,
   width: 51.005,
  height: 11.766
},
otherDiagnosisPOAP:{ 
     llx: 472.213,
     lly: -660.696,
     urx: 479.485,
     ury: -648.93,
   width: 7.272,
  height: 11.766
},
otherDiagnosisCodeQ:{ 
     llx: 479.703,
     lly: -660.695,
     urx: 530.708,
     ury: -648.929,
   width: 51.005,
  height: 11.766
},
otherDiagnosisPOAQ:{ 
     llx: 530.636,
     lly: -660.695,
     urx: 537.908,
     ury: -648.929,
   width: 7.272,
  height: 11.766
},
reserved364:{ 
     llx: 545.95,
     lly: -648.246,
     urx: 601.309,
     ury: -636.48,
   width: 55.359,
  height: 11.766
},
reserved365:{ 
     llx: 537.814,
     lly: -660.695,
     urx: 601.311,
     ury: -648.929,
   width: 63.497,
  height: 11.766
},
admittingDiagnosisCode:{ 
     llx: 38.4441,
     lly: -672.892,
     urx: 90.3641,
     ury: -661.126,
   width: 51.92,
  height: 11.766
},
patientReasonForVisitA:{ 
     llx: 126.747,
     lly: -672.892,
     urx: 176.623,
     ury: -661.126,
   width: 49.876,
  height: 11.766
},
patientReasonForVisitB:{ 
     llx: 176.991,
     lly: -672.892,
     urx: 226.867,
     ury: -661.126,
   width: 49.876,
  height: 11.766
},
patientReasonForVisitC:{ 
     llx: 227.264,
     lly: -672.892,
     urx: 277.14,
     ury: -661.126,
   width: 49.876,
  height: 11.766
},
PPS_Code:{ 
     llx: 306.217,
     lly: -672.892,
     urx: 342.747,
     ury: -661.126,
   width: 36.53,
  height: 11.766
},
ECI_Code_A:{ 
     llx: 356.994,
     lly: -672.892,
     urx: 407.545,
     ury: -661.126,
   width: 50.551,
  height: 11.766
},
ECI_CodePOA_A:{ 
     llx: 407.1,
     lly: -672.892,
     urx: 414.372,
     ury: -661.126,
   width: 7.272,
  height: 11.766
},
ECI_Code_B:{ 
     llx: 414.365,
     lly: -672.892,
     urx: 464.916,
     ury: -661.126,
   width: 50.551,
  height: 11.766
},
ECI_CodePOA_B:{ 
     llx: 465.449,
     lly: -672.892,
     urx: 472.721,
     ury: -661.126,
   width: 7.272,
  height: 11.766
},
ECI_Code_C:{ 
     llx: 472.12,
     lly: -672.892,
     urx: 522.671,
     ury: -661.126,
   width: 50.551,
  height: 11.766
},
ECI_CodePOA_C:{ 
     llx: 522.89,
     lly: -672.892,
     urx: 530.162,
     ury: -661.126,
   width: 7.272,
  height: 11.766
},
reserved377:{ 
     llx: 539.855,
     lly: -672.892,
     urx: 601.876,
     ury: -661.126,
   width: 62.021,
  height: 11.766
},
mainProcedureCode:{ 
     llx: 10.5011,
     lly: -696.515,
     urx: 68.6261,
     ury: -684.749,
   width: 58.125,
  height: 11.766
},
mainProcedureDate:{ 
     llx: 68.9941,
     lly: -696.515,
     urx: 118.87,
     ury: -684.749,
   width: 49.8759,
  height: 11.766
},
otherProcedureCodeA:{ 
     llx: 119.617,
     lly: -696.515,
     urx: 176.99,
     ury: -684.749,
   width: 57.373,
  height: 11.766
},
otherProcedureDateA:{ 
     llx: 176.994,
     lly: -696.515,
     urx: 226.87,
     ury: -684.749,
   width: 49.876,
  height: 11.766
},
otherProcedureCodeB:{ 
     llx: 227.617,
     lly: -696.515,
     urx: 284.99,
     ury: -684.749,
   width: 57.373,
  height: 11.766
},
otherProcedureDateB:{ 
     llx: 284.994,
     lly: -696.515,
     urx: 334.87,
     ury: -684.749,
   width: 49.876,
  height: 11.766
},
otherProcedureCodeC:{ 
     llx: 10.5011,
     lly: -720.145,
     urx: 68.6261,
     ury: -708.379,
   width: 58.125,
  height: 11.766
},
otherProcedureCodeC:{ 
     llx: 68.9941,
     lly: -720.145,
     urx: 118.87,
     ury: -708.379,
   width: 49.8759,
  height: 11.766
},
otherProcedureCodeD:{ 
     llx: 119.617,
     lly: -720.145,
     urx: 176.99,
     ury: -708.379,
   width: 57.373,
  height: 11.766
},
otherProcedureDateD:{ 
     llx: 176.994,
     lly: -720.145,
     urx: 226.87,
     ury: -708.379,
   width: 49.876,
  height: 11.766
},
otherProcedureCodeE:{ 
     llx: 227.617,
     lly: -720.145,
     urx: 284.99,
     ury: -708.379,
   width: 57.373,
  height: 11.766
},
otherProcedureDateE:{ 
     llx: 284.994,
     lly: -720.145,
     urx: 334.87,
     ury: -708.379,
   width: 49.876,
  height: 11.766
},
reserved390:{ 
     llx: 335.25,
     lly: -720.369,
     urx: 371.25,
     ury: -678.756,
   width: 36,
  height: 41.613
},
attendingProviderNPI:{ 
     llx: 433.126,
     lly: -685.261,
     urx: 507.361,
     ury: -673.495,
   width: 74.235,
  height: 11.766
},
attendingProvider2ndIdQual:{ 
     llx: 522.068,
     lly: -685.261,
     urx: 537.188,
     ury: -673.495,
   width: 15.12,
  height: 11.766
},
attendingProvider2ndId:{ 
     llx: 537.31,
     lly: -685.261,
     urx: 601.49,
     ury: -673.495,
   width: 64.18,
  height: 11.766
},
attendingProviderLastName:{ 
     llx: 389.811,
     lly: -696.515,
     urx: 500.617,
     ury: -684.749,
   width: 110.806,
  height: 11.766
},
attendingProviderFirstName:{ 
     llx: 517.539,
     lly: -696.515,
     urx: 601.493,
     ury: -684.749,
   width: 83.954,
  height: 11.766
},
opPhysicianNPI:{ 
     llx: 433.126,
     lly: -708.892,
     urx: 507.361,
     ury: -697.126,
   width: 74.235,
  height: 11.766
},
opPhysician2ndIdQual:{ 
     llx: 522.068,
     lly: -708.892,
     urx: 537.188,
     ury: -697.126,
   width: 15.12,
  height: 11.766
},
opPhysician2ndId:{ 
     llx: 537.31,
     lly: -708.892,
     urx: 601.49,
     ury: -697.126,
   width: 64.18,
  height: 11.766
},
opPhysicianLastName:{ 
     llx: 389.811,
     lly: -720.882,
     urx: 500.617,
     ury: -709.116,
   width: 110.806,
  height: 11.766
},
opPhysicianFirstName:{ 
     llx: 517.539,
     lly: -720.882,
     urx: 601.493,
     ury: -709.116,
   width: 83.954,
  height: 11.766
},
otherProvider1Type:{ 
     llx: 407.575,
     lly: -732.889,
     urx: 421.609,
     ury: -721.123,
   width: 17.0, //14.034,
  height: 11.766
},
otherProvider1NPI:{ 
     llx: 433.126,
     lly: -732.889,
     urx: 507.361,
     ury: -721.123,
   width: 74.235,
  height: 11.766
},
otherProvider12ndIdQual:{ 
     llx: 522.068,
     lly: -732.889,
     urx: 537.188,
     ury: -721.123,
   width: 15.12,
  height: 11.766
},
otherProvider12ndId:{ 
     llx: 537.31,
     lly: -732.889,
     urx: 601.49,
     ury: -721.123,
   width: 64.18,
  height: 11.766
},
otherProvider1LastName:{ 
     llx: 389.811,
     lly: -744.892,
     urx: 500.617,
     ury: -733.126,
   width: 110.806,
  height: 11.766
},
otherProvider1FirstName:{ 
     llx: 517.539,
     lly: -744.892,
     urx: 601.493,
     ury: -733.126,
   width: 83.954,
  height: 11.766
},
otherProvider2Type:{ 
     llx: 407.575,
     lly: -756.764,
     urx: 421.609,
     ury: -744.998,
   width: 14.034,
  height: 11.766
},
otherProvider2NPI:{ 
     llx: 433.126,
     lly: -756.764,
     urx: 507.361,
     ury: -744.998,
   width: 74.235,
  height: 11.766
},
otherProvider22ndIdQual:{ 
     llx: 522.068,
     lly: -756.895,
     urx: 537.188,
     ury: -745.129,
   width: 15.12,
  height: 11.766
},
otherProvider22ndId:{ 
     llx: 537.31,
     lly: -756.764,
     urx: 601.49,
     ury: -744.998,
   width: 64.18,
  height: 11.766
},
otherProvider2LastName:{ 
     llx: 389.811,
     lly: -768.515,
     urx: 500.617,
     ury: -756.749,
   width: 110.806,
  height: 11.766
},
otherProvider2FirstName:{ 
     llx: 517.539,
     lly: -768.515,
     urx: 601.493,
     ury: -756.749,
   width: 83.954,
  height: 11.766
},
remarks1:{ 
     llx: 47.0441,
     lly: -733.33,
     urx: 184.186,
     ury: -721.123,
   width: 137.1419,
  height: 12.207
},
remarks2:{ 
     llx: 12.7041,
     lly: -745.333,
     urx: 184.186,
     ury: -733.126,
   width: 171.4819,
  height: 12.207
},
remarks3:{ 
     llx: 12.7041,
     lly: -757.205,
     urx: 184.186,
     ury: -744.998,
   width: 171.4819,
  height: 12.207
},
remarks4:{ 
     llx: 12.7041,
     lly: -768.956,
     urx: 184.186,
     ury: -756.749,
   width: 171.4819,
  height: 12.207
},
codeQualifier1:{ 
     llx: 198.745,
     lly: -732.889,
     urx: 211.872,
     ury: -721.123,
   width: 13.127,
  height: 11.766
},
codeQualifier2:{ 
     llx: 198.745,
     lly: -744.892,
     urx: 211.872,
     ury: -733.126,
   width: 13.127,
  height: 11.766
},
codeQualifier3:{ 
     llx: 198.745,
     lly: -756.764,
     urx: 211.872,
     ury: -744.998,
   width: 13.127,
  height: 11.766
},
codeQualifier4:{ 
     llx: 198.745,
     lly: -768.515,
     urx: 211.872,
     ury: -756.749,
   width: 13.127,
  height: 11.766
},
code1:{ 
     llx: 212.691,
     lly: -732.889,
     urx: 284.879,
     ury: -721.123,
   width: 72.188,
  height: 11.766
},
code2:{ 
     llx: 212.691,
     lly: -744.892,
     urx: 284.879,
     ury: -733.126,
   width: 72.188,
  height: 11.766
},
code3:{ 
     llx: 212.691,
     lly: -756.764,
     urx: 284.879,
     ury: -744.998,
   width: 72.188,
  height: 11.766
},
code4:{ 
     llx: 212.691,
     lly: -768.515,
     urx: 284.879,
     ury: -756.749,
   width: 72.188,
  height: 11.766
},
value1:{ 
     llx: 285.31,
     lly: -732.889,
     urx: 371.246,
     ury: -721.123,
   width: 85.936,
  height: 11.766
},
value2:{ 
     llx: 285.31,
     lly: -744.892,
     urx: 371.246,
     ury: -733.126,
   width: 85.936,
  height: 11.766
},
value3:{ 
     llx: 285.31,
     lly: -756.764,
     urx: 371.246,
     ury: -744.998,
   width: 85.936,
  height: 11.766
},
value4:{ 
     llx: 285.31,
     lly: -768.515,
     urx: 371.246,
     ury: -756.749,
   width: 85.936,
  height: 11.766
}
};
var obj = {
  
};
obj.test = function(  ) {
  var doc = new PDFDocument({autoFirstPage: false});
  doc.fontSize(10);
  doc.font('Times-Roman');
  doc.addPage({margins:{top:18, bottom:18, left:22, right:18}});
  Object.keys(ub04FldCfg).forEach(fldName=>{
    var fldObj = ub04FldCfg[fldName];
    doc.text(fldName, fldObj.llx, -fldObj.ury, { width: fldObj.width, height: fldObj.height});
  });
  doc.pipe( fs.createWriteStream('c:/Temp/pdftest.pdf'))
  doc.end();
}
obj.createUB04 = function() {
  var doc = new PDFDocument({autoFirstPage: false});
  doc.fontSize(10);
  doc.font('Times-Roman');
  doc.addPage({margins:{top:18, bottom:18, left:22, right:18}});
  return doc;
}
obj.writeFields = function( doc, fldMap, oscSetup ) {
  var writeField = function( fldName, text ) {
    var fldObj = ub04FldCfg[fldName];
    if (fldObj) {
      var x = Number(((fldObj.llx + ((oscSetup.ub04OffsetX || 0)*72))*oscSetup.ub04ScalingFactor).toFixed(3));
      var y = Number(((fldObj.ury + ((oscSetup.ub04OffsetY || 0)*72))*oscSetup.ub04ScalingFactor).toFixed(3));
      doc.text(text, x, -y, { width: fldObj.width, height: fldObj.height});
    } else {
      console.log("Unknown UB04 field "+fldName);
    }
  }
    Object.keys(fldMap).forEach(fld=>{
    writeField( fld, fldMap[fld]);
  })
}
export default obj;