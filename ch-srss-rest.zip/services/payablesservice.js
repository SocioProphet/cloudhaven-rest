import PatientCase from '../models/patientcase'
import moment from 'moment'
import VendorFee from '../models/vendorfee'
import {getFeeAmount} from "../js/utils"
import mongoose from 'mongoose'

var obj = {
};
obj.createPayables = function( patientCase ) {
  var vendorsToDelete = null;
  var payables = [];

  return PatientCase.findById( patientCase._id )
  .populate({path:'primaryPayer.claimsPayer', select:{contractedRate:1}})
  .populate({path: 'procedure'})
  .populate({path: 'vendorFees.vendor'})
  .populate({path: 'payables.vendor'})
  .then((patientCase)=>{
    var bookedCnt = patientCase.vendorFees.length;
    var requiredOrgCnt = patientCase.requiredVendorTypes.length;
     
    if (bookedCnt < requiredOrgCnt) {
      return {errMsg:`The number of booked vendors (${bookedCnt}) does not match the number required (${requiredOrgCnt}) for this treatment package.`}
    }
    var contractedRate = patientCase.primaryPayer.contractedRate || 0;
    var vendorFees = patientCase.vendorFees.map((pf)=>{
      return {org:pf.vendor, feeAmount:getFeeAmount(pf.fee, contractedRate)};
    })
    var origVendorMap = patientCase.payables?patientCase.payables.reduce((mp,p)=>{
      var v = p.vendor._id.toString();
      mp[v] = v;
      return mp;
    },{}):{};
    var vendorFeeTotal = vendorFees.reduce(function(t,orgFee){
      var vendorId = orgFee.org.id;
      t += orgFee.feeAmount;
      if (!origVendorMap[vendorId]) {
        payables.push({patientCase: patientCase._id, vendor: orgFee.org, amount:orgFee.feeAmount})
      }
      delete origVendorMap[vendorId];
      return t;
    },0.0)
    vendorsToDelete = Object.keys(origVendorMap);
    var bmcRemainder = contractedRate - vendorFeeTotal;
    if (bmcRemainder < 0) {
      return {errMsg: `The sum of vendor payables (${vendorFeeTotal})is greater than the contracted rate (${contractedRate}).`};
    }
    var promises = [];
    if (vendorsToDelete.length>0) {
      var vendorToPayablesMap = patientCase.payables.reduce((mp,p)=>{
        mp[p.vendor.id] = p.id;
        return mp;
      },{})
      var payablesToDelete = vendorsToDelete.map(v=>(vendorToPayablesMap[v]))
      promises.push(PatientCase.findOneAndUpdate({_id:patientCase._id}, {$pull:{payables:{'_id': {$in:payablesToDelete}}}}))
    }
    return Promise.all(promises)
    .then((result)=>{
      return PatientCase.findOneAndUpdate({_id:patientCase._id}, {$push:{payables: {$each:payables}}}, {new:true})
      .populate({path: 'payables.vendor'})
      .then((newPC)=>{
        if (patientCase.opReportUploaded) {
          var update = {$set:{}};
          for (var i=0;i<newPC.payables.length;i++) {
            var vd = newPC.payables[i];
            var paymentTerms = vd.vendor.paymentTerms;
            update['$set']['payables.'+i+'.apClockStartDate'] =  newPC.calendarBooking.day;
            update['$set']['payables.'+i+'.dueDate'] = moment(newPC.calendarBooking.day).add(paymentTerms||0, 'days').toDate();
          }
          return PatientCase.findOneAndUpdate({_id:patientCase._id}, update);
        }
        return mongoose.Promise.resolve(true);
      })
    })
  })
}

export default obj;
