import { NotificationConfig } from '../models/notificationconfig'
import NotificationRequest from '../models/notificationrequest'
import NotificationService from './notificationservice'
import PatientCase from '../models/patientcase'
import NotificationType from '../models/notificationtype'
//import ClearingHouse from './clearinghouse'
import Logger from './eventlogger'
import moment from 'moment';
import mongoose from 'mongoose';
import {safeRef} from "../js/utils";
import patient from '../models/patient'

var obj = {};
obj.doOverduePayablesNotifications = function() {
  console.log('entered doOverduePayablesNotifications');
  Logger.log('Daily Job', 'Running Overdue payables notification job.');
  PatientCase.find({'payables.overdueNotificationSent':false, 'payables.datePaid':{$eq:null}, 'payables.dueDate':{$lt:new Date()}})
  .populate('payables.vendor')
  .populate({path:'patient', select:{patientId:1}})
  .then(patientCases=>{
    var today = moment().startOf('day');
    if (patientCases.length>0) {
      NotificationType.findOne({name:'A/P Overdue Payment Notification'})
      .then(notificationType=>{
        if (!notificationType) {
          Logger.error('Daily Job - overdue payables', 'Notification type A/P Overdue Payment Notification not defined.');
          return;
        }
        var emails = [];
        var payableIds = [];
        var patientCaseIds = {};
        var promises = patientCases.reduce(function(ar,patientCase){
          ar = ar.concat(patientCase.payables.filter(payable=>(!payable.overdueNotificationSent && !payable.datePaid && payable.dueDate<today))
            .map(payable=>{
              var contact = payable.vendor.contacts.find(contact=>(contact.contactType=='Primary'));
              if (!contact || !safeRef(contact.contactInfo).email) {
                Logger.error('Daily Job - overdue payables', "No email contact found for "+payable.vendor.name+' in overdue payables notifications.');
              } else {
                emails.push(contact.contactInfo.email||'');
              }
              payableIds.push(payable._id);
              patientCaseIds[patientCase._id] = patientCase._id;
              return NotificationService.populateTemplate( {patientCase:patientCase, vendor:payable.vendor, payable:payable, template:notificationType.content});
            })
          );
          return ar;
        }, []);
        patientCaseIds = Object.keys(patientCaseIds).map(id=>(patientCaseIds[id]));
        if (patientCaseIds.length>0 && payableIds.length>0) {
          promises.push(PatientCase.updateMany({_id:{$in:patientCaseIds}}, 
            {$set:{'payables.$[elem].overdueNotificationSent':true}},
            {arrayFilters: [{'elem._id':{$in:payableIds}}]}))
        }
        mongoose.Promise.all(promises)
        .then(results=>{
          var emailList = [];
          for (var i=0;i<emails.length;i++) {
            if (emails[i]) {
              emailList.push( {destEmail:emails[i], subject:notificationType.subject, body:results[i], fromEmail:notificationType.fromEmail} );
            }
          }
          NotificationService.throttledSendEmails( emailList )
          .then(result => {
            Logger.log('Daily Job', 'Overdue payables notification job completed successfully.');
          })
        })
      })
      .catch((error)=>{
        Logger.error('Daily Job - overdue payables', error+'');
      })
    } else {
      Logger.log('Daily Job', 'Overdue payables notification job completed successfully (no cases).');
    }
  })
  .catch((error)=>{
    Logger.error('Daily Job - overdue payables', error+'');
  })
}

obj.doScheduledNotifications = function(onDemand) {
  Logger.log('Daily Job', 'Disabled.');
  if (true) return;
  Logger.log('Daily Job', 'Running scheduled notifications');
  var scheduledNotifications = Object.keys(NotificationConfig).reduce((ar,event)=>ar.concat(NotificationConfig[event].filter(config=>config.daysTrigger)), []);
  if (scheduledNotifications.length==0) {
    Logger.log('Daily Job', 'Scheduled notifications completed successfully (no notifications found).');
    return;
  }
  var dayBounds = scheduledNotifications.reduce((ar,config)=>{
    config.daysTrigger.forEach(dayTrigger=>{
      if (ar[0]==null || dayTrigger<ar[0]) {
        ar[0] = dayTrigger;
      }
      if (ar[1]==null || dayTrigger>ar[1]) {
        ar[1] = dayTrigger;
      }
    })
    return ar;
  }, [null,null]);
  var mToday = moment().startOf('day');

  var dateLowBound = moment(mToday).subtract(dayBounds[1], 'days').toDate();
  var dateHighBound = moment(mToday).subtract(dayBounds[0]-1, 'days').toDate();
  PatientCase.find({'calendarBooking.day':{$gte:dateLowBound, $lt:dateHighBound}, 'calendarBooking.status':'Booked', status: {$in:['Open', 'Closed']}})
  .then(patientCases=>{
    if (patientCases.length==0) return null;
    var patientCaseIds = patientCases.map(patientCase=>patientCase._id);
    var notificationTypesMap = {};
    var notificationCount = 0;
    var caseNotificationsMap = patientCases.reduce((mp,patientCase)=>{
      var patientCaseId = patientCase.caseId;
      scheduledNotifications.forEach((notification)=>{
        notification.daysTrigger.forEach((dayTrigger)=>{
          if (mToday.isSame(moment(patientCase.calendarBooking.day).add(dayTrigger, 'days'), 'day')) {
            notificationCount++;
            var list = mp[patientCaseId] || (mp[patientCaseId]=[]);
            list.push({dayTrigger:dayTrigger, notification:notification});
            notificationTypesMap[notification.notificationType]=true;
          }
        })
      })
      return mp;
    }, {});
    if (notificationCount==0) {
      Logger.log('Daily Job - scheduled notifications', 'Scheduled notifications completed successfully (no notifications found).');
      return null;
    }
    var nTypes = Object.keys(notificationTypesMap);
    NotificationRequest.find({patientCase:{$in:patientCaseIds}, notificationType:{$in:nTypes}, dayTrigger:{$ne:null}})
    .then((notificationRequests)=>{
      var existingRequestMap = notificationRequests.reduce((mp,request)=>{
        mp[request.patientCase.toString()+':'+request.notificationType+':'+request.dayTrigger] = true;
        return mp;
      },{});
      return existingRequestMap;
    })
    .then((existingRequestMap)=>{
//      existingRequestMap = {};
//      console.log("!!!!!!!!!!!!!!!!!! DELETE ME !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
      var logLines = [];
      patientCases.forEach((patientCase)=>{
        logLines.push('Scheduled Notifications for Case # '+patientCase.caseId);
        var notifications = caseNotificationsMap[patientCase.caseId] || [];
        var caseUnsentList = notifications.filter((notification)=>(!existingRequestMap[patientCase._id.toString()+':'+notification.notification.notificationType+':'+notification.dayTrigger]));
        logLines.push(caseUnsentList.map(o=>(o.notification.notificationType)));
        if (onDemand) {
          console.log(`Sending ${caseUnsentList.length} notifications for case ${patientCase.caseId}...`);
        } else {
          Logger.log('Daily Job', logLines.join('\n'));
        }
        if (caseUnsentList.length>0) {
          var configList = caseUnsentList.map(o=>Object.assign({dayTrigger:o.dayTrigger}, o.notification))
          NotificationService.createNotificationsFromConfig(patientCase._id, configList);
        }
      });
      Logger.log('Daily Job', 'Scheduled notifications completed successfully.');
    })
    .catch((error)=>{
      Logger.error('Daily Job - scheduled notifications', error+'');
    })
  })
  .catch((error)=>{
    Logger.error('Daily Job - scheduled notifications', error+'');
  })
}
obj.dailyJob = function(onDemand) {
  Logger.log('Daily Job', 'Running daily job');
  console.log('Daily Job', 'Running daily job');
  try {
    obj.doScheduledNotifications(onDemand);
    obj.doOverduePayablesNotifications();  
  } catch (e) {
    Logger.error('Daily Job - scheduled notifications', e+'');
  }
//  ClearingHouse.getClaimsStatus();
}
export default obj;