import PatientCase from '../models/patientcase'
import Logger from './eventlogger'
import moment from 'moment';
import ftpClient  from 'ssh2-sftp-client'
import Bottleneck from "bottleneck"
import sequence from 'promise-sequence'
//import fs from 'fs'

var obj = {};

const downloadDir = 'Download';
var eventCodeMap = {
  'A-I':' ACCEPTED BY INTERMEDIARY',
  'A-P':' RECEIVED BY PAYER',
  'A-R':' CLAIM ACCEPTED BY REPRICER',
  'A-T':' CLAIM PASSED ALL EDITS',
  'A-T':' CLAIM PASSED ALL EDITS AFTER BEING REPRICED',
  'AM-P':' RECEIVED BY PAYER',
  'AT-T':' CLAIM PASSED ALL EDITS ANDWAS UPLOADED IN A TEST FILE AND WILL NOT BE FORWARDED',
  'B-T':' CLAIM BUILT',
  'C':' CLAIM CANCELLED',
  'D-P':' CLAIM DENIED BY PAYER',
  'FI-I':' CLAIM SENT TO AN INTERMEDIARY',
  'FI-T':' CLAIM SENT TO AN INTERMEDIARY',
  'FP-I':' INTERMEDIARY SENT CLAIM TO THE PAYER',
  'FP-R':' REPRICER SENT CLAIM TO THE PAYER',
  'FP-T':' CLAIM SENT TO THE PAYER',
  'FPM-I':' CLAIM TO BE PRINTED AND MAILED',
  'FPM-R ':' CLAIM PRINTED AND MAILED TO PAYER',
  'FR-T':' CLAIM SENT TO A REPRICER',
  'H-I':' RECEIVED BY INTERMEDIARY',
  'H-P':' CLAIM PENDED BY PAYER',
  'H-R':' CLAIM PENDED BY REPRICER',
  'I-I':' INFORMATIONAL',
  'I-P':' INFORMATIONAL',
  'K-I':' RECEIVED BY INTERMEDIARY',
  'K-P':' RECEIVED BY PAYER',
  'K-R':' RECEIVED BY REPRICER',
  'P-P':' PAID BY PAYER',
  'P-R':' CLAIM PRICED BY REPRICER',
  'Q':' TEST CLAIM DELETED',
  'R-I':' CLAIM REJECTED BY INTERMEDIARY',
  'R-P':' CLAIM REJECTED BY PAYER',
  'R-R':' CLAIM REJECTED BY REPRICER',
  'R-T':' CLAIM REJECTED BY SECOND EDITS',
  'R-TCI':' CLAIM REJECTED BY SECOND EDITS-CCI',
  'R-TCL':' CLAIM REJECTED BY SECOND EDITS-LCD',
  'R-TCN':' CLAIM REJECTED BY SECOND EDITS-NCD',
  'R-TPQ':' CLAIM REJECTED BY SECOND EDITS',
  'R-Z':' CLAIM REJECTED BY FIRST EDITS',
  'RF-I':' CLAIM REJECTED BY INTERMEDIARY',
  'RT-T':' CLAIM REJECTED BY SECOND EDITS',
  'T-T':' INSTANCE TERMINATED. NEW INSTANCE WILL BE RESUBMITTED',
  'X-T':' INSTANCE TERMINATED',
  'XR-T':' INSTANCE RESUBMITTED BY REPRICER',
  'Z-P':' CLAIM PROCESSING COMPLETE'
};
function processClaimResponse(sftp, fileName, claimResponse) {
  console.log('processing claim response');
  var lines = claimResponse.split('\r\n');
  console.log(lines.length+' lines found');
  var caseEventsMap = {};
  for (var i=1;i<lines.length;i++) {
    var parts = lines[i].split('|');
    if (!parts[i] || parts.length<12) continue;
    var caseId = parts[4].substring(0,parts[4].length-1);
    var payerSelectorCode = parts[4].substring(parts[4].length-1);
    
    var statusList = caseEventsMap[caseId] || (caseEventsMap[caseId]=[]);
    statusList.push({
      event: eventCodeMap[parts[0]],
      datetime: moment( parts[1], 'MM/DD/YYYY HH:mm:ss.SSS').toDate(),
      messages: parts[2].split('~'),
      payerSelector: payerSelectorCode=='P'?'primaryPayer':'secondaryPayer'
    })
  }
  var caseIds = Object.keys(caseEventsMap);
console.log(caseIds.length+ ' case Ids: '+caseIds.join(','));
  if (caseIds.length==0) {
    return sftp.delete('/'+downloadDir+'/'+fileName)
    .then(()=>{
      return Promise.resolve(true)
    })
    .catch((err)=>{
      console.log('File delete error '+err);
      return Promise.resolve(true);
    })
  }
  var updPromises = [];
  return PatientCase.find({caseId:{$in:caseIds}}, {caseId:1, primaryPayer:1, secondaryPayer:1})
  .populate()
  .then(patientCases=>{
    patientCases.forEach(pc=>{
      var update = {'$push':{}};
      var gotOne = false;
      ['primaryPayer', 'secondaryPayer'].forEach(payerSelector=>{
        if (payerSelector=='secondaryPayer' && !pc.secondaryPayer.claimsPayer) return;
        var existingEventsMap = pc[payerSelector].claimHistory.reduce((mp,ch)=>{
          mp[ch.datetime.getTime()] = ch;
          return mp;
        },{});
        var addList = (caseEventsMap[pc.caseId]||[]).filter((ev)=>{
          var millis = ev.datetime.getTime();
          return ev.payerSelector==payerSelector && existingEventsMap[millis]==null;
        });
        if (addList.find(ev=>(ev.event=='CLAIM PROCESSING COMPLETE'))) {
          update['$set'] = {};
          update['$set'][payerSelector] = {claimProcessed:true};
        }
        if (addList.length>0) {
          addList.forEach(e=>{
            delete e.payerSelector;
          })
          update['$push'][payerSelector+'.claimHistory'] = {$each:addList};
          gotOne = true;
        }
      })
      if (gotOne) {
        updPromises.push(PatientCase.findByIdAndUpdate( pc._id, update));
      }
    });
    return sequence(updPromises);
  })
  .then(results=>{
    console.log('deleting /'+downloadDir+'/'+fileName);
    return sftp.delete('/'+downloadDir+'/'+fileName)
    .then(result=>{
      return Promise.resolve(true)
    })
    .catch((err)=>{
      console.log(err);
      return Promise.resolve(false);
    })
  })
  .catch((err)=>{
    console.log(err);
    return Promise.resolve(true);
  })
}
function getClaimResponse( sftp, fileName ) {
  var promise = new Promise(function( resolve, reject){
    console.log('Getting /'+downloadDir+'/'+fileName);
    sftp.get('/'+downloadDir+'/'+fileName) //mongoose.Promise.resolve(fs.createReadStream('C:\\tmp\\'+fileName)) //
    .then(readableStream=>{
      var claimResponse = '';
      readableStream.on('data', (chunk) => {
        claimResponse+=chunk;
      });
      readableStream.on('end', ()=>{
        var result = processClaimResponse(sftp, fileName, claimResponse);
        resolve(result);
      });
    })
    .catch((err)=>{
      Logger.error('Claim Status', 'Failed to retrieve claim status file ('+fileName+')');
      return Promise.resolve(true);
    })
  });
  return promise;
}
obj.getClaimsStatus = function() {
  var promise = new Promise(function( resolve, reject){
    let sftp = new ftpClient();
    sftp.connect({
      host: process.env.CLAIMS_FTP_DOMAIN,
      port: '22',
      username: process.env.CLAIMS_FTP_USER,
      password: process.env.CLAIMS_FTP_PWD,
      readyTimeout: 99999,
      algorithms: {
        kex: ['diffie-hellman-group16-sha512', 'diffie-hellman-group14-sha256', 'diffie-hellman-group-exchange-sha256', 
              'diffie-hellman-group14-sha1', 'diffie-hellman-group-exchange-sha1'],
        cipher: ['aes256-ctr', 'aes128-ctr', 'aes256-cbc', 'aes128-cbc'],
        serverHostKey: ['ssh-rsa' /*, 'ssh-dss'*/],
        hmac: ['hmac-sha2-512', 'hmac-sha2-256', 'hmac-sha1', 'hmac-sha1-96'],
        compress: ['zlib', 'none']
      }
    }).then(() => {
      return sftp.list('/'+downloadDir)
    }).then((data)=>{
      console.log('Returned list:');
      console.log(data);
      var claimResponseCnt = 0;
      var fileList = data.filter(f=>(f.type=='-'));
      console.log(fileList.length+' files found');
      const limiter = new Bottleneck({
        maxConcurrent: 2,
        minTime: 3000
      });
      var throttledGetClaimResponse = limiter.wrap(getClaimResponse);
      var tasks = fileList.map(f=>(throttledGetClaimResponse(sftp, f.name)));
      if (tasks.length==0) {
        Logger.log('Claim Status', 'No claim status files found.');
        resolve(true);
        return;
      }
      return mongoose.Promise.all(tasks)
      .then(results => {
        results.forEach(result=>{
            claimResponseCnt++;
            if (claimResponseCnt == results.length) {
              Logger.log('Claim Status', `Successfully processed ${claimResponseCnt} claim files:\n`+fileList.map(f=>(f.name)).join('\n'));
              sftp.end();
              resolve(true);
            }
        })
      })
      .catch((err)=>{
        sftp.end();
        Logger.error('Claim Status', 'Claims send failed ('+err.message+')');
        resolve(true);
      });
    }).catch((err) => {
      Logger.error('Claim Status', 'sftp connect failed ('+err.message+')');
      resolve(true);
    });
  });
  return promise;
}

export default obj;