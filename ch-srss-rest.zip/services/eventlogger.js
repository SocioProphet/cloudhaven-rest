import EventLog from '../models/eventlog'

var obj = {};
obj.log = function(category, event) {
  return EventLog.create({event:event, category:category});
}
obj.error = function(category, event) {
  return EventLog.create({type:'Error', event:event, category:category});
}
export default obj;