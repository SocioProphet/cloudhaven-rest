
import PatientCase from '../models/patientcase'
import PayablesService from './payablesservice'
import CaseWorkflowAssignment from '../models/caseworkflowassignment'
import Roles from '../models/workflowroles'
import * as WorkflowStates from '../models/workflowstates'
import {safeRef} from "../js/utils";
import moment from 'moment'
import mongoose from 'mongoose'

const defaultWorkflowStateRoleMap = {
  'Needs Tentative Scheduling': Roles.Scheduler,
  'Payer Info Required': Roles.FCM,
  'Need Patient Acceptance': Roles.FCM,
  'Book Confirmed Date': Roles.Scheduler,
  'Need Payer Authorization': Roles.FCM,
  'Need Secondary Payer Authorization': Roles.FCM,
  'Bill Patient': Roles.AR,
  'Patient Payment Due': Roles.AR,
  'Awaiting Surgery': Roles.AR,
  'Disburse Payments': Roles.AP,
  'Bill Primary Payer': Roles.AR,
  'Primary Payer Payment Due': Roles.AR,
  'Bill Secondary Payer': Roles.AR,
  'Secondary Payer Payment Due': Roles.AR
};

function dataIntegrityCheck( patientCase ) {
  var promise = new mongoose.Promise(function( resolve, reject){
    var promises = [];
    var caseChanged = false;
    if (patientCase.patientTermsAcceptanceDate && patientCase.isOpen) {
      if (!patientCase.payables || patientCase.payables.length==0) {
        promises.push(PayablesService.createPayables( patientCase ));
        caseChanged = true;
      }

      if (patientCase.opReportUploaded) {
        var primaryPayerPaymentDue = patientCase.paymentsDue.find(pd=>(pd.payerType=='Primary Payer'));
        if (primaryPayerPaymentDue && primaryPayerPaymentDue.transactions.length>0) {
          var secondaryPayerPaymentDue = patientCase.paymentsDue.find(pd=>(pd.payerType=='Secondary Payer'));
          if (!secondaryPayerPaymentDue && patientCase.secondaryPayer.claimsPayer && patientCase.secondaryPayer.claimsPayer._id) {
            var patientPaymentDue = patientCase.paymentsDue.find(pd=>(pd.payerType == 'Patient'));
            var patientAmountDue = (patientPaymentDue?patientPaymentDue.amount:0) || 0;
            var primaryPayerAmountDue = (primaryPayerPaymentDue?primaryPayerPaymentDue.amount:0) || 0;
            var secondaryPayerAmt = patientCase.primaryPayer.contractedRate - (patientAmountDue+primaryPayerAmountDue);
            var secondaryPayerAmt =  Number((secondaryPayerAmt||0).toFixed(6));
            var dueDate = moment(primaryPayerPaymentDue.transactions[0].txnDate).add((patientCase.secondaryPayer.claimsPayer.paymentTerms?patientCase.secondaryPayer.claimsPayer.paymentTerms:32),'days').toDate();
            if (patientCase.paymentMethod == 'Insurance') {
               promises.push(PatientCase.updateOne({_id:patientCase._id, 'paymentsDue':{'$not':{'$elemMatch':{'payerType':'Secondary Payer'}}}},
                 {$push:{'paymentsDue': { payerType:'Secondary Payer', amount:secondaryPayerAmt, arClockStartDate: primaryPayerPaymentDue.transactions[0].txnDate, dueDate:dueDate} }}));
                 caseChanged = true;
            }
          }
        }


        var primaryPayerAmt = 0;
        var hasSecondaryPayer = patientCase.secondaryPayer && patientCase.secondaryPayer.claimsPayer && patientCase.secondaryPayer.claimsPayer._id;
        hasSecondaryPayer = hasSecondaryPayer!=null && hasSecondaryPayer!='';
        if (!hasSecondaryPayer) {
          primaryPayerAmt =  patientCase.primaryPayer.contractedRate - patientCase.primaryPayer.totalDueFromPatient;
        } else {
          var patientDueAfterPrimary = patientCase.primaryPayer.totalDueFromPatient;
          var patientDueAfterSecondary = patientCase.secondaryPayer.totalDueFromPatient;
          var secondaryResp = patientDueAfterPrimary - patientDueAfterSecondary;
          primaryPayerAmt = patientCase.primaryPayer.contractedRate - (patientDueAfterSecondary + secondaryResp);
        }
        if (!primaryPayerPaymentDue && patientCase.paymentMethod == 'Insurance' && primaryPayerAmt>0) {
          promises.push(PatientCase.findOneAndUpdate({_id:patientCase._id, 'paymentsDue':{'$not':{'$elemMatch':{'payerType':'Primary Payer'}}}},
            {$push:{'paymentsDue': { payerType:'Primary Payer', amount:primaryPayerAmt} }}));
            caseChanged = true;
        }
      }
    }

    if (caseChanged) {
      mongoose.Promise.all(promises)
      .then((result)=>{
        PatientCase.findOne({_id:patientCase._id})
        .populate({path:'procedure'})
        .populate({path:'vendorFees.vendor'})
        .populate({path:'secondaryPayer.claimsPayer'})
        .then((patientCase)=>{
          resolve(patientCase);
        })
      })
    } else {
      resolve(patientCase);
    }
  })
  return promise;
}
var obj = {
};
obj.updateState = function( patientCaseId ) {
  if ((typeof patientCaseId)=='string') patientCaseId = mongoose.Types.ObjectId(patientCaseId)
    var assignmentsToCreate = [];
    var assignmentsToDelete = [];
    var workflowAssignments = [];
    return PatientCase.findOne({_id:patientCaseId})
    .populate({path:'procedure'})
    .populate({path:'vendorFees.vendor'})
    .populate({path:'secondaryPayer.claimsPayer'})
    .then((patientCase)=> {
      return dataIntegrityCheck( patientCase );
    })
    .then((patientCase)=>{
      const checkState = (test, stateName) => {
          var hasState = workflowAssignments.find((wa)=>(wa.workflowState == stateName));
          if (test) {
              if (!hasState) {
      //            var workflowState = WorkflowStatesConfig[stateName]
                var workflowAssignment = { patientCase: patientCase, 
                                          role: defaultWorkflowStateRoleMap[stateName],
                                          workflowState: stateName};
                assignmentsToCreate.push(workflowAssignment);
                workflowAssignments.push(workflowAssignment);
              }
          } else {
              if (hasState) {
                  var assignment = workflowAssignments.find((wa)=>(wa.workflowState == stateName))
                  if (assignment != null && assignment._id) {
                    assignmentsToDelete.push(assignment);
                    workflowAssignments = workflowAssignments.filter((wa)=>(wa.workflowState != stateName));
                  }
              }
          }
      }
      var neededOrgTypesMap = patientCase.requiredVendorTypes.reduce((mp,orgType)=>{
        mp[orgType] = true;
        return mp;
      },{});
      patientCase.vendorFees.forEach(vb=>{
        delete neededOrgTypesMap[vb.vendor.vendorType];
      });
      var hasReqdOrgTypes = Object.keys(neededOrgTypesMap).length==0;
        return CaseWorkflowAssignment.find( { patientCase: patientCaseId } )
        .then((list)=>{
          var updates = {};
            workflowAssignments = list;
            var isDateScheduled = (hasReqdOrgTypes && patientCase.calendarBooking!=null && patientCase.calendarBooking.day!=null);
            var isBooked = (patientCase.calendarBooking!=null && patientCase.calendarBooking.status == 'Booked');
            var hasPayerInfo = patientCase.primaryPayer && patientCase.primaryPayer.relationshipToPatient;
            var hasSecondaryPayer = patientCase.secondaryPayer.claimsPayer && patientCase.secondaryPayer.claimsPayer._id;
            hasSecondaryPayer = hasSecondaryPayer!=null && hasSecondaryPayer!='';
            checkState ( patientCase.isOpen && (!hasReqdOrgTypes || !isDateScheduled), WorkflowStates.NeedsTentativeScheduling);
            checkState ( patientCase.isOpen && isDateScheduled && patientCase.paymentMethod=='Insurance' && !hasPayerInfo, WorkflowStates.PayerInfoRequired);
            checkState ( patientCase.isOpen && isDateScheduled && (patientCase.paymentMethod=='Cash' || hasPayerInfo) &&
                    !patientCase.patientTermsAcceptanceDate, WorkflowStates.NeedPatientTermsAccept);
            checkState ( patientCase.isOpen && isDateScheduled && patientCase.patientTermsAcceptanceDate && !isBooked, WorkflowStates.BookConfirmedDate);
            var isAuthorized = (patientCase.paymentMethod=='Cash' || safeRef(patientCase.payerInfo).payerAuthorizationDate!=null);
            checkState ( patientCase.isOpen && isDateScheduled && patientCase.patientTermsAcceptanceDate && !isAuthorized, WorkflowStates.InsuranceAuthRequired);
            var isAuthorized2 = (patientCase.paymentMethod=='Cash' || safeRef(patientCase.payerInfo).payerAuthorizationDate2!=null);
            checkState ( patientCase.isOpen && isDateScheduled && patientCase.patientTermsAcceptanceDate && hasSecondaryPayer && !isAuthorized2, WorkflowStates.Insurance2AuthRequired);
  
          
  //          checkState ( patientCase.isOpen && patientCase.patientTermsAcceptanceDate && isAuthorized &&
  //                  isBooked && patientCase.patientAmountNotBilled > 0, WorkflowStates.BillPatient)
          
            checkState ( patientCase.isOpen && patientCase.patientTermsAcceptanceDate && /*isAuthorized &&*/ isBooked && 
                    patientCase.patientAmountDue > 0, WorkflowStates.PatientPaymentDue)
          
            var acceptanceDate = patientCase.patientTermsAcceptanceDate;
            var authDate = safeRef(patientCase.payerInfo).payerAuthorizationDate;
            var patientAmtNotBilled = patientCase.patientAmountNotBilled;
            var opReportUploaded = (patientCase.opReportUploaded)
            var patientPaymentDue = patientCase.paymentsDue.find(pd=>(pd.payerType=='Patient'));
            var balanceDueOk = (()=>{
              if (!patientPaymentDue) return false;
              return patientPaymentDue.currentAmountDue<=0 || (patientPaymentDue.receivableAction=='Monthly Payment Plan' && 
                (patientPaymentDue.creditCardOnFile || patientPaymentDue.promissoryNoteSigned));
            })();
  //          var patientAmountNotBilled = patientCase.patientAmountNotBilled;
            checkState ( patientCase.isOpen && patientCase.patientTermsAcceptanceDate && isAuthorized && (!hasSecondaryPayer || isAuthorized2) && isBooked && (!patientPaymentDue || balanceDueOk) &&
                         patientCase.datePreopReportReceived &&
  //                  patientCase.patientAmountNotBilled == 0 &&
                    !opReportUploaded, WorkflowStates.AwaitingSurgery)
          
            checkState ( patientCase.isOpen && patientCase.paymentMethod=='Insurance' && opReportUploaded && patientCase.primaryPayerAmountNotBilled > 0, WorkflowStates.BillPrimaryPayer );
            var primaryPayerPaymentDue = patientCase.paymentsDue.find(pd=>(pd.payerType=='Primary Payer'));
            var secondaryPayerPaymentDue = patientCase.paymentsDue.find(pd=>(pd.payerType=='Secondary Payer'));
            checkState ( patientCase.isOpen && patientCase.paymentMethod=='Insurance' && opReportUploaded && 
              safeRef(primaryPayerPaymentDue).dateBillSent && patientCase.primaryPayerAmountDue > 0, WorkflowStates.PrimaryPayerPaymentDue);
            checkState ( patientCase.isOpen && patientCase.paymentMethod=='Insurance' && opReportUploaded && 
              patientCase.secondaryPayerAmountNotBilled > 0, WorkflowStates.BillSecondaryPayer );
            checkState ( patientCase.isOpen && patientCase.paymentMethod=='Insurance' && opReportUploaded && 
              safeRef(secondaryPayerPaymentDue).dateBillSent && patientCase.secondaryPayerAmountDue > 0, WorkflowStates.SecondaryPayerPaymentDue);
          
            if (patientCase.isOpen && opReportUploaded &&
  //                  patientCase.patientAmountNotBilled == 0 && 
                    patientCase.patientAmountDue == 0 &&
                    (patientCase.paymentMethod=='Cash' || (patientCase.payerAmountNotBilled == 0 && patientCase.payerAmountDue == 0)) && 
                    patientCase.payableAmountOwed == 0) {
                updates.status = patientCase.status = 'Closed';
                if (!patientCase.dateClosed) {
                  patientCase.dateClosed = updates.dateClosed = new Date();
                }
            }
            if (!patientCase.dateClosed && patientCase.status == 'Closed') {
              updates.dateClosed = new Date();
            }
            if (patientCase.status != 'Closed' && patientCase.dateClosed) {
              updates.dateClosed = null;
            }
            checkState ( patientCase.isOpen && opReportUploaded && patientCase.payableAmountPayable > 0, WorkflowStates.DisbursePayments);

            var promises = [];
            if (assignmentsToDelete.length>0) {
              promises.push(CaseWorkflowAssignment.deleteMany({ '_id': {$in: assignmentsToDelete.map((a)=>a._id)}}));
            }
            if (assignmentsToCreate.length>0) {
              promises.push(CaseWorkflowAssignment.create(assignmentsToCreate));
            }
            updates.hasRequiredResources = hasReqdOrgTypes;
            promises.push(PatientCase.findOneAndUpdate({_id:patientCaseId}, { $set: updates }));
            return mongoose.Promise.all(promises)
          })
        })
}
export default obj;