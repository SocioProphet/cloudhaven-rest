import Vendor from '../models/vendor';
import PatientCase from '../models/patientcase';
import Procedure from '../models/procedure';
import moment from 'moment';
import mongoose from 'mongoose';

var obj = {};
function getAvailableDays( patientCases, vendors, dateLow, dateHigh ) {
  var dateList = [];
  var orgBookingsMap = patientCases.reduce(function(mp, patientCase){
    var day = patientCase.calendarBooking.day;
    patientCase.vendorFees.forEach(pf=>{
      var key = pf.vendor+':'+moment(day).format('YYYY-MM-DD');
      if (!mp[key]) {
        mp[key] = 1;
      } else {
        mp[key]++;
      }
    })
    return mp;
  },{})

  var daysOfWeek = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  var today = moment({h:0, m:0, s:0, ms:0}).toDate();
  var startDate = dateLow;//<today?today:dateLow;
  var nonServiceDatesMap = {};
  var availableServiceDatesMap = {};
  var serviceDateCapacitiesMap = {};
  vendors.forEach(vendor=>{
    vendor.nonServiceDates.forEach(nonServiceDate=>{
      try {
        var key = vendor.id+':'+moment( nonServiceDate.date).format('YYYY-MM-DD');
        nonServiceDatesMap[key] = true;  
      } catch (e) {}
    });
    vendor.serviceDateCapacities.forEach(dateCapacity=>{
      try {
        var capDate = moment(dateCapacity.date).format('YYYY-MM-DD');
        var key = vendor.id+':'+capDate;
        serviceDateCapacitiesMap[key] = dateCapacity.capacity;
      } catch (e) {}
    }, {});
    vendor.availableServiceDates.forEach(serviceDate=>{
      try {
        var key = vendor.id+':'+moment( serviceDate.date).format('YYYY-MM-DD');
        availableServiceDatesMap[key] = true;  
      } catch (e) {}
    });
  });
  var dayCntMap = {};
  for (var date = moment(startDate); moment(date).isBefore(dateHigh); date = moment(date).add(1, 'days')) {
    var dateKey = date.format('l');
    var dayOfWeek = daysOfWeek[date.day()];
    var allOk = true;
    var cnt = 0;
    vendors.forEach(vendor=>{
      if (!allOk) return;
      var vendorOk = true;
      var key = vendor.id+':'+moment(date).format('YYYY-MM-DD');
      if (nonServiceDatesMap[key]) {
        vendorOk = false;
        return;
      }
      if (vendor.vendorType == 'Recovery Suite') {
        var serviceDateCapacity = serviceDateCapacitiesMap[key];
        var bookingsCnt = orgBookingsMap[key] || 0;
        if (serviceDateCapacity!=null) {
          if (bookingsCnt >= serviceDateCapacity) {
            vendorOk = false;
          }
        } else {
          if (vendor.dailyCapacity[dayOfWeek]!=null && bookingsCnt>=vendor.dailyCapacity[dayOfWeek]) {
            vendorOk = false;
          }
        }
      } else if (vendor.vendorType != 'Device Maker') {
        if (availableServiceDatesMap[key]==null && !vendor.dailyAvailability[dayOfWeek]) {
          vendorOk = false;
        }
      }
      if (!vendorOk) {
        allOk = false;
      } else {
        cnt++;
      }
    });
    dayCntMap[dateKey] = cnt;
    if (allOk) {
      dateList.push(date.toDate())
    }
  }
  return dateList;
}

obj.canBookDay = function( requiredVendorTypes, vendorIds, dateOfService, ignoreCaseId ) {
      var promise = new Promise(function( resolve, reject){
        var dateLowBnd = moment(dateOfService).startOf('day').toDate();
        var dateHighBnd = moment(dateOfService).add( 1, 'days').toDate();
        obj.availableDaysSearch( requiredVendorTypes, vendorIds, ignoreCaseId, dateLowBnd, dateHighBnd)
        .then((dateList)=>{
          resolve(dateList.length==1 && moment(dateList[0]).isSame(dateOfService, 'day'));
        })
      })
      return promise;
    };

obj.bookProcedure = function( patientCase ) {
  var promise = new Promise(function( resolve, reject){
    var vendorIds =  patientCase.vendorFees?patientCase.vendorFees.map(pf=>pf.vendor._id):[];
    var dateOfService = moment(patientCase.calendarBooking.day).toDate();

    obj.canBookDay(patientCase.requiredVendorTypes, vendorIds, dateOfService, patientCase._id)
    .then((canBook)=>{
      if (!canBook) {
        resolve({errMsg: 'Insufficient Resources'})
      } else {
        resolve({patientCase:patientCase});
      }
    })
  })
  return promise;
};
obj.availableDaysSearch = function( requiredVendorTypes, vendorIds, ignoreCaseId, dateLow, dateHigh) {
      var promise = new Promise(function( resolve, reject){
          var nonDeviceMakerResources = requiredVendorTypes.filter((ot)=>(ot!='Device Maker'))
          var numReqdResources = nonDeviceMakerResources.length;
          if (vendorIds.length < numReqdResources) {
            resolve([]);
            return;
          }
          if ((typeof vendorIds[0])!='object') {
            vendorIds = vendorIds.map((id)=>mongoose.Types.ObjectId(id))
          }
          Vendor.find( { '_id': {$in: vendorIds}} )
          .then((vendors)=> {
            if (vendors.find((r)=>r.vendorFees.length==0)) {
              resolve([]);
            }
            var filter = { 'calendarBooking.day': { $gte: dateLow, $lt:dateHigh}, status: {$in:["Open", "Closed"]} };
            if (ignoreCaseId) {
              filter._id = { $ne: mongoose.Types.ObjectId(ignoreCaseId)}
            }
            PatientCase.find( filter )
            .then( (patientCases) => {
              var dateList = getAvailableDays( patientCases, vendors, dateLow, dateHigh);
              //patientCase, day, vendorBookings.vendor
              resolve(dateList);


            })
          })
      });
      return promise;
    }
  

export default obj;