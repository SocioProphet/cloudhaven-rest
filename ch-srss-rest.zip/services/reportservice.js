import mongoose from 'mongoose'
import {roundFloat} from "../routes/utils";
import PatientCase from '../models/patientcase'
import {getVendorByOrgType, safeRef} from "../js/utils"
import Payable from '../models/payable'
import Roles from '../models/workflowroles'
import moment from 'moment';

var reportCellStyle = 'border:2px solid #000000; padding:4px;';
var reportTableStyle = 'border-collapse:collapse; border:2px solid #000000;'

var obj = {}

/*  function getPatientIdMap( encryptedPatientIds ) {
        HashMap<String, String> keysMap = new HashMap<String, String>()
        HashMap<String, String> patientIdMap = new HashMap<String, String>()
        encryptedPatientIds.each {
            keysMap.put( AESEncryption.encrypt2( PatientRefUtil.decryptPatientReference( it ).toString() ), it )
        }
        var patientIds = PatientId.filterByEncryptedPatientIdInList( keysMap.keySet() )
        patientIds.each {
            var patientRefKey = keysMap.get(it.encryptedPatientId)
            patientIdMap.put(patientRefKey , it.patientId)
        }
        return patientIdMap
}*/

  //payerId: String

  obj.avgRevenuePerMonth = function() {
    var today = moment();
    var m = moment().startOf('month').subtract(1, 'day');
    var lowBound = m.subtract(11, 'months').startOf('month').toDate();
    var today = moment();
    var criteria = {
      status: {$in:['Open', 'Closed']},
      'paymentsDue.transactions.txnDate':{$gte:lowBound}, 
      'paymentsDue.transactions.txnType':'Payment'/*PaymentReceived*/}
    return PatientCase.find(criteria, {paymentsDue:1})
    .populate({path:'procedure', select:{name:1}})
    .then((patientCases)=>{
      var resultsMap = patientCases.reduce((mp,patientCase)=>{
        var procedure = patientCase.procedure.name;
        var procedureId = patientCase.procedure._id;
        var data = mp[procedureId] || (mp[procedureId]={procedureId:procedureId, procedure:procedure, 
          thisMonth:{count:0, totalAmount:0}, lastMonth:{count:0, totalAmount:0}, monthBeforeLast:{count:0, totalAmount:0}, last6Months:{count:0, totalAmount:0}, last12Months:{count:0, totalAmount:0}})
        patientCase.paymentsDue.forEach((paymentDue)=>{
          var list = paymentDue.transactions.filter(txn=>(txn.txnDate>=lowBound && txn.txnType=='Payment'));
          list.forEach(txn=>{
            var txnDateMonthsAgo = today.diff(txn.txnDate, 'months')
            if (txnDateMonthsAgo == 0) {
              data.thisMonth.count++;
              data.thisMonth.totalAmount += txn.amount;
            } else if (txnDateMonthsAgo == 1) {
              data.lastMonth.count++;
              data.lastMonth.totalAmount += txn.amount;
            } else if (txnDateMonthsAgo == 2) {
              data.monthBeforeLast.count++;
              data.monthBeforeLast.totalAmount += txn.amount;
            }
            if (txnDateMonthsAgo >=1 && txnDateMonthsAgo <=6) {
              data.last6Months.count++;
              data.last6Months.totalAmount += txn.amount;
            } 
            if (txnDateMonthsAgo <=12) {
              data.last12Months.count++;
              data.last12Months.totalAmount += txn.amount;
            }
    
          })
        })
        return mp;
      },[]);
      Object.keys(resultsMap).forEach(procedureId=>{
        var monthData = resultsMap[procedureId];
        monthData.thisMonth.averageRevenue = Math.round(monthData.thisMonth.totalAmount/monthData.thisMonth.count);
        monthData.lastMonth.averageRevenue = Math.round(monthData.lastMonth.totalAmount/monthData.lastMonth.count);
        monthData.monthBeforeLast.averageRevenue = Math.round(monthData.monthBeforeLast.totalAmount/monthData.monthBeforeLast.count);
        monthData.last6Months.averageRevenue = Math.round(monthData.last6Months.totalAmount/monthData.last6Months.count);
        monthData.last12Months.averageRevenue = Math.round(monthData.last12Months.totalAmount/monthData.last12Months.count);
      })
      return Object.keys(resultsMap).map(procedureId=>resultsMap[procedureId]);
    })
  }

  obj.vendorAPDaysOverdue = function( vendorId ) {
    var today = moment();
    var criteria = {status: {$in:['Open', 'Closed']} /*, 'payables.datePaid':{$ne:null}, 'payables.dueDate':{$ne:null} , 
  $expr:{$gt:['payables.datePaid', 'payables.dueDate']}*/}
    if (vendorId) {
      criteria['payables.vendor'] = mongoose.Types.ObjectId(vendorId);
    }
    return PatientCase.find(criteria, {payables:1, caseId:1, calendarBooking:1})
    .populate({path:'payables.vendor', select:{name:1}})
    .populate('patient')
    .then((patientCases)=>{
      var filtered = patientCases.reduce((ar,patientCase)=>{
        ar = ar.concat(patientCase.payables.filter((vd)=>{
          vd.patientCase = patientCase;
          return vd.datePaid && vd.dueDate && vd.datePaid>vd.dueDate;
        }
        ));
        return ar;
      },[]);
      var resultsMap = filtered.reduce((mp,vd)=>{
        var vendor = vd.vendor.name;
        var vendorId = vd.vendor._id.toString();

        var data = mp[vendorId] || (mp[vendorId]={vendor:{id:vendorId, name:vendor}, details:[], thisMonth:{count:0, totalDaysOverdue:0}, lastMonth:{count:0, totalDaysOverdue:0}, monthBeforeLast:{count:0, totalDaysOverdue:0}, last6Months:{count:0, totalDaysOverdue:0}, last12Months:{count:0, totalDaysOverdue:0}})
        data.details.push({amount:vd.amount, caseId:vd.patientCase.caseId, patient:vd.patientCase.patient.name, dateOfService:vd.patientCase.calendarBooking.day});
        var datePaidMonthsAgo = today.diff(vd.datePaid, 'months');
        if (datePaidMonthsAgo == 0) {
          data.thisMonth.count++;
          data.thisMonth.totalDaysOverdue += vd.daysOverdue;
        } else if (datePaidMonthsAgo == 1) {
          data.lastMonth.count++;
          data.lastMonth.totalDaysOverdue += vd.daysOverdue;
        } else if (datePaidMonthsAgo == 2) {
          data.monthBeforeLast.count++;
          data.monthBeforeLast.totalDaysOverdue += vd.daysOverdue;
        }
        if (datePaidMonthsAgo <=6) {
          data.last6Months.count++;
          data.last6Months.totalDaysOverdue += vd.daysOverdue;
        } 
        if (datePaidMonthsAgo <=12) {
          data.last12Months.count++;
          data.last12Months.totalDaysOverdue += vd.daysOverdue;
        }
        return mp;
      },{})
      Object.keys(resultsMap).forEach(vendorId=>{
        var monthData = resultsMap[vendorId];
        monthData.thisMonth.avgDaysOverdue = Math.round(monthData.thisMonth.totalDaysOverdue/monthData.thisMonth.count);
        monthData.lastMonth.avgDaysOverdue = Math.round(monthData.lastMonth.totalDaysOverdue/monthData.lastMonth.count);
        monthData.monthBeforeLast.avgDaysOverdue = Math.round(monthData.monthBeforeLast.totalDaysOverdue/monthData.monthBeforeLast.count);
        monthData.last6Months.avgDaysOverdue = Math.round(monthData.last6Months.totalDaysOverdue/monthData.last6Months.count);
        monthData.last12Months.avgDaysOverdue = Math.round(monthData.last12Months.totalDaysOverdue/monthData.last12Months.count);
      })
      return Object.keys(resultsMap).map(vendorId=>resultsMap[vendorId]);
    })
  }


  obj.vendorAgedAP = function() {
    var today = moment().startOf('day').add(50, 'days').toDate();
    return PatientCase.find({status: {$in:['Open', 'Closed']}, "payables":{$ne:[]}, 'payables.datePaid':{$eq:null}, 'payables.dueDate':{$lt:today}},
                      {'payables':1})
    .then((patientCases)=>{
      var totals = {'0-30':0,'30-60':0,'60-90':0,'90+':0};
      patientCases.forEach((patientCase)=>{
        patientCase.payables.filter(vd=>(!vd.datePaid && vd.dueDate<today)).forEach((vd)=>{
          totals[vd.apBucket]++;
        })
      })
      return totals;
    })
  }

  obj.getAgedAR = function( params ) {
    var today = moment().startOf('day').toDate();
    var criteria = {status: {$in:['Open', 'Closed']},
                    paymentsDue: {$elemMatch: {/*dueDate:{$lt:today},*/ payerType: { $regex: /Payer$/ }}},
                    paymentMethod:'Insurance'};
    if (params.payerId) {
      criteria['$or'] = [{'primaryPayer.claimsPayer':mongoose.Types.ObjectId(params.payerId)}, {'secondaryPayer.claimsPayer':mongoose.Types.ObjectId(params.payerId)}]
    }
    return PatientCase.find(criteria, {paymentsDue:1, caseId:1, patient:1, calendarBooking:1 })
    .populate('patient')
    .populate({path:'primaryPayer.claimsPayer'})
    .populate({path:'secondaryPayer.claimsPayer'})
    .limit(params.max)
    .sort('paymentsDue.arAge')
    .then((patientCases)=>{
      var arBucketTotalsMap = {totalBalanceDue:0};
      var paymentsDue = patientCases.reduce((ar,patientCase)=>{
        var list = patientCase.paymentsDue.filter(p=>(p.amount && !p.datePaidInFull /*&& moment(p.dueDate).isBefore(today)*/ && p.payerType.indexOf('Payer')>0));
        list.forEach(p=>{
          var payerField = p.payerType == 'Primary Payer'?'primaryPayer':'secondaryPayer';
          if (!params.payerId || patientCase[payerField].claimsPayer._id == params.payerId) {
            var pd = Object.assign({caseId:patientCase.caseId, patient:patientCase.patient.name, dateOfService:safeRef(patientCase.calendarBooking).day, 
              payer: {_id:patientCase[payerField].claimsPayer._id, name:patientCase[payerField].claimsPayer.name}}, p.toObject());
            arBucketTotalsMap.totalBalanceDue += p.currentAmountDue;
            if (p.arBucketNum!=null) {
              if (arBucketTotalsMap[p.arBucketNum]==null) {
                arBucketTotalsMap[p.arBucketNum] = {cnt:1, amt:p.currentAmountDue};
              } else {
                arBucketTotalsMap[p.arBucketNum].cnt++;
                arBucketTotalsMap[p.arBucketNum].amt += p.currentAmountDue;
              }
              }
            ar.push(pd);
          }
        })
        return ar;
      },[]);
      return {paymentsDue:paymentsDue, arBucketTotalsMap:arBucketTotalsMap, params:params}
    })
  }
  obj.getPatientAgedAR = function( params ) {
//    var today = moment().startOf('day').toDate();
    var criteria = {status: {$in:['Open', 'Closed']}, opReportUploaded: {$ne:null},
                    paymentsDue: {$elemMatch: {payerType: 'Patient'}}};
    if (params.patientId) {
      criteria['patient'] = mongoose.Types.ObjectId(params.patientId)
    }
    return PatientCase.find(criteria, {paymentsDue:1, caseId:1, status:1, opReportUploaded:1 })
    .populate({path:'patient'})
    .limit(params.max)
    .sort('paymentsDue.arAge')
    .then((patientCases)=>{
      var filteredCases = patientCases.filter((pc)=>(pc.opReportUploaded));
      var arBucketTotalsMap = {totalBalanceDue:0};
      var paymentsDue = filteredCases.reduce((ar,patientCase)=>{
        var list = patientCase.paymentsDue.filter(p=>(p.amount>0 && !p.datePaidInFull /*&& moment(p.dueDate).isBefore(today)*/ && p.payerType=='Patient'));
        list.forEach(p=>{
          var pd = Object.assign({caseId:patientCase.caseId, patient:{_id:patientCase.patient._id, name:patientCase.patient.name, dateStatementLastPrinted:patientCase.patient.dateStatementLastPrinted}}, p.toObject());
          arBucketTotalsMap.totalBalanceDue += p.currentAmountDue;
          if (p.arBucketNum!=null) {
            if (arBucketTotalsMap[p.arBucketNum]==null) {
              arBucketTotalsMap[p.arBucketNum] = {cnt:1, amt:p.currentAmountDue};
            } else {
              arBucketTotalsMap[p.arBucketNum].cnt++;
              arBucketTotalsMap[p.arBucketNum].amt += p.currentAmountDue;
            }
          }
          if (pd.receivableAction != 'Sent to Collections') {
            ar.push(pd);
          }
        })
        return ar;
      },[]);
      return {paymentsDue:paymentsDue, arBucketTotalsMap:arBucketTotalsMap, params:params}
    })
  }
  function getVendorTreatmentsCompletedForMonth ( thisYearCases, lastYearCases, year ) {
        if (!thisYearCases || thisYearCases.length==0) return ''
//        var encryptedPatientIds = thisYearCases.collect { it.patientRef.encryptedPatientId }
//        var patientIdMap = this.getPatientIdMap( encryptedPatientIds )
//        var locale = Locale.ENGLISH

        var s = `\
        <h3>Cases Completed</h3>\
        <p/><br/>\
        <table id='TreatmentsCompletedForMonthTable' style='${reportTableStyle}'><thead><tr>\
        <th>Patient Id</th>\
        <th>Case #</th>\
        <th>Procedure</th>\
        <th>Date of Service</th>\
        <th>Amount Due</th>\
        </tr></thead><tbody>`;
        thisYearCases.forEach((patientCase)=> {
            s += `\
            <tr><td>${patientCase.patient.patientId}</td><td>${patientCase.caseId}</td>\
                <td>${patientCase.procedure.name}</td><td>${moment(patientCase.calendarBooking.day).format('l')}</td>\
                <td style="text-align:right;">${patientCase.payableAmountOwed.toFixed(2)}</td></tr>`
        });
        s += `\
        </tbody>\
        <tfoot>\
          <tr><th>${year+''} Total</th>\
              <th>${thisYearCases.length}</th><th colspan=2>&nbsp;</th>\
              <th>${thisYearCases.reduce(function(total, patientCase) {total += patientCase.payableAmountOwed; return total;},0)}</th></tr>`
        var lastYearPayablesAmountOwed = lastYearCases ? lastYearCases.reduce(function(total, patientCase) {total += patientCase.payableAmountOwed; return total;},0) : 0.0
        s += `<tr><th>${(year-1)+''} Total</th>\
                  <th>${lastYearCases?lastYearCases.length:0}</th>
                  <th colspan=2>&nbsp;</th>
                  <th class="currencyTD">${lastYearPayablesAmountOwed}</th></tr>\
        </tfoot></table>`
        s = s.replace(/<td\b/g, `<td style='${reportCellStyle}' ` )
        s = s.replace(/<th\b/g, `<td style='${reportCellStyle}' ` )
        return s
    }

    function getTreatmentsCompletedForMonth( year, month) {
      var m = moment({year:year, month:month, day:1});
      var thisYearLoBnd = m.toDate();
      var thisYearHiBnd = m.add(1, 'months').toDate();
      var m = moment({year:year-1, month:month, day:1});
      var lastYearLoBnd = m.toDate();
      var lastYearHiBnd = m.add(1, 'months').toDate();
      var criteria = {opReportUploaded:true, status: 'Closed', $or:[
          {dateClosed:{$gte:thisYearLoBnd, $lt:thisYearHiBnd}},
          {dateClosed:{$gte:lastYearLoBnd, $lt:lastYearHiBnd}}
      ]}
      return PatientCase.find(criteria)
      .populate('vendorFees.vendor')
      .populate({path:'patient', select:{patientId:1}})
      .populate({path:'procedure', select:{name:1}})
      .then((results)=>{
        var vendorMap = {};
        var vendorCaseMap = results.reduce((mp,patientCase)=>{
          patientCase.vendorFees.forEach((vb)=>{
            var vendorId = vb.vendor._id.toString();
            var vendor = vb.vendor.name;
            var cases = mp[vendorId] || (mp[vendorId]={vendor:{id:vendorId, name:vendor}, thisYear:[], lastYear:[]});
            if (patientCase.yearClosed == year) {
              cases.thisYear.push(patientCase);
            } else if (patientCase.yearClosed == (year-1)) {
              cases.lastYear.push(patientCase);
            }
          })
          return mp;
        },{})
        var retList = Object.keys(vendorCaseMap).map(vendorId=>{
          var cases = vendorCaseMap[vendorId];
          var thisYearTotals = cases.thisYear.reduce((totals, patientCase)=>{
            totals.count++;
            totals.amountOwed += patientCase.payableAmountOwed;
            return totals;
          },{period:moment(thisYearLoBnd).format('MMM-YYYY'), count:0, amountOwed:0});
          var lastYearTotals = cases.lastYear.reduce((totals, patientCase)=>{
            totals.count++;
            totals.amountOwed += patientCase.payableAmountOwed;
            return totals;
          },{period:moment(lastYearLoBnd).format('MMM-YYYY'), count:0, amountOwed:0});
          return {vendor:vendorCaseMap[vendorId].vendor, thisYearCases:cases.thisYear, thisYearTotals:thisYearTotals, lastYearTotals:lastYearTotals, year:year};
//          var s = getVendorTreatmentsCompletedForMonth(  );
//          mp[vendorId] =  {content:s, name:vendorMap[vendorId]};
          return mp;
        });
        return retList.sort((a,b)=>(a.vendor.name<b.vendor.name?-1:(a.vendor.name>b.vendor.name?1:0)))
      });
    }

    function getVendorPaymentsForMonth( thisYearPayments, lastYearPayments, year, forPaid ) {
        if (!thisYearPayments || thisYearPayments.length==0) return '';
//        var encryptedPatientIds = thisYearPayments.collect { it.patientCase.patientRef.encryptedPatientId }
//        var patientIdMap = this.getPatientIdMap( encryptedPatientIds )
//        var locale = Locale.ENGLISH
        var s = `\
          <h3>${forPaid?'Payments Sent':'Payments Due'}</h3>\
          <p/><br/>\
          <table id='VendorPaymentsForMonthTable' style='${reportTableStyle}'>\
          <thead>\
            <tr>\
            <th>Patient Id</th>\
            <th>Case #</th>\
            <th>Amount</th>\
            <th>Procedure</th>\
            <th>Date of Service</th>\
            <th>Date ${forPaid?'Paid':'Due'}</th>\
            <th>Surgery Center</th>\
            </tr>\
            </thead>\
            <tbody>`
        thisYearPayments.forEach((p)=>{
            s += `\
            <tr><td>${p.patientCase.patient.patientId}</td>\
                <td>${p.patientCase.caseId}</td>\
                <td style='text-align:right;'>${p.amount.toFixed(2)}</td>\
                <td>${p.patientCase.procedure.name}</td>\
                <td>${moment(p.patientCase.calendarBooking.day).format('l')}</td>\
                <td>${moment(forPaid?p.datePaid:p.dueDate).format('l')}</td>\
                <td>${getVendorByOrgType(p.patientCase, 'Surgery Center').name}</td></tr>`
        })
        s += `\
        </tbody><tfoot>\
          <tr><th>${year} Total</th> \
              <th>${thisYearPayments.length}</th> \
              <th>${thisYearPayments.reduce((t,p)=> t + p.amount,0).toFixed(2)}</th> \
              <th colspan='4'></th> \
          </tr>`
        if (forPaid) {
            s += `
              <tr><th colspan='2'>${year} Average Days to Pay</th>\
                <th>${(thisYearPayments.reduce((t,p) => t + p.daysToPay,0) / thisYearPayments.length ).toFixed(1)}</th>\
                <th colspan='4'></th> \
              </tr>`;
        }
        var lastYearAmountTotal = lastYearPayments ? lastYearPayments.reduce((t, p) => t + p.amount, 0):0;
        s += `<tr>\
                <th>${year-1} Total</th> \
                <th>${lastYearPayments.size()}</th> \
                <th>${format.format(lastYearAmountTotal )}</th> \
                <th colspan='4'></th> \
                </tr>`
        s += '</tfoot></table>'
        s = s.replace(/<td\b/, `<td style='${reportCellStyle}' ` )
        s = s.replace(/<th\b/, `<td style='${reportCellStyle}' ` )
        return s
    }

    function getAllVendorsPaymentsForMonth( year,  month, forPaid) {
      var m = moment({year:year, month:month, day:1});
      var thisYearLoBnd = m.toDate();
      var thisYearHiBnd = m.add(1, 'months').toDate();
      var m = moment({year:year-1, month:month, day:1});
      var lastYearLoBnd = m.toDate();
      var lastYearHiBnd = m.add(1, 'months').toDate();
      var criteria = {status: {$in:['Open', 'Closed']}};
      if (forPaid) {
        criteria['$or'] = [
          {'payables.datePaid':{$gte:thisYearLoBnd, $lt:thisYearHiBnd}},
          {'payables.datePaid':{$gte:lastYearLoBnd, $lt:lastYearHiBnd}}
        ];
      } else {
        criteria['$or'] = [
            {'payables.dueDate':{$gte:thisYearLoBnd, $lt:thisYearHiBnd}},
            {'payables.dueDate':{$gte:lastYearLoBnd, $lt:lastYearHiBnd}}
          ];
        criteria['payables.datePaid'] = {$eq:null};
      }
      return PatientCase.find(criteria, {caseId:1, 'calendarBooking.day':1, 'payables':1})
      .populate({path:'payables.vendor', select:{name:1}})
      .populate({path:'patient', select:{patientId:1}})
      .populate({path:'vendorFees.vendor', select:{name:1}})
      .populate({path:'procedure', select:{name:1}})
      .then((patientCases)=>{
        var thisYearPayments = patientCases.reduce((ar, patientCase)=>{
          var list = patientCase.payables.filter(p=>(p[forPaid?'yearPaid':'yearDue'] == year && (forPaid || !p.datePaid)));
          list = list.map((p)=>{
            var payment = JSON.parse(JSON.stringify(p));
            payment.patientCase = patientCase;
            return payment;
          });
          ar = ar.concat(list)
          return ar;
        },[]);
        var lastYearPayments = patientCases.reduce((ar, patientCase)=>{
          var list = patientCase.payables.filter(p=>(p[forPaid?'yearPaid':'yearDue'] == (year-1) && (forPaid || !p.datePaid)))
          list = list.map((p)=>{
            var payment = JSON.parse(JSON.stringify(p));
            payment.patientCase = patientCase;
            return payment;
          });
          ar = ar.concat(list)
          return ar;
        },[]);
        var vendorPayableMap = thisYearPayments.reduce((mp,p)=>{
          var vendorId = p.vendor._id.toString();
          var vendor = p.vendor.name;
          var vendors = mp[vendorId] || (mp[vendorId]={vendor:{id:vendorId, name:p.vendor.name}, payments:[]});
          vendors.payments.push(p);
          return mp;
        },{})
        lastYearPayments.forEach((p)=>{
          var vendorId = p.vendor._id.toString();
          if (!vendorPayableMap[vendorId]) vendorPayableMap[vendorId]={vendor:{id:vendorId, name:p.vendor.name}, payments:[]};
        })
        var retList = Object.keys(vendorPayableMap).map((vendorId) => {
          var payableList = vendorPayableMap[vendorId].payments;
          var thisYearPayments = payableList.filter(p=>(p[forPaid?'yearPaid':'yearDue'] == year && (forPaid || !p.datePaid)));
          var lastYearPayments = payableList.filter(p=>(p[forPaid?'yearPaid':'yearDue'] == (year-1) && (forPaid || !p.datePaid)));
          var totals = [];
          var thisYearTotals = {year:year, count: thisYearPayments.length, totalAmount: thisYearPayments.reduce((t,p)=> t + p.amount,0)};
          if (forPaid) {
            thisYearTotals.avgDaysToPay = thisYearPayments==0?0:roundFloat(thisYearPayments.reduce((t,p) => t + p.daysToPay,0) / thisYearPayments.length,1);
          }
          var lastYearTotals = {year:(year-1), count:lastYearPayments.length, totalAmount: lastYearPayments.reduce((t, p) => t + p.amount, 0)};
          if (forPaid) {
            lastYearTotals.avgDaysToPay = lastYearPayments.length==0?0:roundFloat(lastYearPayments.reduce((t,p) => t + p.daysToPay,0) / lastYearPayments.length, 1);
          }

          return {vendor: vendorPayableMap[vendorId].vendor, thisYearPayments:thisYearPayments, thisYearTotals:thisYearTotals, lastYearTotals:lastYearTotals, year:year, forPaid:forPaid}
//          var s = getVendorPaymentsForMonth( paymentsFilter(payableList, year), paymentsFilter(payableList, year-1), year, forPaid )
//          retMap[vendorId] = {vendor:vendorPayableMap[vendorId].vendor, content:s};
        })
        return retList.sort((a,b)=>(a.vendor.name<b.vendor.name?-1:(a.vendor.name>b.vendor.name?1:0)))
      })
    }

    //cl = (vendor, reportContent)=>(`<h2>${vendor}</h2>${reportContent}<br/><br/>`)
    obj.doMonthlyVendorReport = function( params, cl ) {
      var now = moment(); //.startOf('month').subtract(1, 'days')
      var month = params.month?params.month:now.month();
      var year = params.year?params.year:now.year();
      return mongoose.Promise.all([
        getTreatmentsCompletedForMonth( year, month ),
        getAllVendorsPaymentsForMonth( year, month, true ),
        getAllVendorsPaymentsForMonth( year, month, false )])
      .then((results)=>{
        var completedTreatments = results[0];
        var paymentsMade = results[1];
        var paymentsDue = results[2];
        if (!cl) {
          return {completedTreatments:completedTreatments, paymentsMade:paymentsMade, paymentsDue:paymentsDue};
        }
        var vendorIds = Object.keys(completedMap).concat(Object.keys(paymentsMap)).concat(Object.keys(dueMap)).sort((a,b)=>(a<b?-1:(a>b?1:0)))
        return vendorIds.reduce((s,vendorId)=>{
          var vendor = (completedMap[vendorId]||{}).name || (paymentsMap[vendorId]||{}).name || (dueMap[vendorId]||{}).name;
          var reportContent = ((completedMap[vendorId]||{}).content||'') + '<br/><br/>' + ((paymentsMap[vendorId]||{}).content||'') + '<br/><br/>' + ((dueMap[vendorId]||{}).content||'')
          try {
            s += cl( vendor, reportContent );
          } catch (e) {
          }
          return s;
        }, '')
      })
    }

  obj.getTotalCasesMTD = function( params ) {
    var m = moment({year:params.year, month:params.month, day:1})
    var monthLoBnd = moment(m).subtract(1, 'months').toDate();
    var monthHiBnd = m.add(1, 'months').toDate();
    var criteria = {status: {$in:['Open', 'Closed']}, opReportUploaded: true, 'calendarBooking.day':{$gte:monthLoBnd, $lt:monthHiBnd}};
    if (params.surgeonId) {
      criteria['vendorFees.vendor'] = mongoose.Types.ObjectId(params.surgeonId)
    }
    return PatientCase.find(criteria, {procedure:1, calendarBooking:1})
    .populate({path:'procedure', select:{name:1}})
    .then((patientCases)=>{
        if (!patientCases) return [];
        var groupingMap = patientCases.reduce((mp,patientCase)=>{
          var procedureId = patientCase.procedure._id.toString();
          var procedure = patientCase.procedure.name;
          var counts = mp[procedureId] || (mp[procedureId]={procedure:{id:procedureId, name:procedure}, previousMonth:0, currentMonth:0})
          if (!params.month || moment(patientCase.calendarBooking.day).month()==params.month) {
            counts.currentMonth++;
          } else {
            counts.previousMonth++;
          }
          return mp;
        },{});
        var rows = Object.keys(groupingMap).map((procedureId)=>{
          var counts = groupingMap[procedureId];
          return {procedure:counts.procedure, currentMonth:counts.currentMonth, previousMonth:counts.previousMonth, 
            percentChange: counts.previousMonth?parseFloat((((counts.currentMonth-counts.previousMonth)*100)/counts.previousMonth).toFixed(1)): 999}
        }).sort((a,b)=>(a.procedure.name<b.procedure.name?-1:(a.procedure.name>b.procedure.name?1:0)))
        return rows;
      })
    }

    obj.getTotalCasesYTD = function( params ) {
      var m = moment({year:params.year, month:0, day:1})
      var yearLoBnd = moment(m).subtract(1, 'years').toDate();
      var yearHiBnd = m.add(1, 'years').toDate();
      var criteria = {status: {$in:['Open', 'Closed']}, opReportUploaded: true, 'calendarBooking.day':{$gte:yearLoBnd, $lt:yearHiBnd}};
      if (params.surgeonId) {
        criteria['vendorFees.vendor'] = mongoose.Types.ObjectId(params.surgeonId)
      }
      return PatientCase.find(criteria, {procedure:1, calendarBooking:1})
      .populate({path:'procedure', select:{name:1}})
      .then((patientCases)=>{
          if (!patientCases) return [];
          var groupingMap = patientCases.reduce((mp,patientCase)=>{
            var procedureId = patientCase.procedure._id.toString();
            var procedure = patientCase.procedure.name;
              var counts = mp[procedureId] || (mp[procedureId]={procedure:{id:procedureId, name:procedure}, previousYear:0, currentYear:0})
            if (!params.year || moment(patientCase.calendarBooking.day).year()==params.year) {
              counts.currentYear++;
            } else {
              counts.previousYear++;
            }
            return mp;
          },{});
          var rows = Object.keys(groupingMap).map((procedureId)=>{
            var counts = groupingMap[procedureId];
            return {procedure:counts.procedure, currentYear:counts.currentYear, previousYear:counts.previousYear, 
              percentChange: counts.previousYear?parseFloat((((counts.currentYear-counts.previousYear)*100)/counts.previousYear).toFixed(1)): 999}
          }).sort((a,b)=>(a.procedure.name<b.procedure.name?-1:(a.procedure.name>b.procedure.name?1:0)))
          return rows;
        })
      }
  
    obj.getTentativeCases =function( surgeonId ) {
      var criteria = {status: {$in:['Open', 'Closed']}, patientTermsAcceptanceDate: {$ne:null}, 'calendarBooking.status':'Tentative'}
      if (surgeonId) criteria['vendorFees.vendor'] = mongoose.Types.ObjectId(surgeonId);
      var today = moment({h:0, m:0, s:0, ms:0})
      var highBound = moment(today).add(61, 'days').startOf('day').toDate();
      var lowBound = today.startOf('day').toDate();
      criteria['calendarBooking.day'] = {$gte:lowBound, $lt:highBound}
      var today = moment().startOf('day')
      return PatientCase.find(criteria, {procedure:1, calendarBooking:1})
      .populate({path:'primaryPayer.claimsPayer', select:{contractedRate:1}})
      .populate({path:'procedure', select:{name:1}})
      .then((patientCases)=>{
        var dataMap = patientCases.reduce((mp,patientCase)=>{
          var procedureId = patientCase.procedure._id.toString();
          var procedure = patientCase.procedure.name;
          var stats = mp[procedureId] || (mp[procedureId]={procedure:{id:procedureId, name:procedure}, 
              '7':{count:0, sum:0}, '30':{count:0, sum:0}, '60':{count:0, sum:0}})
          var daysOut = moment(patientCase.calendarBooking.day).diff(today, 'days');
          if (daysOut<=7) {
            stats['7'].count++;
            stats['7'].sum += patientCase.procedure.contractedRate;
          }
          if (daysOut<=30) {
            stats['30'].count++;
            stats['30'].sum += patientCase.procedure.contractedRate;
          }
          if (daysOut<=60) {
            stats['60'].count++;
            stats['60'].sum += patientCase.procedure.contractedRate;
          }
          return mp;
        },{})
        return Object.keys(dataMap).map(id=>(dataMap[id])).sort((a,b)=>(a.procedure.name<b.procedure.name?-1:(a.procedure.name>b.procedure.name?1:0)))
      })
    }
    obj.receivedPayments = function( date ) {
      var lowerBoundTS = moment(date).toDate()
      var upperBoundTS = moment(date).add(1, 'days').toDate();
      return PatientCase.find({'paymentsDue.transactions.txnType':'Payment', 'paymentsDue.transactions.txnDate':{'$gte':lowerBoundTS, '$lt':upperBoundTS}})
      .populate({path:'patient', select:{firstName:1, lastName:1, name:1}})
      .populate({path:'primaryPayer.claimsPayer', select:{name:1}})
      .populate({path:'secondaryPayer.claimsPayer', select:{name:1}})
      .populate({path:'procedure', select:{name:1}})
      .then(patientCases=>{
        return patientCases.reduce((ar,patientCase)=>{
          patientCase.paymentsDue.forEach(pd=>{
            var name = '';
            if (pd.payerType == 'Primary Payer') {
              name = patientCase.primaryPayer.claimsPayer.name;
            } else if (pd.payerType == 'Secondary Payer' && patientCase.secondaryPayer.claimsPayer) {
              name = patientCase.secondaryPayer.claimsPayer.name;
            }
            pd.transactions.forEach(txn=>{
              if (txn.txnType=='Payment' && txn.txnDate>=lowerBoundTS && txn.txnDate<upperBoundTS) {
                ar.push({
                  amount: txn.amount,
                  patient: patientCase.patient.name,
                  payerType: pd.payerType,
                  payer: name,
                  procedure: patientCase.procedure.name,
                  txnDate: txn.txnDate
                })
              }
            })
          })
          return ar;
        },[]);
      })
    }

    obj.overPayments = function( startDate, endDate ) {
      var lowerBoundTS = moment(startDate).toDate()
      var upperBoundTS = moment(endDate).add(1, 'days').toDate();
      return PatientCase.find({'paymentsDue.transactions.txnType':'Payment', 'paymentsDue.transactions.txnDate':{'$gte':lowerBoundTS, '$lt':upperBoundTS}})
      .populate({path:'patient', select:{firstName:1, lastName:1, name:1}})
      .populate({path:'primaryPayer.claimsPayer', select:{name:1}})
      .populate({path:'secondaryPayer.claimsPayer', select:{name:1}})
      .populate({path:'procedure', select:{name:1}})
      .then(patientCases=>{
        return patientCases.reduce((ar,patientCase)=>{
          patientCase.paymentsDue.forEach(pd=>{
            var adjustmentTotal = pd.transactions.reduce(function(total, payment) {
              if (payment.txnType == 'Adjustment') total += payment.amount;
              return total;
            }, 0.0);
            var paymentDue = pd.amount - adjustmentTotal;
            var latestPayment = null;
            var paymentTotal = pd.transactions.reduce(function(total, payment) {
                if (payment.txnType == 'Payment') {
                  total += payment.amount;
                  if (!latestPayment || payment.txnDate>latestPayment.txnDate) {
                    latestPayment = payment;
                  }
                }
                return total;
            }, 0.0);
            var overpayment = Number((paymentTotal - paymentDue).toFixed(6));
            if (overpayment>0 && latestPayment && latestPayment.txnDate>=lowerBoundTS && latestPayment.txnDate<upperBoundTS) {
              var name = '';
              if (pd.payerType == 'Primary Payer') {
                name = patientCase.primaryPayer.claimsPayer.name;
              } else if (pd.payerType == 'Secondary Payer' && patientCase.secondaryPayer.claimsPayer) {
                name = patientCase.secondaryPayer.claimsPayer.name;
              }
              ar.push({
                amount: pd.amount,
                overpayment: overpayment,
                patient: patientCase.patient.name,
                payerType: pd.payerType,
                payer: name,
                procedure: patientCase.procedure.name,
                txnDate: latestPayment.txnDate
              });
            }              
          })
          return ar;
        },[]);
      })
    }

    function getBrmRevenue( bmcId ) {
/*OK        var cal = GRMSystemDate.calendar
        cal.clearTime()
        var dateHighBound = cal.time + 1
        var curMonth = cal.get(GregorianCalendar.MONTH)+1
        var year = cal.get(GregorianCalendar.YEAR)
        var lowBoundMonth = (curMonth==12)?1:(curMonth+1)
        var lowCal = new GregorianCalendar(year-1, lowBoundMonth-1, 1)
        var lowBoundDate = lowCal.time
        var arCriteria = PaymentDueTxn.createCriteria()
        var arResults = arCriteria {
            eq ( 'txnType', PaymentDueTxn.PaymentReceived)
            isNotNull( 'txnDate' )
            if (bmcId && bmcId!='null') {
                bmc {
                    idEq(Long.parseLong(bmcId))
                }
            }
            projections {
                groupProperty( 'gra')
                groupProperty( 'bmc')
                groupProperty( 'month' )
                sum( 'amount' )
            }
            between( 'txnDate', lowCal.time, dateHighBound )
        }
        var apCriteria = Payable.createCriteria()
        var apResults = apCriteria {
            isNotNull ( 'datePaid' )
            if (bmcId && bmcId!='null') {
                bmc {
                    idEq(Long.parseLong(bmcId))
                }
            }
            projections {
                groupProperty( 'gra')
                groupProperty( 'bmc')
                groupProperty( 'monthPaid' )
                groupProperty( 'paymentType' )
                sum( 'amount' )
            }
            between( 'datePaid', lowCal.time, dateHighBound )
        }
        Map graBmcMap = new HashMap()
        arResults.each {
            var gra = it[0]
            var bmc = it[1]
            var month = it[2]
            var monthIdx = (month-curMonth) - (month>curMonth?12:0) //L5-$L5 - IF(L5>$L5,12,0)
            var bucketIdx = monthIdx==0?0:(monthIdx==-1 ? 1 : 2)
            var key = gra.id+':'+bmc.id
            var bucketGroups = graBmcMap.get(key)
            if (!bucketGroups) {
                bucketGroups = [gra:gra, bmc:bmc, amts:[]]
                [0,1,2].each { bucketGroups.amts.add([REV:0.0, GRA:0.0, BRM:0.0, VND:0.0]) }
                graBmcMap.put(key, bucketGroups)
            }
            if (bucketIdx in [0,1]) {
                bucketGroups.amts[bucketIdx]['REV'] += it[3]
            }
            bucketGroups.amts[2]['REV'] += it[3]
        }
        apResults.each {
            var gra = it[0]
            var bmc = it[1]
            var month = it[2]
            var monthIdx = (month-curMonth) - (month>curMonth?12:0) //L5-$L5 - IF(L5>$L5,12,0)
            var bucketIdx = monthIdx==0?0:(monthIdx==-1 ? 1 : 2)
            var key = gra.id+':'+bmc.id
            var bucketGroups = graBmcMap.get(key)
            if (!bucketGroups) {
                bucketGroups = [gra:gra, bmc:bmc, amts:[]]
                [0,1,2].each { bucketGroups.amts.add([REV:0.0, GRA:0.0, BRM:0.0, VND:0.0]) }
                graBmcMap.put(key, bucketGroups)
            }
            if (bucketIdx in [0,1]) {
                bucketGroups.amts[bucketIdx][it[3]] += it[4]
            }
            bucketGroups.amts[2][it[3]] += it[4]
        }
        var retList = graBmcMap.collect { it.value }.sort { a,b -> (a['gra'].name+':'+a['bmc'].name) <=> (b['gra'].name+':'+b['bmc'].name)}
        var retData = [['GRA', 'BMC','This Mo Rev', 'This Mo BRM Rev', 'This Mo BMC Rev', 'This Mo Vendor Expense', 'Last Mo Rev', 'Last Mo BRM Rev', 'Last Mo BMC Rev', 'Last Mo Vendor Expense', 'Last 6 Mo Rev', 'Last 6 Mo BRM Rev', 'Last 6 Mo BMC Rev', 'Last 6 Mo Vendor Expense']]
        retList.each {
            var row = [it['gra'], it['bmc']]
            it['amts'].each {
                row.add(it['REV'])
                row.add(it['BRM'])
                row.add(it['GRA'])
                row.add(it['VND'])
            }
            retData.add(row)
        }
        return retData
    }*/



}

export default obj;