/* Not currently used

const sgMail = require('@sendgrid/mail');
var obj = {};
obj.sendNotification = function( email, subject, content) {
  sgMail.setApiKey(process.env.SENDGRID_API_KEY);
  const msg = {
    to: email,
    from: emailSender,
    subject: subject,
    html: content,
    customArgs: {
      vendorid: "v1234",
      caseId:"c1235"
    },
    trackingSettings: {
      clickTracking: {
        enable:true
      }
    }
  };
  sgMail.send(msg);
}
export default obj;*/