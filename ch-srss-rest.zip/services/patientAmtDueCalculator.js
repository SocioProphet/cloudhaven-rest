var obj = {
};
function round(n) {
  return Number((n||0).toFixed(6));
}
function calcSection( patientCase, payerSelector, cost ) {
  var payerSection = patientCase[payerSelector];
  if (!payerSection || !payerSection.claimsPayer || !payerSection.claimsPayer._id) {
    payerSection.totalDueFromPatient = '';
    return 0;
  }
  if (payerSelector=='secondaryPayer' && payerSection.expectedAmountOverride) {
    patientCase.secondaryPayer.totalDueFromPatient = round(patientCase.primaryPayer.totalDueFromPatient||0) - (payerSection.expectedAmountOverride||0);
    return patientCase.secondaryPayer.totalDueFromPatient;
  }
  var oopIncludeDeductible = payerSection.oopAmountIncludesDeductible;
  var deductible = parseFloat(payerSection.deductible || 0);
  var deductibleMet = parseFloat(payerSection.deductibleMet || 0);
  var deductibleRemaining = round(deductible - deductibleMet);
  if (deductibleRemaining<0) deductibleRemaining = 0;

  var patientFactor = round((100.0 - parseFloat(payerSection.benefitPercent || 0) )/100.0);

  var outOfPocket = parseFloat(payerSection.outOfPocket || 0);
  var outOfPocketMet = parseFloat(payerSection.outOfPocketMet || 0);
  var outOfPocketRemaining = round(outOfPocket - outOfPocketMet);
  if (outOfPocketRemaining<0) outOfPocketRemaining = 0;

  var patientCopay = parseFloat(payerSection.copayAmount || 0);

  var coInsurance = 0;
  var patientAmtDue = 0;
  if (oopIncludeDeductible) {
    coInsurance = round(patientFactor * (cost - deductibleRemaining));
    patientAmtDue = round(coInsurance + deductibleRemaining);
    if (patientAmtDue>cost) patientAmtDue = cost;
    if (outOfPocket) {
      patientAmtDue = patientAmtDue > outOfPocketRemaining ? outOfPocketRemaining : patientAmtDue;
    }
    patientAmtDue += patientCopay;
    payerSection.totalDueFromPatient = round(patientAmtDue);
  } else {
    coInsurance = round(cost * patientFactor);
    if (outOfPocket) {
      patientAmtDue = coInsurance > outOfPocketRemaining ? outOfPocketRemaining : coInsurance;
    }
    patientAmtDue = round(patientAmtDue + deductibleRemaining + patientCopay);
    payerSection.totalDueFromPatient = patientAmtDue;
  }
  return payerSection.totalDueFromPatient;
}

obj.calculate = function( patientCase ) {
  if (!patientCase.relationshipToPatient) return 0;
  var contractedRate = parseFloat(patientCase.primaryPayer.contractedRate || 0);
  var totalDueFromPatient = calcSection( patientCase, 'primaryPayer', contractedRate );
  if (patientCase.secondaryPayer && patientCase.secondaryPayer.claimsPayer && patientCase.secondaryPayer.claimsPayer._id) {
    totalDueFromPatient = calcSection( patientCase, 'secondaryPayer', totalDueFromPatient );
  }
  return round(totalDueFromPatient);
}
  export default obj;