import PdfApi from '@/services/PdfApi'

export default function showCostEstimatePdf(window, patientCaseId) {
  PdfApi().get('/patientacceptance/getcostestimate/'+patientCaseId.toString() )
  .then(response=>{
    const file = new Blob( [response.data], {type: 'application/pdf'});
    const fileURL = URL.createObjectURL(file);
    var win = window.open(fileURL, 'Cost Estimate', "height=960,width=840,toolbar=no,menubar=no,scrollbars=yes,location=no,status=no");
    try {
      win.focus();
    } catch(e){
      console.log(e);
    }
  })
  .catch(error => {
        console.log(error);
  });
}
