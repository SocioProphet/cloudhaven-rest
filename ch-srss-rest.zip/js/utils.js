import moment from 'moment';

export function safeRef(o) {
  try {
    return o?o:{};
  } catch (e) {
    return {};
  }
}

export function randomId( n ) {
    var shuffleConfig = [18,14,11,1,21,10,12,7,16,4,13,0,17,5,6,2,15,3,9,8];
    var sN = n.toString(2);
    while (sN.length<19) {
      sN = '0'+sN;
    }
    var sN2 = [];
    for (var idx in shuffleConfig) {
      sN2[shuffleConfig[idx]] = sN[idx];
    }
    var sN2 = parseInt(sN2.join(''), 2).toString()
    while (sN2.length<6) {
        sN2 = '0'+sN2;
      }
      return sN2
}

export function getVendorByOrgType(patientCase, orgType) {
  if (!patientCase.vendorFees) return {};
  var vendorFee = patientCase.vendorFees.find(function(pf){
      return pf.vendor?pf.vendor.vendorType==orgType:false;
    })
    return vendorFee?vendorFee.vendor:{};
};

export function getFeeAmount(vendorFee, contractedRate) {
  return vendorFee.feeType=='Fixed' ? vendorFee.fixedFee : ((contractedRate * vendorFee.percentage)/100.0);
};

export function getPrevBizDay( date ) {
  var m = moment(date).startOf('day').subtract(1, 'day');
  var dayOfWeek = m.day();
  if (dayOfWeek == 0) {
    return m.subtract( 2, 'days').toDate();
  } else if (dayOfWeek == 6) {
    return m.subtract( 1, 'days').toDate();
  }
  return m.toDate();
}
