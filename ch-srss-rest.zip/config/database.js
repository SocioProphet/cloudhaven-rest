module.exports = {
    'secret':'nodeauthsecret',
    'database': 'mongodb://localhost/srssdb'
};